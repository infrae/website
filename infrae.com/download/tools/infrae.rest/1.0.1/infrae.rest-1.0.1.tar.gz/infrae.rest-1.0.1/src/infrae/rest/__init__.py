# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 42334 2010-05-25 09:26:53Z sylvain $

from infrae.rest.components import REST

