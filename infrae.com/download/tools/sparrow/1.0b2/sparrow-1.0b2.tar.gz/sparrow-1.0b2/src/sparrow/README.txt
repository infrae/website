
Sparrow
=======

Introduction
------------

Sparrow is a library that provides a high-level API for
RDF Databases. Any database the provides support for SPARQL Queries and
has a triplestore that can handle contexts can be used as a backend.

The goal of Sparrow is to make sure all these different backends act the same,
making it possible to change RDF Database backends without having to change
your code.

At the moment there is support for the following backends:

 * `Redland / librdf`_
 * `RDFLib`_
 * `Sesame / openrdf`_
 * `Allegro Graph`_

.. _Redland / librdf: http://librdf.org
.. _RDFLib: http://www.rdflib.net
.. _Sesame / openrdf: http://www.openrdf.org
.. _Allegro Graph: http://www.franz.com/agraph/

The API provides support for the following basic functions:

 * Parsing RDF statements from different formats into a contextual database
 * Serializing the RDF statements from a specific context of a database
 * Removing statements from a specific context of a database
 * Performing SPARQL Queries

Installation
------------

Sparrow comes with buildout profiles for several databases. 
These profiles will install and setup the different backends for you.
You don't have to use buildout, but I would recommend it.

To install type:

::

  > python2.5 bootstrap.py
  > ./bin/buildout

This will create some scripts in the bin folder like a testrunner and
(depending on which profile you choose) scripts for configuring and starting
the different backends.

Usage
-----

Normally, you will only need to import the base sparrow module

>>> import sparrow

Most of the database backends will not work out of the box. 
Since the RDFLib backend is written in python and packaged on pypi,
it is always available, and installed with Sparrow.

Let's create an in memory rdflib database

>>> sparrow.database('rdflib', 'memory')
<sparrow.rdflib_backend.RDFLibConnector ...>

This is actually not the database, but a database connector.
It manages the different connections to a database.
Let's get a connection to the database

>>> db = sparrow.database('rdflib', 'memory').connect()
>>> db
<sparrow.rdflib_backend.RDFLibDatabase ...>

Now that we have the database, we can ask it which RDF serialization
formats it supports

>>> db.formats()
['ntriples', 'rdfxml', 'turtle']

Let's add some triples to the database, we will use turtle syntax for this.
We'll make some example statements where we will state that john is a person,
and that his firstname is "John".

>>> data = """@prefix ex: <http://example.org#> .
... ex:john a ex:Person; ex:name "John" ."""

Now we can add this to the database. We will need to tell the database 
which format the data is in, and in which context to store it.
A 'base URI' for the data should also be provided. We will use the 
example.org namespace for that.

>>> db.add(StringIO(data), 'turtle', 'http://example.org','persons')

We can now ask the database, which contexts it has:

>>> db.contexts()
[u'persons']

You can store data in as many different contexts as you like, or put everything
in a single context.

Lets do a simple SPARQL query on the database

>>> result = db.select('SELECT ?x {?x <http://example.org#name> "John".}')

We can get the results as a list of dictionaries. This follows the SPARQL
JSON result format.

>>> result
[{u'x': {'type': u'uri', 'value': u'http://example.org#john'}}]

Besides querying, we can also get the data back from the database in any
of the supported formats. We specify which format we want, and which context
to use.

>>> db.serialize('ntriples', 'persons').read()
'<http://example.org#john> ...'

If the database backend supports it, you can ask how many triples are in a 
context.

>>> db.count('persons')
2

If you want to remove triples, you will need to supply data describing which
triples to remove.

>>> data = StringIO('<http://example.org#john> a <http://example.org#Person>.')
>>> db.remove(data, 'turtle', 'http://example.org', 'persons')
>>> db.count('persons')
1

You can also remove all triples in a context

>>> db.clear('persons')
>>> db.count('persons')
0

Since the 'persons' context is now empty, it is also removed.

>>> db.contexts()
[]
