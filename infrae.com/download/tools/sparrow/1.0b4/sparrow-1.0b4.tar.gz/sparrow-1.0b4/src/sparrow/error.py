
class ConnectionError(Exception):
    pass

class TripleStoreError(Exception):
    pass

class QueryError(Exception):
    pass
