# -*- coding: utf-8 -*-
# Copyright (c) 2011-2012 Infrae. All rights reserved.
# See also LICENSE.txt

from infrae.testbrowser.selenium.browser import Browser

__all__ = ['Browser']
