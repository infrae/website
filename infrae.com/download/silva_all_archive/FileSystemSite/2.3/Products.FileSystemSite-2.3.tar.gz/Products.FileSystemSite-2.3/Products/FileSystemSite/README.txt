CMFCore

  This product declares the key framework services for the Zope
  Content Management Framework (CMF).  Please see the CMF
  "dogbowl site":http://cmf.zope.org, for more details.
