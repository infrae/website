from Products.FileSystemSite.DirectoryView import registerDirectory

registerDirectory('site', globals())
