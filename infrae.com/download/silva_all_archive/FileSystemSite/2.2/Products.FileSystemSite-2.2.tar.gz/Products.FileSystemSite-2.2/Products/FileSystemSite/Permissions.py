
AccessContentsInformation = 'Access contents information'
ManagePortal = 'View management screens'
View = 'View'
ViewManagementScreens = ManagePortal
FTPAccess = 'FTP Access'

