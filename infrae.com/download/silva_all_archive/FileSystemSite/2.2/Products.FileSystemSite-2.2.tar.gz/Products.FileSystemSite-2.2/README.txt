FileSystemSite
==============

FileSystemSite is a split of CMFCore which contains only components to
create filesystem based site. You get a Directory View object, which
let you have Page Template, Python Scripts, Files, which actually
refer to existing files on the file-system.

For more information, look at the CMFCore documentation.



