Products.Annotations
====================

Annotations is a Zope 2 product to support annotation on a
object. It's still used by some Silva components, but you should use
``zope.annotations`` which provides the same features by now.


