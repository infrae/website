"""
Provides for code compatiblity between silva and the cmf.

Author: kapil thangavelu <k_vertigo@objectrealms.net>
"""

import Configuration
from ExtensionClass import Base
from OFS.ObjectManager import UNIQUE

#################################
### Service Lookup

if Configuration.UsingCMF:
    from Products.CMFCore.utils import getToolByName

else:
    _marker = []
    
    SilvaToolMap = {
        'portal_annotations':'service_annotations',
        }

    def getToolByName(ctx, service_name, default=_marker):
        try:
            silva_name = SilvaToolMap[service_name]
        except KeyError, e:
            raise CompatibilityException(str(e))

        try:
            tool = aq_get(ctx, silva_name, default, 1)
        except AttributeError:
            if default is _marker:
                raise
            return default
        
        if tool is _marker:
            raise AttributeError(silva_name)
        
        return tool
    
#################################
### Misc    
if Configuration.UsingCMF:
    from Products.CMFCore.utils import UniqueObject
else:
    class ImmutableId(Base):

        """ Base class for objects which cannot be renamed.
        """
        def _setId(self, id):

            """ Never allow renaming!
            """
            if id != self.getId():
                raise MessageDialog(
                    title='Invalid Id',
                    message='Cannot change the id of this object',
                    action ='./manage_main',)

    class UniqueObject (ImmutableId):

        """ Base class for objects which cannot be "overridden" / shadowed.
        """
        __replaceable__ = UNIQUE
