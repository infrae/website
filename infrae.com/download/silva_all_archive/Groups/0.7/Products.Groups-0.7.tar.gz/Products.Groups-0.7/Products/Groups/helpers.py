import urllib

def add_and_edit(self, id, REQUEST):
    """Helper function to point to the object's management screen if
    'Add and Edit' button is pressed.
    id -- id of the object we just added
    """
    if REQUEST is None:
        return
    try:
        u = self.DestinationURL()
    except:
        u = REQUEST['URL1']
    if REQUEST.has_key('submit_edit'):
        u = "%s/%s" % (u, urllib.quote(id))
    REQUEST.RESPONSE.redirect(u+'/manage_main')

def guessHost(request):
    # Zope got support for finding the remote address itself. Using
    # this method here.
    if hasattr(request, 'getClientAddr'):
        return request.getClientAddr()
    # deprecated for Zope >= 2.7
    headers = ['HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR']
    for header in headers:
        if request.get(header, None):
            return request[header].split(',')[0]
    return None


