# Copyright (c) 2002-2008 Infrae. All rights reserved.
import ZGroupsMapping, ZGroupsService
import Monkey # activate monkey patches

def initialize(context):
    context.registerClass(
        ZGroupsService.ZGroupsService,
        constructors = (ZGroupsService.manage_addGroupsServiceForm,
                        ZGroupsService.manage_addGroupsService),
        icon = "www/groups.png"
        )

    context.registerClass(
        ZGroupsMapping.ZGroupsMapping,
        constructors = (ZGroupsMapping.manage_addGroupsMappingForm,
                        ZGroupsMapping.manage_addGroupsMapping),
        )
    
