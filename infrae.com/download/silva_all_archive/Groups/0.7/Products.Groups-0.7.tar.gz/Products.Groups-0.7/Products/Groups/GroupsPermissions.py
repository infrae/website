# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Revision: 1.4 $
import Globals, AccessControl, Products
from AccessControl import Permissions

def setDefaultRoles(permission, roles):
    '''
    Sets the defaults roles for a permission. Borrowed from CMF.
    '''
    # XXX This ought to be in AccessControl.SecurityInfo.
    registered = AccessControl.Permission._registeredPermissions
    if not registered.has_key(permission):
        registered[permission] = 1
        Products.__ac_permissions__=(
            Products.__ac_permissions__+((permission,(),roles),))
        mangled = AccessControl.Permission.pname(permission)
        setattr(Globals.ApplicationDefaultPermissions, mangled, roles)
        
ChangeGroups = 'Change Groups'
setDefaultRoles(ChangeGroups, ('Manager','ChiefEditor'))

AccessGroups = 'Access Groups information'
setDefaultRoles(AccessGroups, ('Manager', 'ChiefEditor',
                               'Editor', 'Author', 'Reader',
                               'Viewer', 'Authenticated'))

ChangeGroupMappings = 'Change Groups mappings'
setDefaultRoles(ChangeGroupMappings, ('Manager','ChiefEditor'))

AccessGroupMappings = 'Access Group mappings'
setDefaultRoles(AccessGroupMappings, ('Manager', 'ChiefEditor',
                                      'Editor', 'Author', 'Reader',
                                      'Viewer', 'Authenticated'))
