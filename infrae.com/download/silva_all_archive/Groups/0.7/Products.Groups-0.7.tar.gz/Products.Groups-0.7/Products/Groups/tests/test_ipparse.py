import unittest
from Products.Groups.ipparse import IPRange

class IPParseTest(unittest.TestCase):

    def test_parse(self):
        ipr = IPRange('1.2.3.4')
        self.assert_('1.2.3.4' in ipr)
        self.assert_('1.2.3.5' not in ipr)
        self.assert_('1.2.3.3' not in ipr)
       
        ipr = IPRange('1.2.3.5-1.2.3.10')
        self.assert_('1.2.3.5' in ipr)
        self.assert_('1.2.3.7' in ipr)
        self.assert_('1.2.3.10'  in ipr)
        self.assert_('1.2.3.4' not in ipr)
        self.assert_('1.2.3.11' not in ipr)
        self.assert_('1.2.4.7' not in ipr)

        ipr = IPRange('1.2.0.0-1.2.255.255')
        ipr2 = IPRange('1.2.0.0/255.255.0.0')
        ipr3 = IPRange('1.2.0.0/16')
        self.assertEqual(ipr, ipr2)
        self.assertEqual(ipr2, ipr3)
        self.assertEqual(ipr, ipr3)
        self.assert_('1.2.3.5' in ipr)
        self.assert_('1.2.239.14'in ipr)
        self.assert_('1.4.3.10' not in ipr)
        self.assert_('1.1.3.4' not in ipr)
        self.assert_('1.98.3.11' not in ipr)
        self.assert_('10.2.4.7' not in ipr)

    def test_patterns(self):
        ipr = IPRange
        
        self.assert_(ipr._ip.match('1.1.1.1'))
        self.assert_(ipr._ip.match('0.0.0.0'))
        self.assert_(ipr._ip.match('10.1.1.1'))
        self.assert_(ipr._ip.match('255.255.255.255'))
        self.assert_(not ipr._ip.match('256.1.1.1'))
        self.assert_(not ipr._ip.match('1.1.1.256'))
        
        self.assert_(ipr._ip_range.match('10.1.1.1-10.1.1.255'))
        self.assert_(not ipr._ip_range.match('10.1.1.1/10.1.1.255'))
        self.assert_(ipr._ip_mask.match('10.1.1.1/255.255.255.0'))
        self.assert_(not ipr._ip_mask.match('10.1.1.1-255.255.255.0'))
        self.assert_(not ipr._ip_mask.match('10.1.1.1/8'))
        
        self.assert_(ipr._ip_intmask.match('10.1.1.1/8'))
        self.assert_(ipr._ip_intmask.match('10.1.1.1/0'))
        self.assert_(ipr._ip_intmask.match('10.1.1.1/08'))
        self.assert_(ipr._ip_intmask.match('10.1.1.1/28'))
        self.assert_(not ipr._ip_intmask.match('10.1.1.1/38'))
        
    def test_ipintconvert(self):
        ipr = IPRange('0.0.0.0')
        self.assertEqual(ipr._ip_to_int('0.0.0.1'), 1)
        self.assertEqual(ipr._ip_to_int('0.0.1.0'), 256)
        self.assertEqual(ipr._ip_to_int('0.1.0.0'), 65536)
        self.assertEqual(ipr._ip_to_int('1.0.0.0'), 16777216)
        self.assertEqual(ipr._ip_to_int('255.255.255.255'), 0xffffffffL)
        self.assertEqual(ipr._int_to_ip(1), '0.0.0.1')
        self.assertEqual(ipr._int_to_ip(256), '0.0.1.0')
        self.assertEqual(ipr._int_to_ip(65536), '0.1.0.0')
        self.assertEqual(ipr._int_to_ip(16777216), '1.0.0.0')
        self.assertEqual(ipr._int_to_ip(0xffffffffL), '255.255.255.255')
       
    def test_boundaries(self):
        ipr = IPRange('0.0.0.0')
        g = ipr._get_boundaries
        self.assertEquals(g('1.1.1.1'), ('1.1.1.1', '1.1.1.1'))
        self.assertEquals(g('1.1.1.1-1.1.1.2'), ('1.1.1.1', '1.1.1.2'))
        self.assertEquals(g('1.1.1.1-10.1.1.1'), ('1.1.1.1', '10.1.1.1'))
        self.assertEquals(g('1.1.1.1/255.0.0.0'),
            ('1.0.0.0', '1.255.255.255'))
        self.assertEquals(g('255.36.64.0/255.255.255.0'),
            ('255.36.64.0', '255.36.64.255'))
        self.assertEquals(g('1.2.3.4/8'),
            ('1.0.0.0', '1.255.255.255'))
        self.assertEquals(g('255.36.64.0/24'),
            ('255.36.64.0', '255.36.64.255'))
        self.assertEquals(g('1.2.3.4/32'),
            ('1.2.3.4', '1.2.3.4'))
       
def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(IPParseTest))
    return suite

def main():
    unittest.TextTestRunner().run(test_suite())

if __name__ == '__main__':
    main()

