# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: ZGroupsService.py,v 1.4 2003/02/17 18:20:09 zagy Exp $
from OFS import SimpleItem
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
import Globals
from helpers import add_and_edit
from GroupsService import GroupsService

class ZGroupsService(SimpleItem.SimpleItem, GroupsService):
    meta_type = 'Groups Service'

    security = ClassSecurityInfo()
    
    manage_options = (
        {'label':'Edit',       'action':'manage_main'},
        ) + SimpleItem.SimpleItem.manage_options

    manage_main = PageTemplateFile('pt/groupsServiceEdit', globals())

    def __init__(self, id, title):
        ZGroupsService.inheritedAttribute('__init__')(self)
        self.id = id
        self.title = title

Globals.InitializeClass(ZGroupsService)


manage_addGroupsServiceForm = PageTemplateFile("pt/groupsServiceAdd", globals(),
                                               __name__='manage_addGroupsServiceForm')

def manage_addGroupsService(self, id, title, REQUEST=None):
    """Add groups service."""
    object = ZGroupsService(id, title)
    self._setObject(id, object)
    add_and_edit(self, id, REQUEST)
    return ''


