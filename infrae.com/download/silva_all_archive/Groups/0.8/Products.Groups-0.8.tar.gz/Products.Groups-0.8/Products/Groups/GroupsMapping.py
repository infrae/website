# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Revision: 1.7 $
from AccessControl import ClassSecurityInfo
from App.class_init import InitializeClass
import GroupsPermissions
from GroupsErrors import GroupsError

class GroupsMapping:
    """This maps groups to roles.
    """
    security = ClassSecurityInfo()

    def __init__(self):
        self._mappings = {}

    # MANIPULATORS
    security.declareProtected(GroupsPermissions.ChangeGroupMappings,
                              'addMapping')
    def addMapping(self, group, roles):
        """Map group to roles.
        """
        # XXX should disallow adding of certain mappings, such
        # as to manager?
        self._mappings[group] = roles
        self._p_changed = 1

    security.declareProtected(GroupsPermissions.ChangeGroupMappings,
                              'removeMapping')
    def removeMapping(self, group):
        """Remove a mapping.
        """
        del self._mappings[group]
        self._p_changed = 1
       
    security.declareProtected(
        GroupsPermissions.ChangeGroupMappings, 'assignRolesToGroup')
    def assignRolesToGroup(self, group, roles):
        """Assign roles to a group. Create mapping if it not already
        exists.
        """
        group_roles = self._mappings.setdefault(group, [])
        for role in roles:
            if not role in group_roles:
                group_roles.append(role)
        self._p_changed = 1

    security.declareProtected(
        GroupsPermissions.ChangeGroupMappings, 'revokeRolesFromGroup')
    def revokeRolesFromGroup(self, group, roles):
        """Revoke a roles from a group.
        """
        group_roles = self._mappings.get(group, [])
        for role in roles:
            if role in group_roles:
                group_roles.remove(role)
        if not group_roles:
            del self._mappings[group]
        self._p_changed = 1

    security.declareProtected(
        GroupsPermissions.ChangeGroupMappings, 'clear')
    def clear(self):
        """Clear all mappings.
        """
        self._mappings = {}    
       
    # ACCESSORS
    security.declareProtected(GroupsPermissions.AccessGroupMappings,
                              'getMappings')
    def getMappings(self):
        """Get the mappings.
        """
        return self._mappings
           
    security.declareProtected(GroupsPermissions.AccessGroupMappings,
                              'getRoles')
    def getRoles(self, user):
        """Get any extra roles that are attached for this user by
        this mapping. Returns a dictionary with as keys the roles.
        This is used internally by the monkey patch.
        """
        try:
            # If for some reason the service_groups is not
            # available (anymore), return an empty dict.
            groups_service = self.service_groups
        except AttributeError, ae:
            return {}

        groups = groups_service.getGroups(user)
        mappings = self._mappings
        result_roles = {}
        for group in groups.keys():
            roles = mappings.get(group, [])
            for role in roles:
                result_roles[role] = 1
        return result_roles

InitializeClass(GroupsMapping)
