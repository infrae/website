from OFS import SimpleItem
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from App.class_init import InitializeClass
from helpers import add_and_edit

from GroupsMapping import GroupsMapping

class ZGroupsMapping(SimpleItem.SimpleItem, GroupsMapping):
    meta_type = 'Groups Mapping'

    security = ClassSecurityInfo()
    
    manage_options = (
        {'label':'Edit',       'action':'manage_main'},
        ) + SimpleItem.SimpleItem.manage_options

    def __init__(self, id):
        ZGroupsMapping.inheritedAttribute('__init__')(self)
        self.id = id
        self.title = ''
    
    # register the mapping with the object
    def manage_afterAdd(self, item, container):
        if item is self:
            if hasattr(self, 'aq_base'):
                self = self.aq_base
            container.__ac_local_groups__ = self

    def manage_beforeDelete(self, item, container):
        if item is self:
            try:
                del container.__ac_local_groups__
            except:
                pass    
        
InitializeClass(ZGroupsMapping)

manage_addGroupsMappingForm =  PageTemplateFile("pt/groupsMappingAdd", globals(),
                                                __name__='manage_addGroupsMappingForm')

def manage_addGroupsMapping(self, REQUEST=None):
    """Add groups mapping."""
    id = 'acl_groups'
    object = ZGroupsMapping(id)
    self._setObject(id, object)
    add_and_edit(self, id, REQUEST)
    return ''
