Groups
======

Groups is a Zope product that adds Group support to Zope. The Groups product
has been written so that it can be used independently from Silva::
  
    http://infrae.com/products/silva

This is however still very raw, and there is barely any UI support
outside Silva. This means Groups at this moment are only useful from
within Silva, unless you write your own UI.

