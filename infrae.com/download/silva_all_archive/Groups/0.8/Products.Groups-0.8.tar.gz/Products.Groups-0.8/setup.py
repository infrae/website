# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: setup.py 43666 2010-07-15 15:28:14Z sylvain $

from setuptools import setup, find_packages
import os

version = '0.8'

setup(name='Products.Groups',
      version=version,
      description="Groups is a product that adds Group support to Zope 2.",
      long_description=open(os.path.join("Products", "Groups", "README.txt")).read() + "\n" +
                       open(os.path.join("Products", "Groups", "HISTORY.txt")).read(),
      # Get more strings from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=[
                  "Framework :: Zope2",
                  "License :: OSI Approved :: BSD License",
                  "Programming Language :: Python",
                  "Topic :: Software Development :: Libraries :: Python Modules",
                  ],
      keywords='group zope2',
      author='Infrae',
      author_email='info@infrae.com',
      url='http://infrae.com/products/silva',
      license='BSD',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'Zope2',
          ],
      )
