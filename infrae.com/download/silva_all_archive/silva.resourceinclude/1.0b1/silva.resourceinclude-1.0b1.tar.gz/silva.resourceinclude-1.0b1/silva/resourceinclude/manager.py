# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: manager.py 32075 2008-11-17 17:31:24Z sylvain $

from z3c.resourceinclude import manager
import Acquisition

class ResourceManager(manager.ResourceManager, Acquisition.Implicit):

    def searchResource(self, request, name):
        parent = self.aq_parent
        resource = super(ResourceManager, self).searchResource(request, name)
        if resource:
            return resource.__of__(parent)
        return resource


class ResourceManagerFactory(manager.ResourceManagerFactory):

    def __call__(self):
        return ResourceManager()
