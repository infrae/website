# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: provider.py 34706 2009-04-20 17:55:45Z sylvain $

from z3c.resourceinclude import provider
from silva.core.views import views as silvaviews

class ResourceIncludeProvider(provider.ResourceIncludeProvider,
                              silvaviews.ContentProvider):

    def update(self):
        super(ResourceIncludeProvider, self).update()
        self.collector = self.collector.__of__(self.context)
