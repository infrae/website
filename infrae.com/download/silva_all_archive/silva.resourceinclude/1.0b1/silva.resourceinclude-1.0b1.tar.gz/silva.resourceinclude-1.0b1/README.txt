silva.resourceinclude
=====================

silva.resourceinclude collect and merge resources files (CSS, KSS, JS)
on layers. It's based on `z3c.resourceinclude`_. It's used by
``silva.core.layout`` to easily include resources in Silva Layouts.

.. _z3c.resourceinclude: http://pypi.python.org/pypi/z3c.resourceinclude
