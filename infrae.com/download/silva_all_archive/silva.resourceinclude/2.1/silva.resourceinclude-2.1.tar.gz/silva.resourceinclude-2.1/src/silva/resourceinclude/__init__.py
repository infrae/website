# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 39788 2010-02-10 16:36:08Z sylvain $

import silva.resourceinclude.monkeys
