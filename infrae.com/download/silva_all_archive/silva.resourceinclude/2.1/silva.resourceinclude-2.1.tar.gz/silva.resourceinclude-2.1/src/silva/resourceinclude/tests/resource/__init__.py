# this is a package

import os.path

static_dir = os.path.join(
    os.path.dirname(__file__), 'requests_fixture', 'static')
