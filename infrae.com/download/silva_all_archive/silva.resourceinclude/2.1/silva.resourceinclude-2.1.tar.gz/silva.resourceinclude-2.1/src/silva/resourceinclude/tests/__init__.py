# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 32075 2008-11-17 17:31:24Z sylvain $
