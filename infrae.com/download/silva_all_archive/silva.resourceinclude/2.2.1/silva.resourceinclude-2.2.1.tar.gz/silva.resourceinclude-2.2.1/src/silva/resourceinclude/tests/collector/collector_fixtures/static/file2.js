function somefunc2() { return "hello world!" }
