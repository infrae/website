function somefunc1() { return "hello world!" }
