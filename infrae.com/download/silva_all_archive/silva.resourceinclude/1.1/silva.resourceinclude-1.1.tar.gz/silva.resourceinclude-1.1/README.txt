silva.resourceinclude
=====================

silva.resourceinclude collect and merge resources files (CSS, KSS, JS)
on Zope layers, and generate links in HTML pages to those
resources. It's used by ``silva.core.layout`` to easily include
resources in Silva Layouts.

