from zope.publisher.interfaces.browser import IBrowserSkinType

class ISilvaDefault(IBrowserSkinType):
    """Default skin for SilvaLayout.
    """

