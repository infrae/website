# -*- coding: utf-8 -*-
# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: setup.py 32949 2009-01-12 16:28:37Z sylvain $

from setuptools import setup, find_packages
import os

version = '2.2a2'

setup(name='Products.SilvaLayout',
      version=version,
      description="Filesystem layout support for Silva",
      long_description=open(os.path.join("Products", "SilvaLayout", "README.txt")).read() + "\n" +
                       open(os.path.join("Products", "SilvaLayout", "HISTORY.txt")).read(),
      classifiers=[
              "Framework :: Zope2",
              "License :: OSI Approved :: BSD License",
              "Programming Language :: Python",
              "Topic :: Software Development :: Libraries :: Python Modules",
              ],
      keywords='silva cms zope layout',
      author='Infrae',
      author_email='info@infrae.com',
      url='http://infrae.com/download/SilvaLayout',
      license='BSD',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
              'Products.Silva',
              'Products.Formulator',
              'setuptools',
              'silva.core.conf',
              'silva.core.views',
              'silva.core.layout',
              ],
      )
