# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$


from silva.core import conf as silvaconf

silvaconf.extensionName('SilvaLayout')
silvaconf.extensionTitle('Silva Layout')

import helpers

def __allow_access_to_unprotected_subobjects__(name, value=None):
    return name in ('helpers', )

