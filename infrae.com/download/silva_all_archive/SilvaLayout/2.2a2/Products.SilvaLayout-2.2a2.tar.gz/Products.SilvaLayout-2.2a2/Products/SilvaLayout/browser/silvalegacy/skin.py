# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

#since ISilvaLegacy is registered for ISilvaObject, and
# ISilvaDefault has more specific index.html and preview_html
# views (for IContent and IContainer), extending ISilvaDefault
# won't work.  The more specific interface registrations are used.
#class ISilvaLegacy(IBrowserSkinType):

from Products.SilvaLayout.browser.silvadefault.skin import ISilvaDefault
from Products.SilvaLayout.interfaces import ISilvaSkin

from silva.core import conf as silvaconf

class ISilvaLegacy(ISilvaDefault):
    """Legacy layer.
    """

class ISilvaLegacySkin(ISilvaLegacy, ISilvaSkin):
    """Legacy skin for SilvaLayout.
    """
    
    silvaconf.skin('SilvaLegacy')
    
