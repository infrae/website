# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from grokcore import component

# Silva
from Products.Silva import interfaces as silva_interfaces

# SilvaLayout
from Products.SilvaLayout import interfaces

class Node(component.Adapter):
    
    component.implements(interfaces.ITreeNode)
    component.context(silva_interfaces.IContent)
    
    # XXX a better name could be 'isAncestorFor'
    def onBranch(self, node):
        browsingcontext = node.context.aq_inner
        context = self.context.aq_inner 
        if browsingcontext == context:
            return True
        return context in browsingcontext.aq_chain
        
    def getContainerNode(self):
        context = self.context.aq_inner
        container = context.aq_parent
        node = interfaces.ITreeNode(container)
        return node

    def getPublicationNode(self):
        context = self.context.aq_inner
        pub = context.get_publication()
        node = interfaces.ITreeNode(pub)
        return node

    def getVirtualHostRootNode(self):
        context = self.context.aq_inner
        request = context.REQUEST

        # XXX this appears to be needed for the WuWLayout extension
        # but should probably be moved to that extensions completely.
        vhroot = silva_interfaces.IVirtualHosting(context).getVirtualHostRoot()
        # This don't work if the virtual root is not in the silva root ?
        if vhroot is None:
            vhroot = context.get_root()
        return interfaces.ITreeNode(vhroot)
    
    def getObject(self):
        return self.context.aq_inner
        
    def hasChildNodes(self):
        return False
    
    def childNodes(self, filters=()):
        return []
        
class ContainerNode(Node):

    component.context(silva_interfaces.IContainer)
    
    def hasChildNodes(self):
        return bool(self.context._ordered_ids)
    
    def childNodes(self, filters=()):
        for obj in self.context.get_ordered_publishables():
            if self._filter(obj, filters):
                # Continue with next object, since the current one is
                # filtered out.
                continue
            yield interfaces.ITreeNode(obj)
            
    def _filter(self, object, filters):
        for klass in filters:
            filter = klass(object) # implements ITreeNodeFilter
            if filter():
                return True
        return False
            
class RootNode(ContainerNode):
    
    component.context(silva_interfaces.IRoot)

    def getContainerNode(self):
        return self

    def getPublicationNode(self):
        return self    
        
