# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

# Zope 3
from zope import component
from zope.traversing.browser import absoluteURL

# Zope 2
from Products.Five import BrowserView

# SilvaLayout
from Products.SilvaLayout import interfaces


class SilvaView(BrowserView):

    def __init__(self, *args):
        BrowserView.__init__(self, *args)
        self.metadata = interfaces.IMetadata(self.context)

    def getRootMetadata(self, set, element):
        root = self.context.get_root()
        return root.service_metadata.getMetadataValue(root, set, element)

    def getPublicationMetadata(self, set, element):
        pub = self.context.get_publication()
        return pub.service_metadata.getMetadataValue(pub, set, element)
        
    def title(self):
        """title for object
        """
        return self.context.get_title()
    
    def render(self):
        """default public or previewable rendering
        """
        ## This view code should be here.
        return self.context.view()
    
    def modificationtime(self):
        return self.metadata('silva-extra', 'modificationtime')

    def metadata(self, set, value):
        return self.metadata(set, value)
        

class Content(SilvaView):

    def context_or_default(self):
        return self.context

class Container(SilvaView):

    def context_or_default(self):
        return self.context.get_default()

    def render(self):
        """public rendering for folders
        """
        default = self.context_or_default()
        if default is None:
            return self.context.view()
        # Delegate actual rendering to the view for this object
        view = component.getMultiAdapter((default, self.request), name='index.html')
        return view.render()
            
    def modificationtime(self):
        context = self.context_or_default()
        if not context:
            context = self.context
        metadata = interfaces.IMetadata(context)
        return metadata('silva-extra', 'modificationtime')

    
class AutoTOCView(SilvaView):
    """AutoTOCView with filtering 
    """
    def __init__(self, *args, **kwargs):
        SilvaView.__init__(self, *args)
        self.filters = kwargs.get('filters', [])

    def context_or_default(self):
        return self.context

    def getTocNodes(self, depth=-1):
        # XXX This implementation should've reused the ITreeNode adapters;
        # filtering is handled much better there. However, the output HTML
        # for this view should be identical to Silva's core rendering
        # for AutoTOC objects and thus we mimic that rendering here.
        items = []
        context = self.context_or_default()
        container = context.get_container()
        depth_flag = None
        for indent, obj in container.get_public_tree_all():
            # Skip all items 'deeper' than the one that needed filtering
            if depth_flag is not None:
                if indent > depth_flag:
                    continue
                else:
                    depth_flag = None
            # XXX code copied from adapters.treenode. Should be refactored.
            if self._filter(obj, self.filters):
                # Continue with next object, since the current one is
                # filtered out.
                depth_flag = indent
                continue
            items.append((indent, absoluteURL(obj, self.request), obj.get_title(),))
        return items
            
    def _filter(self, object, filters):
        # XXX code copied from adapters.treenode. Should be refactored.
        for klass in filters:
            filter = klass(object) # implements ITreeNodeFilter
            if filter():
                return True
        return False
    
    def render(self):
        """public rendering for autoTOC
        """
        request = self.request
        context = self.context_or_default()
        view = component.getMultiAdapter((context, request), name='autotoc')
        return view()
