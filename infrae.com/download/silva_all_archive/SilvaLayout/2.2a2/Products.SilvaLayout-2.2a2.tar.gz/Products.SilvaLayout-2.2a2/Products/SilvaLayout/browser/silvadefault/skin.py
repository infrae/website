# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from Products.SilvaLayout.interfaces import ISilvaSkin, ISilvaLayer

from silva.core import conf as silvaconf

class ISilvaDefault(ISilvaLayer):
    """Default layer.
    """

class ISilvaDefaultSkin(ISilvaDefault, ISilvaSkin):
    """Default skin for SilvaLayout.
    """

    silvaconf.skin('SilvaDefault')
