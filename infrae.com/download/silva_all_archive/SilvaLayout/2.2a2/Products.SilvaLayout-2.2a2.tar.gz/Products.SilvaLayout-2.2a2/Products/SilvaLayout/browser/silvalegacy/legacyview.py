# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from Products.SilvaLayout.browser.silvaview import Content, Container

#here we need to extend both silvaview.Content and
#silvaview.container so that the extra functionality
# for PUT and HEAD support works

class LegacyViewHelper(object):
    default_view = 'index_html'

    def lookup_and_call(self, view):
        lookedup = getattr(self.context.aq_inner, view)
        return lookedup()

    def __call__(self):
        """ look up in hierarcy for index_html
            and then call it"""
        return self.lookup_and_call(self.default_view)

class LegacyContentView(LegacyViewHelper, Content):
    """Render IContent using the legacy zodb-based
       layout mechanism (index_html, content.html,
       layout_macro.html"""

class LegacyContainerView(LegacyViewHelper, Container):
    """Render IContainer using the legacy zodb-based
       layout mechanism (index_html, content.html,
       layout_macro.html"""

