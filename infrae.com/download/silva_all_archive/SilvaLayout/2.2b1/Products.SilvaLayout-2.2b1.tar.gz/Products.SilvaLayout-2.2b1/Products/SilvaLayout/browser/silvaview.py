# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

# Zope 3
from zope import component

# Zope 2
from Products.Five import BrowserView

# SilvaLayout
from Products.SilvaLayout import interfaces


class SilvaView(BrowserView):

    def __init__(self, *args):
        BrowserView.__init__(self, *args)
        self.metadata = interfaces.IMetadata(self.context)

    def getRootMetadata(self, set, element):
        root = self.context.get_root()
        return root.service_metadata.getMetadataValue(root, set, element)

    def getPublicationMetadata(self, set, element):
        pub = self.context.get_publication()
        return pub.service_metadata.getMetadataValue(pub, set, element)

    def title(self):
        """title for object
        """
        return self.context.get_title()

    def render(self):
        """default public or previewable rendering
        """
        ## This view code should be here.
        return self.context.view()

    def modificationtime(self):
        return self.metadata('silva-extra', 'modificationtime')

    def metadata(self, set, value):
        return self.metadata(set, value)


class Content(SilvaView):

    def context_or_default(self):
        return self.context

class Container(SilvaView):

    def context_or_default(self):
        return self.context.get_default()

    def render(self):
        """public rendering for folders
        """
        default = self.context_or_default()
        if default is None:
            return self.context.view()
        # Delegate actual rendering to the view for this object
        view = component.getMultiAdapter(
            (default, self.request), name='index.html')
        return view.render()

    def modificationtime(self):
        context = self.context_or_default()
        if not context:
            context = self.context
        metadata = interfaces.IMetadata(context)
        return metadata('silva-extra', 'modificationtime')

