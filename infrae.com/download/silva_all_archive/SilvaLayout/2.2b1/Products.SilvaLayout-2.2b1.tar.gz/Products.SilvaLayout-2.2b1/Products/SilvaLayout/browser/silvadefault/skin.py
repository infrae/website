# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: skin.py 39332 2010-01-25 13:55:40Z sylvain $

from Products.SilvaLayout.interfaces import ISilvaSkin, ISilvaLayer


class ISilvaDefault(ISilvaLayer):
    """Default layer.
    """

class ISilvaDefaultSkin(ISilvaDefault, ISilvaSkin):
    """Default skin for SilvaLayout.
    """

    # We don't register that skin by default
