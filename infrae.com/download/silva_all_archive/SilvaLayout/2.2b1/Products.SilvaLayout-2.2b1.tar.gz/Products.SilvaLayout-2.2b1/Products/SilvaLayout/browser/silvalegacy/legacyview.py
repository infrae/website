# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: legacyview.py 39330 2010-01-25 13:48:57Z sylvain $

from Products.SilvaLayout.browser.silvaview import Content, Container

#here we need to extend both silvaview.Content and
#silvaview.container so that the extra functionality
# for PUT and HEAD support works

ERROR_LEGACY_NOT_INSTALLED = """
<html>
<body>
<h1>Sorry, but it seems you didn't install a legacy layout</h1>

<p>You can do it in service extensions. This will install files that you
will be able to modify in ZMI.</p>
</body>
</html>
"""

class LegacyViewHelper(object):
    default_view = 'index_html'

    def lookup_and_call(self, view):
        lookedup = getattr(self.context.aq_inner, view)
        # Sanity checks
        root = self.context.get_root()
        root_path = '/'.join(root.getPhysicalPath())
        lookedup_path = '/'.join(lookedup.getPhysicalPath())
        if not lookedup_path.startswith(root_path):
            return ERROR_LEGACY_NOT_INSTALLED
        return lookedup()

    def __call__(self):
        """ look up in hierarcy for index_html
            and then call it"""
        return self.lookup_and_call(self.default_view)

class LegacyContentView(LegacyViewHelper, Content):
    """Render IContent using the legacy zodb-based
       layout mechanism (index_html, content.html,
       layout_macro.html"""

class LegacyContainerView(LegacyViewHelper, Container):
    """Render IContainer using the legacy zodb-based
       layout mechanism (index_html, content.html,
       layout_macro.html"""

