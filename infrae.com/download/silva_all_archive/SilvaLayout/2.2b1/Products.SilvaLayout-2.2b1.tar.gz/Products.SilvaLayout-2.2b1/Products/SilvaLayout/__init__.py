# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 39332 2010-01-25 13:55:40Z sylvain $


from silva.core import conf as silvaconf

silvaconf.extensionName('SilvaLayout')
silvaconf.extensionTitle('Silva Layout')

import helpers

def __allow_access_to_unprotected_subobjects__(name, value=None):
    return name in ('helpers', )

