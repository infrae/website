# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: helpers.py 39332 2010-01-25 13:55:40Z sylvain $

# Zope
from AccessControl import ModuleSecurityInfo

# Zope3
from zope import component
from zope.publisher.interfaces.browser import IBrowserSkinType

from Products.SilvaLayout.interfaces import ISilvaSkin

# Helpers to integrate Zope3, Five and SilvaLayout functionality
# with Zope2 and Silva

__allow_access_to_unprotected_subobjects__ = 1

module_security = ModuleSecurityInfo('Products.SilvaLayout.helpers')

module_security.declareProtected(
    'Access Contents Information', 'getAvailableSkins')
def getAvailableSkins():
    skins = component.getUtilitiesFor(IBrowserSkinType)
    return [name for name, skin in skins if skin.extends(ISilvaSkin)]
