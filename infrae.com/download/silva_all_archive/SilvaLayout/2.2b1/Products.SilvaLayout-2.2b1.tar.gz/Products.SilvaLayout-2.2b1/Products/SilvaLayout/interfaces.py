# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: interfaces.py 39332 2010-01-25 13:55:40Z sylvain $

# Zope 3
from zope.interface import Interface

class IMetadata(Interface):

    def __getitem__(setname):
        pass

    def __call__(setname, elementname):
        pass

class IMetadataSet(Interface):

    def __getitem__(elementname):
        pass

class ITreeNode(Interface):

    def getObject():
        """Retrieve Silva content object represented by node.
        """
        pass

    def onBranch(node):
        """Return True if supplied node is on the same sub tree branch in
        the object hierarchy. False otherwise.
        """
        pass

    def getContainerNode():
        """Convenience method to retrieve the 'nearest' containing node
        """
        pass

    def getPublicationNode():
        """Convenience method to retrieve the 'nearest' containing
        Publication node.
        """
        pass

    def hasChildNodes():
        """Return True if node's context contains child objects.
        False otherwise.
        """
        pass

    def childNodes():
        """Return iterator over child object.
        """
        pass

class ITreeNodeFilter(Interface):

    def __init__(context):
        """Context is a content object, not an ITreeNode object.
        """
        pass

    def __call__():
        """Return True if this content object is "filtered out" or, in
        other words, is not to be included in the ITreeNode tree. False if
        it is not to be filtered out.

        It is preferred to have a question-like class name, such as
        'NotPublic', or 'NotVisible'.
        """
        pass


from silva.core.layout.interfaces import ISilvaLayer, ISilvaSkin


