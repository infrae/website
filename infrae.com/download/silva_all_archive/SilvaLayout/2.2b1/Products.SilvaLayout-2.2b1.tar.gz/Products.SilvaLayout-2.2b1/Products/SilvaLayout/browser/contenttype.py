# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# Five
from Products.Five import BrowserView

class ContentType(BrowserView):
    def __call__(self):
        request = self.request
        response = request.RESPONSE
        
        charset = 'UTF-8'
        mimetype = 'text/html'
        header = "Content-Type"
        value = '%s; charset=%s' % (mimetype, charset)

        # XXX implicilty set it on the RESPONSE too. How can we 
        # do this explicitly?
        response.setHeader(header, value)
        return """<meta http-equiv="%s" content="%s" />""" % (header, value)
