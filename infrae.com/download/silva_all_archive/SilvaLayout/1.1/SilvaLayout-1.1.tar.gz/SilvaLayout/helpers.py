# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# Zope
from AccessControl import ModuleSecurityInfo, allow_module
# Zope3
from zope import component
from zope.schema.vocabulary import getVocabularyRegistry

# Helpers to integrate Zope3, Five and SilvaLayout functionality
# with Zope2 and Silva

__allow_access_to_unprotected_subobjects__ = 1

module_security = ModuleSecurityInfo('Products.SilvaLayout.helpers')

module_security.declareProtected(
    'Access Contents Information', 'getAvailableSkins')
def getAvailableSkins():
    vr = getVocabularyRegistry()
    vocab = vr.get(None, 'Browser Skins')
    return [e.token for e in vocab]
