from Products.SilvaLayout.browser.silvadefault.skin import ISilvaDefault

class ISilvaLayoutTemplate(ISilvaDefault):
    """Default skin for SilvaLayout.
    """
