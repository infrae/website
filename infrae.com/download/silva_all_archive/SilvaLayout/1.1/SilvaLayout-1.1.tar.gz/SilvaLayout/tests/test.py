import unittest
from zope.publisher.browser import applySkin
from AccessControl.ZopeSecurityPolicy import getRoles

from Products.Silva.tests.SilvaTestCase import SilvaTestCase
from Products.SilvaLayout.browser.silvadefault.skin import ISilvaDefault

class PUTTraversalTestCase(SilvaTestCase):
    # Test for https://infrae.com/issue/silva/issue1678

    def afterSetUp(self):
        pass

    def test_traverse_to_put(self):
        applySkin(self.root.REQUEST, ISilvaDefault)
        
        doc = self.add_document(self.root, 'doc', 'Some Document')
        view = doc.restrictedTraverse('@@index.html')

        doc_put = doc.restrictedTraverse('PUT')
        view_put = doc.restrictedTraverse('@@index.html/PUT')

        document_put_roles = getRoles(doc, 'PUT', doc_put, None)
        view_put_roles = getRoles(view, 'PUT', view_put, None)

        self.assertEquals(document_put_roles, view_put_roles)


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(PUTTraversalTestCase))
    return suite
