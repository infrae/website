# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# Silva
from Products.Silva.ExtensionRegistry import extensionRegistry
# Python package
import install, helpers

#import formulator_extension

def __allow_access_to_unprotected_subobjects__(name, value=None):
    return name in ('helpers', )

def initialize(context):
    extensionRegistry.register(
        'SilvaLayout', 'Silva Layout', context, [], install, depends_on='Silva')
