# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from zope import component
from zope.interface import directlyProvidedBy, directlyProvides
from zope.event import notify
from zope.publisher.browser import SkinChangedEvent
from zope.publisher.interfaces.browser import IBrowserSkinType
from zope.traversing import namespace

from Products.SilvaLayout import interfaces
from silva.core.views.traverser import SilvaPublishTraverse
from silva.core.views.interfaces import IPreviewLayer

SKIN_TO_KEEP = [IPreviewLayer,]

def applySkinButKeepSome(request, skin):
    ifaces = [iface for iface in directlyProvidedBy(request)
              if not (IBrowserSkinType.providedBy(iface) and iface in SKIN_TO_KEEP)]
    # Add the new skin.
    ifaces.append(skin)
    directlyProvides(request, *ifaces)
    notify(SkinChangedEvent(request))



class SkinSetterMixin(object):
    def _setSkin(self, request):
        """Set skin if necessary"""

        try:
            metadata = interfaces.IMetadata(self.context)
        except TypeError, e:
            request.set('resourcebase', self.context)
        else:
            try:
                skin_name = metadata('silva-layout', 'skin')
            except AttributeError:
                # AttributeError means that the silva-layout metadata set
                # was not installed, so just bail out without setting any
                # skin
                return
            
            if skin_name:
                # Retrieve the skin object
                skin = component.getUtility(IBrowserSkinType, name=skin_name)
                if not skin.providedBy(request):
                    # Simply override any previously set skin
                    applySkinButKeepSome(request, skin)
                    # Set the base url for resources 
                    request.set('resourcebase', self.context)


class SkinnyTraverser(SilvaPublishTraverse, SkinSetterMixin):
    def publishTraverse(self, request, name):
        self._setSkin(request)
        return super(SkinnyTraverser, self).publishTraverse(request, name)

    def browserDefault(self, request):
        self._setSkin(request)
        return super(SkinnyTraverser, self).browserDefault(request)


class SkinnyTraversable(SkinSetterMixin):
    def traverse(self, name, furtherPath):
        self._setSkin(self.request)
        return super(SkinnyTraversable, self).traverse(name, furtherPath)
    
class ResourceSkinnyTraversable(SkinnyTraversable, namespace.resource):
    pass

class ViewSkinnyTraversable(SkinnyTraversable, namespace.view):
    pass

