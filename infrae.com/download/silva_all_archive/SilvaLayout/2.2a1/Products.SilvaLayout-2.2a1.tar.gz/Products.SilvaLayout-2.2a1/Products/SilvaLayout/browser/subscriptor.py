# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from Products.Five import BrowserView

from Products.Silva import subscriptionerrors as errors
from Products.Silva.i18n import translate as _


class Subscriptor(BrowserView):    
    def try_subscribe(self):
        emailaddress = self.request.get("emailaddress","")
        #a subscription or unsubscription attempt
        try:
            self.service.requestSubscription(self.context,
                                             emailaddress)
        except errors.NotSubscribableError, e:
            return self.context.subscriptor(
                message_type='warning',
                message=_('content is not subscribable'), 
                subscr_emailaddress=emailaddress)
        except errors.InvalidEmailaddressError, e:
            return self.context.subscriptor(
                message_type='warning',
                message=_('emailaddress not valid'), 
                subscr_emailaddress=emailaddress)
        except (errors.AlreadySubscribedError, errors.NotSubscribedError), e:
            # We just pretend to have sent email in order not to expose
            # any information on the validity of the email address
            pass
        mailedmessage = _(
            'Confirmation request for subscription has been emailed to ${emailaddress}')
        mailedmessage.set_mapping({'emailaddress': emailaddress})
        return self.__render__(message=mailedmessage,
                               message_type='feedback',
                               show_form=False)

    def try_unsubscribe(self):
        emailaddress = self.request.get("emailaddress","")
        try:
            self.service.requestCancellation(self.context, emailaddress)
        except errors.NotSubscribableError, e:
            return self.context.subscriptor(
                message=_('content is not subscribable'), 
                message_type='warning',
                subscr_emailaddress=emailaddress)
        except errors.InvalidEmailaddressError, e:
            return self.context.subscriptor(
                message=_('emailaddress not valid'), 
                message_type='warning',
                subscr_emailaddress=emailaddress)
        except (errors.AlreadySubscribedError, errors.NotSubscribedError), e:
            # We just pretend to have sent email in order not to expose
            # any information on the validity of the emailaddress
            pass
        
        mailedmessage = _(
            'Confirmation request for cancellation has been emailed to ${emailaddress}')
        mailedmessage.set_mapping({'emailaddress': emailaddress})

        return self.__render__(message=mailedmessage,
                               message_type='feedback',
                               show_form=False)


