# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 28348 2008-04-15 10:02:21Z sylvain $
