# Copyright (c) 2008-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 39193 2010-01-19 17:01:40Z sylvain $
