=========================
Silva OpenDocument Export
=========================

This extension provides an export feature to ODT (Open Document Format)
for `Silva`_ 2.2 and higher, for Silva Publication and Silva Document.

.. _Silva: http://infrae.com/products/silva

