Everything in this directory, including the tests subdirectory, should work
independently of ParsedXML and with another Python DOM as well. The only
change necessary should be to the DOM loading in the unit tests subdir.

