SilvaViews
==========

``SilvaViews`` is a component that is used by Silva to attach old
style views (implemented by DirectoryViews templates and python
scripts) to objects.

