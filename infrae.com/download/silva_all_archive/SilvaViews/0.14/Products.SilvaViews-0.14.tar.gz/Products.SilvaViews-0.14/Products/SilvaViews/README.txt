SilvaViews
==========

SilvaViews is a component that is used by Silva to attach views to objects.
It could also be used outside of Silva in other projects.
