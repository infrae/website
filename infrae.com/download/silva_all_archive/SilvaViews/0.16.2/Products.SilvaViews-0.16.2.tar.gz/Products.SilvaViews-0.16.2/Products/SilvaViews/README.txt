==========
SilvaViews
==========

``SilvaViews`` is a component that is used by `Silva`_ to attach old
style views (implemented by directory views templates and python
scripts) to objects.

It is no longer used in `Silva`_ 3.

Code repository
===============

The code for this extension can be found in Git:
https://github.com/silvacms/Products.SilvaViews

.. _Silva: http://silvacms.org
