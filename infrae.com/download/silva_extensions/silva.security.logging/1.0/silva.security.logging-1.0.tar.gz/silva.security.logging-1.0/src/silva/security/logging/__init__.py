# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.security.logging')
silvaconf.extensionTitle('Silva Security Logging')
silvaconf.extensionSystem()
