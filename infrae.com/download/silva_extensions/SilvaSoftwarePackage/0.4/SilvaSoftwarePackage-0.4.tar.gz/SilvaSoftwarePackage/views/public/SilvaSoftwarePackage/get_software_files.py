## Script (Python) "get_software_files"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=release
##title=
##
return release.get_files()
