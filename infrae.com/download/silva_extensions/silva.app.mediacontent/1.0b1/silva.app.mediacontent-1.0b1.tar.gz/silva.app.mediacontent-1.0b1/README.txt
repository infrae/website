silva.app.mediacontent
======================

Simple content types to manage media content.

