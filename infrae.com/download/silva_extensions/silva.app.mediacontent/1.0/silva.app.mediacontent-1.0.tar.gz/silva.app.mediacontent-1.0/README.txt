======================
silva.app.mediacontent
======================

``silva.app.mediacontent`` a set of simple content types to add and
manage local and remote media content in Silva.

This extension requires Silva 2.3, or 3.x.
