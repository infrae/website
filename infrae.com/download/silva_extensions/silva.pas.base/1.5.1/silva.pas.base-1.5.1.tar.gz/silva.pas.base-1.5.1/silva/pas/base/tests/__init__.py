# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 28109 2008-03-19 11:33:54Z sylvain $
