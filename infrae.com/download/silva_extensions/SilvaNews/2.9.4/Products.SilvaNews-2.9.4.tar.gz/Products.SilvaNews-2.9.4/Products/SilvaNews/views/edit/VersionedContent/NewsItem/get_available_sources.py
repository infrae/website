
from Products.SilvaExternalSources.ExternalSource import availableSources

return availableSources(context.REQUEST['model'])
