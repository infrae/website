## Script (Python) "content_mode"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
context.set_edit_mode('content')
return context.tab_edit()
