# This is a package.

NS_SILVA_FIND = 'http://infrae.com/namespace/silva-find'
