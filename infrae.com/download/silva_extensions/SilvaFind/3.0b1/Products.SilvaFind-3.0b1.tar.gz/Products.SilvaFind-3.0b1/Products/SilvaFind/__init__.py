# Copyright (c) 2006-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from Products.SilvaFind import install
from silva.core import conf as silvaconf

silvaconf.extension_name('SilvaFind')
silvaconf.extension_title('Silva Find')
silvaconf.extension_default()

