# This is a package.

NS_FIND_URI = 'http://infrae.com/namespace/silva-find'
