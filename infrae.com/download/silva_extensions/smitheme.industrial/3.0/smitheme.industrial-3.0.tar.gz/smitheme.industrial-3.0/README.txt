===================
smitheme.industrial
===================

``smitheme.industrial`` is an alternative demo skin for the Silva
Management Interface in Silva 3.x.

For more information on how to make your own skin, please check the
`Silva developer documentation`_.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/smitheme.industrial/.

.. _Silva developer documentation: http://docs.infrae.com/silva/

