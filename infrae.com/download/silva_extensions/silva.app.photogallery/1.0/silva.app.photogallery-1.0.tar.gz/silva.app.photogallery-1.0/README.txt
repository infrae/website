======================
silva.app.photogallery
======================

``silva.app.photogallery`` provides an additional view to a folder in
Silva 3.0, that is selectable using a customization marker. It will
display the images inside the folder using a `Gallerific`_
photogallery.

It is a really simple extension, showing off the customization marker
feature available in Silva.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.app.photogallery/.


.. _Gallerific: http://www.twospy.com/galleriffic/
