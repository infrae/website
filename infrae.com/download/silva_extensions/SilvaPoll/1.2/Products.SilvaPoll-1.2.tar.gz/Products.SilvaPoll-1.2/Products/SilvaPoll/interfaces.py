from zope.interface import Interface

class IServicePolls(Interface):
    pass
