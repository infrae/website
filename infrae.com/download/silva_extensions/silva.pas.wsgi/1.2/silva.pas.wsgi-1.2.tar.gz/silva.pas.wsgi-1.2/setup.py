# -*- coding: utf-8 -*-
# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from setuptools import setup, find_packages
import os

version = '1.2'

setup(name='silva.pas.wsgi',
      version=version,
      description="Reuse WSGI authentication in Silva",
      long_description=open("README.txt").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      classifiers=[
        "Framework :: Zope2",
        "Programming Language :: Python",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: BSD License",
        ],
      keywords='pas silva wsgi authentication',
      author='Sylvain Viollon',
      author_email='info@infrae.com',
      url='https://hg.infrae.com/silva.pas.wsgi/trunk',
      license='BSD',
      package_dir={'': 'src'},
      packages=find_packages('src'),
      namespace_packages=['silva', 'silva.pas'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
        "setuptools",
        "collective.monkeypatcher",
        ],
      extras_require = {'demo': ['repoze.who', 'tornado', 'pycurl']},
      entry_points = """
      [console_scripts]
      lookup_service = silva.pas.wsgi.demo.lookup_service:service [demo]
      """
      )
