
from AccessControl.SpecialUsers import emergency_user
from Acquisition import aq_base

from Products.PluggableAuthService.interfaces.authservice import _noroles
from zExceptions import Forbidden


def validate(self, request, auth='', roles=_noroles):
        """ See IUserFolder.
        """
        plugins = self._getOb('plugins')
        is_top = self._isTop()
        authenticated = False

        user_ids = self._extractUserIds(request, plugins)
        accessed, container, name, value = self._getObjectContext(
            request[ 'PUBLISHED' ], request)


        for user_id, login in user_ids:
            user = self._findUser(plugins, user_id, login, request=request)

            # Emergency user.
            if aq_base(user) is emergency_user:
                if is_top:
                    return user
                else:
                    return None
            authenticated = True

            if self._authorizeUser(
                user, accessed, container, name, value, roles):
                return user

        # We found a user, that is authenticated, and comes form
        # repoze, forbid access.
        if (authenticated and
            request.environ.get('REMOTE_USER') is not None and
            request.environ.get('repoze.who.identity') is not None):
            raise Forbidden(u"You don't have access to this resource.")

        if not is_top:
            return None

        #
        #   No other user folder above us can satisfy, and we have no user;
        #   return a constructed anonymous only if anonymous is authorized.
        #
        anonymous = self._createAnonymousUser(plugins)
        if self._authorizeUser(
            anonymous, accessed, container, name, value, roles):
            return anonymous

        return None
