# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from AccessControl import ClassSecurityInfo
from App.class_init import InitializeClass

from Products.PluggableAuthService.plugins.BasePlugin import BasePlugin
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

from zope.interface import implements
from silva.pas.wsgi.interfaces import IWSGIUserPlugin
from repoze.who.api import get_api


class WSGIUserPlugin(BasePlugin):
    """Add a WSGI user pas plugin.
    """
    security = ClassSecurityInfo()
    meta_type = 'Silva WSGI User Plugin'
    implements(IWSGIUserPlugin)

    def __init__(self, id, title=None):
        # BasePlugin lacks of a default working __init__
        self._setId(id)
        self.title = title

    def extractCredentials(self, request):
        """Extract if available user credentials.
        """
        login = request.environ.get('REMOTE_USER', None)
        if login is not None:
            return {'login': login, 'password': login}
        return {}

    security.declarePrivate('authenticateCredentials')
    def authenticateCredentials(self, credentials):
        """Directly approve user credentials. If first_name and
        last_name are defined they will the UserName of the user, his
        UserId will still be his login.
        """
        request = self.REQUEST
        if credentials['login'] == request.environ.get('REMOTE_USER'):
            fullname = credentials['login']
            if 'repoze.who.identity' in request.environ:
                first_name = request.environ.get('first_name')
                last_name = request.environ.get('last_name')
                if first_name and last_name:
                    fullname = u'%s %s' % (first_name, last_name)
            return (credentials['login'], fullname)
        return None

    security.declarePrivate('getGroupsForPrincipal')
    def getGroupsForPrincipal(self, principal, request=None):
        if request is None:
            request = self.REQUEST
        if principal._login == request.environ.get('REMOTE_USER'):
            if 'repoze.who.identity' in request.environ:
                identity = request.environ['repoze.who.identity']
                return tuple(identity.get('groups'))
        return tuple()

    security.declarePrivate('challenge')
    def challenge(self, request, response):
        """Initiate a challenge by setting status to 401.
        """
        api = get_api(request.environ)
        api.challenge()
        return True

    security.declarePrivate('resetCredentials')
    def resetCredentials(self, request, response):
        """Call forget on repoze.who.
        """
        api = get_api(request.environ)
        api.forget()

    security.declarePrivate('enumerateUsers')
    def enumerateUsers(
        self, id=None, login=None, exact_match=False, sort_by=None,
        max_results=None, **kw):
        """We cannot list any user so we know all of them.
        """
        request = self.REQUEST
        if id == request.environ.get('REMOTE_USER'):
            return  [{'id': id, 'login': id, 'pluginid': self.getId()}]
        return []

InitializeClass(WSGIUserPlugin)


manage_addWSGIUserPluginForm = PageTemplateFile(
    'www/userAddForm',
    globals(),
    __name__="manage_addWSGIUserPluginForm")


def manage_addWSGIUserPlugin(self, id, title='', RESPONSE=None ):
    """Add a WSGI user pas plugin.
    """
    plugin = WSGIUserPlugin(id, title)
    self._setObject(id, plugin)

    if RESPONSE is not None:
        RESPONSE.redirect('manage_workspace')
