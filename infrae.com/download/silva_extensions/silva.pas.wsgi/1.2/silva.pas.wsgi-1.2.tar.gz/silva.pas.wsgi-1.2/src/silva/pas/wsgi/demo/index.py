# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt.
import bisect

def common_start(str, str_cmp):
    i = 0
    min_len = min(len(str), len(str_cmp))
    while i < min_len:
        if str[i] != str_cmp[i]:
            break
        i += 1
    return (i, str[0:i])


class Node(object):
    children = None
    infix = None # wikipedia!
    value = None

    def __init__(self, infix, value=None):
        self.infix = infix
        self.value = value

    def add_child(self, child_node):
        if self.children is None:
            self.children = []
        bisect.insort_right(self.children, child_node)

    def remove_child(self, child_node):
        index = self.children.index(child_node)
        del self.children[index]

    def __lt__(self, other):
        return self.infix < other.infix

    def display(self, io, indent=0):
        print "%s|" % (" " * (indent))
        print "%s+--+ '%s' | %s" % (" " * indent, self.infix, str(self.value))
        for child in (self.children or []):
            child.display(io, indent=indent + 3)

    def values(self):
        values = set()
        if self.value:
            values.add(self.value)
        if self.children:
            for child in self.children:
                values = values.union(child.values())
        return values

    def search(self, string, buf='', pos=0):
        if not string:
            return self.values()

        for child in self.children or []:
            if len(string) >= len(child.infix):
                if string.startswith(child.infix):
                    return child.search(
                        string[len(child.infix):],
                        buf + self.infix,
                        pos + len(self.infix))
            else:
                if child.infix.startswith(string):
                    return child.values()

        return set()

    def add(self, string, value=None):
        if not string:
            self.value = value
            return

        for child in self.children or []:
            if child.infix == string:
                child.add('', value=value or string)
            common_len, common_suffix = common_start(child.infix, string)
            if common_len:
                if common_len == len(child.infix):
                    return child.add(
                        string[common_len:], value=value or string)

                self.remove_child(child)
                child.infix = child.infix[common_len:]
                new_base = Node(common_suffix)
                new_base.add_child(child)
                self.add_child(new_base)
                return new_base.add(string[common_len:], value=value or string)

        node = Node(string, value is not None and value or string)
        self.add_child(node)
        return node


class WildcardSearch(object):

    def __init__(self, values):
        self.tree = Node('', None)
        self.mapping = {}
        for kid, key  in enumerate(values.keys()):
            self.mapping[kid + 1] = values[key]
            key = key + '$'
            for position in range(len(key)):
                search_key = key[position:] + key[0:position]
                self.tree.add(search_key, kid + 1)

    def __call__(self, string, exact_match=False):
        ids = None
        if exact_match:
            string = '$' + string + '$'
        for part in string.lower().split('*'):
            part_ids = self.tree.search(part)
            if ids:
                ids = ids.intersection(part_ids)
            else:
                ids = part_ids
        return map(lambda id: self.mapping[id], ids)
