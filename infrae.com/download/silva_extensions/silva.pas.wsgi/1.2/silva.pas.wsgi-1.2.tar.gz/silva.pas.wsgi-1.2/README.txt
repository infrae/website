==============
silva.pas.wsgi
==============

`silva.pas.wsgi` add support into Zope 2 to use WSGI authentication
provided by `repoze.who`_ by providing a PAS plugin for it. This
extension is used in Silva in conjunction with `silva.pas.base`_.

Of course, `repoze.who`_ must be used in your WSGI stack.

.. _repoze.who: http://docs.repoze.org/who/2.0/
.. _silva.pas.base: http://infrae.com/download/silva_extensions/silva.pas.base
