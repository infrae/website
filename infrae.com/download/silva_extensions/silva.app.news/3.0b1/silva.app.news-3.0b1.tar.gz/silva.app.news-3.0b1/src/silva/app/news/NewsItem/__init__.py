
from silva.app.news.NewsItem.content import NewsItem, NewsItemVersion
from silva.app.news.NewsItem.content import NewsItemVersionCatalogingAttributes
