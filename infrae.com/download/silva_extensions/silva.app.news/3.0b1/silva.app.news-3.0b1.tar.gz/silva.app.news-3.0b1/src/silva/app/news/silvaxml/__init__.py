# this is a package

NS_NEWS_URI = 'http://infrae.com/namespace/silva-app-news'
