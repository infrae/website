# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# this is a package

from silva.core.xml import registerNamespace

NS_NEWS_URI = 'http://infrae.com/namespace/silva-app-news'
registerNamespace('silva-app-news', NS_NEWS_URI)
