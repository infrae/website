silvatheme.multiflex
====================

``silvatheme.multiflex`` demo theme for Silva based on
`silva.core.layout`_.

.. _silva.core.layout: http://infrae.com/download/silva_all/silva.core.layout



