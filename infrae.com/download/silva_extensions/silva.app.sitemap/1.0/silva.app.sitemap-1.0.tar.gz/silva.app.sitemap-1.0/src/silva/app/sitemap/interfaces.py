# -*- coding: utf-8 -*-
# Copyright (c) 2012 Infrae. All rights reserved.
# See also LICENSE.txt

from silva.core.interfaces.service import ISilvaLocalService


class ISitemapService(ISilvaLocalService):
    """ A Service for configuration sitemaps.
    """
