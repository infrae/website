=================
silva.app.sitemap
=================

Introduction
============

``silva.app.sitemap`` is an extension let you generate xml sitemaps
0.9 (see http://www.sitemaps.org/protocol.html).

A view ``sitemap.xml`` available on every folder of your site will let
you access the sitemap.

A local service will permit you to configure which contetnt you want to
see in the sitemap.


Code repository
===============

Source code can be found at:
https://hg.infrae.com/silva.app.sitemap
