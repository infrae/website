======================
silva.searchandreplace
======================

``silva.searchandreplace`` let you add a new `Silva`_ service *Silva
Search and Replace Service* for Silva 2.2 and higher that is able to
search inside multiple documents, and replace found strings with a new
provided value.

.. _Silva: http://infrae.com/products/silva


