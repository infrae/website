# Copyright (c) 2009-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 38861 2010-01-05 16:40:18Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.searchandreplace')
silvaconf.extensionTitle('Silva Search and Replace')
silvaconf.extensionSystem()
