=======================
silva.security.overview
=======================

Introduction
============

``silva.security.overview`` add a new service that index all access
settings throughout all a Silva site.

In one ZMI management screen it let manager look for user access across
all the site.

You have the possibility to export the access definition in a CSV
file.

It requires at least Silva 3.0. For Silva 2.3, please look at older versions.

Code repository
===============

You can find the code for this extension in Mercurial:
https://hg.infrae.com/silva.security.overview/.
