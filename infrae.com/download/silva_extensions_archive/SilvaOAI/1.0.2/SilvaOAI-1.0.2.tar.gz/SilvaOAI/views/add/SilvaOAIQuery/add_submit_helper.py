##parameters=model, id, title, result

oai_storage_id = result['oai_storage_id']
model.manage_addProduct['SilvaOAI'].manage_addQuery(id, title, oai_storage_id)

return getattr(model, id) 
