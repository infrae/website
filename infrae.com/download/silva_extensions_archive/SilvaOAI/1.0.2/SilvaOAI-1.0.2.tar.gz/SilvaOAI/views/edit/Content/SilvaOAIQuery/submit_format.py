model = context.REQUEST.model
view = context

model.setMetadataFormat(context.REQUEST['metadata_format'])
return view.tab_edit(message_type="feedback", message="Silva OAI Query Changed")
