##parameters=index
model = context.REQUEST.model

# Ugh.
trun = lambda y: y[:70] + test(len(y) > 70, '..', '')
tup = lambda z: (z, z)

result = [('All values', 'none')]
values = [tup(trun(unicode(value)))
           for value in model.getCatalog().uniqueValuesFor(index)]

values.sort()
return result + values
