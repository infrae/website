## Script (Python) "render_field"
##parameters=field
from DateTime import DateTime
if field:
    if same_type(field, DateTime()):
        field = field.strftime('%d-%m-%Y')
    else:
        if same_type(field, []):
            field = ", ".join(field)
return field
