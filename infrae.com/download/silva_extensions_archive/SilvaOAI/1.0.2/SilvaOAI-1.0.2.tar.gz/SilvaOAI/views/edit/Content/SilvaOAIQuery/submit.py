from Products.Formulator.Errors import ValidationError, FormValidationError
request = context.REQUEST
model = request.model
view = context

try:
    result = model.get_form().validate_all(context.REQUEST)
except FormValidationError, e:
    return view.tab_edit(message_type="error",
                         message=view.render_form_errors(e))

if result['set'] == 'none':
    model.set_set(None)
else:
    model.set_set(result['set'])

model.set_filters(result)

if request['input_intro_text']:
    model.set_intro_text(request['input_intro_text'])
    
return view.tab_edit(message_type="feedback", message="Silva OAI Query Changed")
