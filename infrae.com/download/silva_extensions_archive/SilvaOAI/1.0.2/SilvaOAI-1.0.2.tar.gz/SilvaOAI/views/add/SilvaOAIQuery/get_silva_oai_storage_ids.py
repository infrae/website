# XXX replace this with interface or method call to get parents directly?

storage_ids = []
for parent in context.REQUEST.PARENTS:
    objects = parent.objectValues(['OAIPMH Service'])
    for object in objects:
        storage_ids.append((object.id, object.id))
return storage_ids
