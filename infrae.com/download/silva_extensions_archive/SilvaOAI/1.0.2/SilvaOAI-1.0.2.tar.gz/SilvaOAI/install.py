from Products.FileSystemSite.DirectoryView import manage_addDirectoryView
from Products.Silva.install import add_fss_directory_view

def install(root):
    add_fss_directory_view(root.service_views, 'SilvaOAI', __file__, 'views')
    registerViews(root.service_view_registry)

    # re-configure security for not only managers
    # may add Silva OAI Query objects
    configureSecurity(root)

    # configure meta data bindings for the Silva OAI content
    # this will set up the title as metadata (and some more ...)
    configureMetadata(root)

def uninstall(root):
    unregisterViews(root.service_view_registry)
    root.service_views.manage_delObjects(['SilvaOAI'])
    # XXX unregister metadata when possible
    
def is_installed(root):
    return hasattr(root.service_views, 'SilvaOAI')

def registerViews(reg):
    reg.register('edit', 'Silva OAI Item', ['edit', 'Content', 'SilvaOAIItem'])
    reg.register('edit', 'Silva OAI Query', ['edit', 'Content', 'SilvaOAIQuery'])

    reg.register('public', 'Silva OAI Item', ['public', 'SilvaOAIItem'])
    reg.register('public', 'Silva OAI Query', ['public', 'SilvaOAIQuery'])
    
    reg.register('add', 'Silva OAI Item', ['add', 'SilvaOAIItem'])
    reg.register('add', 'Silva OAI Query', ['add', 'SilvaOAIQuery'])

def configureSecurity(root):
    """ add security declarations to allo Authors
        to add Silva Demo Extension instances """
    # cut & paste from Products.Silva.install.configureSecurity
    all_author = ['Author', 'Editor', 'ChiefEditor', 'Manager']
    root.manage_permission('Add Silva OAI Querys', all_author)    
    
def configureMetadata(root):
    """ add the default bindings of metadata for the
    oai Query and Item. """

    mapping = root.service_metadata.getTypeMapping()
    # XXX this information gets lost objectn a "Silva" refresh :(
    import zLOG
    zLOG.LOG('silva extension', -100, 'Extension configure metadata')
    my_mappings = (
        {'type' : 'Silva OAI Item',
         'chain': 'silva-content, silva-extra'},
        {'type' : 'Silva OAI Query',
         'chain': 'silva-content, silva-extra'}
        )
    # FIXME I do not want to set the default-chain here,
    # but I have to if I add something via "editMappings"
    default_chain = mapping.getDefaultChain()
    mapping.editMappings(default_chain, my_mappings)

    # zLOG.LOG('silva extension', -100,
    #          'set demo extension to:'+root.service_metadata.getTypeMapping().getChainFor('??'))
    
def unregisterViews(reg):
    reg.unregister('edit', 'Silva OAI Item')
    reg.unregister('edit', 'Silva OAI Query')
    
    reg.unregister('public', 'Silva OAI Item')
    reg.unregister('public', 'Silva OAI Query')
    
    reg.unregister('add', 'Silva OAI Item')
    reg.unregister('add', 'Silva OAI Query')

def registerMetadata(reg):
    mapping = reg.getTypeMapping()
    tm = (
        {'type':'Silva OAI Query', 'chain':'silva-content, silva-extra'},
        {'type':'Silva OAI Item', 'chain':'silva-content, silva-extra'},
        )
    mapping.editMappings('', tm)
    
