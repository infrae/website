# SilvaOAI
# Silva objects for OAI

from Products.FileSystemSite.DirectoryView import registerDirectory
import silvaoai
from Products.Silva.ExtensionRegistry import extensionRegistry
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
import install

def initialize(context):
    extensionRegistry.register(
        'SilvaOAI', 'Silva OAI', context, [],
        install, depends_on='Silva')
    
    context.registerClass(

        silvaoai.Query,
        constructors = (silvaoai.manage_addQueryForm,
                        silvaoai.manage_addQuery),
        icon = "www/silvaoai_query.png"
        )

    extensionRegistry.addAddable('Silva OAI Query', 3)
            
    registerDirectory('views', globals())
    registerTypeForMetadata(silvaoai.Query.meta_type)
    registerTypeForMetadata(silvaoai.Item.meta_type)
