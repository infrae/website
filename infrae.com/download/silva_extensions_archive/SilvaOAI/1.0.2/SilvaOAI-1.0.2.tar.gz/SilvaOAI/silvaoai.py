from DateTime import DateTime
# Zope
from OFS import SimpleItem
from AccessControl import ClassSecurityInfo
from Globals import InitializeClass
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
# Silva
from Products.Silva.Content import Content
from Products.Silva import SilvaPermissions
# Formulator
from Products.Formulator.Form import ZMIForm


# Item

icon = "www/silvageneric.gif"
class Item(Content, SimpleItem.SimpleItem):
    """An item.
    """
    
    security = ClassSecurityInfo()
    
    meta_type = 'Silva OAI Item'
    
    def __init__(self, obj):
        self.id = obj.id
        self._obj = obj

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'getObj')
    def getObj(self):
        """Get underlying object.
        """
        return self._obj

    security.declareProtected(
        SilvaPermissions.ChangeSilvaContent, 'setSpec')
    def setSpec(self):
        """setSpec
        """
        return self._obj.setSpec()
    
InitializeClass(Item)

class BaseQuery(Content, SimpleItem.SimpleItem):
    """Query base class.
    """
    security = ClassSecurityInfo()

    def __init__(self, id, title, service):
        BaseQuery.inheritedAttribute('__init__')(self, id, title)
        self._service = service
        self._metadata_format = None
        
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'getService')
    def getService(self):
        """Get the OAI service the query is to use.
        """
        return getattr(self, self._service)
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'getCatalog')
    def getCatalog(self):
        """Get OAI catalog.
        """
        return self.getService().getCatalog(self._metadata_format)

    security.declarePublic(
        SilvaPermissions.AccessContentsInformation, 'getStorage')
    def getStorage(self):
        """Get OAI Storage.
        """
        return self.getService().getStorage(self._metadata_format)

    security.declarePublic(
        SilvaPermissions.AccessContentsInformation, 'getMetadataFormat')
    def getMetadataFormat(self):
        return self._metadata_format
        
    def __getitem__(self, id):
        """Return item with id wrapped in context of query.
        """
        # XXX could do a catalog query here to check whether this object
        # is within query parameters, but we won't for performance
        # reasons
        return Item(self.getStorage()._getOb(id)).__of__(self)

    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                              'is_published')
    def is_published(self):
        """Always be published."""
        return 1

    security.declareProtected(
        SilvaPermissions.ChangeSilvaContent, 'setMetadataFormat')
    def setMetadataFormat(self, format):
        """Set the metadata format.
        """
        self._metadata_format = format

InitializeClass(BaseQuery)
    
class Query(BaseQuery):
    """A query for items.

    A query consists of two parts -- one restricts the items by
    certain criteria, the other can be used to search in these items.
    """

    security = ClassSecurityInfo()

    meta_type = 'Silva OAI Query'

    def __init__(self, id, title, service):
        Query.inheritedAttribute('__init__')(self, id, title, service)
        self._filters = {}
        self._searchables = []
        self._setSpec = None
        self._start_dt = None
        self._end_dt = None
        self._intro_text = None
        self._unique_values = {}
        self._cache_time = {}
        
    # MANIPULATORS
    
    security.declareProtected(
        SilvaPermissions.ChangeSilvaContent, 'set_intro_text')
    def set_intro_text(self, text):
        self._intro_text = text
        
    security.declareProtected(
        SilvaPermissions.ChangeSilvaContent, 'set_filters')
    def set_filters(self, dict):
        """Set the filters dictionary (Filter results to be returned on
        values of fields in self._filters.)
        """
        self._filters = {}
        self._unique_values = {}
        self._cache_time = {}
        for key in dict.keys():
            if dict[key] and not dict[key] == ['none']:
                self._filters[key] = dict[key]
            elif self._filters.has_key(key):
                del self._filters[key]
                
    security.declareProtected(
        SilvaPermissions.ChangeSilvaContent, 'set_set')
    def set_set(self, setSpec):
        """Only return items in particular set.
        """
        if setSpec and setSpec != ['none']:
            self._setSpec = setSpec
        else:
            self._setSpec = None

    # ACCESSORS

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_intro_text')
    def get_intro_text(self):
        return self._intro_text
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_set')
    def get_set(self):
        return self._setSpec

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_fields')
    def get_fields(self):
        return self.getService().getSchema(
            self._metadata_format).getFields()
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_user_searchables')
    def get_user_searchables(self):
        return self.getService().getSchema(
            self._metadata_format).getUserSearchables()

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_initial_sort_on')
    def get_initial_sort_on(self):
        return self.getService().getSchema(
            self._metadata_format).getInitialSortOn()

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_initial_sort_order')
    def get_initial_sort_order(self):
        return self.getService().getSchema(
            self._metadata_format).getInitialSortOrder()
            
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_value_for_index')
    def get_value_for_index(self, index):
        if hasattr(self, index):
            return getattr(self, index)
        return None

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_columns')
    def get_columns(self):
        return self.getService().getSchema(
            self._metadata_format).getResultColumns()

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_item_fields')
    def get_item_fields(self):
        """Get fields to be displayed.
        """
        return self.getService().getSchema(
            self._metadata_format).getItemFields()
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_metadata_formats')
    def get_metadata_formats(self):
        return self.getService().getMetadataFormats()

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_filters')
    def get_filters(self):
        return self._filters

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_filtered_fields')
    def get_filtered_fields(self):
        result = []
        for field in self._filters.keys():
            if field[:9] == 'metadata_' and self._filters[field]:
                result.append(field)
                return result

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_form')
    def get_form(self):
        catalog = self.getCatalog()
        query_form = ZMIForm('query_form', 'Query Form', 1)
        query_form.manage_addField('set', 'Set', 'MultiListField')
        values = query_form.get_field('set').values
        values['size'] = 3
        values['required'] = 0
        values['unicode'] = 1
        filters = self.get_filters()
        if filters.has_key('set'):
            values['default'] = self._filters['set']
        service = self.getService()
        toplevel_sets = service.getSubSets(None)
        result = [('All sets', 'none')]
        for key in sorted_keys_by_value(toplevel_sets):
            result.append((toplevel_sets[key], key))
            sets = service.getSubSets(key)
            for subkey in sorted_keys_by_value(sets):
                result.append(('... %s' % sets[subkey], subkey))
        values['items'] = result
        for field in self.get_fields():
            field.addEditField(query_form, filters, catalog)
        return query_form.__of__(self)

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_unique_values')
    def get_unique_values(self, column):
        if not hasattr(self, '_unique_values'):
            # XXX Defensive code, to prevent having to throw away all 
            # old queries. Could go if we ever have the time to make
            # an upgrade script
            self._unique_values = {}
            self._cache_time = {}
        unique_values = self._unique_values.get(column, None)
        if unique_values:
            cache_time = self._cache_time.get(column, None)
            if (cache_time and
                cache_time > self.getService().getDatestamp()):
                return unique_values
        result = []
        result_query = self.query()
        for brain in result_query:
            list = brain[column]
            if list:
                for value in list:
                    if value not in result:
                        result.append(value)
        result.sort()
        self._unique_values[column] = result
        self._cache_time[column] = DateTime()
        return self._unique_values[column]

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_user_form')
    def get_user_form(self):
        query_form = ZMIForm('user_form', 'Search Form', 1)
        service = self.getService()
        user_searchables = self.get_user_searchables()
        for field in self.get_fields():
            id = field.getId()
            if id in user_searchables and not self._filters.has_key(id):
                unique_values = []
                if field.getIndexType() == 'KeywordIndex':
                    for value in self.get_unique_values(id):
                        unique_values.append((value[:60], value))
                field.addPublicField(query_form, unique_values)
        query_form.manage_addField('fulltext', 'Fulltext Search', 'StringField')
        values = query_form.get_field('fulltext').values
        values['required'] = 0
        values['unicode'] = 1
        return query_form.__of__(self)
                
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_query')
    def get_query(self):
        q = {}
        if self._setSpec is not None:
            q['setSpec'] = self._setSpec
        filters = self.get_filters()
        for field in self.get_fields():
            field.updateQuery(q, self.get_filters())
        q['sort_order'] = self.get_initial_sort_order()
        q['sort_on'] = self.get_initial_sort_on()
        return q

    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'get_user_query')
    def get_user_query(self, REQUEST):
        result = self.get_user_form().validate_all(REQUEST)
        q = {}
        user_searchables = self.get_user_searchables()
        for field in self.get_fields():
            id = field.getId()
            if id in user_searchables and not self._filters.has_key(id):
                unique_values = None
                if field.getIndexType() == 'KeywordIndex':
                    unique_values = self.get_unique_values(id)
                field.updatePublicQuery(q, result, unique_values)
        fulltext = result.get('fulltext', None)
        if fulltext:
            q['fulltext'] = fulltext
        sort_on = REQUEST.form.get('sort_on')
        if sort_on:
            q['sort_on'] = sort_on
        sort_order = REQUEST.form.get('sort_order')
        if sort_order:
            q['sort_order'] = sort_order
        return q
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'user_query')
    def user_query(self):
        q = self.get_query()
        req = self.REQUEST
        uq = self.get_user_query(req)
        q.update(uq)
        return self.getCatalog()(q)
    
    security.declareProtected(
        SilvaPermissions.AccessContentsInformation, 'query')
    def query(self):
        return self.getCatalog()(self.get_query())

    def is_deletable(self):
        """A Query is always deletable. (Since it is always published, the
        choices for deletable are always or never, and never makes the least
        sense ;)
        """
        return 1
    
InitializeClass(Query)
    
manage_addQueryForm = PageTemplateFile(
    "www/queryAdd", globals(),
    __name__='manage_addQueryForm')

def manage_addQuery(self, id, title, service, REQUEST=None):
    """Add OAI query.
    """
    object = Query(id, title, service)
    self._setObject(id, object)
    object = getattr(self, id)
    object.set_title(title)
    return ''

def sorted_keys_by_value(dict):
    result = [(value, key) for key, value in dict.items()]
    result.sort()
    result = [key for value, key in result]
    return result
