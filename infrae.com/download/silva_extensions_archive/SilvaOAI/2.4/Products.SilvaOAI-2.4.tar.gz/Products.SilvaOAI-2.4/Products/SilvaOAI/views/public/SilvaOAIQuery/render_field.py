## Script (Python) "render_field"
##parameters=field
from DateTime import DateTime
if field:
    if same_type(field, DateTime()):
        field = "%(year)04d-%(month)02d-%(day)02d" % {
            'year':field.year(), 
            'month': field.month(), 
            'day': field.day()}
    else:
        if same_type(field, []):
            field = ", ".join(field)
return field
