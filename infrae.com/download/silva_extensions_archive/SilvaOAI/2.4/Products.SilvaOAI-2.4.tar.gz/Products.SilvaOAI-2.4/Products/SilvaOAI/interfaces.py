from zope.interface import Interface

class ISilvaOAIQuery(Interface):
    """Marker interface for Silva OAI Query objects"""

class ISilvaOAIItem(Interface):
    """Marker interface for Silva OAI Item objects"""
