# Copyright (c) 2002-2007 Infrae. All rights reserved.
# See also LICENSE.txt

from Globals import InitializeClass, package_home
from AccessControl import ClassSecurityInfo
from OFS import SimpleItem
from zope.interface import implements

from Products.PageTemplates.PageTemplateFile import PageTemplateFile

from Products.Formulator.Form import ZMIForm

from Products.Silva.interfaces import IAsset
from Products.Silva import SilvaPermissions as permissions
from Products.Silva import helpers

from Products.Silva.SilvaObject import SilvaObject
from Products.Silva.Asset import Asset

from Products.SilvaExternalSources.interfaces import IExternalSource
from Products.SilvaExternalSources.ExternalSource import ExternalSource

from Products.OAICore.query import ManageableQuery
from Products.SilvaOAI.silvaoai import AutocompletionQueryFieldMixIn

class QuerySource(AutocompletionQueryFieldMixIn, ManageableQuery, ExternalSource, SimpleItem.SimpleItem):
    """Hybrid OAI Query, ExternalSource
    """

    implements(IExternalSource)

    security = ClassSecurityInfo()

    def __init__(self, id, service):
        ManageableQuery.__init__(self, service)
        self.id =  id

    # OAI
    security.declareProtected(
        permissions.ChangeSilvaContent, 'updateManageForm')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'getManageForm')
    def getManageForm(self):
        query_form = ZMIForm('query_form', 'Query Form', 1)
        self.updateManageForm(query_form)
        return query_form.__of__(self)

    # Override some permissions
    security.declareProtected(
        permissions.ChangeSilvaContent, 'getMetadataFormat')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'getService')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSet')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSort')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSortOrder')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setFilters')

    # ExternalSource
    security.declareProtected(permissions.ChangeSilvaContent, 'form')
    def form(self):
        # No need for a document editor level form - everything is
        # handled from the query source itself. At the moment.
        return ZMIForm('empty', 'Empty', 1).__of__(self)

    security.declareProtected(
        permissions.AccessContentsInformation, 'to_html')
    def to_html(self, REQUEST, **kw):
        """Render HTML for inclusion in Silva Documents.
        """
        results = self.queryResults({})
        return self.records_layout(results=results)

    security.declareProtected(
        permissions.AccessContentsInformation, 'records_layout')
    records_layout = PageTemplateFile(
        "www/records.zpt", globals(), __name__='records_layout')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'is_cacheable')
    def is_cacheable(self, *args, **kw):
        return False

    security.declareProtected(
        permissions.ChangeSilvaContent, 'data_encoding')
    def data_encoding(self):
        return 'utf-8'

    security.declareProtected(permissions.ChangeSilvaContent, 'description')
    def description(self):
        return 'List OAI items'

class QuerySourceAsset(QuerySource, SilvaObject):
    """A Query Source is a hybrid asset. It returns results of a search within
       a harvested OAI repository and is also an External Source that can
       be embedded in documents.
    """

    implements(IExternalSource, IAsset)

    meta_type = "Silva OAI Source"

    security = ClassSecurityInfo()

    # Silva Asset
    security.declareProtected(
        permissions.AccessContentsInformation, 'is_deletable')
    def is_deletable(self):
        return 1

    security.declareProtected(
        permissions.AccessContentsInformation, 'is_published')
    def is_published(self):
        return 1

    security.declareProtected(
        permissions.AccessContentsInformation, 'get_title')
    def get_title (self):
        return SilvaObject.get_title(self)

    def to_html(self, REQUEST, **kw):
        """Render HTML for inclusion in Silva Documents.
        """
        results = self.queryResults({})
        return self.recordsLayout(results=results)

    security.declareProtected(
        permissions.AccessContentsInformation, 'recordsLayout')
    def recordsLayout(self, results):
        return self.public['records'](results=results)


InitializeClass(QuerySourceAsset)


manage_addQueryForm = PageTemplateFile(
    "www/queryAdd", globals(),
    __name__='manage_addQueryForm')

def manage_addQuerySourceAsset(context, id, title, service, REQUEST=None):
    query = QuerySourceAsset(id, service)
    # XXX needs id validation
    context._setObject(id, query)
    query = getattr(context, id)
    query.set_title(title)
    helpers.add_and_edit(context, id, REQUEST)
    return query
