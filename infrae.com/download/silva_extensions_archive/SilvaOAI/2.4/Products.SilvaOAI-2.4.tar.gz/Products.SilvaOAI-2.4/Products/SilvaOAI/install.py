from Products.FileSystemSite.DirectoryView import manage_addDirectoryView
from Products.Silva.install import add_fss_directory_view
from silvaoai import Query, Item
from oaisource import QuerySourceAsset
from cherrypicking import Cherry

query_type = Query.meta_type
item_type = Item.meta_type
asset_type = QuerySourceAsset.meta_type
cherry_type = Cherry.meta_type

types = [
    query_type, 
    asset_type, 
    ]

def install(root):
    add_fss_directory_view(root.service_views, 'SilvaOAI', __file__, 'views')
    add_fss_directory_view(root, 'silvaoai_images', __file__, 'images')
    registerViews(root.service_view_registry)
    configureSecurity(root)
    configureMetadata(root)
    configureAddables(root)
    configureLayout(root)
    
def uninstall(root):
    unregisterViews(root.service_view_registry)
    root.service_views.manage_delObjects(['SilvaOAI'])
    root.manage_delObjects(['silvaoai_images'])
    # XXX unregister metadata when possible
    
def is_installed(root):
    return hasattr(root.service_views, 'SilvaOAI')

def registerViews(reg):

    reg.register('add', query_type, ['add', 'SilvaOAIQuery'])
    reg.register('edit', query_type, ['edit', 'Content', 'SilvaOAIQuery'])
    reg.register('public', query_type, ['public', 'SilvaOAIQuery', 'view'])
    reg.register('preview', query_type, ['public', 'SilvaOAIQuery', 'preview'])

    reg.register('public', item_type, ['public', 'SilvaOAIItem', 'view'])
    reg.register('preview', item_type, ['public', 'SilvaOAIItem', 'preview'])

    reg.register('add', asset_type, ['add', 'SilvaOAIQuery']) #reusing view
    reg.register('edit', asset_type, ['edit', 'Asset', 'QuerySourceAsset'])
    reg.register('public', asset_type, ['public', 'QuerySourceAsset', 'view'])
    reg.register('preview', asset_type, ['public', 'QuerySourceAsset', 'preview'])

    type = cherry_type
    reg.register('public', type, ['public', 'QuerySourceAsset', 'view'])
    reg.register('preview', type, ['public', 'QuerySourceAsset', 'preview'])
    
    
def configureSecurity(root):
    """ add security declarations to allo Authors
        to add Silva Demo Extension instances """
    # cut & paste from Products.Silva.install.configureSecurity
    all_author = ['Author', 'Editor', 'ChiefEditor', 'Manager']
    root.manage_permission('Add Silva OAI Querys', all_author)    
    
def configureMetadata(root):
    """ add the default bindings of metadata for the
    oai Query and Item. """

    mapping = root.service_metadata.getTypeMapping()
    # XXX this information gets lost objectn a "Silva" refresh :(
    import zLOG
    zLOG.LOG('silva extension', -100, 'Extension configure metadata')
    my_mappings = (
        {'type' : item_type,
         'chain': 'silva-content, silva-extra'},
        {'type' : query_type,
         'chain': 'silva-content, silva-extra'},
        {'type' : asset_type,
         'chain': 'silva-content, silva-extra'},
        )
    # FIXME I do not want to set the default-chain here,
    # but I have to if I add something via "editMappings"
    default_chain = mapping.getDefaultChain()
    mapping.editMappings(default_chain, my_mappings)

    # zLOG.LOG('silva extension', -100,
    #          'set demo extension to:'+root.service_metadata.getTypeMapping().getChainFor('??'))
    
def unregisterViews(reg):
    for type in types:
        reg.unregister('add', type)    
        reg.unregister('edit', type)
        reg.unregister('public', type)
        reg.unregister('preview', type)
    reg.unregister('public', item_type)
    reg.unregister('preview', item_type)
    reg.unregister('public', cherry_type)
    reg.unregister('preview', cherry_type)
        
def registerMetadata(reg):
    mapping = reg.getTypeMapping()
    tm = (
        {'type':query_type, 'chain':'silva-content, silva-extra'},
        {'type':item_type, 'chain':'silva-content, silva-extra'},
        {'type':asset_type, 'chain':'silva-content, silva-extra'},
        )
    mapping.editMappings('', tm)
    
def configureAddables(root):
    addables = types
    new_addables = root.get_silva_addables_allowed_in_publication()
    for addable in addables:
        if addable not in new_addables:
            new_addables.append(addable)
    root.set_silva_addables_allowed_in_publication(new_addables)

def configureLayout(root, default_if_existent=0):
    from Products.Silva import install
    for id in ['dl_oai.js', 'dl_oai.css']:
        install.add_helper(
            root, id, globals(), install.dtml_add_helper, 1)
    install.add_helper(
        root, 'directory-index.html.pt', globals(), install.pt_add_helper, 1)
