from setuptools import setup, find_packages
import os

setup(name='Products.SilvaOAI',
      version='2.4',
      description="Silva integration for OAICore.",
      classifiers=[
              "Development Status :: 5 - Production/Stable",
              "Framework :: Zope2",
              "License :: OSI Approved :: BSD License",
              "Programming Language :: Python",
              "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='zope2 silva harvesting oai oaipmh',
      author='Infrae',
      author_email='info@infrae.com',
      url='http://infrae.com/products/oaipack',
      license='BSD',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'Products.OAICore',
         ],
      )
