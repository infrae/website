# Copyright (c) 2004 Guido Wesdorp. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py,v 1.3 2004/05/31 23:33:02 johnny Exp $

from ImageFile import ImageFile
from Products.Silva.ExtensionRegistry import extensionRegistry
from Products.Silva.ImporterRegistry import importer_registry
import install

from Products.Silva.fssite import registerDirectory
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata

import SilvaBlog
import SilvaBlogCategory
import SilvaBlogArticle

misc_ = {
         'silvablogcategory_unapproved.png':ImageFile('www/silvablogcategory_unapproved.png',
         globals()) 
         }

def initialize(context):
    extensionRegistry.register(
        'SilvaBlog', 'Silva Blog', context, 
        [SilvaBlog, SilvaBlogCategory, SilvaBlogArticle],
        install, depends_on='SilvaDocument')
        
    registerDirectory('views', globals())
    
    registerTypeForMetadata(SilvaBlog.SilvaBlog.meta_type)
    registerTypeForMetadata(SilvaBlogCategory.SilvaBlogCategory.meta_type)
    registerTypeForMetadata(SilvaBlogArticle.SilvaBlogArticleVersion.meta_type)

