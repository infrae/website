# Copyright (c) 2004 Guido Wesdorp. All rights reserved.
# See also LICENSE.txt
# $Id: install.py,v 1.5 2004/05/31 23:31:39 johnny Exp $
"""Install for Silva Blog
"""

from Products.Silva.install import add_fss_directory_view
from Products.SilvaBlog import SilvaBlog
from Products.SilvaBlog import SilvaBlogCategory
from Products.SilvaBlog import SilvaBlogArticle

def install(root):
    # create the core views from filesystem
    add_fss_directory_view(root.service_views,
                           'SilvaBlog', __file__, 'views')
    # also register views
    registerViews(root.service_view_registry)

    # security
    root.manage_permission('Add Silva Blogs',
                           ['Author', 'Editor', 'ChiefEditor', 'Manager'])
    root.manage_permission('Add Silva Blog Categorys',
                           ['Author', 'Editor', 'ChiefEditor', 'Manager'])
    root.manage_permission('Add Silva Blog Articles',
                           ['Author', 'Editor', 'ChiefEditor', 'Manager'])
    root.manage_permission('Add Silva Blog Article Versions',
                           ['Author', 'Editor', 'ChiefEditor', 'Manager'])

    mapping = root.service_metadata.getTypeMapping()
    mapping.editMappings('', [
        {'type': 'Silva Blog',
        'chain': 'silva-content, silva-extra'},
        {'type': 'Silva Blog Category',
        'chain': 'silva-content, silva-extra'},
        {'type': 'Silva Blog Article Version',
        'chain': 'silva-content, silva-extra'},
        ])

    configureAddables(root)
        
def uninstall(root):
    unregisterViews(root.service_view_registry)
    root.service_views.manage_delObjects(['SilvaBlog'])
    
def is_installed(root):
    return hasattr(root.service_views, 'SilvaBlog')

def registerViews(reg):
    """Register core views on registry.
    """
    # edit
    reg.register('edit', 'Silva Blog', 
                    ['edit', 'Container', 'SilvaBlog'])
    reg.register('edit', 'Silva Blog Category', 
                    ['edit', 'Container', 'SilvaBlogCategory'])
    reg.register('edit', 'Silva Blog Article', 
                    ['edit', 'VersionedContent', 'SilvaBlogArticle'])
    # public
    reg.register('public', 'Silva Blog', 
                    ['public', 'SilvaBlog'])
    reg.register('public', 'Silva Blog Category',
                    ['public', 'SilvaBlogCategory'])
    reg.register('public', 'Silva Blog Article', 
                    ['public', 'SilvaBlogArticle'])
    # add
    reg.register('add', 'Silva Blog', 
                    ['add', 'SilvaBlog'])
    reg.register('add', 'Silva Blog Category', 
                    ['add', 'SilvaBlogCategory'])
    reg.register('add', 'Silva Blog Article', 
                    ['add', 'SilvaBlogArticle'])
    # preview
    reg.register('preview', 'Silva Blog Article Version',
                    ['preview', 'SilvaBlogArticle'])
    
def unregisterViews(reg):
    types = ['Silva Blog', 
            'Silva Blog Category',
            'Silva Blog Article']
    for meta_type in types:
        reg.unregister('edit', meta_type)
        reg.unregister('public', meta_type)
        reg.unregister('add', meta_type)

def configureAddables(root):
    """Make sure the articles aren't addable in the root"""
    current_addables = root.get_silva_addables_allowed_in_publication()
    new_addables = []
    for a in current_addables:
        if a != 'Silva Blog Article' or a != 'Silva Blog Category':
            new_addables.append(a)
    if 'Silva Blog' not in current_addables:
        new_addables.append('Silva Blog')
        
    root.set_silva_addables_allowed_in_publication(new_addables)

