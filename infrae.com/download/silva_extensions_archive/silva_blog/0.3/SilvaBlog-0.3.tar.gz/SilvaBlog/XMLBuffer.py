
# copied from SilvaNews NewsViewer
class XMLBuffer:
    """Small file-like object for XML output.
    
    Implicitly converts unicode to UTF-8 and replaces characters to 
    entities when required
    """

    def __init__(self):
        self._buffer = []

    def write(self, data):
        if type(data) != type(u''):
            data = unicode(str(data))
        self._buffer.append(data)
        
    def read(self):
        """The semantics are different from the plain file interface's read!
            
        This will return the full buffer always, and won't move the 
        pointer
        """
        ret = ''.join(self._buffer)
        ret = self._convert(ret)
        return ret

    def _convert(self, data):
        """Convert data to UTF-8.
        """
        data = data.encode('UTF-8')
        return data

def quote_xml ( data ):
    """Quote string for XML usage.
    """
    if not data:
        return data
    data = data.replace('&', '&amp;')
    data = data.replace('"', '&quot;')
    data = data.replace('<', '&lt;')
    data = data.replace('>', '&gt;')
    return data


RDFHEADER = ('<?xml version="1.0" encoding="UTF-8" ?>\n' 
              '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
              'xmlns:silvanews="http://infrae.com/namespaces/silvanews" '
              'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns="http://purl.org/rss/1.0/">\n')
