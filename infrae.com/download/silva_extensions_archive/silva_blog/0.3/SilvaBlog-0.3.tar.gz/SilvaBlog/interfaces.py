from Interface import Interface, Attribute

class ISilvaBlog(Interface):
    """Silva Blog"""
    
    comments_allowed = Attribute("Set to true if discussion is allowed for comments")
    def get_current_items(self, items):
        """get the currently published items for this blog"""
    
    def get_recent_article(self):
        """ get the last, published blog article """
    
    def get_categories(self):
        """ return list of categories for all blog articles"""
    
    def get_articles_for_category(self, category):
        """ return a list of ISilvaBlogArticle objects published under
            subject otherwise return all ISilvaBlogArticles
        """
    
    def get_editable_items(self, month, year):
        """get the current items for this blog"""
    
    def get_processed_items(self, month, year):
        """helper method overridden from ViewCode for tab_edit to
           provide a set of dicts
        """
    def get_processed_status_tree(self, status, offset, limit=25):
        """ XXX undocumented"""
    
    def set_discussion(self, on):
        """ set blog preferences"""

class ISilvaBlogCategory(Interface):
    """ a folderish Silva Blog Category """
    
    def get_current_items(self, items):
        """get the currently published items for this category"""

    def contains_unpublished_items(self):
        """returns true if the category contains unpublished articles"""

class ISilvaBlogArticle(Interface):
    """Silva Blog Article"""


    def get_category(self):
        """ returns the category the article is published under,
            None otherwise
        """

    def add_comment(self, comment, REQUEST):
        """add a comment
            
           comment (dictionary)
                title (str)
                name (str)
                email (str)
                comment (str)
        """
    
    def comments(self):
        """get all comments"""
    
    def _index_version(self, version):
        """indexes a article version"""
    
    def _update_publication_status(self):
        """updates status of publication"""

class ISilvaBlogArticleVersion(Interface):
    """Silva Blog Article Version"""
    
    default_catalog = Attribute("The id of the service catalog indexing article versions")
    
    def index_object(self, *args, **kwargs):
        """indexes object in blog catalog"""
    
    def reindex_object(self):
        """updates object in blog catalog"""
    
    def blogtitle(self):
        """returns title of the blog article"""
    
    def set_blogtitle(self, value):
        """sets the title of the blog article XXX"""
