# Copyright (c) 2004 Guido Wesdorp. All rights reserved.
# See also LICENSE.txt
# $Id: SilvaBlog.py,v 1.14 2004/06/04 19:29:36 johnny Exp $

# Zope imports
from Globals import InitializeClass
from DateTime import DateTime
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from Products.BTreeFolder2.BTreeFolder2 import BTreeFolder2

# Silva imports
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
from Products.Silva import SilvaPermissions
from Products.Silva.helpers import add_and_edit
from Products.Silva.SilvaObject import SilvaObject
from Products.Silva.Folder import Folder
from Products.Silva.interfaces import IContainer, IVersionedContent, IContent
from Products.Silva import mangle
from Products.ProxyIndex.ProxyIndex import RecordStyle

# Silva Blog imports
from Products.SilvaBlog.interfaces import ISilvaBlog
from Products.SilvaBlog.XMLBuffer import XMLBuffer, quote_xml, RDFHEADER
icon = "www/silvablog.png"

# this is nasty... a bit of a trick to get SilvaObject's methods
# get called before SimpleItem's, but BTreeFolder2's before Folder's
class SilvaBlog(SilvaObject, BTreeFolder2, Folder):
    """Silva Blog"""

    security = ClassSecurityInfo()
    meta_type = 'Silva Blog'
    __implements__ = (IContainer, ISilvaBlog)

    def __init__(self, id):
        Folder.__init__(self, id)
        BTreeFolder2.__init__(self, id)
        self._initBTrees()
        self.comments_allowed = 1
    
    def manage_afterAdd(self, *args, **kwargs):
        Folder.manage_afterAdd(self, *args, **kwargs)

    def manage_beforeDelete(self, *args, **kwargs):
        Folder.manage_beforeDelete(self, *args, **kwargs)

    def manage_afterClone(self, *args, **kwargs):
        Folder.manage_afterClone(self, *args, **kwargs)

    def get_silva_addables_allowed_in_publication(self):
        # maybe we can return assets as well later...
        return ['Silva Image', 
                'Silva Blog Article', 
                'Silva Blog Category']

    # Accessors
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_current_items')
    def get_current_items(self, items=15):
        """get the current items for this blog"""

        query = {'meta_type': 'Silva Blog Article Version', 
                                'version_status': 'public',
                                'sort_on': 'publication_datetime',
                                'sort_order': 'descending',
                                'path': '/'.join(self.getPhysicalPath()),
                                }
        objs = self.blog_catalog(query)[:items]
        return [obj.getObject().object() for obj in objs]
    
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_recent_article')
    def get_recent_article(self):
        """ get the last, published blog article """
        try:
            return self.get_current_items()[0]
        except IndexError:
            return None

    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_categories')
    def get_categories(self):
        """ return list of categories for all blog articles"""
        categories = []
        tree = self.get_public_tree(0)
        for depth,obj in tree:
          if IContainer.isImplementedBy(obj) and\
             not obj in categories:
            categories.append(obj)
        return categories 
    
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_articles_for_category')
    def get_articles_for_category(self, category=None):
        """ return a list of ISilvaBlogArticle objects published under
            subject otherwise return all ISilvaBlogArticles
        """
        if category is None:
          return self.get_current_items()
        
        categories = self.get_categories()
        for cat in categories:
          if category == cat.get_title():
            return cat.get_ordered_publishables()
            
        
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_editable_items')
    def get_editable_items(self, month=None, year=None):
        """get the current items for this blog
           returns list of tuples (obj, publication_datetime)
        """
        if month is None:
            month = DateTime().month()
        if year is None:
            year = DateTime().year()
        endmonth = month + 1
        endyear = year
        if endmonth > 12:
            endmonth = 1
            endyear += 1
            
        start = DateTime('%s/%s/01' % (year, month))
        end = DateTime('%s/%s/01' % (endyear, endmonth))
        query = {'meta_type': 'Silva Blog Article Version', 
                                'sort_on': 'get_modification_datetime',
                                'sort_order': 'descending',
                                'get_modification_datetime': {
                                        'query': [start, end],
                                        'range': 'minmax'},
                                'path': '/'.join(self.getPhysicalPath()),
                                }
        brains = self.blog_catalog(query)

        # we need to do more than just brain.getObject().object(), since the 
        # result of that will contain doubles (there can be different versions 
        # of one object in the query result)
        ret = []
        added = []
        for brain in brains:
            article = brain.getObject().object()
            mod_time = article.get_modification_datetime()
            container = article.get_container()
            # check if the container of the article is our blog,
            # otherwise the article is in a category (folder), which
            # shouldn't be listed in the blog view
            if article not in added and\
            ISilvaBlog.isImplementedBy(container):
                # thats sucky, but we can't test if article is in ret
                added.append(article)
                ret.append((article, mod_time))

        objs = self.objectValues(['Silva Image', 'Silva Blog Category'])
        for obj in objs:
            mod_time = obj.get_modification_datetime()
            ret.append((obj, mod_time))

        return ret

    # method overridden from ViewCode, will provide a handy set of dicts 
    # for tab_edit
    security.declareProtected(SilvaPermissions.ReadSilvaContent,
                              'get_processed_items')
    def get_processed_items(self, month=None, year=None):
        """helper method overridden from ViewCode for tab_edit to
           provide a set of dicts
        """
        i = 0
        publishables = self.get_editable_items(month, year)

        result = []
        render_icon = self.render_icon
        for item, pub_time in publishables:
            status = item.get_object_status()
            modification_datetime = item.get_modification_datetime()
            is_published = status[2] == 'published'
            is_approved = status[0] == 'approved'
            is_versioned_content = IVersionedContent.isImplementedBy(item)
            d = {
                'number': i,
                'item': item,
                'item_id': item.id,
                'title_editable': item.get_title_editable(),
                'meta_type': item.meta_type,
                'item_url': item.absolute_url(),
                'editor_link': self.get_editor_link(item),
                'status_style': status[1],
                'has_modification_time': modification_datetime,
                'modification_time': 
                    mangle.DateTime(modification_datetime).toShortStr(),
                'last_author': item.sec_get_last_author_info().fullname(),
                'is_container': IContainer.isImplementedBy(item),
                'is_versioned_content': is_versioned_content,
                'is_content': (IContent.isImplementedBy(item) and 
                                not is_versioned_content),
                'is_published': is_published,
                'is_approved': is_approved,
                'is_published_or_approved': is_published or is_approved,
                'rendered_icon': render_icon(item),
                }
            result.append(d)
            i += 1
        return result

    security.declareProtected(SilvaPermissions.ChangeSilvaContent, 
                                'get_processed_status_tree')
    def get_processed_status_tree(self, status, offset, limit=25):
        if status == 'closed':
            status = ['closed', 'last_closed']
        query = {'meta_type': 'Silva Blog Article Version', 
                                'version_status': status,
                                'sort_on': 'get_modification_datetime',
                                'sort_order': 'descending',
                                'path': '/'.join(self.getPhysicalPath()),
                                }
        objs = [obj.getObject().object() 
                  for obj in self.blog_catalog(query)[offset:offset+limit]]
        ret = []
        for obj in objs:
            infodict = {}
            ret.append(infodict)
            
            infodict['id'] = mangle.String.truncate(obj.id, 22)

            # do not smash the smi because one object is broken
            if obj.meta_type[:6] == 'Broken':
                infodict['meta_type'] = obj.meta_type
                infodict['title_html'] = 'Broken content object'
                for key in ('absolute_url', 'icon', \
                            'implements_content', 'implements_container',
                            'implements_versioning'):
                    infodict[key]=''
                continue

            infodict['title'] = obj.get_title_editable()
            infodict['meta_type'] = obj.meta_type
            infodict['absolute_url'] = obj.absolute_url()
            infodict['icon'] = self.render_icon(obj)            
            
            infodict['implements_content'] = obj.implements_content()
            if infodict['implements_content']:
                infodict['is_default'] = obj.is_default()
                infodict['container_meta_type'] = \
                          obj.get_container().meta_type

            infodict['implements_container'] = obj.implements_container()

            infodict['implements_versioning'] = obj.implements_versioning()
            if infodict['implements_versioning']:
                status, style, public_status = obj.get_object_status()
                infodict['status'] = status
                infodict['status_style'] = style
                infodict['public_status'] = public_status
                infodict['ref'] = self.create_ref(obj)

                datetime = obj.get_next_version_publication_datetime()
                if datetime:
                    str_datetime = mangle.DateTime(datetime).toShortStr()
                    infodict['next_version_publication_datetime'] = \
                                str_datetime

                datetime = obj.get_public_version_publication_datetime()
                if datetime:
                    str_datetime = mangle.DateTime(datetime).toDateStr()
                    infodict['public_version_publication_datetime'] = \
                                str_datetime

                datetime = obj.get_next_version_expiration_datetime()
                if datetime:
                    str_datetime = mangle.DateTime(datetime).toShortStr()
                    infodict['next_version_expiration_datetime'] = \
                                str_datetime
                    
                datetime = obj.get_public_version_expiration_datetime()
                if datetime:
                    str_datetime = mangle.DateTime(datetime).toDateStr()
                    infodict['public_version_expiration_datetime'] = \
                                str_datetime
        return ret

    security.declareProtected(SilvaPermissions.ChangeSilvaContent, 
                                'set_blog_prefs')
    def set_blog_prefs(self, comments_allowed):
        """ set blog preferences """
        if comments_allowed == 1:
            self.comments_allowed = 1
        else:
            self.comments_allowed = 0
        return
    
    # code copied from SilvaNews.NewsViewer
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                              'rss')
    def rss(self, REQUEST=None):
        """Return the contents of this viewer as an RSS/RDF (RSS 1.0) feed"""
        # XXX
        # damn, how to get the version from an article
        if REQUEST is not None:
            REQUEST.RESPONSE.setHeader('Content-Type', 'text/xml;charset=UTF-8')
        # get the newest items
        items = 15
        query = {'meta_type': 'Silva Blog Article Version', 
                                'version_status': 'public',
                                'sort_on': 'publication_datetime',
                                'sort_order': 'descending',
                                'path': '/'.join(self.getPhysicalPath()),
                                }
        items = self.blog_catalog(query)[:items]
        
        # create RDF/XML for the channel
        xml = XMLBuffer()
        xml.write(RDFHEADER)

        # get the metadata binding to get the metadata for this viewer
        mdbinding = self.service_metadata.getMetadata(self)
        creationdate = mdbinding.get('silva-extra', 'creationtime')
        
        # create RDF/XML frame
        xml.write('<channel rdf:about="%s">\n' % self.absolute_url())
        xml.write('<title>%s</title>\n' % quote_xml(self.get_title()))
        xml.write('<link>%s</link>\n' % self.absolute_url())
        xml.write('<description>%s</description>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'content_description')))
        xml.write('<dc:creator>%s</dc:creator>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'creator')))
        date = creationdate.HTML4()
        xml.write('<dc:date>%s</dc:date>\n' % quote_xml(date))

        # output <items> list
        # and store items in a list for later use
        xml.write('<items>\n<rdf:Seq>\n')
        for item in items:
            item = item.getObject().object()
            url = item.absolute_url()
            xml.write('<rdf:li rdf:resource="%s" />\n' % url)
        xml.write('</rdf:Seq>\n</items>\n')
        xml.write('</channel>\n\n')
        # loop over the itemslist and create the RSS/RDF item elements
        for item in items:
            self._rss_item_helper(item.getObject(), xml)
        # DONE return XML
        xml.write('</rdf:RDF>\n')
        return xml.read()

    def _rss_item_helper(self, item, xml):
        """convert a single Silva object to an RSS/RDF 'hasitem' element"""
        xml.write('<item rdf:about="%s">\n' % item.object().absolute_url())
        mdbinding = self.service_metadata.getMetadata(item)
        # RSS elements
        xml.write('<title>%s</title>\n' % quote_xml(item.object().get_title()))
        xml.write('<link>%s</link>\n' % quote_xml(item.object().absolute_url()))
        xml.write('<description>%s</description>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'content_description')))
        # DC elements
        xml.write('<dc:subject>%s</dc:subject>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'subject')))
        xml.write('<dc:creator>%s</dc:creator>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'creator')))
        xml.write('<dc:date>%s</dc:date>\n' %
                  quote_xml(mdbinding.get('silva-extra', 'creationtime').HTML4()))
                  
        xml.write('</item>\n')
        return
        
InitializeClass(SilvaBlog)

class El:
    """Helper class to initialize the catalog lexicon
    """
    def __init__(self, **kw):
        self.__dict__.update(kw)

def setup_catalog(blog):
    """Sets up the ZCatalog
    """
    # See if catalog exists, if not create one
    if not hasattr(blog, 'blog_catalog'):
        blog.manage_addProduct['ZCatalog'].manage_addZCatalog(
            'blog_catalog', 'Blog Catalog')

    catalog = blog.blog_catalog
    lexicon_id = 'blog_lexicon'

    # Add lexicon with right splitter (Silva.UnicodeSplitter.Splitter 
    # registers under "Unicode Whitespace splitter")
    # XXX ugh, hardcoded dependency on names in ZCTextIndex
    catalog.manage_addProduct['ZCTextIndex'].manage_addLexicon(
        lexicon_id, 
        elements=[El(group='Case Normalizer', name='Case Normalizer'),
                    El(group='Stop Words', name=" Don't remove stop words"),
                    El(group='Word Splitter', 
                        name="Unicode Whitespace splitter"),
                    ]
        )

    existing_indexes = catalog.indexes()
    indexes = [
        ('id', 'FieldIndex'),
        ('meta_type', 'FieldIndex'),
        ('path', 'PathIndex'),
        ('fulltext', 'ZCTextIndex'),        
        ('version_status', 'FieldIndex'),
        ('get_modification_datetime', 'DateIndex'),
        ('publication_datetime', 'DateIndex'),
        ]

    for field_name, field_type in indexes:
        if field_name in existing_indexes:
            continue

        # special handling for argument passing to zctextindex
        # ranking algorithm used is best for larger text body / query 
        # size ratios
        if field_type == 'ZCTextIndex':
            extra = RecordStyle(
                {'doc_attr':field_name,
                 'lexicon_id':'blog_lexicon',
                 'index_type':'Okapi BM25 Rank'}
                )
            catalog.addIndex(field_name, field_type, extra)
            continue
        
        catalog.addIndex(field_name, field_type)

def manage_addSilvaBlog(self, id, title, REQUEST=None):
    if not mangle.Id(self, id).isValid():
        return
    o = SilvaBlog(id)
    self._setObject(id, o)
    object = getattr(self, id)
    object.set_title(title)
    setup_catalog(object)
    add_and_edit(self, id, REQUEST)
    return ''

manage_addSilvaBlogForm = PageTemplateFile("www/silvaBlogAdd", 
                                    globals(),
                                    __name__='manage_addSilvaBlogForm')

registerTypeForMetadata(SilvaBlog.meta_type)
