Copyright (c) 2004 Guido Wesdorp. All rights reserved.
See also LICENSE.txt

Meta::
  
  Valid for:  SilvaBlog 0.1
  Author:     Guido Wesdorp
  Email:      guido@infrae.com
  CVS:        $Revision: 1.1 $

SilvaBlog

  SilvaBlog is a simple blogging tool for Silva. It allows users to write
  blog articles that can be viewed, searched and commented upon by other
  users. It's designed to be scalable, since it uses a BTreeFolder as the
  basis. 


Installing SilvaBlog

  See INSTALL.txt.

Using SilvaBlog

  After installing SilvaBlog in your Silva, you can create a 'Silva Blog',
  add 'Silva Blog Articles' to it, publish them and they can be viewed by
  clients. If you want to manage your articles a bit more, store the
  articles in one or more 'Silva Blog Categories'.
 
License
  
  Silva is released under the BSD license. See 'LICENSE.txt'.
  
  
