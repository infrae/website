##parameters=model, id, title, result
model.manage_addProduct['SilvaBlog'].manage_addSilvaBlogArticle(id, title)
return getattr(model, id)
