## Script (Python) "render_view"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=Add a comment
##
from Products.Formulator.Errors import ValidationError, FormValidationError

request = context.REQUEST
view = context
model = request.model

try:
    result = view.comments_form.validate_all(request)
except FormValidationError, e:
    request.set('error', 'Please fill in all input fields' % e)
    return model.index_html()


name = result['commentor']
email = result['email']
title = result['opening']
comment = result['comment']
    
return model.add_comment(title, name, email, comment, request)
