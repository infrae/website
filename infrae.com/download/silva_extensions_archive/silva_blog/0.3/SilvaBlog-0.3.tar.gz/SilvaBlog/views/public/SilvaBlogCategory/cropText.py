## Script (Python) "cropText"
##parameters=text, length
##title=Crop text on a word boundary

# cropped from CMFPlone and customized by me
# I've to admit, that this approach is really hackerish and may break
# the overview of published articles if length is to short or uses tags
# not recognized by me

if len(text)>length:
    text = text[:length]
    l = text.rfind('</p>')
    if l > length/2:
        text = text[:l]
    text = "%s</p>" % text
return text
