from Products.Formulator.Errors import ValidationError, FormValidationError
model = context.REQUEST.model
view = context

try:
    result = view.form.validate_all(context.REQUEST)
except FormValidationError, e:
    return view.tab_edit(message_type="error", message=context.render_form_errors(e))
   
msg = ['Blog Preferences changed']
msg_type = 'feedback'

if result.has_key('comments_allowed'):
    model.set_blog_prefs(result['comments_allowed'])
    
return view.tab_edit(message_type=msg_type, message=' '.join(msg))
