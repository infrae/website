# Copyright (c) 2004 Guido Wesdorp. All rights reserved.
# See also LICENSE.txt
# $Id: SilvaBlogArticle.py,v 1.6 2004/06/04 16:53:56 johnny Exp $

# Zope imports 
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from DateTime import DateTime

# Silva imports 
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
from Products.Silva import SilvaPermissions
from Products.Silva.helpers import add_and_edit
from Products.Silva import mangle
from Products.SilvaDocument.Document import Document, DocumentVersion
from Products.Silva.interfaces import IVersionedContent, IVersion

# SilvaBlog imports
from Products.SilvaBlog.interfaces import ISilvaBlogArticle, ISilvaBlogCategory

icon = "www/silvablogarticle.png"

class SilvaBlogArticle(Document):
    """Silva Blog Article"""

    security = ClassSecurityInfo()
    meta_type = 'Silva Blog Article'
    __implements__ = (IVersionedContent, ISilvaBlogArticle)

    def __init__(self, id):
        SilvaBlogArticle.inheritedAttribute('__init__')(self, id)
        self._comments = []

    def manage_beforeDelete(self, *args, **kwargs):
        # somehow uncataloging in manage_beforeDelete fails, while this seems 
        # to work just fine...
        path = '/'.join(self.getPhysicalPath())
        for version in self._get_indexable_versions():
            self.blog_catalog.uncatalog_object('%s/%s' % (path, version.id))
        for versionid in self.get_previous_versions():
            self.blog_catalog.uncatalog_object('%s/%s' % (path, versionid))
        SilvaBlogArticle.inheritedAttribute('manage_beforeDelete')(
                                                self, *args, **kwargs)

    def close_version(self, *args, **kwargs):
        """Close published version
        
            only delegates to super and reindexes version
        """
        SilvaBlogArticle.inheritedAttribute('close_version')(
                                            self, *args, **kwargs)
        version = getattr(self, self._previous_versions[-1][0])
        path = '/'.join(version.getPhysicalPath())
        self.blog_catalog.uncatalog_object(path)
        self.blog_catalog.catalog_object(version, path)

    def is_cacheable(self):
        return 0
    
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_category')
    def get_category(self):
        """ returns the category the article is published under,
            None otherwise
        """
        folder = self.get_container()
        if ISilvaBlogCategory.isImplementedBy(folder):
            return folder

    security.declarePublic('add_comment')
    def add_comment(self, comment, REQUEST):
        """add a comment
            
           comment (dictionary)
                title (str)
                name (str)
                email (str)
                comment (str)
        """
        self._comments.append(comment)
        self._p_changed = 1
        if REQUEST:
            return self.index_html()

    security.declarePublic('comments')
    def comments(self):
        """get all comments"""
        return self._comments

    def _index_version(self, version):
        obj = getattr(self, str(version))
        path = '/'.join(obj.getPhysicalPath())
        self.blog_catalog.uncatalog_object(path)
        self.blog_catalog.catalog_object(obj, path)
        SilvaBlogArticle.inheritedAttribute('_index_version')(self, version)

    def _update_publication_status(self):
        public = self.get_public_version(0)
        SilvaBlogArticle.inheritedAttribute('_update_publication_status')(self)
        if public != self.get_public_version(0):
            last_closed = self.get_last_closed_version(0)
            if last_closed is not None:
                self._index_version(self.get_last_closed_version(0))

InitializeClass(SilvaBlogArticle)

class SilvaBlogArticleVersion(DocumentVersion):
    """Silva Blog Article Version"""

    default_catalog = 'service_catalog'
    security = ClassSecurityInfo()
    meta_type = 'Silva Blog Article Version'
    __implements__ = IVersion

    def __init__(self, id):
        SilvaBlogArticleVersion.inheritedAttribute('__init__')(
                                                    self, id, 'dummy title')
        self._blogtitle = ''
    
    def index_object(self, *args, **kwargs):
        SilvaBlogArticleVersion.inheritedAttribute('index_object')(
                                                    self, *args, **kwargs)
        self.blog_catalog.catalog_object(self, 
                                        '/'.join(self.getPhysicalPath()))

    def reindex_object(self):
        SilvaBlogArticleVersion.inheritedAttribute('reindex_object')(self)
        self.blog_catalog.uncatalog_object('/'.join(self.getPhysicalPath()))
        self.blog_catalog.catalog_object(self, 
                                            '/'.join(self.getPhysicalPath()))

    # Accessors
    security.declareProtected(SilvaPermissions.AccessContentsInformation, 
                                'blogtitle')
    def blogtitle(self):
        return self._blogtitle
    
    # Manipulators
    security.declareProtected(SilvaPermissions.ChangeSilvaAccess, 
                                'set_blogtitle')
    def set_blogtitle(self, value):
        self._blogtitle = value
    
InitializeClass(SilvaBlogArticleVersion)

def manage_addSilvaBlogArticle(self, id, title, REQUEST=None):
    if not mangle.Id(self, id).isValid():
        return
    o = SilvaBlogArticle(id)
    self._setObject(id, o)
    object = getattr(self, id)
    object.manage_addProduct['SilvaBlog'].manage_addSilvaBlogArticleVersion(
                                                                '0', title)
    object.create_version('0', None, None)
    add_and_edit(self, id, REQUEST)
    return ''

def manage_addSilvaBlogArticleVersion(self, id, title, REQUEST=None):
    version = SilvaBlogArticleVersion(id)
    self._setObject(id, version)
    version = getattr(self, id)

    if type(title) != type(u''):
        title = unicode(title, 'UTF-8')
    version.set_title(title)
    add_and_edit(self, id, REQUEST)
    return ''

manage_addSilvaBlogArticleForm = PageTemplateFile("www/silvaBlogArticleAdd", 
                globals(), __name__ = 'manage_addSilvaBlogArticleForm')

manage_addSilvaBlogArticleVersionForm = PageTemplateFile(
                "www/silvaBlogArticleVersionAdd", globals(), 
                __name__ = 'manage_addSilvaBlogArticleVersionForm')

registerTypeForMetadata(SilvaBlogArticleVersion.meta_type)
