# Copyright (c) 2004 Roman Joost. All rights reserved.
# See also LICENSE.txt

# Zope imports
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

# Silva imports
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
from Products.Silva.helpers import add_and_edit
from Products.Silva.Folder import Folder
from Products.Silva.interfaces import IContainer
from Products.Silva import mangle
from Products.Silva import SilvaPermissions
from Products.Silva import icon as silva_icon

# Silva Blog imports
from Products.SilvaBlog.interfaces import ISilvaBlogCategory
icon = "www/silvablogcategory.png"
icon_nonpub = "www/silvablogcategory_unapproved.png"

class SilvaBlogCategory(Folder):
    """Silva Blog Category"""

    security = ClassSecurityInfo()
    meta_type = 'Silva Blog Category'
    __implements__ = (ISilvaBlogCategory, IContainer )

    def __init__(self, id):
        Folder.__init__(self, id)
    
    def manage_afterAdd(self, *args, **kwargs):
        Folder.manage_afterAdd(self, *args, **kwargs)

    def manage_beforeDelete(self, *args, **kwargs):
        Folder.manage_beforeDelete(self, *args, **kwargs)

    def manage_afterClone(self, *args, **kwargs):
        Folder.manage_afterClone(self, *args, **kwargs)

    def get_silva_addables_allowed_in_publication(self):
        # maybe we can return assets as well later...
        return ['Silva Image', 'Silva Blog Article']

    # Accessors
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'get_current_items')
    def get_current_items(self, items=15):
        """get the currently published items for this category"""
        query = {'meta_type': 'Silva Blog Article Version', 
                                'version_status': 'public',
                                'sort_on': 'publication_datetime',
                                'sort_order': 'descending',
                                'path': '/'.join(self.getPhysicalPath()),
                                }
        objs = self.blog_catalog(query)[:items]
        return [obj.getObject().object() for obj in objs]
    
    security.declareProtected(SilvaPermissions.AccessContentsInformation,
                                'contains_unpublished_items')
    def contains_unpublished_items(self):
        """returns true if the category contains unpublished articles"""
        query = {'meta_type': 'Silva Blog Article Version',
                 'version_status':'unapproved',
                 'path':'/'.join(self.getPhysicalPath()),
                 }
        if len(self.blog_catalog(query)) > 0:
            return True
            
        return False 

InitializeClass(SilvaBlogCategory)


def manage_addSilvaBlogCategory(self, id, title, REQUEST=None):
    if not mangle.Id(self, id).isValid():
        return
    o = SilvaBlogCategory(id)
    self._setObject(id, o)
    object = getattr(self, id)
    object.set_title(title)
    add_and_edit(self, id, REQUEST)
    return ''

manage_addSilvaBlogCategoryForm = PageTemplateFile("www/silvaBlogAdd", 
                                    globals(),
                                    __name__='manage_addSilvaBlogForm')

registerTypeForMetadata(SilvaBlogCategory.meta_type)
