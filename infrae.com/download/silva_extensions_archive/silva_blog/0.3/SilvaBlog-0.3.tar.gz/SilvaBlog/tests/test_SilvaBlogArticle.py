# Copyright (c) 2003-2004 Infrae. All rights reserved.
# See also LICENSE.txt
#
# Testing of xml<->xhtml bidrectional conversions.
# this tests along with the module is intended to 
# work with python2.1 and python2.2 or better
# 
# $Id $
import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from DateTime import DateTime
from Testing import ZopeTestCase
import unittest
# 
# module setup
#
import SilvaTestCase
from Products.Silva import SilvaPermissions
from Products.SilvaBlog.SilvaBlogArticle import\
        SilvaBlogArticle, SilvaBlogArticleVersion
from Products.SilvaBlog.interfaces import\
        ISilvaBlogArticle, ISilvaBlogArticleVersion

class BlogArticleTestCase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):

        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(blog, 'b', 'B')
        self.c = c = self.add_blogarticle(blog, 'c', 'C')
        
        # publish all
        for doc in [a,b,c]:
            doc.set_unapproved_version_publication_datetime(DateTime() - 1)
            doc.approve_version()

    def test_add_comment(self):
        c = {'title': "Foobar",
              'name': "Roman Joost",
              'email': "test@test.com",
              'comment': "This is a stupid testing comment",
              'datetime': DateTime()
            }
        c_date = DateTime()
        request = self.root.REQUEST
        self.root.blog.a.add_comment(c, None)
        
        comments = self.root.blog.a.comments()
        self.assertEqual(len(comments), 1)
        self.assert_(comments[0] == c)

    def test_get_category(self):
        self.f = f = self.add_blogcategory(self.root.blog, 'f', 'F')
        self.g = g = self.add_blogarticle(f, 'g', 'G')
        self.h = h = self.add_blogarticle(f, 'h', 'H')

        g.set_unapproved_version_publication_datetime(DateTime() - 1)
        g.approve_version()
   
        cat = g.get_category()
        self.assertEqual(self.f, cat)

        cat = self.a.get_category()
        self.assertEqual(None, cat)
#
# invocation of test suite
#
        
if __name__ == '__main__':
    framework()
else:
    # While framework.py provides its own test_suite()
    # method the testrunner utility does not.
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(BlogArticleTestCase))
        return suite

