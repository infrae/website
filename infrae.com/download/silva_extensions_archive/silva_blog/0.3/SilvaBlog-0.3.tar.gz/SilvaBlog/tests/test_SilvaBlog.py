# Copyright (c) 2003-2004 Infrae. All rights reserved.
# See also LICENSE.txt
#
# Testing of xml<->xhtml bidrectional conversions.
# this tests along with the module is intended to 
# work with python2.1 and python2.2 or better
# 
# $Id $
import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from DateTime import DateTime
from Testing import ZopeTestCase
import unittest
# 
# module setup
#
import SilvaTestCase
from Products.Silva import SilvaPermissions
from Products.SilvaBlog.SilvaBlog import SilvaBlog
from Products.SilvaBlog.interfaces import ISilvaBlog, ISilvaBlogArticle

class BlogTestCase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):

        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(blog, 'b', 'B')
        self.c = c = self.add_blogarticle(blog, 'c', 'C')
        
        # publish all
        for doc in [a,b,c]:
            doc.set_unapproved_version_publication_datetime(DateTime() - 1)
            doc.approve_version()

    def test_get_current_items(self):
        items = self.root.blog.get_current_items()
        expected = [self.a, self.b, self.c]
        self.assertEquals(expected, items)
    
    def test_recent_article(self):
        for doc in [self.a, self.b, self.c]:
          doc.close_version()
        artcl = self.root.blog.get_recent_article()
        self.assertEquals(None, artcl)
    
    def test_get_processed_items(self):
        self.c.create_copy()
        _date = DateTime()
        year = _date.year()
        month = _date.month()
        items = self.root.blog.get_processed_items(month,year)
        for item in items:
            self.assert_(ISilvaBlogArticle.isImplementedBy(item['item']))
            self.assert_(item['item'] in [self.a, self.b, self.c])

class ArticlesTestCase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):
        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(blog, 'b', 'B')
        self.c = c = self.add_blogarticle(blog, 'c', 'C')
        
        # publish all, but with b as the last one
        for doc in [a,c,b]:
            doc.set_unapproved_version_publication_datetime(DateTime() - 1)
            doc.approve_version()
    
    def test_ordered_ids(self):
        self.assertEquals(len(self.root.blog._ordered_ids), 3)
    
    def test_recent_article(self):
        artcl = self.root.blog.get_recent_article()
        # it's a, because the DateTime() we're setting in our test,
        # let's doc a be the last published one
        self.assertEquals(self.a, artcl)

class PublicationTimeTestCase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):

        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(blog, 'b', 'B')
        self.f = f = self.add_blogcategory(blog, 'f', 'F')
        self.c = c = self.add_blogarticle(f, 'c', 'C')
        
    def test_get_editable_items(self):
        items = self.root.blog.get_editable_items()
        self.assertEquals(len(items), 3)
        docs = [x[0] for x in items]
        self.assert_(self.c not in docs)
        self.assert_(self.f in docs)
        self.assert_(self.a in docs)
        self.assert_(self.b in docs)

# this works obviously in tab_edit, maybe we should add a folderish
# category object to have a better distinction between articles and
# *categories*
#    def test_get_editable_items_in_a_folder(self):
#        items = self.root.blog.f.get_editable_items()
#        self.assertEquals(len(items), 1)
#        docs = [x[0] for x in items]
#        self.assert_(self.c in docs)
        
class TabeditTestCase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):

        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(blog, 'b', 'B')
        self.c = c = self.add_blogarticle(blog, 'c', 'C')
        self.d = d = self.add_image(blog, 'd', 'testimage')
        
        # publish all
        self.published_articles = []
        i = 0
        for doc in [a,b,c,d]:
            time = DateTime()
            if ISilvaBlog.isImplementedBy(doc):
                doc.set_unapproved_version_publication_datetime(time)
                doc.approve_version()
            d = {
                'number': i,
                'item': doc,
                'item_id': doc.id,
                'title_editable': doc.get_title_editable(),
                'meta_type': doc.meta_type,
                'item_url': doc.absolute_url(),
                'editor_link': blog.get_editor_link(doc)
                }
            self.published_articles.append(d)
            i += 1
           

    def test_get_processed_items(self):
        _date = DateTime()
        year = _date.year()
        month = _date.month()
        dicts = self.root.blog.get_processed_items(month, year)
        
        self.assertEquals(len(self.published_articles), len(dicts))
        while dicts:
            expected_d = dicts.pop()
            d = self.published_articles.pop()
            for key,val in d.items():
                if expected_d.has_key(key):
                    self.assert_(val == expected_d[key],\
                        "not expected value [%s] for key: %s"\
                            %(val, key))

            
class SubjectsTestCase(SilvaTestCase.SilvaTestCase):

    def afterSetUp(self):
        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 

        # add some articles to it
        self.f = f = self.add_folder(blog, 'f', 'F')
        self.g = g = self.add_folder(blog, 'g', 'G')
        self.a = a = self.add_blogarticle(blog, 'a', 'A')
        self.b = b = self.add_blogarticle(f, 'b', 'B')
        self.c = c = self.add_blogarticle(g, 'c', 'C')
        self.d = d = self.add_blogarticle(g, 'd', 'D')

       
        for doc in [a,b,c]:
            doc.set_unapproved_version_publication_datetime(DateTime() - 1)
            doc.approve_version()

    def test_get_categories(self):
        subj = self.root.blog.get_categories()
        
        self.assertEquals(len(subj), 2)
        self.assertEquals([self.f, self.g], subj)

    def test_get_articles_for_category(self):
        articles = self.root.blog.get_articles_for_category("G")
        self.assertEquals(len(articles), 2)
        self.assertEquals([self.c, self.d], articles)

        articles = self.root.blog.get_articles_for_category()
        self.assertEqual(len(articles), 3)
        self.assertEqual([self.a, self.b, self.c], articles)
        
        articles = self.root.blog.get_articles_for_category("NoValidSubject")
        self.assertEqual(None, articles)

        self.d = d = self.add_image(self.f, 'd', 'testimage')
        articles = self.root.blog.get_articles_for_category("F")
        self.assert_(self.d not in articles)
    
       
#
# invocation of test suite
#
        
if __name__ == '__main__':
    framework()
else:
    # While framework.py provides its own test_suite()
    # method the testrunner utility does not.
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(BlogTestCase))
        suite.addTest(unittest.makeSuite(ArticlesTestCase))
        suite.addTest(unittest.makeSuite(PublicationTimeTestCase))
        suite.addTest(unittest.makeSuite(TabeditTestCase))
        suite.addTest(unittest.makeSuite(SubjectsTestCase))
        return suite

