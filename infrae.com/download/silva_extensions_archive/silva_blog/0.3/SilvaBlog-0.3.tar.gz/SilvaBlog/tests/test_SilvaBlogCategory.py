# Copyright (c) 2003-2004 Infrae. All rights reserved.
# See also LICENSE.txt
#
# Testing of xml<->xhtml bidrectional conversions.
# this tests along with the module is intended to 
# work with python2.1 and python2.2 or better
# 
# $Id $
import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from DateTime import DateTime
from Testing import ZopeTestCase
import unittest
# 
# module setup
#
import SilvaTestCase
from Products.Silva import SilvaPermissions
from Products.SilvaBlog.SilvaBlogCategory import SilvaBlogCategory
from Products.SilvaBlog.interfaces import ISilvaBlogCategory

class BlogCategoryTestcase(SilvaTestCase.SilvaTestCase):
    
    def afterSetUp(self):

        # add a blog
        self.installExtension('SilvaBlog')
        blog = self.add_blog(self.root, 'blog', 'SilvaBlog') 
        
        # add some articles to it
        self.a = a = self.add_blogcategory(blog, 'a', 'A')
        self.b = b = self.add_blogcategory(blog, 'b', 'B')
        self.z = z = self.add_blogcategory(blog, 'z', 'Z')
        self.c = c = self.add_blogarticle(a, 'c', 'C')
        self.d = d = self.add_blogarticle(a, 'd', 'D')
        self.e = e = self.add_blogarticle(b, 'e', 'E')
        
        # publish all
        for doc in [c,d,e]:
            doc.set_unapproved_version_publication_datetime(DateTime() - 1)
            doc.approve_version()

    def test_get_current_items(self):
        items = self.root.blog.a.get_current_items()
        expected = [self.c, self.d]
        self.assertEquals(expected, items)

    def test_contains_unpublished_items(self):
        f = self.add_blogarticle(self.b, 'f', 'F')
        self.assert_(self.b.contains_unpublished_items() is True)
        self.assert_(self.a.contains_unpublished_items() is False)
        self.assert_(self.z.contains_unpublished_items() is False)
    
    
#
# invocation of test suite
#
        
if __name__ == '__main__':
    framework()
else:
    # While framework.py provides its own test_suite()
    # method the testrunner utility does not.
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(BlogCategoryTestcase))
        return suite

