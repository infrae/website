# Copyright (c) 2003-2004 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py,v 1.3 2004/07/21 11:46:42 jw Exp $
#
