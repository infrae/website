# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
# Silva
from Products.Silva.ExtensionRegistry import extensionRegistry
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
from Products.FileSystemSite.DirectoryView import registerDirectory
# SilvaRailroad
from Products.SilvaRailroad import install
from Products.SilvaRailroad import SilvaRailroadService, SilvaRailroadProxy

def initialize(context):
    # Zope initialization
    
    context.registerClass(
        SilvaRailroadService.SilvaRailroadService,
        constructors = (SilvaRailroadService.manage_addRailroadServiceForm,
                        SilvaRailroadService.manage_addRailroadService),
        )
    
    extensionRegistry.register(
        'SilvaRailroad', 'Silva Railroad', context, [SilvaRailroadProxy], 
        install, depends_on='SilvaExternalSources')

    registerDirectory('views', globals())
    
    registerTypeForMetadata(SilvaRailroadProxy.SilvaRailroadProxy.meta_type)
    
    import os
    from Globals import package_home
    from Products.Formulator.Form import ZMIForm
    from Products.Formulator.XMLToForm import XMLToForm
    from Products.SilvaRailroad import formsregistry    

    # XXX Maybe use FormulatorFormFile for the forms registry?    
    def _XMLToForm(mimetype, filename):
        filename = os.path.join(package_home(globals()), 'forms', filename)
        file = open(filename, 'rb')
        form = ZMIForm('form-%s' % mimetype, 'Parameters form (%s)' % mimetype)
        XMLToForm(file.read(), form)
        file.close()
        return form
    
    # Default form
    formsregistry.registerDefaultForm(_XMLToForm('unkown type', 'rr_unknown.form'))
    # Specific (main)types forms
    types = (
        ('video/*', 'rr_quicktime.form'),
        ('audio/*', 'rr_midi.form'),
        ('image/*', 'rr_image.form'),
        ('application/pdf', 'rr_pdf.form'),
        )
    for mimetype, filename in types:
        formsregistry.registerFormForMimetype(mimetype, _XMLToForm(mimetype, filename))
        