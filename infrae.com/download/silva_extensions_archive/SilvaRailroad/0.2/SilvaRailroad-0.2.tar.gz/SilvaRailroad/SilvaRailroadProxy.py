# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
# Zope
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from Products.PythonScripts.standard import html_quote
# Silva
from Products.Silva.interfaces import IAsset
from Products.Silva.Asset import Asset
from Products.Silva import helpers
from Products.Silva import SilvaPermissions as permissions
# SilvaExternalSources
from Products.SilvaExternalSources.interfaces import IExternalSource
from Products.SilvaExternalSources.ExternalSource import ExternalSource
# Railroad
from Products.Railroad import interfaces, errors, proxy
# SilvaRailroad
from Products.SilvaRailroad import formsregistry, SilvaRailroadService

icon = 'www/railroadproxy.png'

# XXX This needs to go in some sort or registry too I guess
CONTENTEMBED_MAPPING = {
    'image': u'<img src="%(url)s" alt="%(title)s" %(attributes)s/>',
    'video': u'<object data="%(url)s" type="%(type)s" alt="%(title)s" %(attributes)s>\r%(parameters)s Can\'t show <a href="%(url)s">`%(title)s`</a> in your browser! </object>',
    'audio': u'<object data="%(url)s" type="%(type)s" alt="%(title)s" %(attributes)s>\r%(parameters)s Can\'t show <a href="%(url)s">`%(title)s`</a> in your browser! </object>',
    'application/pdf': u'<object data="%(url)s" type="%(type)s" alt="%(title)s" %(attributes)s>\r%(parameters)s Can\'t show document <a href="%(url)s">`%(title)s`</a> in your browser! </object>',
    }

class SilvaRailroadProxy(proxy.Proxy, Asset, ExternalSource):
    """Silva Railroad Proxy
    """

    meta_type = 'Silva Railroad Proxy'
    
    __implements__ = (interfaces.IRailroadProxy, IAsset, IExternalSource)
    
    security = ClassSecurityInfo()
    
    def __init__(self, id, title, unique_id):
        Asset.__init__(self, id, title)
        proxy.Proxy.__init__(self, unique_id)
        
    # IExternalSource interface
    
    security.declareProtected(permissions.View, 'show_properties')
    def show_properties(self):
        """Test method to show all stored properties
        """
        dav_properties = self.fetch_properties()
        return repr(dav_properties)

    security.declareProtected(permissions.View, 'filesize')
    def filesize(self):
        property_name = SilvaRailroadService.PROPERTIES_MAPPING['filesize']
        dav_properties = self.fetch_properties()
        size = dav_properties[property_name]
        size = int(size)
        return size
    
    security.declareProtected(permissions.View, 'mimetype')
    def mimetype(self):
        property_name = SilvaRailroadService.PROPERTIES_MAPPING['contenttype']
        dav_properties = self.fetch_properties()
        mimetype = dav_properties[property_name]
        return mimetype.strip()
    
    security.declareProtected(permissions.ChangeSilvaContent, 'form')
    def form(self):
        """Return a parameter form according to objects mimetype.
        """
        mimetype = self.mimetype()
        form = formsregistry.getFormForMimetype(mimetype)
        return form.__of__(self)
    
    def to_xml(self, REQUEST=None, **kw):
        return "<h1>Testing proxy 1 2 3</h1>"
    
    def to_html(self, REQUEST=None, **kw):
        """ render HTML for RR source
        """
        resource_url = self.resource_url()
        
        parameters = {}
        parameters.update(kw)
        
        link_text = parameters.get('link_text')
        if link_text == '':
            link_text = self.get_title_or_id()

        display = parameters.get('display')
        if display == 'link':
            return u'<a href="%s">%s</a>' % (resource_url, html_quote(link_text))

        # Decide based on mimetype how to embed the file
        mimetype = self.mimetype()
        maintype, subtype = mimetype.split('/')
        embedding = CONTENTEMBED_MAPPING.get(mimetype, None)
        if embedding is None:
            embedding = CONTENTEMBED_MAPPING.get(maintype, None)
            if embedding is None:
                return u'<a href="%s">%s</a>' % (resource_url, html_quote(link_text))    
        
        # Options for string interpolation w/embed template
        options = {
            'url': resource_url,
            'title': html_quote(self.get_title_or_id()),
            'link_text': link_text,
            'type': mimetype
            }
            
        width = parameters.get('width', None)
        height = parameters.get('height', None)
        attrs = []
        if width:
            attrs.append(u'width="%s"' % width)
        if height:
            attrs.append(u' height="%s"' % height)
        options['attributes'] = ' '.join(attrs)

        # Parameters for string interpolation w/embed template
        params = []
        for key, value in parameters.items():
            if key == 'display':
                continue
            value = value.strip()
            if not value:
                continue
            param = '<param name="%s" value="%s" />' % (key, value)
            params.append(param)
        options['parameters'] = u'\n'.join(params)
        # Interpolate
        embeded = embedding % options
        return embeded
    
    # Railroad events
    
    security.declareProtected(
        permissions.ChangeSilvaContent, 'on_upload_succeeded')
    def on_upload_succeeded(self, url, errormsg):
        """Notifies proxy of a succesful resource upload to the Railroad
        repository.
        
        Method should be publishable (i.e., the implementation needs
        to have a doc string).
        """
        proxy.Proxy.on_upload_succeeded(self, url, errormsg)
        request = self.REQUEST
        redirect_url = self.absolute_url() + '/edit'
        request.RESPONSE.redirect(redirect_url)
    
    security.declareProtected(
        permissions.ChangeSilvaContent, 'on_upload_failed')
    def on_upload_failed(self, errormsg):
        """Notifies proxy of a failed resource upload to the Railroad
        repository.
        
        Method should be publishable (i.e., the implementation needs
        to have a doc string).
        """
        proxy.Proxy.on_upload_failed(self, errormsg)
        raise errors.RailroadError(errormsg)
        
InitializeClass(SilvaRailroadProxy)

manage_addSilvaRailroadProxyForm = PageTemplateFile(
    "www/railroadProxyAdd", globals(), __name__='manage_addSilvaRailroadProxyForm')

def manage_addSilvaRailroadProxy(context, id, title, unique_id, REQUEST=None):
    """Add Silva Railroad Proxy object
    """
    proxy = SilvaRailroadProxy(id, title, unique_id)
    context._setObject(id, proxy)
    proxy = getattr(context, id)
    proxy.set_title(title)
    proxy.set_railroad_service(context.service_railroad)
    helpers.add_and_edit(context, id, REQUEST)
    return proxy
