# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

_mimetype_to_form = {}

def registerFormForMimetype(mimetype, form):
    maintype, subtype = mimetype.split('/')
    if maintype == '*':
        maintype = None
    if subtype == '*':
        subtype = None
    _mimetype_to_form[(maintype, subtype)] = form

def registerDefaultForm(form):
    _mimetype_to_form[(None, None)] = form

def unregisterMimetype(mimetype):
    maintype, subtype = mimetype.split('/')
    del _mimetype_to_form[(maintype, subtype)]

def getFormForMimetype(mimetype):
    maintype, subtype = mimetype.split('/')
    if _mimetype_to_form.has_key((maintype, subtype)):
        # Specific mimetype found
        return _mimetype_to_form[(maintype, subtype)]
    elif _mimetype_to_form.has_key((maintype, None)):
        # Maintype found
        return _mimetype_to_form[(maintype, None)]
    else:
        # Mimetype not found, return default form
        return _mimetype_to_form[(None, None)]

def getFormForMimetypeInContext(context, mimetype):
    form = getFormForMimetype(mimetype)
    return form.__of__(context)