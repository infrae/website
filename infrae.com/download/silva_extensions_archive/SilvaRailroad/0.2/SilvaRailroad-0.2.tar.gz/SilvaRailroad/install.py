# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
# Silva
from Products.Silva import install as silvainstall
from Products.Silva import roleinfo
# SilvaRailroad
from Products.SilvaRailroad import SilvaRailroadService

def install(root):
    silvainstall.add_fss_directory_view(
        root.service_views, 'SilvaRailroad', __file__, 'views')
    configureRailroadService(root)
    registerViews(root.service_view_registry)
    configureAddables(root)
    configureSecurity(root)
    setupMetadata(root)

def uninstall(root):
    configureRailroadService(root, uninstall=True)
    unregisterViews(root.service_view_registry)
    root.service_views.manage_delObjects(['SilvaRailroad'])

def is_installed(root):
    return hasattr(root.service_views, 'SilvaRailroad')

def configureRailroadService(context, uninstall=False):
    id = 'service_railroad'
    
    if uninstall:
        # XXX We don't remove the Railroad service, as it would loose all
        # settings. This implies that this extension is not cleaned 
        # up properly upon uninstall.
        #if id in context.objectIds():
        #    context.manage_delObjects([id,])
        return

    if id not in context.objectIds():
        SilvaRailroadService.manage_addRailroadService(
            context, '/repository/url/', '/service/url/', 'repository name', 'client name')

def registerViews(reg):
    reg.register('add', 'Silva Railroad Proxy', ['add', 'RailroadProxy'])
    reg.register('edit', 'Silva Railroad Proxy', ['edit', 'Asset', 'RailroadProxy'])
    reg.register('public', 'Silva Railroad Proxy', ['public', 'RailroadProxy'])

def unregisterViews(reg):
    reg.unregister('add', 'Silva Railroad Proxy')
    reg.unregister('edit', 'Silva Railroad Proxy')
    reg.unregister('public', 'Silva Railroad Proxy')

def configureSecurity(root):
    add_permissions = ('Add Silva Railroad Proxys',)
    for add_permission in add_permissions:
        root.manage_permission(add_permission, roleinfo.AUTHOR_ROLES)
    
def setupMetadata(root):
    mapping = root.service_metadata.getTypeMapping()
    default = ''
    tm = (
        {'type': 'Silva Railroad Proxy', 'chain': 'silva-content, silva-extra'},
        )
    mapping.editMappings(default, tm)

def configureAddables(root):
    addables = ('Silva Railroad Proxy', )
    new_addables = root.get_silva_addables_allowed_in_publication()
    for a in addables:
        if a not in new_addables:
            new_addables.append(a)
    root.set_silva_addables_allowed_in_publication(new_addables)
            