# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
# Zope
from OFS import SimpleItem
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
# Silva
from Products.Silva import helpers
from Products.Silva import SilvaPermissions
# Railroad
from Products.Railroad import interfaces, service, RailroadService
# SilvaRailroad
from Products.SilvaRailroad import formsregistry

SILVA_NS = u'http://www.infrae.com/silva/metadata/1.0/'
DC_NS = u'http://purl.org/dc/elements/1.1/'

icon = 'www/railroadservice.png'

# Mappings

PERMISSIONS_MAPPING = {
    'get': SilvaPermissions.View,
    'head': SilvaPermissions.View,
    'options': SilvaPermissions.View,
    'propfind': SilvaPermissions.View,
    'post': SilvaPermissions.ChangeSilvaContent,
    'put': SilvaPermissions.ChangeSilvaContent,
    'proppatch': SilvaPermissions.ChangeSilvaContent,
    'delete': SilvaPermissions.ChangeSilvaContent,
    }

PROPERTIES_MAPPING = {
    'modification_time': ('getlastmodified', 'DAV:'),
    'creation_time': ('creationdate', 'DAV:'),
    'contenttype': ('getcontenttype', 'DAV:'),
    'filesize': ('getcontentlength', 'DAV:'),
    'description': ('description', DC_NS),
    'maintitle': ('title', DC_NS),
    'shorttitle': ('shorttitle', SILVA_NS),
    'subject': ('subject', DC_NS),
    'keywords': ('keywords', SILVA_NS),
    'comment': ('comment', SILVA_NS),
    'creator': ('creator', DC_NS),
    'publication_time': ('date', DC_NS)
    }

METADATA_MAPPING = {
    'description': ('description', 'silva-extra'),
    'maintitle': ('maintitle', 'silva-content'),
    'shorttitle': ('shorttitle', 'silva-content'),
    'subject': ('subject', 'silva-extra'),
    'keywords': ('keywords', 'silva-extra'),
    'comment': ('comment', 'silva-extra'),
    'creator': ('creator', 'silva-extra'),
    'publication_time': ('publicationtime', 'silva-extra')
    }
    
class SilvaRailroadService(RailroadService.RailroadService, SimpleItem.SimpleItem):
    """Silva Railroad Service
    """
    
    meta_type = 'Silva Railroad Service'
    
    __implements__ = (interfaces.IRailroadService, )
    
    security = ClassSecurityInfo()    
        
    security.declarePublic('generate_unique_id')
    
    # XX I don't like these class attrs... its to make these
    # constants available in Python Scripts...
    permissions_mapping = PERMISSIONS_MAPPING
    properties_mapping = PROPERTIES_MAPPING
    metadata_mapping = METADATA_MAPPING
    
    def _getPermissionForMethod(self, method):
        """Returns the Silva permission that is associated 
        with a certain Railroad HTTP method
        """
        method = method.strip().lower()
        permission = PERMISSIONS_MAPPING[method]
        return permission
    
InitializeClass(SilvaRailroadService)

manage_addRailroadServiceForm = PageTemplateFile(
    "www/railroadServiceAdd", globals(), __name__='manage_addRailroadServiceForm')

def manage_addRailroadService(
    context, repository_url, services_url, repository_name, client_name, 
    REQUEST=None):    
    """Add a basic Zope Railroad Service object
    """
    if not repository_url.endswith('/'):
        repository_url = repository_url + '/'

    if not services_url.endswith('/'):
        services_url = services_url + '/'
    
    id = 'service_railroad'
    title = 'Railroad Service'
    service = SilvaRailroadService(
        id, title, repository_url, services_url, repository_name, client_name)
    context._setObject(id, service)
    service = getattr(context, id)
    helpers.add_and_edit(context, id, REQUEST)
    return service
