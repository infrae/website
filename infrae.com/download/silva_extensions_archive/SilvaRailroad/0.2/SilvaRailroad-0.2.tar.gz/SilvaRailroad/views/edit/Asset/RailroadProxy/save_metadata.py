request = context.REQUEST
model = request.model
view = context
form = request.form

SILVA_NS = u'http://www.infrae.com/silva/metadata/1.0/'

service = context.service_railroad
repo_url = service.repository_url()
resource_url = model.resource_url()

properties = {}

for fieldname, propname in service.properties_mapping.items():
    if fieldname in ('modification_time', 'creation_time', 'contenttype', 'filesize'):
        continue
    fn = 'field_' + fieldname
    if form.has_key(fn):
        v = form[fn]
        try:
            v = v.decode('utf-8')
        except AttributeError:
            # unicode objects don't have decode
            pass
        properties[propname] = v
    else:
        properties[propname] = u''
#

service.set_properties_for(model, properties)

## ms = context.service_metadata
## editable = model.get_editable()
## binding = ms.getMetadata(editable)

## values = {}
## for set_name in binding.getSetNames():
##     values[set_name] = {}
##     if request.form.has_key(set_name):
##         for key, value in request.form[set_name].items():
##             values[set_name][key] = value

## all_errors = {}
## for set_name in binding.getSetNames():
##     errors = binding.setValues(set_name, values[set_name], reindex=1)
##     if errors:
##         all_errors[set_name] = errors

## if all_errors:
##     # There were errors...
##     type = 'error'
##     msg = 'The data that was submitted did not validate properly.'
## else:
##     type = 'feedback'
##     msg = 'Metadata saved.'
##     model.sec_update_last_author_info()

type = 'feedback'
msg = 'Metadata saved.'
all_errors = {}

## model.sec_update_last_author_info()

return view.tab_metadata(
    form_errors=all_errors,
    message_type=type,
    message=msg)
