from Products.Formulator.Errors import FormValidationError

request = context.REQUEST
model = request.model

try:
    result = context.form.validate_all(context.REQUEST)
except FormValidationError, e:
    return context.tab_edit(
        message_type="error", 
        message=context.render_form_errors(e))
        
title = result.get('object_title', '')
model.set_title(title)
model.sec_update_last_author_info()
    
msg = ['Title changed.']
msg_type = 'feedback'

return context.tab_edit(message_type=msg_type, message=' '.join(msg))
