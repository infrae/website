##parameters=model, id, title, result
unique_id = result['unique_id']

model.manage_addProduct['SilvaRailroad'].manage_addSilvaRailroadProxy(
    id, title, unique_id)
    
return getattr(model, id)
