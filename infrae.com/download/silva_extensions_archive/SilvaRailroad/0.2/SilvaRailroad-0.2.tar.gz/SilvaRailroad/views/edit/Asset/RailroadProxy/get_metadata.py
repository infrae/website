##parameters=content
## from Products.SilvaMetadata.Exceptions import BindingError

request = context.REQUEST
model = request.model
view = context

# Build a dict for use in the edit pagetemplate,
# format:
# {
#  'setNames': [name1, name2,..],
#   set1: {'elementNames': [name1, name2,...],
#          'setTitle':...,
#           element1: {'view':...,
#                      'isAcquired':...},
#                      'isEditable':...,
#                      'render':...,
#                      'isRequired':...},
#                      'isAcquirable':...},
#                      'description':...},
#                      'title':...},
#           element2:...
#         },
#   set2:...
# }

if content is None:
    return None

def_dict = {
    'isAcquired': 0,
    'isEditable': 1,
    'isRequired': 0,
    'isAcquireable': 0
    }

service = model.get_railroad_service()
repo_url = service.repository_url()
resource_url = model.resource_url()
properties = service.fetch_properties_for(model)

set_name = 'silva'
## set_title = set_name + '-railroad [%s]' % repo_url
set_title = set_name + '-railroad'
pt_binding = {}
pt_binding['setNames'] = set_names = [set_name]
set = {}
fnames = []

form = context.metadata_form

fields = form.get_fields()

for field in fields:
    fname = field.id
    fnames.append(fname)
    # get property value from RR properties
    try:
        property_name = service.properties_mapping[fname]
        try:
            value = properties[property_name].decode('utf-8')
        except AttributeError:
            # unicode objects don't have decode
            value = properties[property_name]
            pass
    except KeyError:
        value = None
        pass
    view = None
    render = None
    # check special cases
    if fname == 'maintitle':
        # title has to be the same everywhere
        value = model.get_title()
    elif value is None:
        # if no value set on RR side, try to get one from the metadata system
##         try:
##             element, sname = meta_map[fname]
##             value = binding.get(sname, element)
## ##             bound_element = binding.getElement(sname, element)
##             render = renderEdit(sname, element)
##             view =  renderView(sname, element)
##         except KeyError:
##             mvalue = None
##             bound_element = None
##             pass
        # no, empty value
        value = None
    # populate element dict
    d = def_dict.copy()
    d['value'] = value
    if view is None:
        view = field.render_view(value=value)
    if render is None:
        render = field.render(value=value)
    d['view'] = view
    if fname in ('modification_time', 'creation_time', 'contenttype', 'publication_time'):
        d['isEditable'] = 0
        d['render'] = None
    else:
        d['render'] = render
    d['description'] = field.get_value('description')
    d['title'] = field.get_value('title')
    set[fname] = d

set['elementNames'] = fnames
set['setTitle'] = set_title
pt_binding[set_name] = set

return pt_binding
