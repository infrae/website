# init

from mobi.caching.cache import *
from mobi.caching.backend import NoCacheBackend
