from silva.core.layout.interfaces import ISilvaSkin


class ISilvaMobiSkin(ISilvaSkin):
    """ Base skin for mobiles.

    Mobile skin should declare two directives :
    - silva.mobi.martiansupport.directives.mobiskin
    - silva.mobi.martiansupport.directives.mobidevice

    ... code: python

        from mobi.interfaces.devices import (
            IBasicDeviceType, IAdvancedDeviceType)
        from silva.mobi.martiansupport import directives as silvamobi
        from silva.mobi.interfaces import ISilvaMobiSkin

        skin_name = u'My mobile skin'

        class IMySiteMobileSkin(BaseLayer, ISilvaMobiSkin):
            silvamobi.mobiskin(skin_name)
            silvamobi.mobidevice(IBasicDeviceType)

        class IMySiteAdvancedMobileSkin(AdvancedLayer, ISilvaMobiSkin):
            silvamobi.mobiskin(skin_name)
            silvamobi.mobidevice(IAdvancedDeviceType)

    """
