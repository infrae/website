import martian
from grokcore.view.directive import TaggedValueStoreOnce


class mobidevice(martian.Directive):
    scope = martian.CLASS
    store = TaggedValueStoreOnce()
    default = None
    validate = None


class mobiskin(martian.Directive):
    scope = martian.CLASS
    store = TaggedValueStoreOnce()
    default = None
    validate = martian.validateText

