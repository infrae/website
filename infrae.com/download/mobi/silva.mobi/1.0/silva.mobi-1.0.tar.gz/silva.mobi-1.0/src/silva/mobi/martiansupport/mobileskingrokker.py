from zope.interface.interface import InterfaceClass
from zope.component.interface import provideInterface
from silva.mobi.interfaces import ISilvaMobiSkin
from mobi.interfaces.devices import IDeviceType
from silva.mobi.martiansupport import directives as silvamobi
from martian.error import GrokError

import martian


class SilvaMobiSkinGrokker(martian.InstanceGrokker):
    martian.component(InterfaceClass)
    martian.directive(silvamobi.mobiskin, silvamobi.mobidevice)

    def grok(self, name, interface, module_info, config, **kw):
        mobiskin = silvamobi.mobiskin.bind().get(interface)
        mobidevice = silvamobi.mobidevice.bind().get(interface)
        if mobiskin is None:
            return False

        if not interface.extends(ISilvaMobiSkin):
            raise GrokError(
                "The mobiskin and mobidevice directives should be used on "
                "interfaces that extends %s only." %
                ISilvaMobiSkin.__identifier__,
                interface)

        if not issubclass(mobidevice, IDeviceType):
            raise GrokError(
                "The mobidevice directives should provide an device type"
                "that extends %s only." % IDeviceType.__name__,
                interface)

        # declare skin
        config.action(
            discriminator=('utility', mobidevice, mobiskin),
            callable=provideInterface,
            args=(mobiskin, interface, mobidevice)
        )

        return True

