==========
silva.mobi
==========

``silva.mobi`` contains the base systems for creating mobile layouts in Silva.
It provides tools to create layouts that adapts to the device capabilities.
It also provide a way to automatically switch to a mobile layout if some
condition matches.
