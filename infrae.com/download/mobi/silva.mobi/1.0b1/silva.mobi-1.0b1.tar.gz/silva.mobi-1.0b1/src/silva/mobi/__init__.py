# package

from silva.mobi.martiansupport.directives import mobiskin, mobidevice

# make pyflakes happy
mobiskin
mobidevice
