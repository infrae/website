"""
We start by grokking the test.

>>> grok('silva.mobi.tests.grok.mobiskin')

Now the skin should be registered in the ZCA as a named utility, for which
the name is the name of the skin.

>>> from zope import component
>>> from mobi.interfaces.devices import (
...     IDeviceType, IBasicDeviceType, IStandardDeviceType)
>>> from zope.publisher.interfaces.browser import IBrowserSkinType

>>> sm = component.getGlobalSiteManager()
>>> sorted([reg for reg in sm.registeredUtilities()
...             if reg.provided.isOrExtends(IDeviceType)],
...      lambda x,y: cmp(x.provided.__name__, y.provided.__name__))
... #doctest:+NORMALIZE_WHITESPACE
[UtilityRegistration(<BaseGlobalComponents base>,
  IAdvancedDeviceType, 'test_skin', IAdvancedSkin, None, ''),
 UtilityRegistration(<BaseGlobalComponents base>,
  IBasicDeviceType, 'test_skin', IBasicSkin, None, ''),
 UtilityRegistration(<BaseGlobalComponents base>,
  IStandardDeviceType, 'test_skin', IStandardSkin, None, '')]

The layout factory default behavior is to set the skin only if host starts with
"m." as in "m.infrae.com" or ends with ".mobi".

>>> from zope.publisher.browser import TestRequest
>>> from infrae.layout.interfaces import ILayoutFactory

The layout factory is an adapter for ILayoutFactory that adapts the request
and context.

>>> request = TestRequest()
>>> request.environ = {}
>>> context = getRootFolder()
>>> layout_factory = component.getMultiAdapter(
...     (request, context,), ILayoutFactory)
>>> layout_factory #doctest: +ELLIPSIS
<silva.mobi.tests.grok.mobiskin.Factory object ...>


We set a host for the request.

>>> request.environ['HTTP_HOST'] = 'www.infrae.com:21032'

The skin should not be applied since the host does not match the requirements.

>>> layout_factory.should_apply()
False

If we change the host to "m.infrae.com" then it should apply.

>>> request.environ['HTTP_HOST'] = 'm.infrae.com'
>>> layout_factory.should_apply()
True

Idem with "infrae.mobi".

>>> request.environ['HTTP_HOST'] = 'infrae.mobi:8080'
>>> layout_factory.should_apply()
True

The factory is called with a view and return the appropriate layout given
wsgi environment data provided by mobi.devices middleware.

>>> request.environ['mobi.devices.marker'] = IStandardDeviceType
>>> layout = layout_factory(object())

The skin corresponding to the device type should have been set on the request.

>>> from silva.core.layout.interfaces import ISilvaSkin
>>> filter(lambda x: x.isOrExtends(ISilvaSkin), request.__provides__)
[<InterfaceClass silva.mobi.tests.grok.mobiskin.IStandardSkin>]


"""

from silva.core.layout.interfaces import ISilvaLayer
from mobi.interfaces.devices import (
    IBasicDeviceType, IStandardDeviceType, IAdvancedDeviceType)
from silva.mobi.interfaces import ISilvaMobiSkin
from silva.mobi.factory import MobiLayoutFactory
from silva import mobi as silvamobi


_skin_name = 'test_skin'


class IBasicLayer(ISilvaLayer):
    pass


class IStandardLayer(IBasicLayer):
    pass


class IAdvancedLayer(IStandardLayer):
    pass


class IBasicSkin(IBasicLayer, ISilvaMobiSkin):
    silvamobi.mobidevice(IBasicDeviceType)
    silvamobi.mobiskin(_skin_name)


class IStandardSkin(IStandardLayer, ISilvaMobiSkin):
    silvamobi.mobidevice(IStandardDeviceType)
    silvamobi.mobiskin(_skin_name)


class IAdvancedSkin(IAdvancedLayer, ISilvaMobiSkin):
    silvamobi.mobidevice(IAdvancedDeviceType)
    silvamobi.mobiskin(_skin_name)


class Factory(MobiLayoutFactory):
    skin = _skin_name

