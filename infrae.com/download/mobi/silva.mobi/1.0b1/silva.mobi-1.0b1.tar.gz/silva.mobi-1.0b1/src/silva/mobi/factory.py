from five import grok
from zope.interface import Interface
from zope.component import getUtility
from silva.core.interfaces import ISilvaObject
from silva.core.layout.traverser import applySkinButKeepSome
from mobi.interfaces.devices import IBasicDeviceType
from infrae import layout


import logging
logger = logging.getLogger('silva.mobi')


class MobiLayoutFactory(layout.LayoutFactory):

    grok.adapts(Interface, ISilvaObject)
    grok.baseclass()

    # default skin, needs to be overridden by subclasses
    skin = 'Mobile Skin'

    def __init__(self, request, context):
        self.request = request
        self.context = context

    def should_apply(self):
        """
        Default implementation for automatic selection of skin.

        Can be overridden by subclass to customize behavior.
        """
        port = "80"
        host = self.request.environ.get('HTTP_HOST', '')
        if ":" in host:
            host, port = host.split(':', 1)
        return host.startswith('m.') or host.endswith('.mobi')

    def __get_skin(self):
        device_type = self.request.environ.get(
            'mobi.devices.marker', IBasicDeviceType)
        return getUtility(device_type, name=self.skin)

    def __apply_skin(self, skin):
        applySkinButKeepSome(self.request, skin)

    def __call__(self, view):
        """ Lookup the factory for the mobile
        """
        if self.should_apply():
            skin_interface = self.__get_skin()
            logger.info('apply mobile skin %s' % skin_interface.__name__)
            self.__apply_skin(skin_interface)

        return super(MobiLayoutFactory, self).__call__(view)

