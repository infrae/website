# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_grok.py 42356 2010-05-25 13:23:53Z sylvain $
import unittest
import doctest

from Products.Silva.testing import SilvaLayer, suite_from_package
from Products.Silva.testing import Browser

import silva.mobi

mobi_layer = SilvaLayer(silva.mobi, zcml_file='configure.zcml')

globs = {
    'grok': mobi_layer.grok,
    'getRootFolder': mobi_layer.get_application,
    'Browser': Browser,
    }

def create_test(build_test_suite, name):
    test =  build_test_suite(
        name,
        globs=globs,
        optionflags=doctest.ELLIPSIS + doctest.NORMALIZE_WHITESPACE)
    test.layer = mobi_layer
    return test


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(suite_from_package(
            'silva.mobi.tests.grok', create_test))
    return suite

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
