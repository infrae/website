# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt.
