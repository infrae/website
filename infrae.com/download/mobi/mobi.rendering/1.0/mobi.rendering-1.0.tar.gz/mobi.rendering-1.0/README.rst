mobi.rendering
--------------

A simple ztk based rendering system for buildout mobile applications. 

see documentation at http://mobi.infrae.com/rendering_system.html


