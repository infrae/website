===============
mobi.interfaces
===============


Interfaces package for mobi.* libs.
see ``mobi.devices`` for more info.

