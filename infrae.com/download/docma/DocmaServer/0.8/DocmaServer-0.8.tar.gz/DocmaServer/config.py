# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: config.py,v 1.9 2003/08/01 11:04:19 guido Exp $

"""This script parses the configuration file 'docma_config.cfg'

To modify configuration settings, edit 'docma_config.cfg'
"""

import ConfigParser

config = ConfigParser.ConfigParser()
config.read('docma_config.cfg')

XMLRPC_PORT = config.getint('Server', 'xmlrpc_port')
XMLRPC_PASSWORD = config.get('Server', 'xmlrpc_password')
STORAGE_DIRECTORY = config.get('Server', 'storage_directory')
STORAGE_EXPIRE = config.getint('Server', 'storage_expire') * 60
COMMAND_TIMEOUT = config.getint('Server', 'command_timeout')
MAX_RETRIES = config.getint('Server', 'max_retries')
LOG_FILE = config.get('Server', 'log_file') or None
WORD_FRONTPAGES = config.get('Server', 'word_frontpages')
WORD_TEMPLATE = config.get('Server', 'word_template')

# Mail settings

SMTP_SERVER = config.get('Email', 'smtp_server')
SENDER_ADDRESS = config.get('Email', 'sender_address')

# I left these here, since they aren't easily stored in config format files
# and they're probably not modified too often anyway...

MAIL_JOBFINISHED = """Your job %(queueid)s has finished. 
It is stored under the storage id %(storageid)s.

%(description)s

"""

MAIL_JOBFAILED = """Your job %(queueid)s has failed.

%(description)s


Detailed error message:

%(traceback)s

"""


