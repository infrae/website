# requierd for the framework
import getopt, sys, traceback, glob, os

from silva2word.SilvaDOMHandler import SilvaDOMHandler
from xml.dom.minidom import parseString
import os
import tempfile

from cl_app import CommandLineApp

class s2wStandalone(CommandLineApp):
    # if the app processes files, set the following switch to 1
    # this will glob args and use stdin as fallback if not args are
    # provided
    processes_files = 1

    preload = 1

    # the getopt_args will be used to parse the commandline args
    # into a dict, key the value in this dict and value the cl value
    getopt_args = {'t:': 'template', 'v': 'visible'}
    # the result dict
    opts = {}

    # enter the mandatory opts
    required_opts = []

    # enter whether we expect non-opt args as well
    # this only needs to be set if self.processes_files is not set
    # to true
    require_args = 1

    def main(self, data, filename):
        """The main part of the program, this has to be modified for each app

        This method will be called with args if self.processes_files is false,
        and for each path in globbed args or the contents of stdin (read fully)
        if self.processes_files is true
        """
        tmpf = tempfile.mktemp('silva.doc')
        try:
            dom = parseString(data)
        except:
            print 'Exception during parsing %s:' % filename
            exc, e, tb = sys.exc_info()
            print self.format_exc(exc, e, tb)
            del tb
        try:
            kwargs = {}
            if self.opts.has_key('template'):
                kwargs['template'] = self.opts['template']
            if self.opts.has_key('visible'):
                kwargs['visibility'] = 1
            s = SilvaDOMHandler(tmpf, dom, **kwargs)
            s.run(dom)
            root = filename
            if root.find('.') > -1:
                root, ext = os.path.splitext(filename)
            open('%s.doc' % root, 'wb').write(s.getDOC())
        except:
            print 'Exception during processing', filename
            exc, e,  tb = sys.exc_info()
            print self.format_exc(exc, e, tb)
            del tb
        print

    def usage(self, error=None):
        u = ''
        if error:
            u += '%s\n\n' % error
        u += ('Usage: %s [-t <template>] [-v] <paths>\n'
                '\ttemplate is a Word template to use'
                '\t-v toggles visibility\n' % sys.argv[0])
        return u

if __name__ == '__main__':
    s2wStandalone()
