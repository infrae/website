
import unittest

from word2silva import P

class ParagraphTest(unittest.TestCase):

    def list2xml(self, tags):
        return ''.join(map(lambda x: x.tag(), tags))
            
    
    def test_Tag(self):

        tag = P.Tag('foo', '', True, 2)
        self.assertEqual(tag.tag(), '<foo>')
        tag = P.Tag('foo', 'bar="baz"', True, 2)
        self.assertEqual(tag.tag(), '<foo bar="baz">')
        tag = P.Tag('foo', 'bar="baz"', False, 2)
        self.assertEqual(tag.tag(), '</foo>')
        tag = P.Tag('foo', 'bar="baz"', None, 2)
        self.assertEqual(tag.tag(), '<foo bar="baz"/>')
        tag = P.Tag('foo', '', None, 2)
        self.assertEqual(tag.tag(), '<foo/>')
           
    def test_wellform(self):
        t1 = P.Tag('foo', '', True, 1)
        t2 = P.Tag('bar', '', True, 2)
        t3 = P.Tag('foo', '', False, 3)
        t4 = P.Tag('bar', '', False, 4)
        t5 = P.Tag('bar', '', None, 1)
        
        w1 = self.list2xml(P.P.wellform([t1, t2, t3, t4]))
        self.assertEqual(w1, '<foo><bar></bar></foo><bar></bar>')
        w1 = self.list2xml(P.P.wellform([t3]))
        self.assertEqual(w1, '')
        res = self.list2xml(P.P.wellform([t5]))
        self.assertEqual(res, '<bar/>')
        res = self.list2xml(P.P.wellform([t1, t5, t3]))
        self.assertEqual(res, '<foo><bar/></foo>')
           
def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(ParagraphTest))
    return suite

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())



