# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Stephan Richter
# ************************************************************************
"""

$Id: List.py,v 1.4 2003/01/09 09:38:52 zagy Exp $
"""
from SilvaObject import SilvaObject


class List(SilvaObject):


    def __init__(self, original, level, type='none', title=u''):
        SilvaObject.__init__(self, original)

        self.list_level = level
        self.title = title
        self.type = type

    def __repr__(self):
        return self.__class__.__name__+'(%i)' %self.list_level

    def getXML(self):
        xml = u'<nlist type="%s">' %(self.type, )

        for elem in self._elements:
            xml += elem.getXML()

        xml += u'</nlist>'
        return xml

class Li(SilvaObject):

    def getXML(self):
        xml = u'<li>'

        for elem in self._elements:
            xml += elem.getXML()

        xml += u'</li>'
        return xml
                    
