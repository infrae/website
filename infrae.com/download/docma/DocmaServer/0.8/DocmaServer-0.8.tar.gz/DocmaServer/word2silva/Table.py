# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Stephan Richter
# ************************************************************************
"""

$Id: Table.py,v 1.6 2003/01/24 16:11:33 zagy Exp $
"""
from SilvaObject import SilvaObject
from util import stripControlChars


class Table(SilvaObject):

    def __init__(self, original, cols=1, colsizes=None, type="plain"):
        SilvaObject.__init__(self, original)

        self.cols = cols
        self.colsizes = colsizes or cols*[(1, 'L')]
        self.type = type

    def __repr__(self):
        return self.__class__.__name__+'(%i, %s)' %(self.cols, self.type)

    def getXML(self):
        xml = u'<table columns="%s" column_info="%s" type="%s">' % (
            self.cols, ' '.join(map(lambda (w, a): '%s:%s' % (a, w),
                self.colsizes)), self.type)
        for elem in self._elements:
            xml += elem.getXML()
        xml += u'</table>'
        return xml


class Row(SilvaObject):

    def getXML(self):
        xml = u'<row>'
        for elem in self._elements:
            xml += elem.getXML()
        xml += u'</row>'
        return xml


class RowHeader(SilvaObject):    
    
    def __init__(self, original):
        SilvaObject.__init__(self, original)
        self.text = stripControlChars(original.Range.Text.strip())
        
    def getXML(self):        
        return u'<row_heading>%s</row_heading>' % (self.text, )


class Field(SilvaObject):

    def getXML(self):
        xml = u'<field>'
        
        for elem in self._elements:
            xml += elem.getXML()

        xml += u'</field>'
        return xml
            
