# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: convert.py,v 1.59 2004/10/28 16:28:24 guido Exp $

import re
import sys
import os
from types import StringType, UnicodeType
from traceback import format_tb

# Import of COM specific modules and classes
from win32com.client import Dispatch
from pythoncom import CoInitializeEx
from pywintypes import com_error
import time

from twisted.python import log

import silva2word.StyleNameMapping
from silva2word.WordConstants import *
from util import PTDict, lgcd, reverseDict, stripControlChars
from util.timeoutproxy import TimeoutProxy

# import all converter specifc classes
from SilvaObject import SilvaPublication, SilvaFolder, SilvaDocument, TOC
from Heading import Heading
from P import P, Pre
from List import List, Li
from Table import Table, Row, RowHeader, Field
from DefinitionList import DefinitionList, DefinitionTerm
from DefinitionList import DefinitionDescription
from Citation import Citation

INDEX_TITLE = 'Index'

p_LISTSTYLE = \
    re.compile(r"List\s?((?P<style>[A-Za-z\s]+[A-Za-z]))?\s?(?P<level>\d*)")
p_DOCUMENT = re.compile(r"Heading (?P<level>[0-9]+)")
p_HEADING = re.compile(r"(?P<type>[A-Za-z ]+) Heading", re.I)
p_ID = re.compile(r"[^A-Za-z0-9_\.]")
p_COMMENT_VALUE_QUOTES = u'"\u201c\u201d\u201e\u201f'
p_COMMENT_VALUE = re.compile(r'^[%s]([^%s]*)[%s]' % (p_COMMENT_VALUE_QUOTES, 
    p_COMMENT_VALUE_QUOTES, p_COMMENT_VALUE_QUOTES))

# only define the ones that should be mapped, since
# the code checks if there is a key defined for a value
p_HEADING_MAPPING = {'sub sub': 'subsub',
                        'sub paragraph': 'subparagraph',
                        }
    
class StopHandling(Exception):
    """can be raised by any handler to stop processing of further handlers"""

class Converter:

    __tag_to_class = {
        'silva_folder': SilvaFolder,
        'silva_publication': SilvaPublication,
        'silva_document': SilvaDocument,
    }

    __paragraph_alignment = {
        wdAlignParagraphLeft: 'L',
        wdAlignParagraphCenter: 'C',
        wdAlignParagraphRight: 'R',
    }

    # location of the xml schema
    _xml_namespace = "http://www.infrae.com/xml"
    _xml_schema = "silva-0.9.3.xsd"

    def __init__(self, docPath, iAmStillAlive=lambda: None):
        self.iAmStillAlive = iAmStillAlive
        self.docPath = docPath
        
        self.generatedIds = {}
        self.meta = {}
        self.pub = None
        self.stack = []
        self.handlers = []
        self.list_type = None
        
        self._reboot_word(first=True)

        self.isFirstDocument = True

        # Setup some variables that keep track
        self.table_index = 1
        self.col_count = 1
        self.row_count = 1

        self._cacheListIndentation()
        self._buildStyleMaps()

    def _cacheListIndentation(self):
        """caches the LeftIndent attribute of all list styles"""
        
        cache = {}

        level = 0
        while 1:
            level += 1
            name = 'List'
            if level > 1:
                name += ' %i' % (level, )
            try:                
                style = self.doc.Styles(name)
            except com_error:
                break
            indent = style.ParagraphFormat.LeftIndent
            if indent == 0:
                indent = .1
            cache[level] = indent
        self.__list_indentation = cache            
        
    def _buildStyleMaps(self):
        """builds mapping between Word's style names and their english variant
        
            sets self._style_local2canonical and self._style_canonical2local
        """
        id2local = {}
        local2canonical = {}
        for i in range(-100, 0):
            try:
                style = self.doc.Styles(i)
            except com_error:
                continue
            id2local[i] = style.NameLocal
        canonical2id = silva2word.StyleNameMapping.style_name_map
        for c, i in canonical2id.items():
            local_name = id2local[i]
            local2canonical[local_name] = c
        self._style_local2canonical = PTDict(local2canonical)
        self._style_canonical2local = PTDict(reverseDict(local2canonical))

    def __del__(self):
        # Close the document without modifying it
        try:
            try:
                self.doc.Close(SaveChanges=0)
            except com_error:
                pass
            try:
                # No unlink should be done here, since the job might not be 
                # finished (see the _reboot_word hack)
                # XXX This should be done elsewhere though!!
                pass # os.unlink(self.docPath)
            except OSError:
                pass
        except:
            exc, e, tb = sys.exc_info()
            text = '%s: %s\n%s\n' % (exc, e, '\n'.join(format_tb(tb)))

    def getXML(self):
        xml = []
        xml.append('<silva xmlns="%s" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
            '>' % self._xml_namespace)
        # XXX Commenting out the URI to the xsd since it doesn't exist, 
        # and therefore leaving it would break editors trying to load it
        """
        'xsi:schemaLocation="%s %s">' % (self._xml_namespace,
            self._xml_namespace, self._xml_schema))
        """
        if self.pub is not None:
            xml.append(self.pub.getXML())
        xml.append('</silva>')
        return ''.join(xml)

    def getStyle(self, name):
        return self.doc.Styles(self._style_canonical2local[name])

    def findInStack(self, needle):
        """finds needle on stack

            needle: unary function, called for every element on the stack
                if needle returns true, element is returned.

            returns None if needle was not found                
        """
        result = self.findAllInStack(needle)
        if result:
            return result[-1]
        else:
            return None

    def findAllInStack(self, needle):
        stack = self.stack
        result = []
        for element in stack:
            if needle(element):
                result.append(element)
        return result                

    def parseComment(self, comment):
        if not isinstance(comment, (StringType, UnicodeType)):
            try:
                comment = comment.Range.Text
            except com_error:
                raise ValueError, \
                    "comment argument must be string or comment object"
        if not comment.startswith('slv:'):
            return {}
        
        kw = {}
        items = map(lambda x: x.split('='), comment[4:].split(';'))
        for item in items:
            try:
                key, value = item
            except ValueError:
                continue
            m = p_COMMENT_VALUE.search(value)
            if m is None:
                continue
            value = m.group(1)    
            kw[key] = value

        return kw    
            
    def genId(self, text):
        """Generate a unique id from the text."""
        text = p_ID.sub('', text.replace(' ', '_'))
        if text == "":
            text = "unknown"
        if self.generatedIds.has_key(text):
            i = 1
            while self.generatedIds.has_key(text + str(i)):
                i += 1
            text = text + str(i)
        self.generatedIds[text] = 1
        return text
   
    def getNextId(self, wp):
        meta = {}
        if self.pub is None:
            prop = self.doc.BuiltinDocumentProperties
            unknown = prop(wdPropertyTitle).value
            comments = prop(wdPropertyComments).value
            if comments:
                for line in comments.split('\n'):
                    line = line.strip()
                    meta = self.parseComment(line)
                    if meta != {}:
                        break
        else:
            unknown = 'unknown'
            meta = self.meta
        text = stripControlChars(wp.Range.Text).strip()
        uid = None
        obj = None
        uid = meta.get('id')
        obj = meta.get('obj')
        if not uid:
            uid = text
        if not uid:
            uid = meta.get('title')
        if not uid:
            uid = unknown
        uid = self.genId(uid)
        return uid, obj

    def correctDocumentId(self, id):
        if id in ['silva_root', ]:
            id = 'd_' + id
        return id.lower()

    def _make_stats(self, start, end):
        delta_time = end-start
        mins = int(delta_time)/60
        secs = delta_time%60

        print "Required time: %.2i:%.2d" %(mins, secs)
        print "Pages Generated: %i" %self.doc.Range().ComputeStatistics(2)

    def run(self):
        stack = self.stack
        list_type = 'none'
        start = time.time()
        # Walk through all paragraphs in the document. Note that paragraphs
        # seem to be the best choice here, since Word seems to be
        # paragraph-based and everything else is simply markup.
        paragraphs = len(self.doc.Paragraphs)
        for pid in range(0, paragraphs):
            if pid > 0 and pid % 30 == 0:
                self._reboot_word()
            wp = self.doc.Paragraphs[pid]                
            wp.Range.Select()
            self.handleWordParagraph(wp)
        end = time.time()
        self._make_stats(start, end)

    def remove_index(self):
        """Removes the index from the back (I assume :) of the document"""
        # remove only the last one, who knows what the author had in mind if 
        # (s)he decided to use more than one...
        if len(self.doc.Indexes):
            self.doc.Indexes[len(self.doc.Indexes) - 1].Delete()
            # remove the last paragraphs as long as they're empty or
            # when they seem to be the 'Index' header
            i = 0
            while 1:
                i += 1
                lastpar = stripControlChars(
                            self.doc.Paragraphs.Item(
                                    self.doc.Paragraphs.Count - 1
                                ).Range.Text).strip()
                if not lastpar or lastpar == INDEX_TITLE:
                    self.doc.Paragraphs.Item(
                                self.doc.Paragraphs.Count - 1
                            ).Range.Delete()
                    if lastpar == INDEX_TITLE:
                        break
                else:
                    break

    def remove_word_tocs(self):
        """Removes all the Table of Contents fields (the Word things, not the 
        Silva things) from the document
        """
        while len(self.doc.TablesOfContents):
            self.doc.TablesOfContents[len(self.doc.TablesOfContents) - 1].Delete()
            
    def _reboot_word(self, first=False):
       
        if not first:
            self.doc.Close(SaveChanges=wdSaveChanges)
            self.app.Quit(SaveChanges=wdDoNotSaveChanges)
            self.app = None
        
        self.app = None
        i = 0
        while not hasattr(self.app, 'Documents'):
            self.app = Dispatch("Word.Application")
            i += 1
            if i >= 100:
                raise Exception, 'Error instantiating COM object'
            time.sleep(0.1)

        self.doc = self.app.Documents.Open(self.docPath)
        for window in self.doc.Windows:
            self.app.Visible = 1
            view = window.View
            view.ShowAll = False
            view.ShowHiddenText = False
            view.ShowFieldCodes = False

        self.remove_index()
        self.remove_word_tocs()

        """
        # Start Word and load
        #thread_init = lambda: CoInitializeEx(0)
        #self.app = TimeoutProxy(Dispatch, thread_init=thread_init)(
        #    'Word.Application')
        self.app = Dispatch('Word.Application')
        # perform the same dirty trick here as in silva2word/SilvaDOMHandler.py
        # to make sure the com instance is actually created
        i = 1
        try:
            self.doc = self.app.Documents.Open(self.docPath)
            for window in self.doc.Windows:
                self.app.Visible = 1
                view = window.View
                view.ShowAll = False
                view.ShowHiddenText = False
                view.ShowFieldCodes = False

        except:
            i += 1
            if i >= 100:
                raise
            time.sleep(1)
            self.app = Dispatch('Word.Application')
        """
        
    def handleWordParagraph(self, wp):
        handlers = self.handlers = self.getHandlers(wp)
        while len(handlers) > 0:
            self.iAmStillAlive()
            handler = handlers[0]
            del(handlers[0])
            try:
                handler(wp)
            except StopHandling:
                self.handlers = []
                break

    def getHandlers(self, wp):
        """returns a list of handlers for given word paragraph"""
        handlers = []
        if wp.Style is None:
            return []
        wp_style = wp.Style.NameLocal
        can_wp_style = self._style_local2canonical[wp_style]
        handlers.append(self.handleComments)
        if can_wp_style == 'List Spacing':
            return []
        if can_wp_style == 'Plain Text':
            isPreformatted = True
        else:
            handlers.append(self.closePreformatted)
            isPreformatted = False
        if can_wp_style.startswith('Definition '):
            isDefinition = True
        else:
            handlers.append(self.closeDefinitionList)
            isDefinition = False
        if can_wp_style.startswith('Citation '):
            isCitation = True
        else:
            handlers.append(self.closeCitation)
            isCitation = False
        if (not can_wp_style.startswith('Heading') and 
                self.getListLevel(wp) > 0):
            isList = True
        else:
            handlers.append(self.closeList)
            isList = False
        if self.getTableSurrounding(wp) is not None:
            isTable = True
        else:
            isTable = False
            handlers.append(self.closeTable)
        if self.pub is None:
            handlers.append(lambda wp: self.handleDocument(wp, level=1))
        if isTable:
            handlers.append(self.handleTable)
        if isCitation:
            handlers.append(self.handleCitation)
        if isList:
            handlers.append(self.handleList)
        if isDefinition:
            handlers.append(self.handleDefinitionList)
        elif isPreformatted:
            handlers.append(self.handlePreformatted)
        elif (can_wp_style.startswith('Heading ')):
            handlers.append(self.handleDocument)
        elif can_wp_style == 'Preface Heading':
            handlers.append(lambda wp: self.handleDocument(wp, level=1))
        elif (can_wp_style.endswith(' Heading') and
                can_wp_style != 'Row Heading'):
            handlers.append(self.createHeading)
        else:
            handlers.append(self.handleParagraph)
        return handlers

    def handleDocument(self, wp, level=None):
        self.is_first_paragraph = 1
        stack = self.stack 
        title = stripControlChars(wp.Range.text.strip())
        if level is None:            
            m = p_DOCUMENT.match(
                self._style_local2canonical[wp.Style.NameLocal])
            if m is None:
                h = Heading(wp)
                stack[-1].addElement(h)
                return
            level = int(m.group('level'))
        # Now move to the right node in the tree.
        while (stack and (level <= getattr(stack[-1], 'level', sys.maxint)
                or not isinstance(stack[-1], (SilvaPublication, 
                SilvaFolder)))):
            self.stack.pop()
        document_id, tag_name = self.getNextId(wp) 
        document_id = self.correctDocumentId(document_id)
        object_class = self.__tag_to_class.get(tag_name)
        if object_class is None:
            object_class = SilvaFolder
        if not title: 
            if self.isFirstDocument:
                self.isFirstDocument = 0
                title = self.doc.BuiltinDocumentProperties(
                                    wdPropertyTitle
                                ).value
            elif self.pub is None:
                title = self.doc.BuiltinDocumentProperties(
                    wdPropertyTitle).value
            else:
                title = self.meta.get('title', '')
        obj = object_class(wp, id=document_id, title=title, level=level)
        if self.pub is None:
            self.pub = obj
            obj.isRoot = True
        if stack == []:
            stack.append(self.pub)
        if stack[-1] is not obj:
            container = stack[-1]
            index = container._elements[0]
            # delete an empty index
            if isinstance(index, SilvaDocument) and index.id == 'index':
                if len(index._elements ) == 0:
                    del(container._elements[0])
            container.addElement(obj)
            stack.append(obj)
        if isinstance(obj, (SilvaFolder, SilvaPublication)):
            obj = SilvaDocument(wp, id='index', title=title, level=level)
            stack[-1].addElement(obj)
            stack.append(obj)
     
    def handleComments(self, wp):
        self.meta = {}
        comments = wp.Range.Comments
        wp_start = wp.Range.Start
        wp_end = wp.Range.End
        if len(comments) == 0:
            return
        for comment in comments:
            if comment.Reference.Start < wp_start: 
                continue
            if comment.Reference.End > wp_end:
                break
            kw = self.parseComment(comment)
            if kw == {}:
                continue
            self.meta.update(kw)

    def createHeading(self, wp):
        self.closeList(wp)
        self.closeTable(wp)
        self.closeCitation(wp)
        self.closePreformatted(wp)
        self.closeDefinitionList(wp)
        text = wp.Range.Text
        m = p_HEADING.match(text)
        if m is None:
            type = None
        else:
            type = m.group('type')
        # Simply create and add it.
        if type:
            type = type.lower()
        if p_HEADING_MAPPING.has_key(type):
            type = p_HEADING_MAPPING[type]
        h = Heading(wp, type)
        self.stack[-1].addElement(h)

    # List methods
    def createList(self, level, list_type):
        stack = self.stack
        lst = List(None, level, list_type, '')
        stack[-1].addElement(lst)
        stack.append(lst)
        return lst

    def closeList(self, wp):
        """Finishes all lists"""
        stack = self.stack
        while self.findInStack(lambda x: isinstance(x, List)):
            stack.pop()

    def getListStyle(self, wp):
    
        # mapping of lower case word styles to xml styles
        word2xml = {
            'number': '1',
            'roman upper': 'I',
            'roman': 'i',
            'letter upper': 'A',
            'letter': 'a',
            'bullet': 'disc',
            'square': 'square',
            'circle': 'circle',
            '': 'none',
        }
        word_style = self._style_canonical2local[wp.Style.NameLocal]
      
        m = p_LISTSTYLE.match(word_style)
        if m is None:
            # this is not a list style 
            if wp.Range.ListFormat.ListType in (wdListSimpleNumbering,
                    wdListOutlineNumbering, wdListMixedNumbering):
                style = '1'
            elif wp.Range.ListFormat.ListType == wdListBullet:
                style = 'disc'
            else:
                style = None
            if style is None:
                return None
            return style, 1 
        if m.group('style') is None:
            style = 'none'
        else:            
            try: 
                style = word2xml[m.group('style').lower()]
            except KeyError: 
                style = 'none'
        try: 
            level = int(m.group('level'))
        except ValueError: 
            level = 1
        return (style, level)

    def getListLevel(self, wp):
        """return list level of passed word paragraph"""
        style = self.getListStyle(wp)
        if style is not None:
            return style[1]
        # no list style, so apply magic :)
        indent = wp.Format.LeftIndent
        list_in = self.__list_indentation
        for level in list_in:
            if list_in[level] <= indent < list_in.get(level+1, sys.maxint):
                return level
        return 0

    def handleList(self, wp):
        """handles lists"""
        stack = self.stack
        _style = self.getListStyle(wp)
        li = None
        if _style is None:
            # list item is continuing
            isContinuing = True
            new_list_type = 'none' #HUUUH
            level = self.getListLevel(wp)
        else:
            isContinuing = False
            new_list_type, level = _style
            
        find_list = lambda: self.findInStack(lambda x: isinstance(x, List))
        get_current_list_level = lambda: len(self.findAllInStack(lambda x: 
            isinstance(x, List)))
        currentList = find_list()
        currentListLevel = get_current_list_level()
       
        if currentList is None and isContinuing:
            # something went wrong, but it's definitive not a list
            return
        
        if not isContinuing and (currentList is None or 
                currentList.type != new_list_type or 
                currentListLevel != level):
            # we need to create a new list, so pop everything from the stack
            # until the list level is reached
            while currentListLevel >= level:
                stack.pop()
                currentListLevel = get_current_list_level()
                if currentListLevel == level:
                    top_list = find_list()
                    # in case the style does not change, keep the list and 
                    # just add a new list item.
                    if top_list.type == new_list_type:
                        li = Li(wp)
                        top_list.addElement(li)
                        stack.append(li)
                        break
            while currentListLevel < level:
                lst = self.createList(currentListLevel+1, new_list_type)
                li = Li(wp)
                lst.addElement(li)
                stack.append(li)
                currentListLevel = get_current_list_level()
        elif not isContinuing:
            li = Li(wp)
            currentList.addElement(li)
            if isinstance(stack[-1], Li):
                stack.pop()
            stack.append(li)
        else:
            li = currentList._elements[-1]

        if not isContinuing:
            text = wp.Range.Text.strip()
            if not text == '':
                li.addElement(P(wp))
            raise StopHandling
             
    def getTableSurrounding(self, wp):
        """return table object which surrounds given word_paragraph

            If there is no table None is returned.
        """
        try:
            return wp.Range.Tables[0]
        except IndexError:
            return None

    def createTable(self, wp):
        self.closeList(wp)
        self.closePreformatted(wp)
        self.closeDefinitionList(wp)
        self.closeCitation(wp)
        wt = self.getTableSurrounding(wp)
        stack = self.stack
        self.col_count = 0
        self.row_count = 0 
        self.row_count_max = wt.Rows.count
        self.col_count_max = wt.Columns.count
        tableWidths = []
        max_cells = 0
        for i in range(0, self.row_count_max):
            row = wt.Rows[i]
            cells = row.Cells.count
            if cells < self.col_count_max:
                continue
            for j in range(0, cells):
                cell = row.Cells[j]
                width = cell.width
                alignment = self.__paragraph_alignment.get(
                    cell.Range.ParagraphFormat.Alignment, 'L') 
                tableWidths.append((width, alignment))
            break
        # somehow gcd can result in 0 sometimes, so added extra check here
        gcd = 0
        if tableWidths:
            max_width = max(map(lambda (w, a): w, tableWidths))
            if max_width == 0: max_width = 1
            tableWidths = \
                map(lambda (w, a): (int(w), a),
                map(lambda (w, a): ((w/max_width)*50, a),
                    tableWidths))
            gcd = lgcd(map(lambda (w, a): w, tableWidths))

        if tableWidths and gcd != 0:
            tableWidths = map(lambda (w, a): (w/gcd, a), tableWidths)
        else:
            tableWidths = self.col_count_max*[(1, 'L')]
        self.handleComments(wp)
        table = Table(wt, self.col_count_max, tableWidths, 
            self.meta.get('type', 'grid'))
        stack[-1].addElement(table)
        stack.append(table)
        
    def handleTable(self, wp):

        stack = self.stack
        handlers = self.handlers
        wt = self.getTableSurrounding(wp)
        if self.findInStack(lambda x: isinstance(x, Table)) is None:
            self.createTable(wp)
        try:            
            cell = wp.Range.Cells[0]
        except IndexError:
            return
        if cell.RowIndex > self.row_count:
            self.createTableRow(wp)
        if cell.ColumnIndex > self.col_count:
            self.createTableCell(wp)

    def createTableRow(self, wp):
        stack = self.stack
        cell = wp.Range.Cells[0]
        row = cell.Row
        self.row_count = cell.RowIndex
        self.col_count = cell.ColumnIndex
        if not isinstance(stack[-1], Table):
            while not isinstance(stack[-1], (Row, RowHeader)):
                stack.pop()
            last_row = stack[-1]
            if isinstance(last_row, Row):
                # Pump in missing fields in case user joined some cells
                while len(last_row._elements) < self.col_count_max:
                    last_row.addElement(Field(wp))
            while not isinstance(stack[-1], Table):
                stack.pop()
        if (row.Cells.count == 1 and self.col_count_max > 1 or 
            self.col_count_max == 1 and
                self._style_local2canonical[wp.Style.NameLocal] == 
                    "Row Heading"):
            rh = RowHeader(wp)
            stack[-1].addElement(rh)
            stack.append(rh)
        else:            
            r = Row(wp)
            stack[-1].addElement(r)
            stack.append(r)
            self.createTableCell(wp)
            
    def createTableCell(self, wp):
        stack = self.stack
        cell = wp.Range.Cells[0]
        self.col_count = cell.ColumnIndex
        if self.col_count > 1:
            self.closeList(wp)
            self.closeDefinitionList(wp)
            self.closePreformatted(wp)
            while not isinstance(stack[-1], Row):
                stack.pop()
        field = Field(wp)                
        stack[-1].addElement(field)
        stack.append(field)

    def closeTable(self, wp):
        stack = self.stack
        while self.findInStack(lambda x: isinstance(x, Table)):
            stack.pop()            

    def createCitation(self, wp):
        self.closeTable(wp)
        self.closeList(wp)
        self.closePreformatted(wp)
        self.closeDefinitionList(wp)
        cite = Citation(wp)
        stack = self.stack
        stack[-1].addElement(cite)
        stack.append(cite)
        return cite
        
    def handleCitation(self, wp):
        stack = self.stack
        handlers = self.handlers
        if self.findInStack(lambda x: isinstance(x, Citation)) is None:
            cite = self.createCitation(wp)
            print 'created new citation'
        else:
            cite = stack[-1]

        wp_style = wp.Style.NameLocal
        if wp_style == self._style_canonical2local['Citation Author']:
            content = stripControlChars(wp.Range())
            cite.setAuthor(content)
            print 'setting author to', content
        elif wp_style == self._style_canonical2local['Citation Source']:
            content = stripControlChars(wp.Range())
            cite.setSource(content)
            print 'setting source to', content
        elif wp_style == self._style_canonical2local['Citation Text']:
            content = P(wp, 1).getXML()
            cite.setContent(content)
            print 'setting content to', repr(content)
            

    def closeCitation(self, wp):
        stack = self.stack
        while self.findInStack(lambda x: isinstance(x, Citation)):
            stack.pop()
           
    def handleParagraph(self, wp):
        
        # Create the paragraph and add it to the tree. No
        # stack entry needed, since nothing ever can go into a
        # paragraph.
        
        self.stack[-1].addElement(P(wp, self, correct_first=self.is_first_paragraph))
        self.is_first_paragraph = 0

    def handleDefinitionList(self, wp):
        stack = self.stack
        wp_style = wp.Style.NameLocal

        if isinstance(stack[-1], DefinitionList):
            dl = stack[-1]
        else:                     
            dl = DefinitionList(wp) # XXX: handle type
            stack[-1].addElement(dl)
            stack.append(dl)

        if wp_style == self._style_canonical2local['Definition Term']:
            item_class = DefinitionTerm
        elif wp_style == self._style_canonical2local['Definition Description']:
            item_class = DefinitionDescription
        else:
            item_class = None

        if item_class is not None:
            dl.addElement(item_class(wp))

    def closeDefinitionList(self, wp):
        stack = self.stack
        if stack and isinstance(stack[-1], DefinitionList):
            stack.pop()

    def handlePreformatted(self, wp):
        stack = self.stack
        if isinstance(stack[-1], Pre):
            pre = stack[-1]
        else:
            pre = Pre(wp)
            stack[-1].addElement(pre)
            stack.append(pre)
        
        pre.addElement(stripControlChars(wp.Range.Text))

    def closePreformatted(self, wp):
        stack = self.stack
        if stack and isinstance(stack[-1], Pre):
            stack.pop()

