# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: SilvaObject.py,v 1.10 2003/03/26 16:07:23 zagy Exp $
"""

$Id: SilvaObject.py,v 1.10 2003/03/26 16:07:23 zagy Exp $
"""

from util import replaceMap, stripControlChars

class SilvaObject:
    
    tagName = ""
    
    def __init__(self, original, title=u'', level=1, id=None):
        self.id = id
        self._elements = []
        self.title = title
        self.original = original
        if not hasattr(self, "level"):
            self.level = level


    def __repr__(self):
        return self.__class__.__name__


    def addElement(self, element):
        self._elements.append(element)

    def getXML(self):
        xml = u'<silva_%s id="%s"><title>%s</title>' % (self.tagName, 
            self.getId(), self.getTitle())
        for elem in self._elements:
            xml += elem.getXML()
        xml += u'</silva_%s>' % self.tagName
        return xml


    def getId(self):
        return self.id.encode('us-ascii', 'remove')


    def getTitle(self):
        return stripControlChars(replaceMap(self.title.strip()))



class SilvaDocument(SilvaObject):
    tagName = "document"

    def addElement(self, element):
        if isinstance(element, (SilvaPublication, SilvaFolder, 
                SilvaDocument)):
            raise ValueError, "Document cannot contain %s" % (
                type(element), )
        SilvaObject.addElement(self, element)                

    def getXML(self):
        xml = u'<silva_document id="%s"><title>%s</title><doc>' % (
            self.getId(), self.getTitle(), )
        for elem in self._elements:
            xml += elem.getXML()
        xml += '</doc></silva_document>'
        return xml
       
    def getId(self):
        doc_id = SilvaObject.getId(self)
        if not doc_id:
            doc_id = 'index'
        return doc_id    
        

class SilvaFolder(SilvaObject):
    tagName = "folder"

    def __init__(self, original, title=u'', level=1, id=None, root=False):
        SilvaObject.__init__(self, original, title, level, id)
        self.isRoot = root
        
        
    def getXML(self):
        if not self._elements: 
            return u''
        e = self._elements        
        if len(e) == 1:
            if not self.isRoot and e[0].id == 'index':
                e[0].id = self.id
            return e[0].getXML()                    
        return SilvaObject.getXML(self)
     

class SilvaPublication(SilvaFolder):
    level = 0
    tagName = "publication"

    def addElement(self, element):
        if not isinstance(element, (SilvaDocument, SilvaFolder, TOC)):
            print "can't add %s to publication" % element
            return
        SilvaObject.addElement(self, element)


class Help:
    def __init__(self, orig):
        self.orig = orig
        self.Range = orig.Parent.Range()

class TOC(SilvaObject):

    def __init__(self, orig, title=u""):
        SilvaObject.__init__(self, orig, title, id="index")
        
    def getXML(self):
        return ('<silva_document id="index"><title>%s</title>'
                '<doc><toc></toc></doc></silva_document>' % self.title)

