# Copyright (c) infrae in 2004
"""

$Id: Citation.py,v 1.1 2004/10/27 15:09:15 guido Exp $
"""
from SilvaObject import SilvaObject
from util import stripControlChars


class Citation(SilvaObject):

    author = 'error: author not set'
    source = 'error: source not set'
    content = 'error: no content found'

    def __repr__(self):
        return self.__class__.__name__

    def getXML(self):
        xml = (u'<cite><author>%s</author><source>%s</source>%s</cite>' %
                    (self.author, self.source, self.content))
        return xml

    def setAuthor(self, author):
        self.author = author

    def setSource(self, source):
        self.source = source

    def setContent(self, content):
        self.content = content
        
