# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: service.py,v 1.22 2003/06/03 10:36:04 guido Exp $



"""DocMa service that ties all the pieces together."""

# system imports
import os
import tempfile
import time
from types import IntType
from cStringIO import StringIO
from email.MIMEText import MIMEText

# twisted imports
from twisted.internet import app
from twisted.web import server
from twisted.python import util
from twisted.persisted import dirdbm
from twisted.internet import reactor
# docma imports
from docma import xmlrpc, mail
from batchprocessor import queue, processpool
import silva2word
import config


def deleteFile(result, filename):
    try:
        os.remove(filename)
    except OSError:
        pass
    return result


class DocMaService(app.ApplicationService):
    """A service that does DocMa batch processing."""

    fromEmail = config.SENDER_ADDRESS
    smtpHost = config.SMTP_SERVER
    password = config.XMLRPC_PASSWORD
    storagePath = os.path.abspath(config.STORAGE_DIRECTORY)
    expireTimeout = config.STORAGE_EXPIRE
    frontTemplatesPath = os.path.abspath(config.WORD_FRONTPAGES)
    wordTemplate = os.path.abspath(config.WORD_TEMPLATE)
    timeout = config.COMMAND_TIMEOUT * 60 # convert to seconds
    commandRetries = config.MAX_RETRIES
    
    def __init__(self, application):
        app.ApplicationService.__init__(self, "infrae.docma", application)
        self.xmlrpcFactory = server.Site(xmlrpc.DocMa(self))
        # disable HTTP logging
        self.xmlrpcFactory.log = lambda request: None
        
    def startService(self):
        app.ApplicationService.startService(self)
        self.queue = queue.Queue()
        self.pool = processpool.ProcessPool(1, self.queue,
                                            timeout=self.timeout,
                                            maxRuns=self.commandRetries)
        self.expire()
        self.storage = dirdbm.Shelf(os.path.join(self.storagePath, "storage"))
        self.descriptions = dirdbm.Shelf(os.path.join(self.storagePath,
            "descriptions"))
        self.prefix = "%s-" % os.getpid()
        try:
            self.storagecounter = max(map(int, self.storage.keys())) + 1
        except ValueError:
            self.storagecounter = 0
        if not isinstance(self.storagecounter, IntType):
            self.storagecounter = 0

    def stopService(self):
        del self.storage
        del self.descriptions
        del self.prefix
        del self.queue
        del self.pool

    def expire(self):
        """Expire word2silva entries."""
        reactor.callLater(60, self.expire)
        if not hasattr(self, "storage"):
            return
        now = time.time()
        for k in self.storage.keys():
            if now - self.storage.getModificationTime(k) > \
                    self.expireTimeout * 60:
                del self.storage[k]
                try:
                    del self.descriptions[k]
                except KeyError:
                    pass

    def emailSuccess(self, result, toEmail, description, storage_id, queue_id):
        text = config.MAIL_JOBFINISHED % {
            'storageid': storage_id,
            'queueid': queue_id,
            'description': description,
        }
        subject = 'DocmaServer job %s finished' % (queue_id, )
        payload = [MIMEText(text.encode('UTF-8'), _charset='UTF-8')]
        mail.sendEmail(payload, config.SENDER_ADDRESS, toEmail, subject, 
            self.smtpHost)
        return result
        
    def emailFailure(self, failure, toEmail, description, storage_id, queue_id):
        tb = StringIO()
        failure.printTraceback(tb)
        tb = tb.getvalue()
        text = config.MAIL_JOBFAILED % {
            'storageid': storage_id,
            'queueid': queue_id,
            'traceback': tb,
            'description': description,
        }
        subject = 'DocmaServer processing failure'  
        payload = [MIMEText(text.encode('UTF-8'), _charset='UTF-8')]
        mail.sendEmail(payload, config.SENDER_ADDRESS, toEmail, subject,
            self.smtpHost)
        # Debugging email sent on error
        #mail.sendEmail(payload, config.SENDER_ADDRESS, 'guido@infrae.com', subject,
        #    self.smtpHost)
        return failure            

    def silva2word(self, username, frontTemplate, silvaDoc, description, reboot_pause=5):
        """Convert silva XML to word file.

        Returns tuple (ident, result) where result is a Deferred
        (which will eventually return a string whose contents are Word file.)

        The identifier can be used for querying the queue about the status
        of the operation.
        """
        from docma import word
        filename = tempfile.mktemp('silva.doc')
        queueID, d = self.queue.addCommand(username, word.Silva2Word(
            filename, silvaDoc, frontTemplate, self.wordTemplate, description, reboot_pause))
        
        storageID = self.storagecounter
        d.addBoth(deleteFile, filename)
        d.addCallback(self._storeResult, storageID, username, description, 
            'word')
        self.storagecounter += 1

        return  queueID, storageID, d

    def word2silva(self, username, wordFile, description):
        """Convert word file to silva XML.

        Returns tuple (queueID, storageID, result) where result is a Deferred
        (which will eventually return 1.)
        
        The XML is stored in storage area, and can be retrieved using the
        getResult() command using the storageID returned by this command.
        """
        # create word file on filesystem
        filename = tempfile.mktemp('silva.doc')
        f = open(filename, "wb")
        f.write(wordFile)
        f.close()

        # queue command
        from docma import word
        queueID, d = self.queue.addCommand(username, word.Word2Silva(filename,
            description))
        storageID = self.storagecounter
        self.storagecounter += 1
        
        # delete the file when processing is done
        d.addBoth(deleteFile, filename)
        d.addCallback(self._storeResult, storageID, username, description, 
            'silva')
        
        return queueID, storageID, d

    def _storeResult(self, result, storageID, username, description, format):
        key = str(storageID)
        self.storage[key] = result
        self.descriptions[key] = (username, description, format)
        
    
    def getResult(self, id):
        """Return result of a word2silva command."""
        return self.storage[str(id)]

    def delResult(self, id):
        """Delete result of a word2silva command."""
        key = str(id)
        del self.storage[key]
        del self.descriptions[key]

    def getDescriptions(self):
        """Return list of (id, description) tuples."""
        return map(lambda (a, (b, c, d)): (a, c), self.getResultDescriptions())
    
    
    def getResultUsers(self):
        """returns list of (id, username) tuples. """
        return map(lambda (a, (b, c, d)): (a, b), self.getResultDescriptions())
        
   
    def getResultDescriptions(self, username=None):
        """returns list of (id, (username, description, format)) tuples
        
            If username is not None only items matching this username are 
            returned.  Format is either 'word' or 'silva'.
            
        """
        
        return \
            filter(lambda (a, (b, c, d)): 
                username is None and 1 
                or username == c, 
            map(lambda (x, y): (int(x), y),
                self.descriptions.items()))
        
    def getFrontTemplate(self, name):
        """Return path to a template for front page."""
        # clean any path separators from names, for security
        if not name: return None
        return os.path.join(self.frontTemplatesPath, name + ".doc")
    
