# dummy init, is imported by 'word.py' and can be used to set e.g. path 
# and environment vars
# used for the Windows installer
