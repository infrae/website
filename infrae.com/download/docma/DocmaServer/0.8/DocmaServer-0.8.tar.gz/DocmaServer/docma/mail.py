# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: mail.py,v 1.5 2003/08/11 11:43:51 guido Exp $
"""Send email with attachment."""

from types import TupleType, ListType
from cStringIO import StringIO
from email.MIMEMultipart import MIMEMultipart
from smtplib import SMTP

from twisted.internet import reactor

def sendEmail(attachments, fromEmail, toEmail, subject, smtphost):
    """Send an email with an attachment.

        attachments: list, payload of message
        
        Returns Deferred with result.
    """
    email = MIMEMultipart()
    email['Subject'] = subject
    email['From'] = fromEmail
    email['To'] = toEmail
    for payload in attachments:
        email.attach(payload)
    smtp = SMTP(smtphost)
    smtp.sendmail(fromEmail, [toEmail], email.as_string())
