#!/usr/bin/env python
# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: Silva XML to KWD Converter
# *
# * Creation Date: May 2002
# *
# * Authors: Stephan Richter
# ************************************************************************
"""
Executable. Syntax:

run <XML File Path> [<title page path>] [<Template File Path>]

$Id: run.py,v 1.3 2003/06/03 10:36:05 guido Exp $
"""
import SilvaDOMHandler

from types import StringType, UnicodeType, ListType
StringTypes = (StringType, UnicodeType)

import xml.dom.minidom, sys, os


TEMPLATE = os.path.join(os.path.dirname(os.path.abspath(SilvaDOMHandler.__file__)), "template.dot")


def getDOM(file):
    """Get DOM tree from file or filename"""
    if type(file) in StringTypes:
        file = open(file)

    text = file.read()
    dom = xml.dom.minidom.parseString(text)

    return dom


if __name__ == '__main__':

    xml_fn = sys.argv[1]
    try:
        template = sys.argv[3]
    except:
        template = TEMPLATE

    try:
        front = sys.argv[2]
    except:
        front = ''
    
    dom = getDOM(xml_fn)
    handler = SilvaDOMHandler.SilvaDOMHandler(front, template, 2)
    handler.run(dom)
    #handler.process(dom, front, template, 2)
