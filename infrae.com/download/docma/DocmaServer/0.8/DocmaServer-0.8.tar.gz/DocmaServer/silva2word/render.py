# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: render.py,v 1.10 2004/10/27 15:09:15 guido Exp $

"""Rendering library for Silva.

This contains various utilty classes for rendering Silva documents.

Plugin modules for rendering specific Silva tags can use these classes
for rendering, but they don't need to. The classes are designed so that
they can support multiple rendering formats. At the moment however,
they only support MS Word rendering.
"""

class Renderable:
    """An object that can be rendered on to a document."""
    
    postProcessWord = None
    
    def setPostProcessWord(self, f):
        """Set a post processing function for Word COM objects.

        f will be called with two arguments - f(handler, obj):
           handler - the SilvaDOMHandler used for rendering
           obj - the Word COM object.

        This method allows you to customize output of Renderables, without
        having to subclass them.
        """
        assert callable(f)
        self.postProcessWord = f
    
    def renderWord(self, context, handler):
        """Render to Word, given a SilvaDOMHandler object.

        Override this if you don't want the default policy.
        """
        obj = self.doRenderWord(context, handler)
        if self.postProcessWord:
            self.postProcessWord(handler, obj)
    
    def doRenderWord(self, context, handler):
        """Should return a Word COM object that was created."""
        raise NotImplementedError, "implement in subclasses"

    def cleanupWord(self, handler):
        """Move to end of the document."""
        end = handler.doc.Range().End
        sel = handler.app.Selection
        sel.Start = end
        sel.End = end
        sel.Style = handler.getStyle("Body Text")

class Table(Renderable):
    """A table."""

    def __init__(self, subtable=0, type='plain', aligns=None):
        self.rows = []
        self.widths = None
        self.subtable = subtable
        self.table_type = type
        self.aligns = aligns
    
    def setWidths(self, *widths):
        """Set the widths of the table columns.

        Values should be floating point values that add up to 1.
        """
        self.widths = widths
    
    def addRow(self, *cells):
        """Add a row of cells to the table.

        Cells should be Cell instances.
        """
        self.rows.append(cells)

    def doRenderWord(self, context, handler):
        app, doc = handler.app, handler.doc
        if self.subtable:
            app.Selection.Style = handler.getStyle(context.style)
            app.Selection.TypeText(' ')
            text_len = app.Selection.End
        else:
            app.Selection.TypeText(' ')
            text_len = doc.Range().End
        numcols = max(map(len, self.rows))
        table = app.Selection.Tables.Add(
                    doc.Range(text_len-1, text_len), len(self.rows), numcols)

        handler._clear_table(table)
        
        # set table widths
        table_width = table.Columns.Width * numcols
        if self.widths:
            for i in range(len(self.widths)):
                table.Columns(i+1).Width = table_width * self.widths[i]

        # create cell contents
        i = 0
        for row in self.rows:
            j = 0
            for cell in row:
                start = table.Cell(i+1, j+1).Range.Start
                handler.app.Selection.Start = start
                handler.app.Selection.End = start
                for r in cell.renderables:
                    r.renderWord(context, handler)
                c = table.Cell(i+1,j+1)
                if cell.style:
                    c.Range.Style = handler.getStyle(cell.style)
                if self.aligns:
                    if c.Range.Paragraphs.Count == 1:
                        c.Range.Paragraphs(1).Alignment = handler._align_mapping[self.aligns[j]]
                j += 1
            if j > 0 and j < numcols:
                # we either allow cells or a row heading (in which all cells are merged)
                table.Rows(i+1).Cells.Merge()
                try:
                    # this can error out in a weird way, try to perform the 
                    # action and if anything goes wrong we'll just skip it
                    table.Cell(i+1, 1).Range.Style = 'Row Heading'
                except:
                    pass
            i += 1
            
        table.LeftPadding = 1.5
        table.RightPadding = 1.5
        table.TopPadding = 0.5
        table.BottomPadding = 0.5

        self.set_table_style(table)
        
        #Tag the first table cell with the style attributes.
        handler.addComment(Range=table.Cell(1,1).Range, type=self.table_type)

        return table

    def set_table_style(self, table):
        type = self.table_type
        if type == 'plain':
            pass
        
        elif type == 'grid':
            for b in range(6):
                table.Borders(b+1).Visible = 1
            table.Rows(1).Range.Bold = 1
            table.Rows(1).HeadingFormat = -1

        elif type == 'datagrid':
            for b in range(6):
                table.Borders(b+1).Visible = 1
            table.Rows(1).Borders(1).Visible = 0
            table.Rows(1).Borders(2).Visible = 0
            table.Rows(1).Borders(4).Visible = 0
            table.Rows(1).Borders(5).Visible = 0
            table.Rows(1).Range.Bold = 1

        elif type == 'listing' or type == 'list':
            table.Rows(1).Borders(3).Visible = 1
            table.Rows(1).Range.Bold = 1

class Cell:
    """A cell in a table.

    Accepts a list of renderables and an optional style for the cell.
    """
    
    def __init__(self, renderables, style=None):
        self.renderables = renderables
        self.style = style

class Text:
    """Render text."""

    def __init__(self, text):
        self.text = text

    def renderWord(self, context, handler):
        handler.app.Selection.TypeText(self.text)

class FieldText:
    """Store text taken from a field."""

    def __init__(self, context, field):
        self.field = field
        self.node = context.node
    
    def renderWord(self, context, handler):
        handler.app.Selection.TypeText(handler._getTextOfTag(self.node, self.field))

class ContentBlob(Renderable):
    """A page, composed of content fields."""
    
    def __init__(self):
        self.contents = []
        self.construct()
        
    def add(self, renderable):
        """Add a new item to be rendered."""
        self.contents.append(renderable)
        return renderable
    
    def renderWord(self, context, handler):
        for r in self.contents:
            r.renderWord(context, handler)
            self.cleanupWord(handler)
        del self.contents

    def construct(self):
        """Actual construction - factory method."""
        raise NotImplementedError, "implement in subclasses"

class Record(ContentBlob):
    """A record, like a ContentBlob but starts on a new page"""

    def renderWord(self, context, handler):
        handler.app.Selection.InsertBreak(Type=0)
        ContentBlob.renderWord(self, context, handler)

class ContentNode(Renderable):
    """A plain content node, will be rendered by SilvaDOMHandler"""
    
    def __init__(self, context):
        self.context = context

    def renderWord(self, context, handler):
        handler._walkSubNodes(self.context, handler._container_elements)

class TextContentNode(Renderable):
    """A text content node, doesn't contain container elements but does contain markup"""

    def __init__(self, context):
        self.context = context

    def renderWord(self, context, handler):
        handler.renderText(self.context)

# not in use yet
class StyleNode(Renderable):
    """A Style action"""

    def __init__(self, context):
        self.context = context

    def renderWord(self, context, handler):
        end = handler.doc.Range().End
        sel = handler.app.Selection
        sel.Start = end
        sel.End = end
        sel.Style = self.context.style

__all__ = "Renderable Table Cell Text FieldText ContentBlob Record ContentNode "\
            "TextContentNode StyleNode".split()
