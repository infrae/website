# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: silva_course.py,v 1.6 2003/06/17 15:57:08 guido Exp $


"""Handler for <silva_course> record tags."""

from silva2word.render import *


COURSE_CONTENT_TITLE = 'Global Description of course content'
COURSE_GOALS_TITLE = 'Goal(s) of the course'

class ContentField(Renderable):
    """Content that has title and <doc></doc> content."""

    def __init__(self, context, field, title, style):
        self.field = field
        self.title = title
        self.style = style
        self.context = context
    
    def renderWord(self, context, handler):
        # add title
        app = handler.app
        app.Selection.Style = handler.getStyle(self.style)
        app.Selection.TypeText(self.title + '\n')

        # render content
        docnode = self.context.node.getElementsByTagName(self.field)[0].getElementsByTagName('doc')[0]
        newcontext = self.context.clone(node=docnode)
        handler._walkSubNodes(newcontext, handler._container_elements)

class Course(Record):

    descriptions = (('teaching_staff'   , 'Teaching Staff'),
                    ('coordinator'      , 'Coordinator'),
                    ('consulting_hour'  , 'Consulting Hour'),
                    ('term'             , 'Term'),
                    ('load'             , 'Load'),
                    ('educational_form' , 'Educational Form'),
                    ('examination'      , 'Examination'),
                    ('literature'       , 'Literature'))

    def __init__(self, context):
        self.context = context
        Record.__init__(self)

    def construct(self):
        # title table
        t = self.add(Table())
        t.addRow(
            Cell([FieldText(self.context, "course_title")], style="Course Title Heading"),
            Cell([FieldText(self.context, "code")], style="Course Code Heading"),
            )
        t.setWidths(.8, .2)
        t.setPostProcessWord(self._postTitle)

        # layout table
        # XXX This element is skipped because it is now allowed to place 
        # tables in courses in Silva, and nested tables are hell to use in Word
        # t2 = self.add(Table())
        #t2 = self.add(Table())
        #t2.setPostProcessWord(self._postLayout)
        #t2.addRow(Cell([ContentField(self.context, "content", COURSE_CONTENT_TITLE ,'Course Goal and Content Heading'),
        #               ContentField(self.context, "goal", COURSE_GOALS_TITLE, 'Course Goal and Content Heading')])
        #         )

        self.add(Text(' \n'))
        self.add(ContentField(self.context, 'content', COURSE_CONTENT_TITLE, 'Course Goal and Content Heading'))

        self.add(Text('\n'))
        self.add(ContentField(self.context, 'goal', COURSE_GOALS_TITLE, 'Course Goal and Content Heading'))
        self.add(Text('\n'))
        
        # details table
        t = self.add(Table())
        t.setWidths(.25, .75)
        t.setPostProcessWord(self._postDetails)
        for fieldName, description in self.descriptions:
            t.addRow(Cell([Text(description)], style="Course Details Heading"),
                      Cell([FieldText(self.context, fieldName)], style="Table Body Text"))
    
    def _postTitle(self, handler, table):
        """Post processing for title table."""
        table.Borders(3).Visible = 1
    
    def _postLayout(self, handler, table):
        """Post processing for layout table."""
        doc = handler.doc
        page_height = (doc.PageSetup.PageHeight - doc.PageSetup.TopMargin - 
                       doc.PageSetup.BottomMargin - 10 - 36)
        table.Cell(1, 1).Height = page_height*.65
        table.Cell(2, 1).Height = page_height*.35
        table.Cell(2, 1).VerticalAlignment = 3

    def _postDetails(self, handler, table):
        table.TopPadding = 0.8
        table.BottomPadding = 0.8

def renderWord(handler, context):
    """Render a 'silva_course' record."""
    c = Course(context)
    c.renderWord(context, handler)
