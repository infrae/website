# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: registry.py,v 1.7 2004/10/26 13:49:11 guido Exp $


"""Plugin registry."""

def loadModule(name):
    """Load a module given its full name."""
    return __import__(name, globals(), locals(), [name.split('.')[-1]])

def getPlugin(tagName):
    """Load and return a plugin module for a given tag.

    Raises KeyError if no such plugin exists.
    """
    return loadModule(PLUGINS[tagName][0])

def getTagsOfType(type):
    result = []
    for tag, (module, tagType) in PLUGINS.items():
        if tagType == type:
            result.append(tag)
    return result


# Edit this dict to add your own plugins - this is a mapping between
# tag names and the modules that handle their rendering, and their
# type ('toplevel', 'container' or 'text').
PLUGINS = {
    'silva_course' : ['silva2word.plugins.silva_course', 'toplevel'],
    #'silva_newsitem_reference': ['silva2word.plugins.silva_news', 'toplevel'], 
    #'silva_agenda': ['silva2word.plugins.silva_news', 'toplevel'], 
    'image': ['silva2word.plugins.image', 'container'],
    'table': ['silva2word.plugins.table', 'container'],
    'cite': ['silva2word.plugins.cite', 'container'],
    }
