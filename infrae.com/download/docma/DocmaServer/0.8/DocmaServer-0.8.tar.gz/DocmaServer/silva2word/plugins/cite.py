# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: cite.py,v 1.2 2004/10/27 15:09:15 guido Exp $


"""Handler for <cite> tags."""

from silva2word.render import *
from silva2word.StyleNameMapping import *
import operator

class SilvaCitation(ContentBlob):
    def __init__(self, context, handler):
        self.context = context
        self.handler = handler
        ContentBlob.__init__(self)

    def construct(self):
        handler = self.handler
        context = self.context
        node = context.node

        authornode = node.getElementsByTagName('author')[0];
        sourcenode = node.getElementsByTagName('source')[0];
        pars = node.getElementsByTagName('p');

        self.add(
            TextContentNode(
                self.context.clone(
                    node=authornode,
                    style='Citation Author',
                )
            )
        )
        self.add(
            TextContentNode(
                self.context.clone(
                    node=sourcenode,
                    style='Citation Source',
                )
            )
        )
        for par in pars:
            self.add(
                TextContentNode(
                    self.context.clone(
                        node=par,
                        style='Citation Text',
                    )
                )
            )

def renderWord(handler, context):
    """Render a 'citation' element."""
    c = SilvaCitation(context, handler)
    c.renderWord(context, handler)
