# ***********************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: Silva XML to Word Converter
# *
# * Creation Date: May 2002
# *
# * Authors: Stephan Richter, Zagy & co
# ************************************************************************
"""
This module contains the code that handles a DOM that was generated from a
Silva export file.

$Id: SilvaDOMHandler.py,v 1.57 2004/10/28 16:28:24 guido Exp $
"""

import string
import time
import os
import sys
import re
import operator
from types import ListType
from tempfile import mktemp
from win32com.client import Dispatch
from pywintypes import com_error
from util import reverseDict
import win32com
import traceback

import registry
# XXX maybe change this to explicit imports
from WordConstants import *
from word2silva.convert import p_LISTSTYLE
from StyleNameMapping import style_name_map
    
# XXX: replace by some configuration thingy
INDEX_TITLE = 'Index'
TOC_TITLE = 'Table of Contents'
PREFACE_FOLDER_IDS = ['leeswijzer' ,'preface']

p_SPACE = re.compile(r'\s+')

class SilvaDOMHandler:
    """Handles a Silva DOM tree and calls the right methods at the right time
       to create the document. This is a "technology-independent" component
       meaning that it will not depend on reportlab, latex or whatever.

       The above is not true. Yet :)
       
       If an unknown tag 'FOO' is encountered and no 'handle_FOO' method is
       available, it will load an approriate module registed in registry.py,
       and call the module's 'renderWord(self)'. 
       
       """

    _remove_from_p = ('\t', '\n')
    
    # defines the elements that can be inside a text element, such as 'p'
    _text_elements = (
        'link',
        'em', 
        'strong', 
        'index', 
        'underline',
        'super', 
        'sub',
        'br',
        'abbr',
        'acronym',
    ) + tuple(registry.getTagsOfType('text'))
   
    # elements, contained in a doc
    _container_elements = (
        'list', 
        'nlist', 
        'p', 
        'heading', 
        'table', 
        'dlist',
        'pre',
        'toc',
        ) + tuple(registry.getTagsOfType('container'))

    _toplevel_elements = (
        'silva_publication', 
        'silva_folder',
        'silva_document'
    ) + tuple(registry.getTagsOfType('toplevel'))
    
    _align_mapping = {
        'L': 0,
        'R': 2,
        'C': 1,
        'J': 5
    }


    _list_xml = {
        'bullet': 'List Bullet',
        'disc': 'List Bullet',
        'circle': 'List Circle',
        'square': 'List Square',
        'dash': 'List Dash',
        'none': 'List',
        '1': 'List Number',
        'a': 'List Letter',
        'A': 'List Letter Upper', 
        'i': 'List Roman',
        'I': 'List Roman Upper',
    }
      
    _tag_style_mapping = {
        'em': 'Italic',
        'strong': 'Bold',
        'underline': 'Underline',
        'super': 'Superscript',
        'sub': 'Subscript',
        }

    _list_word = reverseDict(_list_xml)

    def __init__(self, tempFilename, dom, titledoc='', template='', visibility = 2,
                 reboot_pause=5, iAmStillAlive=lambda: None):
        """Initialize the handler."""

        self.iAmStillAlive = iAmStillAlive # call this every once in a while
        self.titledoc = titledoc
        self.template = template
        self.visibility = visibility
        self.docData = None
        
        self.output = ''
        self.level = 0

        self.isFirstContentPage = False

        self.app = Dispatch("Word.Application")
        self.app.Visible = (visibility >= 2)
        
        self.docName = tempFilename
        
        self.docs_processed = 0
        
        if titledoc:
            self.doc = self.app.Documents.Open(os.path.abspath(titledoc), 
                ReadOnly=1)
            if template:                
                self.doc.AttachedTemplate = template
        else:
            self.doc = self.app.Documents.Add(Template=template)
        self.doc.SaveAs(self.docName)
    
        self._cacheListIndentation()
        self._setupListStyles()
        self.__list_isNlist = []
        self.getStyle('Hyperlink').Font.Underline = 0

        self._reboot_pause = reboot_pause
        
    def _reboot_word(self):
        self.doc.Close(SaveChanges=wdSaveChanges)
        self.app.Quit(SaveChanges=wdDoNotSaveChanges)

        self.app = None
        i = 0
        while not hasattr(self.app, 'Documents'):
            self.app = Dispatch("Word.Application")
            i += 1
            if i >= 100:
                raise Exception, 'Error instantiating COM object'
            time.sleep(0.1)

        self.doc = self.app.Documents.Open(self.docName)
        self.app.Visible = (self.visibility >= 2)

        self.app.Selection.Start = self.app.Selection.End = \
            self.doc.Range().End

    def _cacheListIndentation(self):
        """caches the LeftIndent attribute of all list styles"""
        # generate a mapping from list level to number of pixels indentation
        cache = {}            
        level = 1
        while 1:
            if level == 1:
                name = 'List'
            else:
                name = 'List %s' % level
            style = self.getStyleNoAdd(name)
            if style is None:                 
                break
            cache[level] = style.ParagraphFormat.LeftIndent
            level += 1
        self.__list_indentation = cache            
        
    def _setupListStyles(self):
        """fixes the indentation of all list styles"""

        max_level = max(self.__list_indentation.keys())
        for base_name in self._list_word:
            for level in range(1, max_level+1):
                if level == 1: 
                    name = base_name
                else: 
                    name = '%s %s' % (base_name, level)
                self.getStyle(name).ParagraphFormat.LeftIndent = \
                    self.__list_indentation[level]
           
    def __del__(self):
        if getattr(self, 'dontClose', False):
            return
        if getattr(self, 'doc', None) is not None:
            try:
                self.doc.Close(SaveChanges=True)
            except com_error:
                pass
        #try:
        #    os.unlink(self.docname)
        #except AttributeError:
        #    pass
        #except OSError:
        #    pass
            
    def getNodeAttribute(self, node, name):
        """Return value of node attribute."""
        return node.attributes.get(name).value
    
    def addComment(self, Range=None, **kw):
        """Add a word comment to the document.
        
            Range: a Range object to which the commend should be added. 
                If None, app.Selection is used.
        """
        text = ';'.join(
            map(lambda (x, y): '%s="%s"' % (x, y), 
            map(lambda (x, y): (x, y.replace('"', '\"')),
            map(lambda (x, y): (str(x), y), 
                kw.items()))))
        comment = 'slv:%s' % (text, )
        if Range is None:
            Range = self.app.Selection.Range
        Range.Comments.Add(Range, comment)
    
    def _getText(self, node):
        """Retrieves all the contained text from a node."""        
        text = u""
        for child in node.childNodes:
            if child.nodeType == child.TEXT_NODE:
                text += child.data
        text = text.strip()
        words = text.split()
        if words:
            text = ' '.join(words)
        return text

    def _getTextOfTag(self, node, tagName):
        """Retrieves the text of a certain element having tagName"""
        nodes = node.getElementsByTagName(tagName)
        if len(nodes) > 0:
            return self._getText(nodes[0])
        return ""

    def _walkSubNodes(self, context, tagNames=()):
        """Walks through all the specified sub nodes of the current node and
           handles them. """
        for child in context.node.childNodes:
            name = getattr(child, 'tagName', None)
            if name in tagNames:
                self._execNodeHandler(context.clone(node=child))
    
    def _execNodeHandler(self, context):
        """Execute the handler of the current node."""
        self.iAmStillAlive()
        tagName = getattr(context.node, 'tagName', None)
        if tagName is not None:
            self.level += 1
            handler = getattr(self, 'handle_' + tagName, None)
            if handler:
                handler(context)
            else:
                # load plugin for unknown tag
                # XXX fix plugins to use context
                try:
                    try:
                        registry.getPlugin(tagName).renderWord(self, context)
                    except:
                        exc, e, tb = sys.exc_info()
                        print 'Exception in running plugin for %s:' % tagName
                        print '%s: %s' % (exc, e)
                        print '\n'.join(traceback.format_tb(tb))
                        print
                        del tb
                except KeyError:
                    pass
            self.level -= 1

    def _has_node_valid_subs(self, node):
        return filter(lambda node, s=self: node.nodeType != 3 and \
                      node.tagName in self._container_elements,
                      node.childNodes)

    def _insertIndex(self, style):
        """Add index to story"""
        self.app.Selection.InsertBreak()
        self.app.Selection.Style = self.getStyle('Heading 1')
        self.app.Selection.TypeText(INDEX_TITLE + '\n')
        self.app.Selection.Style = self.getStyle(style)
        self.app.Selection.TypeText(' ')
        text_len = self.doc.Range().End
        index = self.doc.Indexes.Add(
            self.doc.Range(text_len-1, text_len))
        index.NumberOfColumns = 2

    def _fixSections(self):
        """Disconnect section 2 from section 1."""
        if self.doc.Sections.Count < 2:
            print "Not disconnecting sections since there's only one"
            return
        
        for x in range(1, 4):
            self.doc.Sections(2).Headers(x).LinkToPrevious = 0
            footer = self.doc.Sections(2).Footers(x)
            footer.LinkToPrevious = 0
            footer.PageNumbers.RestartNumberingAtSection = 1

        for x in range(1, 4):
            self.doc.Sections(1).Headers(x).Range.Delete()
            self.doc.Sections(1).Footers(x).Range.Delete()
    
    def getStyleNoAdd(self, name):
        word_style = style_name_map.get(name, name)
        try:
            return self.doc.Styles(word_style)
        except com_error:
            return None
         
    def getStyle(self, name):
        word_style = style_name_map.get(name, name)
        try:
            return self.doc.Styles(word_style)
        except com_error:            
            # the requested style is not in the document, so we add it
            style = self.doc.Styles.Add(word_style, wdStyleTypeParagraph)
            if name.startswith('List'):
                style.BaseStyle = wdStyleList
            else:
                style.BaseStyle = wdStyleBodyText
            return style

    def _clear_table(self, table):
        for x in range(1, 7):
            table.Borders(x).Visible = 0

    def _make_stats(self, start, end):
        delta_time = end-start
        mins = int(delta_time)/60
        secs = delta_time%60

        print "Required time: %.2i:%.2d" %(mins, secs)
        print "Pages Generated: %i" %self.doc.Range().ComputeStatistics(2)

    def _setProperties(self):

        prop = self.doc.BuiltinDocumentProperties
        prop(wdPropertyTitle).value = self.title
        prop(wdPropertyAuthor).value = u'Silva2Word'
        prop(wdPropertyCompany).value = u''
        prop(wdPropertyComments).value = u'This file was generated '\
            'by Silva2Word.\nslv:id="%s";obj="%s"' % (self.rootId, 
                self.rootObject)

    def _updateFields(self):
   
        self.doc.Fields.Update()

    def run(self, dom):
        """Process the dom tree."""
        # determine with which node we'll start processing
        silva_node = dom.firstChild
        children = filter(lambda x: x.nodeType == x.ELEMENT_NODE, 
            silva_node.childNodes)
        style = 'Body Text'
        if len(children) == 1:
            if children[0].nodeName == 'silva_document':
                context = Context(silva_node, style)
            else:
                context = Context(children[0], style)
        else:
            context = Context(silva_node, style)
            
        start = time.time()
        try:            
            docid = context.node.attributes.get('id').value
        except AttributeError:
            docid = None
            
        if not docid:
            try:
                docid = context.node.childNodes[0].attributes.get('id').value
            except AttributeError:
                docid = None

        if not docid:
            docid = 'unknown_document'
        self.rootId = docid            
        self.title = title = self._getTextOfTag(context.node, 'title')
        docobj = context.node.nodeName
        # you cannot import a root anyway, so throw it away
        if docobj == 'silva_root': 
            docobj = 'silva_publication'
        self.rootObject = docobj
        self._setProperties()

        self.isFirstContentPage = True
        self.app.Selection.Start = self.doc.Range().End
        self.app.Selection.End = self.doc.Range().End

        if docobj == 'silva':
            docobj = 'silva_document'

        # remove this to remove the title from the top pub from the text
        # (so it is only shown on the frontpage)
        # do some cheating to set the heading style
        title = self._getTextOfTag(context.node, 'title')
        if not title:
            title = 'Missing index document, so no title available'
        self.app.Selection.Style = self.getStyle('Heading 1')
        self.app.Selection.TypeText('%s\n' % title)
        self.addComment(self.app.Selection.Range, **{'id': docid, 'obj': docobj})
        if docobj != 'silva_document':
            self.isFirstContentPage = False
            
        self._walkSubNodes(context, self._toplevel_elements)
        
        self._insertIndex(context.style)        
        self._fixSections()
        self._updateFields() 
        end = time.time()
        self.app.Visible = (self.visibility >= 1)
        self._make_stats(start, end)
        
    def getDOC(self):
        """return document"""

        if self.docData is None:
            if self.doc is None:
                return None
            self.doc.Save()
            self.doc.Close()
            self.doc = None
    
            f = open(str(self.docName), "rb")
            self.docData = f.read()
            f.close()
            
        return self.docData
        
    def handle_silva_publication(self, context):
        """Handle silva_publication element."""
        self.handle_silva_folder(context)

    def handle_silva_root(self, context):
        """Handle silva_publication element."""
        self.handle_silva_folder(context)

    def _handle_preface_silva_folder(self, context):
        """Handle silva_folder element with id in PREFACE_FOLDER_IDS"""

        # Place cursor to the right place to insert the preface
        self.app.Selection.Start = self.doc.Range().Start
        self.app.Selection.End = self.doc.Range().End
        find = self.app.Selection.Find
        find.ClearFormatting()
        find.Text = u''
        find.MatchCase = 0
        find.MatchWholeWord = 0
        find.MatchWildcards = 0
        find.MatchSoundsLike = 0
        find.MatchAllWordForms = 0
        find.Style = 'TOC Heading'
        find.Execute()
        
        start = self.app.Selection.Start 
        self.app.Selection.End = start
        self.app.Selection.InsertBreak()
        self.app.Selection.End = start

        # Now handle the content
        id = context.node.attributes.get('id').value
        tagname = context.node.nodeName
        #self.addComment(id=id, obj=tagname)
        #title = self._getTextOfTag(context.node, 'title')
        self.app.Selection.Style = self.getStyle('Preface Heading')
        #self.app.Selection.TypeText(title + '\n')
        self.handle_title(context, {'id': id, 'obj': tagname})

        self._walkSubNodes(context, self._toplevel_elements)

        self.app.Selection.Style = self.getStyle('Normal')
        # Place the cursor on the right position (end of document)
        end = self.doc.Range().End
        self.app.Selection.Start = end
        self.app.Selection.End = end

    def handle_silva_folder(self, context):
        """Handle silva_folder element."""
        #self._reboot_word()
        # this should be one of silva_folder, silva_root, silva_publication
        tagname = context.node.nodeName 
        
        id = context.node.attributes.get('id').value
        if id.lower() in PREFACE_FOLDER_IDS:
            return self._handle_preface_silva_folder(context)
        
        self.handle_title(context, {'id': id, 'obj': tagname})
        self._walkSubNodes(context, self._toplevel_elements)
        
    def handle_silva_document(self, context):
        """Handle silva_document element."""
        # There is this error message in word `The formatting in this 
        # document is too compelex. Pleas full save the document now.'
        # Previously Word was rebooted for every folder, but that
        # wasn't enough, so now we do it each x documents.
        self.docs_processed += 1
        if self.docs_processed and self.docs_processed % self._reboot_pause == 0:
            self._reboot_word()
        
        id = context.node.attributes.get('id').value # XXX will raise an error if id doesn't exist!
        tagname = context.node.nodeName

        if id != 'index' and not self.isFirstContentPage:
            self.handle_title(context, {'id': id, 'obj': tagname})
        
        context = context.clone(
            node=context.node.getElementsByTagName('doc')[0])
        self._walkSubNodes(context, self._container_elements)

    def getTableType(self, node):
        """Get type of table
        """
        table_type = node.attributes.get('type', None)
        if table_type is not None:
            return table_type.value
        else:
            return 'plain'

    def getColumnInfo(self, node):
        """Get column info of table.
        """
        columns = int(node.attributes.get('columns').value)
        column_info = node.attributes.get('column_info', None)
        # make up default if nothing is found in XML
        if column_info is None:
            column_info = ' '.join(['L:1'] * columns)
        else:
            column_info = column_info.value
            
        column_info_entries = column_info.split(' ')
        assert len(column_info_entries) == columns
        
        aligns = []
        sizes = []
        for entry in column_info_entries:
            align, size = entry.split(':')
            size = float(size)
            sizes.append(size)
            aligns.append(align)
        return aligns, sizes

    def row_heading(self, context, table, row):
        """Turn row into row heading.
        """
        # merge all cells for heading
        table.Rows(row).Cells.Merge()
        # set style to Row Heading
        table.Cell(row, 1).Range.Style = self.getStyle('Row Heading')
        # put selection inside cell
        start = table.Cell(row, 1).Range.Start
        self.app.Selection.Start = start
        self.app.Selection.End = start
        # add heading text to cell
        self.renderTextBasic(context)

    def row(self, context, table, row, aligns):
        table.Rows(row).Range.Style = self.getStyle(
            'Table Body Text')
        column = 1
        for field in context.node.childNodes:
            nodeName = field.nodeName
            if nodeName == 'field':
                align = aligns[column - 1]
                self.field(context.clone(node=field),
                           table, row, column, align)
                column += 1
            elif nodeName == 'column_heading':
                align = aligns[column - 1]
                self.column_heading(context.clone(node=field),
                                    table, row, column, align)
                column += 1

    def field(self, context, table, row, column, align):
        # put selection into cell
        start = table.Cell(row, column).Range.Start
        self.app.Selection.Start = start
        self.app.Selection.End = start

        if self._has_node_valid_subs(context.node):
            # this is a table with nested items
            self._walkSubNodes(context.clone(style='Table Body Text'),
                               self._container_elements)
        else:
            # this is a table with direct text content
            # XXX shouldn't occur anymore
            self.renderTextBasic(context)  

        # set alignment if possible (single paragraph contents)
        cell = table.Cell(row, column)
        if cell.Range.Paragraphs.Count == 1:
            cell.Range.Paragraphs(1).Alignment = self._align_mapping[align]

    def column_heading(self, context, table, row, column, align):
        field(context, table, row, column, align)
        # change style of table cell to heading
        table.Cell(row, column).Range.Style = self.getStyle('Column Heading')
        
    def old_handle_table(self, context):
        """Handle table element."""        
        table_type = self.getTableType(context.node)

        # Add an empty line before grid tables.
        if table_type == 'grid':
            self.app.Selection.Style = self.getStyle('Body Text')
            self.app.Selection.TypeText('\n')

        # get column info
        aligns, sizes = self.getColumnInfo(context.node)
        columns = len(aligns)

        # set up table; columns are still all the same size
        self.app.Selection.TypeText(' ')
        text_len = self.doc.Range().End
        table = self.app.Selection.Tables.Add(
            self.doc.Range(text_len-2, text_len), 1, columns)

        # adjust table column widths according to column info
        table_width = table.Columns.Width * columns
        unit_width = table_width / reduce(operator.add, sizes)
        # table.Columns.DistributeWidth() - XXX probably not necessary
        for i in range(len(sizes)):
            try:
                table.Columns[i].Width = sizes[i] * unit_width
            except:
                # sometimes Word raises some weird error that says that
                # individual columns in a row can not be accessed because
                # the columns aren't equally wide (!?!?!), just pass here
                # if that happens (of course this *will* result in a table
                # with wrong cellwidths, but at least something's returned)
                pass
  
        # Handle all rows
        after_row_heading = False

        row = 1
        first_row = True
        for child in context.node.childNodes:
            # add new row if row is not first row 
            if not first_row:
                table.Rows.Add()
            else:
                first_row = False
        
            nodeName = child.nodeName
            new_context = context.clone(node=child)
            if nodeName == 'row':
                # split up cells again if we're after row heading
                if after_row_heading:
                    table.Rows(row).Cells.Split(1, columns)
                    after_row_heading = False
                # now fill row
                self.row(new_context, table, row, aligns)
                row += 1  
            elif nodeName == 'row_heading':
                # fill row heading
                self.row_heading(new_context, table, row)
                after_row_heading = 1
                row += 1
                 
        # Apply style
        table.LeftPadding = 1.5
        table.RightPadding = 1.5
        table.TopPadding = 0.5
        table.BottomPadding = 0.5
            
        self._clear_table(table)
        if table_type == 'plain':
            pass
        elif table_type == 'grid':
            for b in range(6):
                table.Borders(b+1).Visible = 1
            table.Rows(1).Range.Bold = 1
            table.Rows(1).HeadingFormat = -1
            
        elif table_type == 'datagrid':
            for b in range(6):
                table.Borders(b+1).Visible = 1
            table.Rows(1).Borders(1).Visible = 0
            table.Rows(1).Borders(2).Visible = 0
            table.Rows(1).Borders(4).Visible = 0
            table.Rows(1).Borders(5).Visible = 0
            table.Rows(1).Range.Bold = 1

        elif table_type == 'listing' or table_type == 'list':
            table.Rows(1).Borders(3).Visible = 1
            table.Rows(1).Range.Bold = 1

        #Tag the first table cell with the style attributes.
        self.addComment(Range=table.Cell(1,1).Range, type=table_type)

        # Clean up. Bring us back to the end of the document
        self.app.Selection.Start = table.Range.End
        self.app.Selection.End = table.Range.End

        self.app.Selection.Style = self.getStyle('One Pixel')
        self.app.Selection.TypeText('\n')

        # I think we should not do this
        # self.app.Selection.Style = self.getStyle(self.useParagraphStyle)
        # self.app.Selection.TypeText("\n")

    def getListType(self, node):
        list_attr = node.attributes.get('type')
        if list_attr is None:
            list_type = 'none'
        else:
            list_type = list_attr.value
        return list_type

    def getListStyle(self, list_type, list_level):
        """Returns the list style based on list type and list level
        """
        base = self._list_xml[list_type]
        if list_level == 1:
            return base
        else:
            return '%s %i' % (base, list_level)
    
    def _finalize_list(self, start, end):
        """Finalize list XXX we don't understand this yet.
        """
        r = self.doc.Range(start, end)
        wp = r.Paragraphs[0]
        lf = wp.Range.ListFormat
        try:
            lf.ApplyListTemplate(lf.ListTemplate, ContinuePreviousList=False)
        except com_error:
            pass

        # add List spacing style after list
        # first change style to list spacing
        start = end = self.app.Selection.End
        r = self.doc.Range(start, end)
        r.Style = self.getStyle('List Spacing')
        # now add newline
        start = self.app.Selection.End
        self.app.Selection.TypeText('\n')
        end = self.app.Selection.End
        # XXX there was something to do with setting style to One Pixel
        # here, but we don't understand why, so we removed it
        
    def handle_list(self, context):
        """Handle list element."""
        context = context.clone(list_level=context.list_level + 1)

        list_type = self.getListType(context.node)
        list_style = self.getListStyle(list_type, context.list_level)
        
        start = self.app.Selection.End
        for element in context.node.childNodes:
            nodeName = element.nodeName
            if nodeName != 'li':
                continue
            self.renderText(context.clone(node=element, style=list_style))
        end = self.app.Selection.End
        self._finalize_list(start, end)

    def handle_nlist(self, context):
        """Handle nlist element."""
        context = context.clone(list_level=context.list_level + 1)

        list_type = self.getListType(context.node)
        list_style = self.getListStyle(list_type, context.list_level)
        
        start = self.app.Selection.End
        for element in context.node.childNodes:
            nodeName = element.nodeName
            if nodeName != 'li':
                continue
            self.nlist_li(context.clone(node=element), list_type)
        end = self.app.Selection.End
        self._finalize_list(start, end)

    def nlist_li(self, context, list_type):
        # find all element children first
        children = []
        for child in context.node.childNodes:
            if child.nodeType != child.ELEMENT_NODE:
                continue
            children.append(child)

        if not children:
            # XXX we don't have any children -- shouldn't occur, right?
            return
        
        style = self.getListStyle(list_type, context.list_level)

        if children[0].nodeName == 'p':
            # first element is a paragraph, render it in list style
            self.renderText(context.clone(node=children[0], style=style))
            # done with first child
            children = children[1:]
        else:
            # first element is not a paragraph, render newline in list style
            self.app.Selection.Style = self.getStyle(style)
            self.app.Selection.TypeText('\n')
            # we do want to work with first child
    
        for child in children:
            start = self.app.Selection.End
            self._execNodeHandler(context.clone(node=child, style=style))
            end = self.app.Selection.End
            r = self.doc.Range(start, end)
            begin_indent = r.ParagraphFormat.LeftIndent
            added_indent = self.__list_indentation.get(
                context.list_level, None)
            if added_indent is not None:
                indent = begin_indent + added_indent
            else:
                indent = begin_indent # XXX does this make any sense?
            try:
                r.ParagraphFormat.LeftIndent = indent
            except AttributeError:
                # XXX for some reason some things cannot be shifted,
                # and by just skipping the error it works?
                pass

    def handle_p(self, context):
        if context.basic:
            self.renderTextBasic(context)
        else:
            self.renderText(context)

    def renderTextBasic(self, context):
        """Handle text, no newline and no style.
        """
        start = self.app.Selection.End
        actions = self.renderTextHelper(context)
        end = self.doc.Range().end
        # since all comment actions actually add contents to the doc (thus
        # changing the location of parts of the text) we execute the actions
        # in reverse...
        actions.reverse()
        for action in actions:
            if isinstance(action, CommentAction):
                commentactions.append(action)
                continue
            action.execute(self.doc)
    
    def renderText(self, context):
        """Handle text, add newline and apply style"""
        start = self.app.Selection.End
        actions = self.renderTextHelper(context)
        self.app.Selection.TypeText("\n")
        end = self.doc.Range().End
        self.doc.Range(start, end).Style = self.getStyle(context.style)
        # since all comment actions actually add contents to the doc (thus
        # changing the location of parts of the text) we execute the actions
        # in reverse...
        actions.reverse()
        for action in actions:
            action.execute(self.doc)

    def renderTextHelper(self, context):
        """Handle text and return actions to apply to parts of it."""
        actions = []
        for child in context.node.childNodes:
            if child.nodeType == child.TEXT_NODE:
                text = child.data
                text = p_SPACE.sub(' ', text)
                if text:
                    self.app.Selection.TypeText(text)
                continue
            
            tagName = getattr(child, 'tagName', None)
            if tagName in self._text_elements:
                start = self.app.Selection.End
                actions += self.renderTextHelper(context.clone(node=child))
                end = self.app.Selection.End

                style = self._tag_style_mapping.get(tagName)
                if style is not None:
                    actions.append(StyleAction(start, end, style))
                elif tagName == 'link':
                    urlattr = child.attributes.get('url')
                    if urlattr is None:
                        continue
                    url = urlattr.value
                    if url == '':
                        url = '#'
                    # This can not be done as an action (like we use for Styles), because
                    # it adds hidden characters to the range
                    if start < end:
                        self.doc.Hyperlinks.Add(self.doc.Range(start, end), url)
                elif tagName == 'index':
                    name = '"%s"' % child.attributes['name'].value
                    # This can not be done as an action (like we use for Styles), because
                    # it adds hidden characters to the range
                    self.doc.Fields.Add(self.doc.Range(end, end), wdFieldIndexEntry, name)
                elif tagName == 'br':
                    self.app.Selection.TypeText('\x0b')
                elif tagName == 'abbr':
                    actions.append(SpecialStyleAction(start, end, 'Underline',
                                    wdUnderlineDash))
                    actions.append(CommentAction(self, start, end, 
                                    title=child.getAttribute('title')))
                elif tagName == 'acronym':
                    actions.append(SpecialStyleAction(start, end, 'Underline',
                                    wdUnderlineDotted))
                    actions.append(CommentAction(self, start, end, 
                                    title=child.getAttribute('title')))

        return actions

    def handle_title(self, context, comment=None):
        """Insert a title to the story."""
        title = self._getTextOfTag(context.node, 'title')
        if title:
            output = ''
            if self.level == 1: 
                if self.isFirstContentPage:
                    self.isFirstContentPage = False
                else:
                    self.app.Selection.InsertBreak()

            self.app.Selection.Style = self.getStyle('Heading %i' % self.level)
            self.app.Selection.TypeText('%s\n' % title)
            
            if comment:
                self.addComment(self.app.Selection.Range, **comment)

    def handle_heading(self, context):
        """Handle heading element."""
        type = context.node.attributes.get('type')
        if type is None:
            type = 'Normal'
        else:
            type = type.value.capitalize()

        self.renderText(context.clone(style='%s Heading' % type))

    def handle_dlist(self, context):
        # XXX: normal or compact, not handled yet
        styleattr = context.node.attributes.get('type', None)
        style = 'normal'
        if styleattr is not None:
            style = styleattr.value 
        
        node = context.node.firstChild
        while node is not None:
            if node.nodeName == 'dt':
                self.renderText(
                    context.clone(node=node, style='Definition Term'))
            elif node.nodeName == 'dd':
                self.renderText(
                    context.clone(node=node, style='Definition Description'))

            node = node.nextSibling

    def handle_pre(self, context):
        text = u""
        for child in context.node.childNodes:
            if child.nodeType == child.TEXT_NODE:
                text += child.data
        
        start = self.app.Selection.End
        self.app.Selection.TypeText(text+'\n')
        end = self.app.Selection.End

        r = self.doc.Range(start, end)
        style = self.getStyle('Plain Text')
        r.Style = style

    def handle_toc(self, context):
        return

        # XXX doesn't work as we want to yet...
        start = self.app.Selection.Start
        self.app.Selection.TypeText('\n')
        r = self.doc.Range(start, start + 1)
        depth = '-1'
        self.addComment(r, toc=depth)
        style = self.getStyle('Plain Text')
        r.Style = style
        
class Context:
    def __init__(self, node, style, level=0, list_level=0, basic=None):
        self.node = node
        self.style = style
        self.level = level
        self.list_level = list_level
        self.basic = basic
        
    def clone(self, **kw):
        context = Context(self.node, self.style, self.level, self.list_level, self.basic)
        for key, value in kw.items():
            if not hasattr(context, key):
                raise AttributeError, "%s is not a context attribute" % key
            setattr(context, key, value)
        return context
        
class StyleAction:
    def __init__(self, start, end, style):
        self._start = start
        self._end = end
        self._style = style
        
    def execute(self, doc):
        setattr(doc.Range(self._start, self._end).Font, self._style, 1)

class SpecialStyleAction:
    def __init__(self, start, end, style, value):
        self._start = start
        self._end = end
        self._style = style
        self._value = value

    def execute(self, doc):
        setattr(doc.Range(self._start, self._end).Font, self._style, 
                self._value)

class CommentAction:
    def __init__(self, handler, start, end, **kwargs):
        self.handler = handler
        self.start = start
        self.end = end
        self.comments = kwargs

    def execute(self, doc):
        self.handler.addComment(doc.Range(self.start, self.end),
                                **self.comments)
