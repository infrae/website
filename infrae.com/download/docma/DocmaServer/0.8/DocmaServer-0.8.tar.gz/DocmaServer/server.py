# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: server.py,v 1.6 2003/02/25 15:16:11 zagy Exp $
"""Run DocMa server."""

import os

if os.name == 'nt':
    from twisted.internet import win32eventreactor
    win32eventreactor.install()

import sys

os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
sys.path.insert(0, os.path.dirname(sys.argv[0]))

from twisted.python import log
from twisted.internet import app

from docma import service
from config import XMLRPC_PORT, LOG_FILE
from util.dualfile import dualFile

application = app.Application("docma")
svc = service.DocMaService(application)
application.listenTCP(XMLRPC_PORT, svc.xmlrpcFactory)
if LOG_FILE:
    logfile = open(LOG_FILE, 'w')
else:
    logfile = None
log.startLogging(dualFile(sys.stdout, logfile))
application.run(save=0)

