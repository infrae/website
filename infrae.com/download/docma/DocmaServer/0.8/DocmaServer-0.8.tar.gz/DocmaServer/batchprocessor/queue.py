"""A round-robin queueing system.

Each command gets a unique identifer. Commands are stored in queues
for each user, and the system will iterate over the users running
one command for each user in each iteration.
"""

from twisted.internet import defer
from twisted.python import log

import time
import copy


class Queue:
    """A queue that tries to be fair to all users.

    In order for the queue to actually run you need to attach it to
    a ProcessPool which will consume commands from the queue.
    
    To add a command to the queue, call q.addCommand - you'll get back
    a Deferred of the result. You can check average time until command
    is finished by looking at q.averageRunTime.
    """

    def __init__(self):
        self.commands = {} # map between command identifier and its state
        self.consumers = []
        self.userQueues = {} # each user gets their own queue
        self._buildUserList()
        self.averageRunTime = {} # map command type - > average time to run per size unit
        self.commandsAddedForType = {} # map command type -> number of commands added
        self.commandsAdded = 0 # total number of commands
    
    def getQueueLength(self):
        """Return number of items in queue."""
        result = 0
        for q in self.userQueues.values(): result += len(q)
        return result

    def getEstimatedRuntime(self, kind, size):
        """Return how much time we estimate it would take to run a newly added command."""
        # this algorithm could use some work...
        result = self.averageRunTime.get(type, 1) * size
        for info in self.commands.values():
            if info['status'] == "notInQueue": continue
            cmd = info["command"]
            kind, size = cmd.getType(), cmd.getSize()
            result += self.averageRunTime.get(kind, 1) * size
        return result

    def getEstimatedIdentTime(self, ident):
        """Return how much longer it will take for the queue to finish"""
        result = 0
        ident_found = 0
        for info in self.commands.values():
            if info["status"] == "notInQueue":
                if info['ident'] == ident:
                    return 0
                continue
            cmd = info['command']
            type, size = cmd.getType(), cmd.getSize()
            result += self.averageRunTime.get(type, 1) * size
            if info['ident'] == ident:
                ident_found = 1
                break
        if not ident_found:
            return 0
        return result
                
    def _buildUserList(self):
        """Build the list of users from which we will take commands."""
        self.users = self.userQueues.keys()
        self.position = 0

    def _sendToConsumer(self, ident):
        """Send a command to a consumer."""

        def logAndPass(e):
            log.err(e)
            return e
        
        info = self.commands[ident]
        command = info['command']
        deferred = info['result']
        info['status'] = 'processing'
        c = self.consumers[0]
        del self.consumers[0]
        result = c(command)
        # we get notified when a command is finished so we can
        # figure out average running time for commands
        result.addBoth(self._commandFinished, ident, time.time())
        result.addErrback(logAndPass)
        result.chainDeferred(deferred)

    def _commandFinished(self, result, ident, startTime):
        """Called when a consumer finishes running a command."""
        cmd = self.commands[ident]["command"]
        kind, size = cmd.getType(), cmd.getSize()
        del self.commands[ident]
        totalTime = max(time.time() - startTime, 0.0) / float(size)
        numCommands = self.commandsAddedForType[kind] - 1
        self.averageRunTime[kind] = ((self.averageRunTime.get(kind, 0) * numCommands) + totalTime) / (numCommands + 1)
        return result
    
    def addCommand(self, user, command):
        """Add a command to the queue, by a specific user.

        Return (id, Deferred of the result) tuple. id can be used with
        self.getStatus command.
        """
        if not self.commandsAddedForType.has_key(command.getType()):
            self.commandsAddedForType[command.getType()] = 1
        else:
            self.commandsAddedForType[command.getType()] += 1
        ident = self.commandsAdded
        self.commandsAdded += 1
        d = defer.Deferred()
        self.commands[ident] = {'status': 'queued',
                                'command': command,
                                'result': d,
                                'user': user,
                                'ident': ident}
        if not self.userQueues and self.consumers:
            self._sendToConsumer(ident)
            return ident, d
        
        self.userQueues.setdefault(user, []).append(ident)
        return ident, d

    def produceCommand(self, callback):
        """Called by consumer when it wants a new command.

        In general this should not be called by end users.
        """
        self.consumers.append(callback)
        
        if not self.userQueues:
            return

        # build list of users if necessary
        if self.position >= len(self.users):
            self._buildUserList()

        # get next user from list of users
        username = self.users[self.position]
        userQ = self.userQueues[username]
        self.position += 1

        # get command from specific user's queue
        ident = userQ[0]
        del userQ[0]

        # if queue is empty remove it
        if not userQ: del self.userQueues[username]

        self._sendToConsumer(ident)

    def getStatus(self, ident):
        """Return status of command with given identifier.

        Status can be 'queued', 'processing', 'notInQueue'.
        """
        if self.commands.has_key(ident):
            return self.commands[ident]['status']
        else:
            return 'notInQueue'

    def getDescription(self, ident):
        """Get description of command with given identifier."""
        return self.commands[ident]['command'].getDescription()
    
    def getIdentQueue(self):
        """Returns a list of identities in the order that they are queued
        """
        # copy the data locally
        userQ = copy.deepcopy(self.userQueues)
        users = self.users + [u for u in userQ.keys() if u not in self.users]
        pos = self.position
        
        queue = []
        # now flatten the queue
        while 1:
            # continue walking through userQ until it's empty
            if not userQ:
                break
            if pos >= len(users):
                pos = 0
            user = users[pos]
            if userQ.get(user):
                queue.append(userQ[user].pop(0))
            else:
                try: del userQ[user]
                except KeyError: pass                    
                del users[users.index(user)]
            pos += 1
                
        return queue
        
    def getIdentIndex(self, ident):
        """Returns the index of ident in the order-queue"""
        q = self.getIdentQueue()
        if not ident in q:
            return -1
        else:
            return q.index(ident)
            
    def getProcessingIdent(self):
        """Returns the ident of the current processing job"""
        if len(self.commands) == 0:
            return 0
        for i in self.commands.keys():
            if self.commands[i]['status'] == 'processing':
                return i
                
    def getIdentOwner(self, ident):
        """Returns the owner of job ident"""
        for i in self.commands.keys():
            if i == ident:
                return self.commands[i]['user']
        return 'No such job'
