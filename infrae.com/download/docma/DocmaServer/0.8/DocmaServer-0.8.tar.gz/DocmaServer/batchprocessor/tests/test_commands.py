import unittest

from batchprocessor import commands
from twisted.internet import reactor
import cmds


class CommandsTestCase(unittest.TestCase):

    def setUp(self):
        self.gotResult = 0
        self.error = None

    def tearDown(self):
        del self.gotResult
        del self.error
    
    def testCommandResult(self):    
        # we run a command, and expect to get 7 as the result
        d = commands.runCommand(cmds.AdderCommand(3, 4))
        d.addCallbacks(self._gotResult, self._gotError)
        while not self.gotResult:
            reactor.iterate()
        if self.error:
            self.fail(self.error)

    def _gotResult(self, result):
        self.gotResult = 1
        if result != 7:
            self.error = ValueError("%s != 7" % result)

    def _gotError(self, error):
        self.gotResult = 1
        self.error = error

    def testBadCommand(self):
        # we run a command, and expect to get error
        d = commands.runCommand(cmds.BadCommand())
        d.addCallbacks(self._gotResult2, self._gotError)
        while not self.gotResult:
            reactor.iterate()
        if not self.error:
            self.fail("We didn't get error from command!")
    
    def _gotResult2(self, result):
        self.gotResult = 1
        
def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(CommandsTestCase)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())

