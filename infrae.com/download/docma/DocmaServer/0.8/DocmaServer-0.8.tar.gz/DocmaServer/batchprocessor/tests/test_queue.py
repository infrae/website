import unittest

from twisted.internet import defer
from batchprocessor import queue

class C:

    def __init__(self, d):
        self.d = d

    def getSize(self): return len(self.d)
    
    def getType(self): return "c"

    def __eq__(self, other):
        return self.__class__ == other.__class__ and self.d == other.d


class QueueTestCase(unittest.TestCase):

    def consumer(self, command):
        return defer.succeed(command)
    
    def testQueueOrder(self):
        import os
        if os.name == 'nt':
            from twisted.internet import win32eventreactor
            win32eventreactor.install()
        consumer = self.consumer
        q = queue.Queue()
        l = []
        q.addCommand("joe", C("1"))[1].addCallback(l.append)
        q.addCommand("joe", C("2"))[1].addCallback(l.append)
        q.addCommand("joe", C("3"))[1].addCallback(l.append)
        q.addCommand("sue", C("1"))[1].addCallback(l.append)
        q.produceCommand(consumer)
        q.addCommand("moe", C("2"))[1].addCallback(l.append)
        q.produceCommand(consumer)
        q.produceCommand(consumer)
        q.produceCommand(consumer)
        q.produceCommand(consumer)
        self.assertEquals(l, [C("1"), C("1"), C("2"), C("2"), C("3")])
        self.assertEquals(q.commandsAdded, 5)
        self.assert_(q.averageRunTime["c"] > 0.0)

    def testEmptyQueue(self):
        consumer = self.consumer
        q = queue.Queue()
        q.produceCommand(consumer)
        q.produceCommand(consumer)
        l = []
        q.addCommand("joe", C("1"))[1].addCallback(l.append)
        q.addCommand("joe", C("2"))[1].addCallback(l.append)
        self.assertEquals(l, [C("1"), C("2")])

    def testQueueStages(self):
        q = queue.Queue()
        ident, deferred = q.addCommand("joe", C("1"))
        self.assertEquals(q.getStatus(ident), "queued")
        d = defer.Deferred()
        q.produceCommand(lambda c: d)
        self.assertEquals(q.getStatus(ident), "processing")
        d.callback(1)
        self.assertEquals(q.getStatus(ident), "notInQueue")


def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(QueueTestCase)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())

