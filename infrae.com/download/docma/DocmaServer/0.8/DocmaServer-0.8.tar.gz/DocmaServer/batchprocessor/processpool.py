# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: processpool.py,v 1.4 2003/06/01 23:04:52 itamar Exp $


"""A pool of processes running commands."""

from twisted.python import log
from batchprocessor import commands, error


class ProcessPool:
    """Runs a number of processes that process commands.

    A ProcessPool is a consumer for a producer of commands. Any queueing
    of commands should be done at the producer.

    Currently we run one process for each command.
    """

    def __init__(self, maxsize, producer, timeout=None, maxRuns=1):
        self.maxsize = maxsize
        self.waiting = 0 # number of commands requested from producer
        self.running = 0 # number of running processes
        self.producer = producer
        self.timeout = timeout # timeout for commands
        self.maxRuns = maxRuns # how many times we run commands if they time
                               # before giving up.
        self.fetchCommands()

    def fetchCommands(self):
        """Tell producer to produce more commands."""
        for i in range(self.maxsize - (self.running + self.waiting)):
            self.waiting += 1
            self.producer.produceCommand(self.runCommand)

    def _handleTimeout(self, failure, command, run):
        failure.trap(error.TimeoutError)
        if run < self.maxRuns:
            log.msg("Attempt no. %s to run %s again" % (run + 1, command))
            return self._runCommand(command, run + 1)
        else:
            return failure
    
    def runCommand(self, command):
        """Run command in processes, returning Deferred of result."""
        if not self.running < self.maxsize:
            raise RuntimeError, "can't run more commands at this time."
        self.running += 1
        self.waiting -=1
        return self._runCommand(command, 0).addBoth(self._processDone)
    
    def _runCommand(self, command, run):
        """Do the actual run.

        Might be called 'recursively' by _handleTimeout.
        """
        d = commands.runCommand(command, timeout=self.timeout)
        # allow commands to clean themselves up
        if hasattr(command, "handleError"):
            d.addErrback(command.handleError)
        # retry support for timeouts
        d.addErrback(self._handleTimeout, command, run)
        return d

    def _processDone(self, result):
        """Callback from command result."""
        assert self.running > 0
        self.running -= 1
        self.fetchCommands()
        return result
