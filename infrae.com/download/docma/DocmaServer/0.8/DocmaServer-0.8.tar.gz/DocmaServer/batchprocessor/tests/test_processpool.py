import unittest

from batchprocessor import processpool, error
from twisted.internet import reactor
import cmds


class Producer:
    """Produces commands for a process pool."""

    # override in instances
    commandFactory = None 
    errback = lambda x: x 

    def __init__(self):
        self.num = 6
    
    def produceCommand(self, callback):
        self.num -= 1
        if self.num < 0:
            reactor.crash()
            return
        d = callback(self.commandFactory())
        d.addErrback(self.errback)


class ProcessPoolTestCase(unittest.TestCase):

    def testProcessPool(self):
        print
        print """We will now launch GUI programs. There should be 3 running a time,
and a total of 6 programs launched."""
        print
        producer = Producer()
        producer.commandFactory = cmds.GUICommand
        pool = processpool.ProcessPool(3, producer)
        reactor.run() # should run until 9 programs are launched

    def testError(self):
        producer = Producer()
        producer.commandFactory = cmds.BadCommand
        pool = processpool.ProcessPool(1, producer)
        pool.errback = lambda f: f.trap(error.BatchError)
        reactor.run()
        self.assertEquals(pool.running, 0)

def test_suite():
    #loader=unittest.TestLoader()
    #return loader.loadTestsFromTestCase(ProcessPoolTestCase)
    # disabling test
    pass
    
if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())


