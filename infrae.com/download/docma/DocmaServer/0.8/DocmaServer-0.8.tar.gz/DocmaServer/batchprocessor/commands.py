# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: commands.py,v 1.14 2003/08/06 10:42:05 guido Exp $

# twisted imports
from twisted.internet import protocol, reactor, defer
from twisted.python import failure, log

# system imports
import cPickle, sys, os
from traceback import format_tb

from batchprocessor import error

PINGING, DONE = "pinging", "done"

# added by Guido for debugging purposes
from docma import mail
import config
from email.MIMEText import MIMEText

# since the os module makes a load of ruckus when you try to use tmpnam,
# i decided to hack up my own version
from tempfilename import tempfilename

class CommandRunner(protocol.ProcessProtocol):
    """Writes a command and gets its result.

    Subprocess sends a stream of '\x00', and then when its done
    a pickle. I hope pickles can never start with a '\x00'!
    """

    def __init__(self, command, resultDeferred, timeoutLength=None):
        if timeoutLength != None:
            self.timeout = reactor.callLater(timeoutLength, killProcess, self)
        else:
            self.timeout = None
        self.timeoutLength = timeoutLength
        self.state = PINGING
        self.command = command
        self.buffer = ""
        self.errBuffer = ""
        self.resultDeferred = resultDeferred
    
    def connectionMade(self):
        s = cPickle.dumps(self.command)
        #payload = [MIMEText('"%s"' % unicode(s, 'cp1252', 'replace').encode('UTF-8', 'replace'), _charset='UTF-8')]
        #mail.sendEmail(payload, config.SENDER_ADDRESS, 'guido@infrae.com', 
        #                'pickle sent from batchprocessor', config.SMTP_SERVER)
        tempnam = tempfilename(os.environ['WINDIR'])
        open(tempnam, 'wb').write(s)
        self.transport.write(cPickle.dumps(tempnam))
        self.transport.closeStdin()

    def outReceived(self, data):
        if self.state == PINGING:
            if self.timeout is not None:
                #log.msg("Got ping, reseting timeout for %s" % self)
                self.timeout.reset(self.timeoutLength)
            while data and (data[0] == "\x00"):
                data = data[1:]
            if data.strip():
                self.state = DONE
        if self.state == DONE:
            self.buffer += str(data)

    def errReceived(self, data):
        self.errBuffer += str(data)
    
    def processEnded(self, reason):
        if self.errBuffer.strip():
            log.msg("Stderr output from batch process: " + self.errBuffer)

        if not self.resultDeferred:
            # probably means we timed out
            return
        
        if not self.buffer.strip():
            self.resultDeferred.errback(
                ValueError(
                    "no data received from batch process " \
                    "(check batch logs for errors)"))
            return
        
        #payload = [MIMEText('"%s"' % unicode(self.buffer, 'cp1252', 'replace').encode('UTF-8', 'ignore'), _charset='UTF-8')]
        #mail.sendEmail(payload, config.SENDER_ADDRESS, 'guido@infrae.com', 
        #            'pickle received in batchprocessor', config.SMTP_SERVER)
        
        try:
            result = cPickle.loads(self.buffer)
            if isinstance(result, error.BatchError):
                self.resultDeferred.errback(RuntimeError(result))
            else:
                content = open(result, 'rb').read()
                self.resultDeferred.callback(cPickle.loads(content))
                os.unlink(result)
        except cPickle.UnpicklingError, e:
            self.resultDeferred.errback(e)
        except ValueError, e:
            self.resultDeferred.errback(e)
        except:
            exc, e, tb = sys.exc_info()
            tbstr = '\n'.join(format_tb(tb))
            del tb
            msg = '%s: %s\n%s\n' % (exc, e, tbstr)
            self.resultDeferred.errback(msg)

        self.resultDeferred = None
        if hasattr(self, "timeout"):
            try:
                self.timeout.cancel()
            except:
                log.deferr()

import batchprocessor
runnerPath = os.path.join(os.path.dirname(batchprocessor.__file__), "runner.py")

def killProcess(protocol):
    """Called on timeout.

    We kill process, and use a TimeoutError as errback
    for Deferred.

    Currently only works on Windows.
    """
    result = protocol.resultDeferred
    del protocol.timeout
    protocol.resultDeferred = None
    import win32process
    try:
        win32process.TerminateProcess(protocol.transport.hProcess, 1)
    except:
        log.deferr()
    result.errback(error.TimeoutError())

def runCommand(command, timeout=None):
    """Run a BatchCommand in a subprocess, returning Deferred for result."""
    result = defer.Deferred()
    p = CommandRunner(command, result, timeout)
    reactor.spawnProcess(p, sys.executable, [sys.executable, '-u', '"%s"' % runnerPath], env=os.environ)
    return result
