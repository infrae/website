# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: dualfile.py,v 1.1 2003/02/11 13:06:32 zagy Exp $

class dualFile:
    def __init__(self, file1, file2):
        self.file1 = file1
        self.file2 = file2

    def __getattr__(self, key):
        def call(*lst, **kwd):
            if self.file2:
                getattr(self.file2, key)(*lst, **kwd)
            return getattr(self.file1, key)(*lst, **kwd)
        return call

