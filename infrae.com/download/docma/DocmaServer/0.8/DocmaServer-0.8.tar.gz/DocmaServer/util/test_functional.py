# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_functional.py,v 1.9 2003/02/11 13:01:12 zagy Exp $



"""
http://www.cs.umd.edu/Outreach/hsContest99/questions/node8.html

In short -- calculate the costs of transforming the orgininal tree to the
generated tree.  The cost of exchanging elements should be fairly high.

Problem: what is `cost'. I'd prefer an approach using probability.

"""


import xmlrpclib, sys, time, re
from xml.dom import minidom



docma_server = "http://pulsar.infrae:8888/"
verybad = 1.0e5

TagExchangeDict = {
    'silva_root': {
        'silva_publication': .5,
        'silva_folder': .5, 
    }, 

    'silva_publication': {
        'silva_root': .5, 
        'silva_folder': .5, 
    },

    'silva_folder': {
        'silva_root': .5,
        'silva_publication': .5, 
    },
}
    

class Node:
    """This is a node in the tree. 

    """
        
    def __init__(self, dom):

        self.label = dom.nodeName
        self.value = dom.nodeValue
        self.node = dom
        self.childs = []
        
        for child in dom.childNodes:
            self.childs.append(Node(child))
        
    def __len__(self):
        return len(self.childs)
            
    def __getitem__(self, item):
        return self.childs[item]
    
    

    def getInsertCost(self):   
        """return cost for inserting or deleting this node

            If self's DOM node is a TEXT_NODE the levenstein distance from '' to
            self.value is returned.
        """
        
        node = self.node
        
        if node.nodeType == node.TEXT_NODE:
            cost = levenstein('', self.value)
        else:
            cost = self.getElementExchangeBadness(None, reverse=True)

        return cost
    
    def getDeleteCost(self):   
        """return cost for inserting or deleting this node
        """
        node = self.node

        
        if node.nodeType == node.TEXT_NODE:
            cost = levenstein(self.value, '')
        else:
            cost = self.getElementExchangeBadness(None)
            
        return cost
    
    def getUpdateCost(self, other):

        cost = 0 
        
        cost += self.getElementExchangeBadness(other)
        cost += self.getAttributeModificationBadness(other)
        
        if self.value is not None and other.value is not None:
            cost += levenstein(self.value, other.value)
        elif self.value is None and other.value is None:
            pass
        else:
            # VERY bad, a whole element disappeared
            cost += verybad
            

        return cost    
            
    
    def getInsertCostCumulated(self):
        cost = self.getInsertCost()
        for c in self.childs:
            cost += c.getInsertCostCumulated()
        return cost

    def getDeleteCostCumulated(self):
        cost = self.getDeleteCost()
        for c in self.childs:
            cost += c.getDeleteCostCumulated()
        return cost
         
    def getElementExchangeBadness(self, other, reverse=False):
        """returns the badness of exchanging elements

            I.e if you have silva_root in the source, but silva_publication 
            in the result.  There is a default badness of `verybad'.

            reverse can be used to reverse the result. I.e exchanging other
            with self rather then self with other. This is only usefull if 
            other is None, which means deleted.
            
        """ 
        
        if other is None: other_label = None
        else: other_label = other.label

        self_label = self.label

        if reverse:
            self_label, other_label = other_label, self_label
            
        if self_label == other_label: return 0
        cost = TagExchangeDict.get(self.label, {}).get(other_label, verybad)
   
        return cost
   
    def getAttributeModificationBadness(self, other):
        
        self_attrs = {}
        other_attrs = {}

        for node_attrs, local_attrs in [(self.node.attributes,  self_attrs), 
            (other.node.attributes, other_attrs)]:
            if node_attrs is None: continue                
            for i in range(0, node_attrs.length):
                attribute = node_attrs.item(i)
                local_attrs[attribute.nodeName] = attribute.nodeValue
       
        self_list = self_attrs.items()
        self_list.sort()

        other_list = other_attrs.items()
        other_list.sort()

        return levenstein(self_list, other_list)
        
    def dist(self, other):
        """return tree distance
        
            This method computres the cost of transforming self into other.
            This is similar to the Levenstein Distance Algorithm, but we have to
            compute subtrees, too.

            http://www.cs.umd.edu/Outreach/hsContest99/questions/node8.html
        """
        
        # build a matrix
        D = [(len(other)+1)*[0] for a in range(0, len(self)+1)]
        
        # update costs:
        D[0][0] = self.getUpdateCost(other)
        
        # insert/delete costs:
        for j in range(0, len(other)):
            D[0][j+1] = D[0][j] + other.childs[j].getInsertCost()
        for i in range(0, len(self)):
            D[i+1][0] = D[i][0] + self.childs[i].getDeleteCost()
        
        for i in range(0, len(self)):
            for j in range(0, len(other)):
                D[i+1][j+1] = tripple_min(
                    D[i][j] + self[i].dist(other[j]), 
                    D[i+1][j] + other.getInsertCostCumulated(),
                    D[i][j+1] + self.getDeleteCostCumulated())

        return D[-1][-1]


def tripple_min(x, y, z):
    return min(min(x, y), min(y, z))


def levenstein(s1, s2):
    """computes levenstein distance between s1 and s2 
    
        See http://chaos.atc.org/cjournal/cdrom/html/09.05/zwakenbu/zwakenbu.htm

        The cost for deleted or updated characters is 5; the cost for added
        characters is 1. It is not satisfactory if characters are eaten by the
        system therefore the update/delete cost is quite high. 
    
    """

    # levenstein parameters
    cost_add = 1
    cost_del = 5
    cost_upd = 5

    D = [(len(s2)+1)*[0] for a in range(0, len(s1)+1)]

    for j in range(0, len(s2)):
        D[0][j+1] = D[0][j] + cost_add

    for j in range(0, len(s1)):
        D[j+1][0] = D[j][0] + cost_del

    for i in range(0, len(s1)):
        for j in range(0, len(s2)):
            if s1[i] == s2[j]: this_cost_upd = 0
            else: this_cost_upd = cost_upd

            D[i+1][j+1] = tripple_min(
                D[i][j] + this_cost_upd, 
                D[i+1][j] + cost_add,
                D[i][j+1] + cost_del)

    return D[-1][-1]

    
def s2w(slv):
    """convert slv to doc

        slv: raw xml string
        returns doc
            
    """

    docma = xmlrpclib.ServerProxy(docma_server)
    ident, storageID = docma.silva2word("fts", "secret", "", "",
        xmlrpclib.Binary(slv))

    while 1:
       status = docma.getJobStatus(ident)
       #print "Job status: %s" % status
       if status == "notInQueue": break
       time.sleep(1)
    
    word = docma.getResult("fts", "secret", storageID).data
    docma.delResult("fts", "secret", storageID)

    return word



def w2s(doc):
    """convert word doc to silva xml

        returns str containing xml

    """
    
    docma = xmlrpclib.ServerProxy(docma_server)
    
    queueID, storageID = docma.word2silva("fts", "secret", 
        xmlrpclib.Binary(doc), "", "http://foo", ("lalala", 12))
    while 1:
        status = docma.getJobStatus(queueID)
        if status == "notInQueue": break
        time.sleep(1)

    xml = docma.getResult("fts", "secret", storageID).data
    docma.delWord2SilvaResult("fts", "secret", storageID)

    return xml 
   



def roundtrip(slv):

    return w2s(s2w(slv))



def buildTree(slv):
    """

      build a tree, containing: insert/delete costs of a node.

    """    
    
    # preprocess 
    slv = slv.replace('\n', ' ')
    slv = re.sub(r'\s+', ' ', slv)
       
    dom = minidom.parseString(slv)
    dom.normalize()
    tree = Node(dom) 
   
    return tree

def prettyPrint(tree, level=0):

    text = ''
    result = []
    
    if tree.value is not None:
        text = " [%s (%s)]" % (
            tree.value.strip()[:20].encode('us-ascii', 'replace'), 
            len(tree.value))
        
    result.append("%s%s%s i:%s d:%s" % ((level*2)*' ', tree.label, text, 
        tree.getInsertCost(), tree.getDeleteCost()))
        
    for c in tree.childs:
        result += prettyPrint(c, level+1)


    return result

if __name__ == '__main__':
    
    testfile = sys.argv[1]
    
    data1 = file(testfile).read()
    data2 = roundtrip(data1)
   
    file('/tmp/functionaltest.xml', 'wb').write(data2)
   
   
    tree1 = buildTree(data1)
    tree2 = buildTree(data2)

    print "\n".join(prettyPrint(tree1))
    print
    print "\n".join(prettyPrint(tree2))

    distance = tree1.dist(tree2)

    print "Distance: %s" % (distance, )
    

