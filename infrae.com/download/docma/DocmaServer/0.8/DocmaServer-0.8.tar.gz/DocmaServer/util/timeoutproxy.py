import sys
import types
from threading import Thread

class _TimeoutThread(Thread):

    def __init__(self, target=None, args=(), kwargs={}, init=None, 
            *a, **kwa):
        Thread.__init__(self, target=target, args=args, kwargs=kwargs, 
            *a, **kwa)
        self.__target = target
        self.__args = args
        self.__kwargs = kwargs
        self.__init = init
        self.ee = self.ev = self.et = self.result = self

    def run(self):
        if self.__init is not None:
            self.__init()
        if self.__target:
            try:
                self.result = self.__target(*self.__args, **self.__kwargs)
            except:
                self.ee, self.ev, self.et = sys.exc_info()
            assert self.ee is not self or self.result is not self

class TimeoutException(Exception):
    pass

class TimeoutProxy:

    _do_not_proxy = ['__del__', '__hash__']
    
    def __init__(self, proxied, timeout=1.0, thread_init=None):
        if isinstance(proxied, TimeoutProxy):
            raise ValueError, "cannot nest timeout proxies"
        self._proxied = proxied
        self._timeout = timeout
        self._thread_init = thread_init

    def __getattr__(self, key):
        if isinstance(key, TimeoutProxy):
            key = key._proxied
        if key in self._do_not_proxy:
            return getattr(self._proxied, key)
        return self._call(getattr, self._proxied, key)

    def __repr__(self):
        return '<TimeoutProxy of %r>' % (self._proxied, )

    def __call__(self, *args, **kwargs):
        method = self.__getattr__('__call__')
        if isinstance(method, TimeoutProxy):
            method = method._proxied
        for arg in list(args) + kwargs.values():
            if isinstance(arg, TimeoutProxy):
                raise ValueError, `arg`
        return self._call(method, *args, **kwargs)

    def _call(self, func, *args, **kwargs):
        t = _TimeoutThread(target=func, args=args, kwargs=kwargs, 
            init=self._thread_init)
        t.start()
        t.join(self._timeout)
        if t.isAlive():
            raise TimeoutException, "Timeout after %f seconds" % (
                self._timeout, )
        if t.ee is not t:
            raise t.ee, t.ev, t.et
        assert t.result is not t
        if self._isRock(t.result):
            result = t.result
        else:
            result = TimeoutProxy(t.result, self._timeout, self._thread_init)
        return result

    def _isRock(self, obj): 
        rock = isinstance(obj, (types.BuiltinFunctionType,
            types.BuiltinMethodType, types.ClassType, types.CodeType,
            types.ComplexType, types.DictProxyType, types.DictType,
            types.DictionaryType, types.EllipsisType, types.FloatType,
            types.FrameType,  types.GeneratorType, types.IntType,
            types.ListType, types.LongType, types.ModuleType, types.NoneType,
            types.SliceType, types.StringTypes, types.TracebackType,
            types.TupleType, types.TypeType, types.XRangeType))
        return rock

