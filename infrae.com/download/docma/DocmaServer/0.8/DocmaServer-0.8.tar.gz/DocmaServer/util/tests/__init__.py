# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py,v 1.1 2002/12/24 13:40:54 zagy Exp $

