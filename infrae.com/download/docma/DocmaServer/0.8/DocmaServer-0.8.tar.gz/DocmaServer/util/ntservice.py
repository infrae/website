# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: ntservice.py,v 1.2 2002/12/24 14:07:48 zagy Exp $


"""A simple DocMa Windows NT Service"""

import sys, os
import win32serviceutil, win32service
from twisted.internet import win32eventreactor
win32eventreactor.install()

# is this even necessary?
if __name__ != '__main__':
    sys.path.append(os.path.dirname(__file__))


class DocMaService(win32serviceutil.ServiceFramework):
    """NT Service for Docma."""
    
    _svc_name_ = "DocMa"
    _svc_display_name_ = "DocMa Batch Server"

    def SvcDoRun(self):
        f = open(r'c:\mylogfile.log','a')
        from twisted.python.log import startLogging
        startLogging(f)
        import server
        server.application.run(save=0)
    
    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        import server
        server.application.shutDown()


if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(DocMaService)
