# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_w2s.py,v 1.5 2003/01/13 10:04:42 zagy Exp $

import sys
import time
import xmlrpclib

from config import XMLRPC_PORT, XMLRPC_PASSWORD

if len(sys.argv) != 3:
    print "Usage: test_w2s.py <doc file> <result file>"
    sys.exit(1)


s = xmlrpclib.ServerProxy("http://pulsar.infrae:%s/" % (XMLRPC_PORT, ))
f = open(sys.argv[1], "rb").read()
queueID, storageID = s.word2silva("test_w2s", XMLRPC_PASSWORD, 
    xmlrpclib.Binary(f), "", "http://foo", sys.argv[1])
    
print "Job Description:", s.getDescription(queueID)
while 1:
    status = s.getJobStatus(queueID)
    print "Job status: %s" % status
    if status == "notInQueue": break
    time.sleep(1)
xml = s.getWord2SilvaResult("test_w2s", XMLRPC_PASSWORD, storageID)
xml = xml.data
s.delWord2SilvaResult("test_w2s", XMLRPC_PASSWORD, storageID)
result = open(sys.argv[2], "wb")
result.write(xml)
result.close()

