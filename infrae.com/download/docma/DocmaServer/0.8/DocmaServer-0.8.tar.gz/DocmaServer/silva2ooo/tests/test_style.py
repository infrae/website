# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_style.py,v 1.3 2003/03/21 17:34:10 zagy Exp $


import unittest
import uno

from silva2ooo.style import ParagraphStyle, ListStyleProperties, ListStyle

from base import TestBase

class ParagraphStyleTest(TestBase):

    def test_existing(self):
        doc = self.getNewDocument()
        try:
            style = ParagraphStyle(doc, 'Text body')
            oo_style = style.getStyle()
            self.assert_(oo_style.queryInterface(uno.getTypeByName(
                "com.sun.star.style.XStyle")))
            self.assert_(oo_style.getName() == style.name)
        finally:
            doc.dispose()
  
    def test_nonexisting(self):
        doc = self.getNewDocument()
        try:
            style = ParagraphStyle(doc, 'Text body2')
            oo_style = style.getStyle()
            self.assert_(oo_style.queryInterface(uno.getTypeByName(
                "com.sun.star.style.XStyle")))
            self.assertEqual(oo_style.getName(), style.name)
            self.assertEqual(oo_style.DisplayName, style.name)
            self.assert_(style.name in style.getFamily().getElementNames())
        finally:
            doc.dispose()
  
    def test_nonexisting_noncreate(self):
        doc = self.getNewDocument()
        try:
            style = ParagraphStyle(doc, 'Dancing style', create=False)
            self.assertRaises(ValueError, style.getStyle)
        finally:
            doc.dispose()

class ListStyleTest(TestBase):

    def test_properties(self):
        
        sp = lambda: ListStyleProperties('foo')
        self.assertRaises(ValueError, sp)
        sp = ListStyleProperties('bullet')
        sp.getNumberingType()
        self.assertNotEqual(sp.getBullet(), (None, None))
        
    def test_bullet(self):
        doc = self.getNewDocument()
        try:
            style = ListStyle(doc, 'bullet')
            style.level = 1
            oo_style = style.getStyle()
            self.assert_(oo_style.queryInterface(uno.getTypeByName(
                "com.sun.star.style.XStyle")))
            self.assertEqual(oo_style.getName(), 'List Bullet')
            self.assertEqual(oo_style.getName(), style.name)
            self.assertEqual(oo_style.DisplayName, style.name)
            self.assert_(style.name in style.getFamily().getElementNames())
        finally:
            doc.dispose()

    def test_number(self):
        doc = self.getNewDocument()
        try:
            style = ListStyle(doc, 'I')
            style.level = 1
            oo_style = style.getStyle()
            self.assert_(oo_style.queryInterface(uno.getTypeByName(
                "com.sun.star.style.XStyle")))
            self.assertEqual(oo_style.getName(), style.name)
            self.assertEqual(oo_style.DisplayName, style.name)
            self.assert_(style.name in style.getFamily().getElementNames())
        finally:
            doc.dispose()


def test_suite():
    suite = unittest.TestSuite()
    #suite.addTest(unittest.makeSuite(ParagraphStyleTest))
    suite.addTest(unittest.makeSuite(ListStyleTest))
    return suite


if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())


            
