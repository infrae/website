# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_unohelper.py,v 1.4 2003/03/24 09:35:23 zagy Exp $


import unittest

import uno
import unohelper

from com.sun.star.lang import XEventListener, typeOfXEventListener, \
    typeOfXTypeProvider

class AComponent(unohelper.Base, XEventListener):

    def disposing(self, event):
        pass

class UnohelperTest(unittest.TestCase):

    def test_TypeProvider(self):
        b = unohelper.Base()

        # there is a cache, check if it returns the same iid on the second
        # call
        iid1 = b.getImplementationId()
        iid2 = b.getImplementationId()
        self.assertEqual(iid1, iid2)

        self.assert_(typeOfXTypeProvider in b.getTypes())
        self.assert_(typeOfXEventListener not in b.getTypes())
        
        c = AComponent()
        self.assert_(typeOfXTypeProvider in c.getTypes())
        self.assert_(typeOfXEventListener in c.getTypes())


def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(UnohelperTest)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())



