# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: xmlrpc.py,v 1.18 2003/07/29 14:37:33 guido Exp $

"""XML-RPC interface to DocMa server."""

import os
from types import UnicodeType
from email.MIMEText import MIMEText

from twisted.web import xmlrpc
from twisted.python import log, failure
from twisted.internet import defer

import config



class DocMa(xmlrpc.XMLRPC):
    """XML-RPC interface to DocMa.

    All methods begining with 'xmlrpc_' are published.
    """
    
    def __init__(self, service):
        xmlrpc.XMLRPC.__init__(self)
        self.service = service
    

    def authenticate(self, username, password):
        if password == self.service.password:
            return True
        else:
            return False
    
    def xmlrpc_silva2word(self, username, password, email, frontName, xml, 
        description="", reboot_pause=5):
        """Convert XML to Word file and email it.

        Arguments:
         - username: string
         - password: string
         - email: string
         - frontCategory: string
         - frontName: string
         - xml: binary (containing raw xml) 
         - description: any
         
        Returns identifier for job, an integer.
        """
        if not self.authenticate(username, password):
            return xmlrpc.Fault(1, "wrong password.")
        log.msg("silva2word: %s <%s>" % (username, email))
        frontTemplate = self.service.getFrontTemplate(frontName)
        queueID, storageID, result = self.service.silva2word(username,
            frontTemplate, xml.data, description, reboot_pause)
        result.addCallback(self.service.emailSuccess, email, description, 
            storageID, queueID)
        result.addErrback(self.service.emailFailure, email, description, 
            storageID, queueID)
        return queueID, storageID
 
    def xmlrpc_word2silva(self, username, password, wordFile, email, 
        objectURL, description=""):
        """Convert Word to XML.

        Arguments:
         - username: string
         - password: string
         - wordFile: binary
         - email: string, user's email
         - objectURL: url which user will be asked to click on
         - description: any
         
        Returns a tuple (queueID, storageID).

        storageID is an identifier for job, an integer, that can be use with
        get/delWord2SilvaResult.
        """
        log.msg("word2silva: %s <%s>" % (username, email))
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")
        queueID, storageID, result = service.word2silva(username, 
            wordFile.data, description)
        result.addCallback(self.service.emailSuccess, email, description, 
            storageID, queueID)
        result.addErrback(self.service.emailFailure, email, description, 
            storageID, queueID)
        return queueID, storageID

    def xmlrpc_getDescription(self, ident):
        """Get description for given job."""
        return self.service.queue.getDescription(ident)
    
    def xmlrpc_getTemplates(self, password):
        """Returns a list of all the frontTemplates"""
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")

        return [file for file in os.listdir(config.WORD_FRONTPAGES) if file[-4:] == '.doc' and file[0] != '~']
        
    def xmlrpc_delTemplate(self, password, filename):
        """Deletes a template from disk"""
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")
            
        os.unlink('%s/%s' % (config.WORD_FRONTPAGES, os.path.basename(filename)))
        return 1
        
    def xmlrpc_addTemplate(self, password, filename, filedata):
        """Places a template on disk (filedata->xmlrpclib.Binary)"""
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")
        
        open('%s/%s' % (config.WORD_FRONTPAGES, os.path.basename(filename)), 'wb').write(filedata.data)
        return 1
    
    def xmlrpc_getResult(self, username, password, storageID):
        """Return result of word2silva processing

        Returns result 
            a Binary, which is a unicode string encoded in UTF-8.
            If there is no such result 0 is returned.
        
        """
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")
        
        try:
            result = service.getResult(storageID)
        except KeyError:
            return 0
        
        if isinstance(result, UnicodeType):
            result = result.encode('utf-8')
        return xmlrpc.Binary(result)
    
    def xmlrpc_getWord2SilvaResult(self, username, password, storageID):
       """return result (method's old name)"""
       return self.xmlrpc_getResult(username, password, storageID)

    def xmlrpc_delResult(self, username, password, storageID):
        """Delete result of word2silva processing.
        
            returns 1 on success, 0 if there was nothing to delete
        """
        service = self.service
        if password != service.password:
            return xmlrpc.Fault(1, "wrong password.")

        try:
            service.delResult(storageID)
        except KeyError:
            return 0
        return 1
    
    def xmlrpc_delWord2SilvaResult(self, username, password, storageID):
        """delete result (method's old name)"""
        return self.xmlrpc_delResult(username, password, storageID)
    
    def xmlrpc_getDescriptions(self):
        """Return list of tuples (storageID, description)."""
        return self.service.getDescriptions()
    
    def xmlrpc_getEstimatedRuntime(self, type, size):
        """Return how long a new command would take, in seconds."""
        return self.service.queue.getEstimatedRuntime(type, size)

    def xmlrpc_getEstimatedIdentTime(self, ident):
        """Return how long it will take before a job is finished"""
        return self.service.queue.getEstimatedIdentTime(ident)

    def xmlrpc_getQueueLength(self):
        """Return length of queue."""
        return self.service.queue.getQueueLength()

    def xmlrpc_getJobStatus(self, ident):
        """Return status of queued job, given identifier returned by silva2word.

        Result is 'queued', 'processing' or 'notInQueue'.
        """
        return self.service.queue.getStatus(ident)
        
    def xmlrpc_getIdentQueue(self):
        """Returns the queue as a flat list of ids on the order they will be processed"""
        return self.service.queue.getIdentQueue()
        
    def xmlrpc_getIdentIndex(self, ident):
        """Returns the index of ident in identQueue (so also returns the number of items before ident will
        be processed)"""
        return self.service.queue.getIdentIndex(ident)
        
    def xmlrpc_getProcessingIdent(self):
        """Returns the ident of the current processing job"""
        return self.service.queue.getProcessingIdent()
        
    def xmlrpc_getIdentOwner(self, ident):
        """Return the owner of ident"""
        return self.service.queue.getIdentOwner(ident)

    def xmlrpc_try_password(self, pw):
        """Returns correctness of pw, serves as a method to find out whether the server is available as well"""
        return pw == self.service.password

       
    def xmlrpc_getResultUsers(self):
        """returns list of (id, username) tuples. """
        return self.service.getResultUsers()
            
    def xmlrpc_getResultDescriptions(self):
        """returns list of (id, (username, description, format) tuples"""
        return self.service.getResultDescriptions()

    def xmlrpc_getResultDescriptionsByUser(self, username):
        """returns list of (id, description, format) tuples matching username"""
        return [(id, desc, format) for (id, (user, desc, format)) in self.service.getResultDescriptions() if user == username]
            
    
        
