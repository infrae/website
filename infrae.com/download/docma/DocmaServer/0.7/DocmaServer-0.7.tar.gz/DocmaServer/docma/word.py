# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: word.py,v 1.8 2003/08/05 15:15:43 guido Exp $


"""Commands for batch processor."""

# required for the Windows installer
import init

# system imports
import os, sys
import xml.dom.minidom

from batchprocessor import interfaces


def killProcess(name):
    """Kill a process based on its name, on Windows."""
    import win32con, win32pdhutil, win32api
    # apparently reset something or other
    try:
        win32pdhutil.GetPerformanceAttributes('Process','ID Process', name)
    except:
        pass

    for pid in win32pdhutil.FindPerformanceAttributesByName(name):
        handle = win32api.OpenProcess(win32con.PROCESS_TERMINATE, 0, pid)
        win32api.TerminateProcess(handle, 1)
        win32api.CloseHandle(handle)


class WordCommand:

    __implements__ = interfaces.ICommand

    def handleError(self, failure):
        """Callback for command if it fails."""
        from batchprocessor.error import TimeoutError
        from twisted.python import log
        failure.trap(TimeoutError)
        log.msg("%s (%r) timed out." % (self, self.description))
        killProcess("WINWORD")
        return failure

    
class Silva2Word(WordCommand):
    """Command for converting Silva XML to MS Word format."""
    
    def __init__(self, filename, xmltext, frontFilename, templateFilename, description, reboot_pause):
        self.filename = os.path.abspath(filename) # where the new DOC file is created
        self.xmltext = xmltext
        self.frontFilename = frontFilename
        self.templateFilename = templateFilename
        self.description = description
        self.reboot_pause = reboot_pause

    def getSize(self):
        return len(self.xmltext) / 1024.0
    
    def getType(self):
        return "silva2word"

    def run(self, iAmStillAlive):
        if os.name != "nt":
            # useful for debugging on POSIX
            raise RuntimeError, "I am not a DOC"

        from silva2word import SilvaDOMHandler
        dom = xml.dom.minidom.parseString(self.xmltext)
        handler = SilvaDOMHandler.SilvaDOMHandler(
            self.filename,
            dom,
            titledoc=self.frontFilename, 
            template=self.templateFilename, 
            visibility=2,
            reboot_pause=self.reboot_pause,
            iAmStillAlive=iAmStillAlive)
        handler.run(dom)
        return handler.getDOC()

    def getDescription(self):
        return self.description


class Word2Silva(WordCommand):
    """Command for converting Word file back into XML."""
    
    def __init__(self, filename, description):
        self.filename = os.path.abspath(filename)
        self.description = description

    def getSize(self):
        return os.path.getsize(self.filename) / 1024.0
    
    def getType(self):
        return "word2silva"

    def run(self, iAmStillAlive):
        if os.name != "nt":
            # useful for debugging on POSIX
            return "<xxx/>"
        from word2silva import convert
        c = convert.Converter(self.filename, iAmStillAlive)
        c.run()
        xml = u'<?xml version="1.0" encoding="UTF-8" ?>'
        xml += c.getXML()
        
        return xml
    
    def getDescription(self):
        return self.description
