#!/usr/bin/env python
# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Stephan Richter
# ************************************************************************
"""
Executable. Syntax:

run <DOC File Path> [<XML File Path>]

$Id: run.py,v 1.2 2003/02/03 21:55:51 itamar Exp $
"""
# import Python modules
import sys, os 

doc_fn = sys.argv[1]
doc_fn = os.path.abspath(doc_fn)

try:
    xml_fn = sys.argv[2]
except:
    xml_fn = doc_fn[:-3] + 'xml'

# Convert to XML
import convert
c = convert.Converter(doc_fn)
c.run()
# Write the results to a file.
xml = c.pub.getXML()
f = open(xml_fn, 'w')
f.write(xml.encode("UTF-8"))
f.close()
