# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Christian Zagrodnick 
# ************************************************************************
"""

$Id: DefinitionList.py,v 1.4 2003/02/11 12:58:35 zagy Exp $
"""
from SilvaObject import SilvaObject, stripControlChars
from P import P

class DefinitionList(SilvaObject):


    def __init__(self, original, type="normal"):
        SilvaObject.__init__(self, original)

        self.type = type

    def getXML(self):
        xml = u'<dlist type="%s">' % (self.type, )
        next = DefinitionTerm
        for elem in self._elements:
            while not isinstance(elem, next):
                xml += next(None).getXML()
                next = next.next
                
            xml += elem.getXML()
            next = next.next
            
        xml += u'</dlist>'
        return xml


class DefinitionObject(SilvaObject):
    
    def __init__(self, original):
        SilvaObject.__init__(self, original)
        self.P = P(original)

    def getXML(self):
        xml = u'<%s>%s</%s>' % (self.tag, self.P.text, self.tag)
        return xml


class DefinitionTerm(DefinitionObject):
    tag = 'dt'
    
class DefinitionDescription(DefinitionObject):
    tag = 'dd'
    
DefinitionDescription.next = DefinitionTerm
DefinitionTerm.next = DefinitionDescription

