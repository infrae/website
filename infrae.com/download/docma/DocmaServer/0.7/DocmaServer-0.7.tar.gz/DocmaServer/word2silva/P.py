# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Stephan Richter, Christian Zagrodnick
# ************************************************************************
"""

$Id: P.py,v 1.28 2003/08/12 16:56:41 guido Exp $
"""

import re
from copy import copy

from util import replaceMap, stripControlChars
from silva2word.WordConstants import *
from word2silva.SilvaObject import SilvaObject
from pythoncom import com_error

p_INDEX = re.compile(r' "([^"]+)" ')
p_SoftBreak = re.compile('\x0b+')


class Tag:
    
    def __init__(self, name, attributes, on, position):
        self.name = name
        self.attributes = attributes
        self.on = on
        self.position = position

    def tag(self):
        space = ''
        empty = ''
        if self.on in (True, None):
            end = ''
            attr = self.attributes
            if attr:
                space = ' '
            if self.on is None:
                empty = '/'
        elif self.on is False:
            end = '/'
            attr = ''
        return '<%s%s%s%s%s>' % (end, self.name, space, attr, empty)

    def __eq__(self, other):
        return self.name == other.name and self.attributes == other.attributes

    def __repr__(self):
        return "<`%s' at %d>" % (self.tag(), self.position)

class P(SilvaObject):
    """This implements the Markup type as specified in the schema"""

    # map Word styles to silva styles
    style_map = {
        'Bold': 'strong',
        'Italic': 'em',
        'Underline': 'underline',
        'Superscript': 'super',
        'Subscript': 'sub',
    }
    

    __handled_fields = [wdFieldIndexEntry, wdFieldHyperlink]

    def __init__(self, original, handle_styles=1, correct_first=0):
        SilvaObject.__init__(self, original)

        self.text = u''
        self.markup = []
        self._non_indexes = [] 
        self._non_indexes_sorted = True

        self.handleWordParagraph(original, handle_styles, 0)

    def handleWordParagraph(self, wp, handle_styles=1, correct_first=0):
        def merge(list1, list2):
            """merge two insertions lists, preserving sorting""" 
            sort_dict = {}
            for tag in list1+list2:
                sort_dict.setdefault(tag.position, []).append(tag)
            indexes = sort_dict.keys()
            indexes.sort()
            result = []
            for index in indexes:
                for tag in sort_dict[index]:
                    result.append(tag)
            return result                    
        
        if wp is None: 
            return
        
        text = wp.Range()
        wp_start = wp.Range.Start
        wp_end = wp.Range.End

        if stripControlChars(text.strip()) == '':
            return
        xml = u''
        inserts = []

        if correct_first:
            # somehow the first paragraph of each document needs 1 char more 
            # room than the rest
            self.nonIndex(wp_start, wp_start + 1)

        if handle_styles:
            inserts = self.processStyles(wp)
            inserts = merge(inserts, self.processIndexes(wp))
            inserts = merge(inserts, self.processLinks(wp))
        inserts = self.wellform(inserts)
        self._blank_indexes(wp)
        self.setupKitchen()
        for tag in inserts:
            if tag.position < wp_start:
                tag.position = wp_start
            elif tag.position > wp_end:
                tag.position = wp_end
            tag.position -= wp_start
            tp = tag.position
            tag.position = self.cookIndex(tag.position)
            #if correct_first:
            #    tag.position -= 1

        next = 0
        for tag in inserts:
            xml += replaceMap(text[next:tag.position])
            xml += tag.tag()
            next = tag.position

        xml += replaceMap(text[next:])
        xml = p_SoftBreak.sub('<br/>', xml)
        xml = stripControlChars(xml)
                
        self.text = xml

    def processComments(self, wp):
        """removes comments"""
        wp_start = wp.Range.Start
        wp_end = wp.Range.End

        for field in wp.Range.Fields:
            if not field.type == wdFieldComments:
                continue

            start = field.Code.start
            end = field.Code.end

            self.nonIndex(start, end)

    def processStyles(self, wp):
        """processes markup like bold and italic"""

        styles = []
        styles_dict = {}
        wp_start = wp.Range.Start
        wp_end = wp.Range.End

        for word_style, silva_style in self.style_map.items():
            wp_range = wp.Range
            find = wp_range.Find
            self.clearFind(find)
            setattr(find.Font, word_style, True)
            last_range = None

            # some strange code here, but believe me, Word requires it... It
            # doesn't seem to be possible to set any constraints about the
            # region Word should search in and also there is some quirky
            # behaviour, such as when Word found something in a certain region
            # the next result can just as well be exactly the same as the 
            # first...
            continued = 0
            while find.Execute(Replace=wdReplaceNone):
                range_start, range_end = wp_range.Start, wp_range.End
                # the 'last problem is the same as current' problem
                if (range_start, range_end) == last_range:
                    break
                last_range = (range_start, range_end)
                # very curious as well, how can it find stuff *before* the
                # range you tell it to search in?
                # XXX Does this mean the range start is already marked up?
                # Should we process that as well?
                if range_start < wp_start:
                    if continued:
                        break
                    # if this happens more than once, break as well, Word
                    # sometimes seems to start all over again as well, 
                    # resulting in an infinite loop...
                    continued = 1
                    continue
                # if the result is outside of the boundaries we want to
                # find in just break
                if range_end >= wp_end:
                    break
                # now we're quite sure there is a genuine result in the
                # area we wanted to search in, add it to the lists of
                # items to process
                styles_dict.setdefault(range_start, []).append(
                    (self.style_map[word_style], True))
                styles_dict.setdefault(range_end, []).insert(0, 
                    (self.style_map[word_style], False))
        index_list = styles_dict.keys()
        index_list.sort()
        for index in index_list:
            styles += map(lambda (style, onoff): Tag(style, '', onoff, index),
                 styles_dict[index])
        return styles

    def processIndexes(self, wp):
        if len(wp.Range.Fields) == 0:
            return []
    
        wp_start = wp.Range.Start
        result = []
        for field in wp.Range.Fields:
            if not field.type == wdFieldIndexEntry: 
                continue 
            
            start = field.Code.Start
            end = field.Code.End

            # somehow this needs 1 character extra space
            self.nonIndex(start, end + 1)
            
            m = p_INDEX.search(field.Code())
            if m is None: 
                continue
            name = m.group(1)
            
            tag = Tag('index', 'name="%s"' % (replaceMap(name), ), None, end)
            result.append(tag)
   
        return result

    def processLinks(self, wp):
        """Process all links in a paragraph"""
        if len(wp.Range.Hyperlinks) == 0:
            return []
        
        result = []
        for link in wp.Range.Hyperlinks:
            try:
                # When a link is really screwed up in Word (I noticed the 
                # problem in a doc where two links were placed around one 
                # piece of text) any call to link.Range will fail with an
                # pythoncom.com_error. Try if we can get the range and if 
                # not skip this link
                start = link.Range.start
                end = link.Range.end
            except com_error:
                continue
            
            url = replaceMap(link.address)
            text = link.TextToDisplay

            text_index = end - len(text) - 2 
            self.nonIndex(start, text_index)
            self.nonIndex(end + 1, end + 1)

            start_tag = Tag('link', 'url="%s"' % (replaceMap(url).replace('\\', '/'), ), True, text_index)
            end_tag = copy(start_tag)
            end_tag.on = False
            end_tag.position = end
            result.append(start_tag)
            result.append(end_tag)
        return result

    def nonIndex(self, start, end):

        self._non_indexes += range(start - 1, end)
        self._non_indexes_sorted = False
   
    def setupKitchen(self):
        """sets up the kitchen for cooking indexes"""
        
        wp_start = self.original.Range.Start
        wp_end = self.original.Range.End
        if not self._non_indexes_sorted:
            self._non_indexes = dict(map(lambda x: (x, 0), 
                self._non_indexes)).keys()
            self._non_indexes.sort()
            self._non_indexes = \
                map(lambda x: x - wp_start, 
                filter(lambda x: wp_start <= x <= wp_end,
                    self._non_indexes))
            self._non_indexes_sorted = True
   
    def cookIndex(self, raw_index):
        nis = self._non_indexes

        while raw_index in nis:
            raw_index += 1
        corrector = 0
        for i in range(0, len(nis)):
            if raw_index <= nis[i]:
                break
            else:
                corrector += 1
        return raw_index - corrector

    def _blank_indexes(self, wp):
        if len(wp.Range.Fields) == 0: 
            return
        for field in wp.Range.Fields:
            if not field.Type in self.__handled_fields:
                self.nonIndex(field.Code.Start, field.Code.End)

    def clearFind(self, find):
        """clear the given find instance"""
        find.ClearFormatting()
        find.ClearAllFuzzyOptions()
        find.Format = 1
        find.Text = u''
        find.MatchCase = 0
        find.MatchWholeWord = 0
        find.MatchWildcards = 0 
        find.MatchSoundsLike = 0
        find.MatchAllWordForms = 0
        find.Wrap = wdWrapNever 
        find.Forward = True

    def wellform(tags):
        """wellform the styles
        
            It basicaly handles cases which would lead to:

                <strong>Foo<em>Bar</strong>baz</em>

            By replacing it by:

                <strong>Foo<em>Bar</em></strong><em>baz</em>
        
            It's not done with xml tags but an internal structure though.

            returns a list of Tag instances
        """
        
        result = []
        stack = []
        for tag in tags:
            if tag.on is True:
                if not tag in stack:
                    result.append(tag)
                    stack.append(copy(tag))
            elif tag.on is False:
                if tag in stack:
                    deactivated_tags = []
                    while 1:
                        deactivate_tag = stack.pop()
                        deactivate_tag.on = False
                        deactivate_tag.position = tag.position
                        result.append(deactivate_tag)
                        if deactivate_tag == tag:
                            break
                        deactivated_tags.append(copy(deactivate_tag))
                    deactivated_tags.reverse()
                    for reactivate_tag in deactivated_tags:
                        reactivate_tag.on = True
                        reactivate_tag.position = tag.position
                        stack.append(copy(reactivate_tag))
                        result.append(reactivate_tag)
            elif tag.on is None:
                result.append(tag)
            else:
                raise ValueError, 'tag.on is invalid (%r)' % (tag.on,)
        assert stack == [], "Stack is not empty: %r (%r)" % (stack, result)
        return result
    wellform = staticmethod(wellform)

    def getXML(self):
        # XXX can there be more types of P here??
        if self.text:
            return u'<p type="normal">%s</p>' % self.text
        return u''

class Pre(SilvaObject):

    def getXML(self):

        elements = \
            map(stripControlChars, 
            map(lambda x: replaceMap(x),
            self._elements))
        text = '\n'.join(elements)    
            
        xml = u'<pre>%s</pre>' % (text, )
        return xml

    
