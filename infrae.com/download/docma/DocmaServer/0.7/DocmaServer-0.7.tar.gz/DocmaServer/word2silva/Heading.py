# ************************************************************************
# * Copyright (c) infrae in 2002
# * For license details please see the license.txt file. 
# *
# * Project: DOC to Silva XML Converter
# *
# * Creation Date: June 2002
# *
# * Authors: Stephan Richter
# ************************************************************************
"""

$Id: Heading.py,v 1.5 2004/02/03 14:13:33 guido Exp $
"""

# XXX I duplicated a lot of code from P.py because the markup
# processing code was an intricate part of the P class and
# (at that moment) impossible to use in a more elegant way
# It would be nice if P.py was refactored at some point so
# the duplicated code can go here

from SilvaObject import SilvaObject
from util import replaceMap, stripControlChars
from silva2word.WordConstants import *
import re
from P import Tag
from copy import copy

p_INDEX = re.compile(r' "([^"]+)" ')

class Heading(SilvaObject):

    __handled_fields = [wdFieldIndexEntry, wdFieldHyperlink]

    # map Word styles to silva styles
    style_map = {
        'Italic': 'em',
        'Underline': 'underline',
        'Superscript': 'super',
        'Subscript': 'sub',
    }
    
    def __init__(self, original, type=None):
        SilvaObject.__init__(self, original)
        self.text = u''
        self.type = type
        if self.type is None:
            self.type = 'normal'
        self.markup = []
        self._non_indexes = [] 
        self._non_indexes_sorted = True
        self.handleHeading(original)

    def handleHeading(self, wp, handle_styles=1, correct_first=0):
        #self.debugfp.write('\nGoing to handle %s\n' % str(wp).encode('ascii', 'replace'))
        #self.debugfp.write('Handle styles: %s\n' % (not not handle_styles))
       
        def merge(list1, list2):
            """merge two insertions lists, preserving sorting""" 
            sort_dict = {}
            for tag in list1+list2:
                sort_dict.setdefault(tag.position, []).append(tag)
            indexes = sort_dict.keys()
            indexes.sort()
            result = []
            for index in indexes:
                for tag in sort_dict[index]:
                    result.append(tag)
            return result                    
        
        if wp is None: 
            return
        
        text = wp.Range()
        wp_start = wp.Range.Start
        wp_end = wp.Range.End

        #self.debugfp.write('Text from paragraph: %s\n\n' % text)
        #self.debugfp.write('Text start: %s\n' % wp_start)
        #self.debugfp.write('Text end: %s\n' % wp_end)
        
        if stripControlChars(text.strip()) == '':
            return
        xml = u''
        inserts = []
        
        """
        if correct_first:
            # somehow the first paragraph of each document needs 1 char more 
            # room than the rest
            self.nonIndex(wp_start, wp_start + 1)
        """
        
        if handle_styles:
            #self.debugfp.write('Going to handle styles\n')
            inserts = self.processStyles(wp)
            #self.debugfp.write('Going to handle indexes\n')
            inserts = merge(inserts, self.processIndexes(wp))
            #self.debugfp.write('Going to handle links\n')
            #inserts = merge(inserts, self.processLinks(wp))

        # well forming shouldn't be necessary since we don't allow markup
        inserts = self.wellform(inserts)
        
        #self.debugfp.write('Inserts: %s\n' % inserts)
        self._blank_indexes(wp)
        self.setupKitchen()
        for tag in inserts:
            if tag.position < wp_start:
                #self.debugfp.write('Start position corrected\n')
                tag.position = wp_start
            elif tag.position > wp_end:
                #self.debugfp.write('End position corrected\n')
                tag.position = wp_end
            tag.position -= wp_start
            tp = tag.position
            tag.position = self.cookIndex(tag.position)
            #self.debugfp.write('Before cookIndex: %s, after: %s\n' % (tp, tag.position))
            #if correct_first:
            #    #self.debugfp.write('Correcting first item\n')
            #    tag.position -= 1

        next = 0
        for tag in inserts:
            #self.debugfp.write('Tag: %s, pos: %s\n' % (tag, tag.position))
            xml += replaceMap(text[next:tag.position])
            xml += tag.tag()
            next = tag.position
            #self.debugfp.write('XML so far: %s\n' % xml)

        xml += replaceMap(text[next:])
        xml = stripControlChars(xml)
                
        self.text = xml

    def handleText(self, wp):
        self.text = ' '.join(wp.Range().split())
        self.text = replaceMap(stripControlChars(self.text))

    def processStyles(self, wp):
        """processes markup like bold and italic"""

        styles = []
        styles_dict = {}
        wp_start = wp.Range.Start
        wp_end = wp.Range.End

        for word_style, silva_style in self.style_map.items():
            wp_range = wp.Range
            find = wp_range.Find
            self.clearFind(find)
            setattr(find.Font, word_style, True)
            last_range = None

            # some strange code here, but believe me, Word requires it... It
            # doesn't seem to be possible to set any constraints about the
            # region Word should search in and also there is some quirky
            # behaviour, such as when Word found something in a certain region
            # the next result can just as well be exactly the same as the 
            # first...
            continued = 0
            while find.Execute(Replace=wdReplaceNone):
                range_start, range_end = wp_range.Start, wp_range.End
                # the 'last is the same as current' problem
                if (range_start, range_end) == last_range:
                    break
                last_range = (range_start, range_end)
                # very curious as well, how can it find stuff *before* the
                # range you tell it to search in?
                # XXX Does this mean the range start is already marked up?
                # Should we process that as well?
                if range_start < wp_start:
                    if continued:
                        break
                    # if this happens more than once, break as well, Word
                    # sometimes seems to start all over again as well, 
                    # resulting in an infinite loop...
                    continued = 1
                    continue
                # if the result is outside of the boundaries we want to
                # find in just break
                if range_end >= wp_end:
                    break
                # now we're quite sure there is a genuine result in the
                # area we wanted to search in, add it to the lists of
                # items to process
                if not self.style_map.has_key(word_style):
                    continue
                styles_dict.setdefault(range_start, []).append(
                    (self.style_map[word_style], True))
                styles_dict.setdefault(range_end, []).insert(0, 
                    (self.style_map[word_style], False))
        index_list = styles_dict.keys()
        index_list.sort()
        for index in index_list:
            styles += map(lambda (style, onoff): Tag(style, '', onoff, index),
                 styles_dict[index])
        return styles

    def getXML(self):
        xml = u'<heading type="%s">' % (self.type, )
        xml += self.text
        xml += u'</heading>'
        return xml
            
    def processIndexes(self, wp):
        #debugfp = open(r'c:\index_debug', 'a')
        #self.debugfp.write('processIndexes\n')
            
        if len(wp.Range.Fields) == 0:
            #debugfp.write('No fields\n')
            return []
    
        wp_start = wp.Range.Start
        #debugfp.write('Wp start: %s\n' % wp_start)
        result = []
        for field in wp.Range.Fields:
            if not field.type == wdFieldIndexEntry: 
                #debugfp.write('No fieldindexentry\n')
                continue 
            
            start = field.Code.Start
            end = field.Code.End

            #debugfp.write('Start of code: %s\n' % start)
            #debugfp.write('End of code: %s\n' % end)
            #debugfp.write('End - 2: %s\n' % wp.Range.Document.Range(end - 2, end - 2)())
            #debugfp.write('Field content: %s\n' % field.Code())
            #debugfp.write('Field content: %s\n' % wp.Range.Document.Range(start, end))
            
            # somehow this needs 1 character extra space
            self.nonIndex(start, end + 1)
            
            m = p_INDEX.search(field.Code())
            if m is None: 
                #debugfp.write('No index\n')
                continue
            name = m.group(1)
            #debugfp.write('Added name %s, loc %s\n' % (name, end))
            
            tag = Tag('index', 'name="%s"' % (replaceMap(name), ), None, end)
            result.append(tag)
   
        return result

    def processLinks(self, wp):
        """Process all links in a paragraph"""
        if len(wp.Range.Hyperlinks) == 0:
            return []
        
        result = []
        for link in wp.Range.Hyperlinks:
            try:
                # When a link is really screwed up in Word (I noticed the 
                # problem in a doc where two links were placed around one 
                # piece of text) any call to link.Range will fail with an
                # pythoncom.com_error. Try if we can get the range and if 
                # not skip this link
                start = link.Range.start
                end = link.Range.end
            except com_error:
                continue
            
            url = replaceMap(link.address)
            text = link.TextToDisplay

            text_index = end - len(text) - 2 
            self.nonIndex(start, text_index)
            self.nonIndex(end + 1, end + 1)

            start_tag = Tag('link', 'url="%s"' % (replaceMap(url).replace('\\', '/'), ), True, text_index)
            end_tag = copy(start_tag)
            end_tag.on = False
            end_tag.position = end
            result.append(start_tag)
            result.append(end_tag)
        return result

    def nonIndex(self, start, end):

        self._non_indexes += range(start - 1, end)
        self._non_indexes_sorted = False
   
    def setupKitchen(self):
        """sets up the kitchen for cooking indexes"""
        
        wp_start = self.original.Range.Start
        wp_end = self.original.Range.End
        if not self._non_indexes_sorted:
            self._non_indexes = dict(map(lambda x: (x, 0), 
                self._non_indexes)).keys()
            self._non_indexes.sort()
            self._non_indexes = \
                map(lambda x: x - wp_start, 
                filter(lambda x: wp_start <= x <= wp_end,
                    self._non_indexes))
            self._non_indexes_sorted = True
   
    def cookIndex(self, raw_index):
        #self.debugfp.write('Going to cook index for %s\n' % raw_index)
        nis = self._non_indexes
        #self.debugfp.write('Nis: %s\n' % nis)
        
        while raw_index in nis:
            raw_index += 1
        corrector = 0
        for i in range(0, len(nis)):
            if raw_index <= nis[i]:
                break
            else:
                corrector += 1
        #self.debugfp.write('Corrected index: %s\n' % (raw_index - corrector))
        return raw_index - corrector

    def _blank_indexes(self, wp):
        if len(wp.Range.Fields) == 0: 
            return
        for field in wp.Range.Fields:
            if not field.Type in self.__handled_fields:
                self.nonIndex(field.Code.Start, field.Code.End)

    def clearFind(self, find):
        """clear the given find instance"""
        find.ClearFormatting()
        find.ClearAllFuzzyOptions()
        find.Format = 1
        find.Text = u''
        find.MatchCase = 0
        find.MatchWholeWord = 0
        find.MatchWildcards = 0 
        find.MatchSoundsLike = 0
        find.MatchAllWordForms = 0
        find.Wrap = wdWrapNever 
        find.Forward = True

    def wellform(tags):
        """wellform the styles
        
            It basicaly handles cases which would lead to:

                <strong>Foo<em>Bar</strong>baz</em>

            By replacing it by:

                <strong>Foo<em>Bar</em></strong><em>baz</em>
        
            It's not done with xml tags but an internal structure though.

            returns a list of Tag instances
        """
        
        result = []
        stack = []
        for tag in tags:
            if tag.on is True:
                if not tag in stack:
                    result.append(tag)
                    stack.append(copy(tag))
            elif tag.on is False:
                if tag in stack:
                    deactivated_tags = []
                    while 1:
                        deactivate_tag = stack.pop()
                        deactivate_tag.on = False
                        deactivate_tag.position = tag.position
                        result.append(deactivate_tag)
                        if deactivate_tag == tag:
                            break
                        deactivated_tags.append(copy(deactivate_tag))
                    deactivated_tags.reverse()
                    for reactivate_tag in deactivated_tags:
                        reactivate_tag.on = True
                        reactivate_tag.position = tag.position
                        stack.append(copy(reactivate_tag))
                        result.append(reactivate_tag)
            elif tag.on is None:
                result.append(tag)
            else:
                raise ValueError, 'tag.on is invalid (%r)' % (tag.on,)
        assert stack == [], "Stack is not empty: %r (%r)" % (stack, result)
        return result
    wellform = staticmethod(wellform)

