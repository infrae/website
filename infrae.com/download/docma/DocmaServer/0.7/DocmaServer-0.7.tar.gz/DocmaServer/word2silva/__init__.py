# Copyright (c) 2002 Infrae. All rights reserved.
"""Convert word back to silva."""
