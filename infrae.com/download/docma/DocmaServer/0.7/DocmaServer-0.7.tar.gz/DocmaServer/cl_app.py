# required for the framework
import getopt, sys, traceback, glob, os

class CommandLineApp:
    """A basic framework for a command-line app"""

    # if the app processes files, set the following switch to 1
    # this will glob args and use stdin as fallback if not args are
    # provided
    processes_files = 1 

    # if set to true, argument 1 of the main method will be the content of
    # the file. Else arg 1 will be None
    preload = 1 

    # the getopt_args will be used to parse the commandline args
    # into a dict, key the value in this dict and value the cl value
    getopt_args = {}

    # enter the mandatory opts
    required_opts = []

    # enter whether we expect non-opt args as well
    # this only needs to be set if self.processes_files is not set
    # to true
    require_args = 1

    # string to show when wrong or missing arguments or options are encountered
    usage_string = 'Usage: %s <paths>' % sys.argv[0]

    def __init__(self):
        """Initializes all variables"""
        try:
            opts, args = getopt.getopt(sys.argv[1:], ''.join(self.getopt_args.keys()))
        except getopt.GetoptError, e:
            print self.usage(e)
            sys.exit(1)

        if self.require_args and not self.processes_files and not args:
            print self.usage()
            sys.exit()

        for opt in self.required_opts:
            if not '-%s' % opt in [o for (o, a) in opts]:
                print self.usage('Required option %s not provided' % opt)
                sys.exit()

        for opt, arg in opts:
            print opt[1:]

            if not opt[1:] in self.getopt_args.keys() and not '%s:' % opt[1:] in self.getopt_args.keys():
                print self.usage('Unknown option %s' % opt)
                sys.exit()

        self.args = args
        if self.processes_files and args:
            globbed = []
            for arg in self.args:
                g = glob.glob(arg)
                if len(g) == 0 and not arg.find('*') and not arg.find('?'):
                    print self.usage('File %s not found!' % arg)
                    sys.exit(1)
                globbed += g
            # now see if we have any files found
            if globbed == []:
                print self.usage('No files found')
                sys.exit(1)
            self.args = globbed

        # parse the opts into self.opts
        self.opts = {}
        for o, a in opts:
            if a:
                o = '%s:' % o
            self.opts[self.getopt_args[o[1:]]] = a

        try:
            if not self.processes_files:
                self.main(self.args, None)
            else:
                if self.args:
                    for arg in self.make_filelist(self.args):
                        data = None
                        if self.preload:
                            data = open(arg, 'rb').read()
                        self.main(data, arg)
                elif self.preload:
                    data = sys.stdin.read()
                    self.main(data, 'stdin')
                else:
                    # if self.preload is false, the main method will not be
                    # able to handle data but only filenames, so reading from sys.stdin 
                    # has no use
                    print self.usage('Filename argument(s) expected')
                    sys.exit(1)
        except:
            exc, e, tb = sys.exc_info()
            print self.format_exc(exc, e, tb)
            del tb
            sys.exit(1)

    def main(self, data, filename):
        """The main part of the program, this has to be modified or overridden for each app

        This method will be called with args if self.processes_files is false,
        and for each path in globbed args or the contents of stdin (read fully)
        if self.processes_files is true
        """
        print 'File:', filename
        print 'Data:', data

    def usage(self, error=None):
        """Returns the string for printing usage directions

        Should be modified for each app"""
        u = ''
        if error:
            u += '%s\n\n' % error
        u += self.usage_string
        return u

    def format_exc(self, exc, e, tb):
        """Formats an exception for printing"""
        out = '%s: %s\n' % (exc, e)
        out += '\n'.join(traceback.format_tb(tb))
        return out

    def make_filelist(self, paths):
        """Converts a list of paths to a list of filepaths, recursing subdirs"""
        filelist = []
        for path in paths:
            if os.path.isfile(path):
                filelist.append(path)
            elif os.path.isfile(path):
                filelist.append(self.make_filelist([path]))
            else:
                print 'Skipping path', path, ', is not a directory or file'
        return filelist

if __name__ == '__main__':
    CommandLineApp()
