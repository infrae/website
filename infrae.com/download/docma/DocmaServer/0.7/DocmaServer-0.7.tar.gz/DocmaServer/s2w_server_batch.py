# requierd for the framework
import getopt, sys, traceback, glob, os

import xmlrpclib, time

from cl_app import CommandLineApp

class s2wServerBatch(CommandLineApp):
    """A basic framework for a command-line app"""

    # if the app processes files, set the following switch to 1
    # this will glob args and use stdin as fallback if not args are
    # provided
    processes_files = 1 

    # if set to true, argument 1 of the main method will be the content of
    # the file (so __init__ does an open(arg).read()), else arg 1 will be None
    preload = 1

    # the getopt_args will be used to parse the commandline args
    # into a dict, key the value in this dict and value the cl value
    getopt_args = {}
    
    # the result dict
    opts = {}

    # enter the mandatory opts
    required_opts = []

    # enter whether we expect non-opt args as well
    # this only needs to be set if self.processes_files is not set
    # to true
    require_args = 1

    # Arguments for the main method
    host = 'localhost'
    port = 8888
    username = 'foo' # just a formality
    password = 'secret'
    email_address = 'guido@infrae.com'
    fronttemplate = 'test'

    def main(self, data, filename):
        """The main part of the program, this has to be modified for each app

        This method will be called with args if self.processes_files is false,
        and for each path in globbed args or the contents of stdin (read fully)
        if self.processes_files is true
        """
        server = xmlrpclib.Server("http://%s:%s" % (self.host, self.port))
        if self.fronttemplate.endswith('.doc'):
            self.fronttemplate = self.fronttemplate[:-4]
        ident, storageid = server.silva2word(self.username, self.password, self.email_address,
                                                self.fronttemplate, xmlrpclib.Binary(data),
                                                'Command line app generation of %s' % filename,
                                                2)
        status = server.getJobStatus(ident)
        print 'Status of %s: %s' % (ident, status)
        
        while status == 'processing' or status == 'queued':
            status = server.getJobStatus(ident)
            time.sleep(1)

        # print 'Finished jobs for this user:', server.getResultDescriptionsByUser(self.username)
        # print 'Description for current job:', server.getDescription(storageid)
        result = server.getResult(self.username, self.password, storageid)
        if hasattr(result, 'data'):
            root = 'stdin'
            if filename.find('.') > -1:
                root, ext = os.path.splitext(filename)
            open('%s.doc' % root, 'wb').write(result.data)
        else:
            print 'Error: result is not a document'

    def usage(self, error=None):
        """Returns the string for printing usage directions

        Should be modified for each app"""
        u = ''
        if error:
            u += '%s\n\n' % error
        u += 'Usage: %s <paths>\n' % sys.argv[0]
        return u

if __name__ == '__main__':
    s2wServerBatch()
