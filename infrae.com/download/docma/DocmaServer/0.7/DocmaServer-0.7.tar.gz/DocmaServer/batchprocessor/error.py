# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: error.py,v 1.3 2003/06/01 21:19:19 itamar Exp $



import sys, traceback, StringIO


class BatchError:
    """An error processing a batch command."""

    def __init__(self):
        f = StringIO.StringIO()
        t, v, tb = sys.exc_info()
        traceback.print_tb(tb, file=f)
        self.value = "%s: %s\n%s" % (t, v, f.getvalue())

    def __str__(self):
        return self.value


class TimeoutError(Exception):
    """Process running timed out."""
