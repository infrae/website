# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: interfaces.py,v 1.3 2003/06/05 18:02:17 itamar Exp $


"""Interfaces for batch processing."""

from twisted.python import components


class ICommand(components.Interface):
    """Interface that must be implemented by commands."""

    def run(self, iAmStillAlive):
        """Return result of running command.

        @param iAmStillAlive: a function that should be called occasionally
        to indicate the command is not frozen or broken.
        """

    def getDescription(self):
        """Return description of the command."""

    def getSize(self):
        """Get size of command."""

    def getType(self):
        """Identifier for command type."""

