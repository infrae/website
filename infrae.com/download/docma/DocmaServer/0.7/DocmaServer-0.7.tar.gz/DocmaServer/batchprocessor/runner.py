# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: runner.py,v 1.12 2003/07/03 15:20:05 guido Exp $


"""Process a batch command.

Read a pickle from stdin, which is assumed to be a BatchCommand
object. Then call the object's run() method, and pickle the
result and write it to stdout.
"""

import sys
import os
import cPickle
from tempfilename import tempfilename

working_dir = os.path.abspath(os.path.join(os.path.dirname(sys.argv[0]), 
    '..'))
os.chdir(working_dir)
sys.path.insert(0, working_dir)

from batchprocessor import error

sys.stdout = sys.stderr

# set binary mode on stdin/out
try:
    import msvcrt
    msvcrt.setmode(sys.__stdout__.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.__stdin__.fileno(), os.O_BINARY)
except ImportError:
    pass

def stillAlive():
    """Notify our parent we're still alive."""
    sys.__stdout__.write("\x00")
    sys.__stdout__.flush()

stillAlive()

# load command
ret = cPickle.load(sys.__stdin__)

# run it
err = 0
try:
    command = cPickle.loads(open(ret, 'rb').read())
    os.unlink(ret)
    result = command.run(stillAlive)
except:
    result = error.BatchError()
    err = 1

# write result
if not err:
    ret = tmpnam = tempfilename(os.environ['WINDIR'])
    res = cPickle.dumps(result)
    open(tmpnam, 'wb').write(res)
else:
    ret = result
cPickle.dump(ret, sys.__stdout__)
sys.__stdout__.flush()
#fd = sys.__stdout__.fileno()
#sys.__stdout__.close()
#os.close(fd)

# exit
sys.exit(0)
