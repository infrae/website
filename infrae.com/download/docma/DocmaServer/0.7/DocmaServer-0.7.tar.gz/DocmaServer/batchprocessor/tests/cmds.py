"""Commands used in testing."""

import operator, os


class AdderCommand:
    """A command that does addition."""

    def __init__(self, *args):
        self.args = args

    def run(self, iAmStillAlive):
        return reduce(operator.add, self.args)


class BadCommand:
    """A command that raises error."""

    def run(self, iAmStillAlive):
        raise RuntimeError


class GUICommand:
    """Run a GUI program."""

    def run(self, iAmStillAlive):
        if os.name == "posix":
            os.system("xterm")
        else:
            print "about to launch notepad"
            os.system(r"c:\winnt\system32\notepad.exe")
