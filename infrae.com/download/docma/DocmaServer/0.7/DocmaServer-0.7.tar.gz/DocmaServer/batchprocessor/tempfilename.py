import random, string, os

def tempfilename(dir):
    name = ''
    for i in range(5):
        name += random.choice(string.lowercase)
    while os.path.isfile('%s/%s' % (dir, name)):
        name += random.choice(string.lowercase)
    return os.path.normpath('%s/%s' % (dir, name))
        
