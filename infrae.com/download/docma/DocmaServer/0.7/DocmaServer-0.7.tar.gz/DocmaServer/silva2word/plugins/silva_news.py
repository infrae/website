# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: silva_news.py,v 1.1 2003/02/07 14:34:29 zagy Exp $

from pywintypes import com_error

def type_text(handler, text, style, newLine=True):
    style = handler.getStyle(style)
    start = handler.app.Selection.End
    handler.app.Selection.TypeText(text)
    if newLine:
        handler.app.Selection.TypeText('\n')
    end = handler.app.Selection.End
    handler.doc.Range(start, end).Style = style

def type_link(handler, node):
    data = {}
    node = node.firstChild
    while node is not None:
        data[node.nodeName] = handler._getText(node)
        node = node.nextSibling
    start = handler.app.Selection.End
    type_text(handler, data.get('text', ''), 'Body Text')
    end = handler.app.Selection.End
    r = handler.doc.Range(start, end-1)
    url = data.get('url', '#')
    if url == '':
        url = '#'
    try:
        handler.doc.Hyperlinks.Add(r, url)
    except com_error:
        # XXX: catch only `Bad parameter' error which is raised if url
        # parameter is no url
        pass

def renderItem(handler):
    curr_node = handler.currNode
    meta = {}
    try:
        meta['id'] = curr_node.attributes.get('id').value
    except AttributeError:
        pass
    try:
        meta['type'] = curr_node.attributes.get('type').value
    except AttributeError:
        pass
    meta['meta_type'] = handler._getTextOfTag('meta_type')
    iter_node = curr_node.firstChild
    while iter_node is not None: 
        work_node = iter_node
        iter_node = iter_node.nextSibling
        if work_node.nodeType != work_node.ELEMENT_NODE:
            continue
        tag = work_node.nodeName
        if tag in ['meta_type', 'size']: 
            continue
        elif tag == 'link':
            type_link(handler, work_node)
            continue
        elif tag == 'content':
            doc_node = work_node.getElementsByTagName('doc')[0]
            handler.currNode = doc_node
            handler._walkSubNodes(handler._container_elements)
            handler.currNode = curr_node
            continue
        text = handler._getText(work_node)
        if not text: 
            continue
        type_text(handler, text, 'NewsItem %s' % (tag, ))
        if tag == 'title':
            handler.addComment(**meta)
    handler.app.Selection.InsertBreak()

def renderAgenda(handler):
    curr_node = handler.currNode
    id = curr_node.attributes.get('id').value
    iter_node = curr_node.firstChild
    while iter_node is not None:
        work_node = iter_node
        iter_node = iter_node.nextSibling
        if work_node.nodeType != work_node.ELEMENT_NODE:
            continue
        if work_node.nodeName == 'title':
            text = handler._getText(work_node)
            if text == '':
                text = 'Agenda'
            start = handler.app.Selection.End
            type_text(handler, text, 'Agenda Title')
            end = handler.app.Selection.End
            r = handler.doc.Range(start, end-1)
            handler.addComment(r, id=id, obj='silva_agenda')
        elif work_node.nodeName == 'silva_newsitem':
            handler.currNode = work_node
            renderItem(handler)
            handler.currNode = curr_node

   
def renderWord(handler):
    node = handler.currNode
    tag = node.nodeName
    if tag == 'silva_newsitem_reference':
        renderItem(handler)
    elif tag == 'silva_agenda':
        renderAgenda(handler)

