# Copyright (c) 2002 Infrae. All rights reserved.
"""Plugins for handling various extensions to Silva XML format.

Plugin modules are expected to have a renderWord(handler) function
at module level, which is called to render the specific element
that module handles.
"""
