# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: image.py,v 1.10 2004/02/03 14:11:50 guido Exp $


"""Support for <image> tag."""

# system imports
import urllib2
import posixpath
import tempfile
import shutil
import time
import re

# docma imports
from silva2word.render import Renderable
from silva2word.WordConstants import *

p_URL = re.compile(r'^[A-Za-z\+\.\-]+:')

class Image(Renderable):
    """A <image> tag renderer.
    """

    _paragraph_alignment = {
        'left': wdAlignParagraphLeft,
        'right': wdAlignParagraphRight,
        'center': wdAlignParagraphCenter,
    }

    _floating_alignment = {
        'left': wdShapeLeft,
        'right': wdShapeRight,
        'center': wdShapeCenter,
    }

    _floating_textwrap = {
        'left': wdWrapRight,
        'right': wdWrapLeft,
        'center': wdWrapNever,
    }
    
    def __init__(self, handler, context):
        self.image_local = None
        image_node = context.node
        self.url = self._url_rewrite(self.getUrl(image_node))
        self.fetchImage() 
        try:
            self.link = image_node.attributes.get('link').value
        except AttributeError:
            self.link = None
        try:            
            alignment = image_node.attributes.get('alignment').value
        except AttributeError:
            alignment = ''
        if '-' not in alignment:
            alignment = 'image-left'
        floating, alignment = alignment.split('-', 1)
        if floating == 'float':
            floating = 1
        else:
            floating = 0
        if alignment not in ('left', 'center', 'right'):
            alignment = 'left'
        self.floating = floating
        self.alignment = alignment

    def getUrl(self, image_node):
        image_fetch = 'getImage?hires:int=1&webformat:int=1'
        export_root_url = image_node.ownerDocument.firstChild.getAttributeNS(
            'http://www.w3.org/XML/1998/namespace', 'base')
        silva_root_url = image_node.ownerDocument.firstChild.getAttribute(
           'silva_root')
        image_path = image_node.getAttribute('path')
        if image_path.startswith('/'):
            return "%s/%s/%s" % (silva_root_url, image_path, image_fetch)
        if p_URL.match(image_path) is not None:
            return image_path
        parents = []
        node = image_node
        while node is not None:
            if node.nodeName in ('silva_folder', 'silva_publication'):
                parents.append(node.getAttribute('id'))
            node = node.parentNode
        parents.append('')
        parents.reverse()
        path = '/'.join(parents)
        return "%s/%s/%s/%s" % (export_root_url, path, image_path, 
            image_fetch)
   
    def _url_rewrite(self, url):
        return url.replace('https://secure-web.eur.nl', 'http://web.eur.nl')
   
    def fetchImage(self):
        """Download image, storing it in self.resultPath.

        Returns path where image is, or None.
        """
        resultPath = tempfile.mktemp()
        try:
            f = urllib2.urlopen(self.url)
        except (urllib2.URLError, ValueError), e:
            print "Couldn't download image %s" % (self.url, )
            print e
            return None
        result = open(resultPath, "wb")
        shutil.copyfileobj(f, result)
        result.close()
        self.image_local = resultPath

    def renderWord(self, handler):
        if self.image_local is None:
            return
        p = handler.doc.Paragraphs.Add()
        picture = p.Range.InlineShapes.AddPicture(self.image_local, 
            LinkToFile=False, SaveWithDocument=True)
        #if self.floating:
            #picture = picture.ConvertToShape()
            #picture.WrapFormat.Type = wdWrapBoth
            #picture.WrapFormat.Side = self._floating_textwrap[self.alignment]
            #picture.Left = self._floating_alignment[self.alignment]
            #p.Range.Delete()
        #else:            
        p.Alignment = self._paragraph_alignment[self.alignment]
        selection = handler.app.Selection
        selection.Start = selection.End = handler.doc.Range().End

def renderWord(handler, context):
    """Render <image> tag."""
    img = Image(handler, context)
    img.renderWord(handler)
