# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: table.py,v 1.2 2003/06/20 13:41:13 guido Exp $


"""Handler for <table> tags."""

from silva2word.render import *
import operator

class SilvaTable(ContentBlob):
    def __init__(self, context, handler):
        self.context = context
        self.handler = handler
        ContentBlob.__init__(self)

    def construct(self):
        handler = self.handler
        node = self.context.node

        if len(node.childNodes) == 0:
            # table without rows, just skip
            return

        type = handler.getTableType(node)
        aligns, sizes = handler.getColumnInfo(node)
        columns = len(aligns)

        # make a list of widths, Word expects fragments of 1 (so the full width is 1)
        size_unit = 1 / reduce(operator.add, sizes)
        widths = [s * size_unit for s in sizes]

        self.add(Text('\n'))
        t = self.add(Table(1, type=type, aligns=aligns))
        t.setWidths(*widths)

        for child in node.childNodes:
            if child.nodeName == 'row':
                fields = child.getElementsByTagName('field')
                cells = []
                for field in fields:
                    # render contents
                    content = ContentNode(self.context.clone(node=field, style='Table Body Text'))
                    c = Cell([content])
                    cells.append(c)
                t.addRow(*cells)
            elif child.nodeName == 'row_heading':
                content = TextContentNode(self.context.clone(node=child, style='Row Heading'))
                cell = Cell([content])
                t.addRow(cell)
            else:
                pass
            
def renderWord(handler, context):
    """Render a 'silva_course' record."""
    c = SilvaTable(context, handler)
    c.renderWord(context, handler)
