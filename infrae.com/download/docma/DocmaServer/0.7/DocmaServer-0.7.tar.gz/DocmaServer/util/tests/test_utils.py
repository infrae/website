import unittest

from util import gcd, lgcd, PTDict, reverseDict, enumerate

class UtilsTest(unittest.TestCase):

    def test_gcd(self):
        self.assertEqual(gcd(1, 1), 1)
        self.assertEqual(gcd(27, 27), 27)
        self.assertEqual(gcd(5, 2), 1)
        self.assertEqual(gcd(10, 5), 5)
        self.assertEqual(gcd(10, 2), 2)
        self.assertEqual(gcd(380, 342), 38)
        self.assertEqual(gcd(188, 987), 47)

    def test_lgcd(self):
        self.assertEqual(lgcd([188, 987, 2538]), 47)
        self.assertEqual(lgcd([1, 2, 3]), 1)
        self.assertEqual(lgcd([10, 20, 30]), 10)
        self.assertEqual(lgcd([7, 7, 7]), 7)
        self.assertEqual(lgcd([64]), 64)
        
    def test_PTDict(self):
        d = {1: 'a', 2: 'b', 3: 'c'}
        d2 = PTDict(d)
        for key, value in d.items():
            self.assertEqual(d2[key], value)
        self.assertEqual(d2[4], 4)
        
    def test_reverseDict(self):
        d = {1: 'a', 2: 'b', 3: 'c'}
        d2 = reverseDict(d)
        for key, value in d.items():
            self.assertEqual(d2[value], key)
    
    def test_enumerate(self):
        result = []
        source = ['a', 'b', 'c']
        for id, letter in enumerate(source):
            result.append((id, letter))
        self.assertEqual(result, [(0, 'a'), (1, 'b'), (2, 'c')])
            
    
def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(UtilsTest)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())


