import unittest

from util.test_functional import tripple_min, buildTree, prettyPrint, levenstein


xml = r'''<?xml version="1.0" encoding='utf-8' ?>
<silva_publication id="test">
    <title>Unergründlich</title>
    <silva_document id="index">
        <title>Unergründlich</title>
        <doc>
            <p type="normal">
        
                Unentdeckt, unerforscht, unergründlich: Schicksal des
                provisorischen Substituts zwischen nutzloser Platzhalterei und
                dem nie formulierten Anspruch auf Beachtung. Ein Schattendasein
                auf der unbekannten Seite der Seite. Heute noch eine einsame,
                doch kräftige Kulturpflanze auf dem unbeackerten, öffentlich
                unbeachteten literarischen Brachland, auf dem die krude
                komponierte, sinnentleerte Worthülse regiert, bin ich morgen
                schon Kult.
            </p>
       </doc>
    </silva_document>
</silva_publication>
'''

xml2 = r'''<?xml version="1.0" encoding='utf-8' ?>
<silva_root id="test">
    <title>Unergründlich</title>
    <silva_document id="index">
        <title>Unergründlich</title>
        <doc>
            <p type="heading">
        
                Onentdeckt, Onerforscht, unergründlich: Schicksal des
                provisorischen Substituts zwischen nutzloser Platzhalterei und
                dem nie formulierten Anspruch auf Beachtung. Ein Schattendasein
                auf der unbekannten Seite der Seite. Heute noch eine einsame,
                doch kräftige Kulturpflanze auf dem unbeackerten, öffentlich
                unbeachteten literarischen Brachland, auf dem die krude
                komponierte, sinnentleerte Worthülse regiert, bin ich morgen
                schon Kult.
            </p>
       </doc>
    </silva_document>
</silva_root>
'''

xml3 = r'''<?xml version="1.0" encoding='utf-8' ?>
<silva_root id="test">
</silva_root>
'''

class FunctionalTestTest(unittest.TestCase):

    def test_tripple_min(self):
        
        self.assertEqual(tripple_min(1, 2, 3), 1)
        self.assertEqual(tripple_min(3, 1, 2), 1)
        self.assertEqual(tripple_min(2, 3, 1), 1)

        self.assertEqual(tripple_min(1, 3, 2), 1)
        self.assertEqual(tripple_min(2, 1, 3), 1)
        self.assertEqual(tripple_min(3, 2, 1), 1)
    
   
    def testLevenstein(self):

        pat1 = 'abc'
        pat2 = 'cde'
        
        self.assertEqual(levenstein(pat1, pat1), 0)
        self.assertNotEqual(levenstein(pat1, pat2), 0)
   
    def testDistance(self):

        tree1 = buildTree(xml)
        tree1_1 = buildTree(xml)
        tree2 = buildTree(xml2)
        tree3 = buildTree(xml3)

        #print "\n".join(prettyPrint(tree1))
        #print
        #print "\n".join(prettyPrint(tree2))
        #print
        #print "\n".join(prettyPrint(tree3))
        
        
        dist1 = tree1.dist(tree1_1)
        dist2 = tree1.dist(tree2)
        dist3 = tree1.dist(tree3)

        #print dist2
        #print dist3

        self.assertEqual(dist1, 0)
        self.assertNotEqual(dist2, 0)
        self.assertNotEqual(dist3, 0)
     
def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(FunctionalTestTest)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())

    
