# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py,v 1.8 2003/03/25 10:33:45 zagy Exp $

from __future__ import generators

# character replacement map
xml_default_entities = (
    ('&', '&amp;'), 
    ('>', '&gt;'),
    ('<', '&lt;'),
    ('"', '&quot;'),
)

class PTDict(dict):
    """Return key instead of raising KeyError on unknown keys."""

    def __getitem__(self, key):
        try:
            return dict.__getitem__(self, key)
        except KeyError:
            return key


class Singleton(object):
    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")
        if it is not None:
            return it
        cls.__it__ = it = object.__new__(cls)
        it.init(*args, **kwds)
        return it
    def init(self, *args, **kwds):
        pass


def reverseDict(adict):
    """returns adict with key, value exchanged

        NOTE: if the values are not unique, the result is unspecified.
    """
    
    rev = {}
    for key, value in adict.items():
        rev[value] = key

    return rev



def gcd(a, b):
    """returns greatest common divisor of a and b"""
    if b == 0:
        return a
    return gcd(b, a % b)


def lgcd(li):
    """returns gcd of list"""
    return min([gcd(a, b) for a in li for b in li])


def replaceMap(text, repl_map=xml_default_entities):
    """replace unwanted characters"""
    for repl, with in repl_map:
        text = text.replace(repl, with)

    return text                
      
  

def stripControlChars(s, strip=None):
    """return s with all characters < 32 removed
    
        strip: a list containing all characters ids to be removed
    """

    if strip is None:
        strip = range(0, 32)

    return ''.join(filter(lambda x: ord(x) not in strip, s))

  
def enumerate(items):
    i = 0
    for item in items:
        yield i, item
        i += 1
    

