# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_s2w.py,v 1.7 2003/01/13 10:04:42 zagy Exp $


import xmlrpclib
import sys
import time

from config import XMLRPC_PORT, XMLRPC_PASSWORD

if len(sys.argv) not in [3, 4]:
    print "Usage: test_s2w.py <slv file> <dest> [template]"
    sys.exit(1)

xmlfile = sys.argv[1]
docfile = sys.argv[2]

try: template = sys.argv[3]
except IndexError: template = 'test'

s = xmlrpclib.ServerProxy("http://pulsar.infrae:%s/" % (XMLRPC_PORT, ))
f = open(xmlfile, "rb").read()
ident, storageID = s.silva2word("test_s2w", XMLRPC_PASSWORD, '', template, 
    xmlrpclib.Binary(f))

while 1:
    status = s.getJobStatus(ident)
    print "Job status: %s" % status
    if status == "notInQueue": break
    time.sleep(1)

word = s.getWord2SilvaResult("itamar", XMLRPC_PASSWORD, storageID).data
file(docfile, 'wb').write(word)


