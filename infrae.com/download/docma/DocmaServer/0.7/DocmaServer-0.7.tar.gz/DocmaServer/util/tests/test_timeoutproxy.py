import unittest
import time
from types import BuiltinFunctionType

from util.timeoutproxy import TimeoutProxy, TimeoutException

class Func:

    def __init__(self, func):
        self._func = func
    
    def __call__(self, *args, **kwargs):
        return self._func(*args, **kwargs)
        


class TimeoutProxyTest(unittest.TestCase):

    def test_rock(self):
        s = TimeoutProxy('a nice string', 1)
        self.assert_(isinstance(s.split, BuiltinFunctionType), repr(s.split))
        s = TimeoutProxy(Func(lambda x: x+1))
        self.assert_(isinstance(s._func, TimeoutProxy), repr(s._func))
    
    def test_attributes(self):
        s = TimeoutProxy('a nice string', 1)
        self.assertEqual(s.split(' '), ['a', 'nice', 'string'])
    
    def test_timeout(self):
        sleep = TimeoutProxy(time.sleep, .1)
        self.assertRaises(TimeoutException, sleep, 1)
        self.assertEqual(sleep(.01), None)
        func = TimeoutProxy(Func(time.sleep), .1)
        self.assertRaises(TimeoutException, sleep, 1)
        self.assertEqual(sleep(.01), None)
        
    def test_exception(self):
        func = TimeoutProxy(lambda: int("foo"))
        self.assertRaises(ValueError, func)
    
    def test_call(self):
        f1 = TimeoutProxy(lambda x: x+1)
        self.assertEqual(f1(1), 2)
        self.assertEqual(f1(2), 3)
        self.assertEqual(f1(3), 4)
        self.assertEqual(f1(4), 5)
        

    def test_nestedcall(self):
        f1 = Func(lambda x: x+1)
        f2 = Func(f1)
        self.assertEqual(f2(1), 2)
        
        tf1 = TimeoutProxy(f1)
        tf2 = TimeoutProxy(Func(tf1))
        self.assertEqual(tf2(1), 2)

def test_suite():
    loader=unittest.TestLoader()
    return loader.loadTestsFromTestCase(TimeoutProxyTest)

if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())



