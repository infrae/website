#!/bin/sh
PYTHONPATH=$PYTHONPATH:. runtests -t --module batchprocessor.tests.test_all
