# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: convert.py,v 1.16 2003/03/28 15:23:14 zagy Exp $

import re
import copy

import uno
from com.sun.star.beans import PropertyValue

from util import Singleton, enumerate
from silva2ooo.openoffice import Paragraph, TextMarkup, List, ComponentList, \
    Table, CellBorder, Annotation, initialize
from style import ParagraphStyle, ListStyle
    

p_SPACE = re.compile(r'\s+')

class convert:
    """convert silva to openoffice"""

    def __init__(self, dom, hide=False):
        assert hide is True or hide is False
        self.xml = dom
        self.hide = hide
        
        self.doc = None

    def __del__(self):
        if self.doc is not None:
           self.doc.dispose()

    def run(self):
        self.doc = self.getNewDocument()
        self.xml.normalize()
        result = silva().walkTree(self.xml.firstChild, self.doc)
        self.render(result)

    def getNewDocument(self):
        desktop = initialize()
        hide = PropertyValue()
        hide.Name = 'Hidden'
        hide.Value = uno.Bool(int(self.hide))
        return desktop.loadComponentFromURL("private:factory/swriter",
            "_blank", 0, (hide, ))

    def render(self, renderables):
        for renderable in renderables:
            renderable.render()


   
class Node(Singleton):

    descent = True
    
    def walkTree(self, node, doc):
        handle_result = self.handle(node, doc)
        if not self.descent:
            return handle_result
        walk_result = []
        child = node.firstChild
        while child is not None:
            handler = self.findClass(child.nodeName)
            if handler is None:
                #print "Skipped %s on %s" % (child.nodeName,
                #    self.__class__.__name__)
                child = child.nextSibling
                continue
            walk_result += handler().walkTree(child, doc)
            child = child.nextSibling
        result = self.handleAfter(node, doc, handle_result, walk_result)
        if len(result) > 0:
            self.attachMeta(node, result[0])
        return result

    def handle(self, node, doc):
        return []

    def handleAfter(self, node, doc, handle_result, walk_result):
        return handle_result + walk_result

    def findClass(self, name):
        cls = getattr(self, name, None)
        if cls is not None:
            if not issubclass(cls, Node):
                cls = None
        return cls

    def marshalMeta(self, meta_data={}, **kwd):
        meta_data = copy.copy(meta_data)
        meta_data.update(kwd)
        meta = ["<meta>"]
        for key, value in meta_data.items():
            meta.append('    <item name="%s">%s</item>' % (key, value))
        meta.append("</meta>")
        return '\n'.join(meta)

    def getMeta(self, node):
        return {}

    def attachMeta(self, node, component):
        meta = self.getMeta(node)
        assert isinstance(meta, dict)
        if len(meta) == 0:
            return
        meta = self.marshalMeta(meta)
        annotation = Annotation(component.doc, meta)
        component.attach(annotation)

class ParagraphNode(Node):
    descent = False
    style = 'Body text'

    def handle(self, node, doc):
        text, markup = self.getParagraphTextAndMarkup(node)
        s = ParagraphStyle(doc, self.style)
        p = Paragraph(doc, text, markup, use_style=s)
        return [p]

    def getParagraphTextAndMarkup(self, node, offset=0):
        text = ''
        actions = []
        child = node.firstChild
        while child is not None:
            t, a = self.getParagraphTextAndMarkup(child, 
                offset+len(text))
            text += t
            actions += a
            child = child.nextSibling
        if node.nodeType == node.TEXT_NODE:
            text = node.nodeValue
            text = p_SPACE.sub(' ', text)
        elif node.nodeType == node.ELEMENT_NODE:
            name = node.nodeName
            markup = None
            start = offset
            end = len(text) + offset
            if name in ('em', 'strong', 'underline', 'super', 
                    'sub'):
                markup = TextMarkup(start, end, name)
            elif name == 'link':
                markup = TextMarkup(start, end, name, 
                    node.attributes['url'].value)
            elif name == 'index':
                markup = TextMarkup(start, end, name, 
                    node.attributes['name'].value)
            elif name == 'br':
                assert (node.firstChild is None, 
                    "A <br> must not have children")
                text = u'\n'
            if markup is not None:
                actions.insert(0, markup)
        return text, actions


class TitleNode(ParagraphNode):

    def handle(self, node, doc):
        level = 0
        parent = node.parentNode
        while parent is not None:
            #print 'Looking at: %s' % parent.nodeName
            if parent.nodeName in ('silva_folder', 'silva_publication', 
                    'silva_document'):
                level += 1
            parent = parent.parentNode
        #print 'Using: ', level
        self.style = 'Heading %d' % (level, )
        return ParagraphNode.handle(self, node, doc)

            
class _TableElement(Node):

    _column_alignment = {
        'L': Paragraph.LEFT,
        'C': Paragraph.CENTER,
        'R': Paragraph.RIGHT,
    }
    
    def getTable(self, node):
        while node.nodeName != 'table':
            node = node.parentNode
        return node

    def getRow(self, node):
        raise NotImplementedError, "Implemented in subclasses"
                            
    def isLastRow(self, node):
        node = node.parentNode.nextSibling
        while node.nodeType != node.ELEMENT_NODE:
            node = node.nextSibling 
            if node is None:
                return True
        return False

    def isLastColumn(self, node):
        node = node.nextSibling
        while node.nodeType != node.ELEMENT_NODE:
            node = node.nextSibling 
            if node is None:
                return True
        return False

                             


class silva(Node):
    
    class silva_folder(Node):

        def getMeta(self, node):
            id = node.getAttribute('id')
            return {
                'id': id,
                'obj': 'silva_folder',
            }
        
        class title(TitleNode):
            pass
 
 
        class silva_document(Node):
        
            def getMeta(self, node):
                id = node.getAttribute('id')
                return {
                    'id': id,
                    'obj': 'silva_document',
                }

            class title(TitleNode):
                pass


            class doc(Node):
                """silva document contents"""

                p = ParagraphNode
                
             
                class heading(ParagraphNode):

                    def handle(self, node, doc):
                        type = node.getAttribute('type')
                        self.style = 'Heading %s' % (type, )
                        return ParagraphNode.handle(self, node, doc)
       
       
                class pre(Node):

                    def handle(self, node, doc):
                        child = node.firstChild
                        text = []
                        while child is not None:
                            assert child.nodeType == child.TEXT_NODE
                            text.append(child.data)
                            child = child.nextSibling
                        text = '\n'.join(text)
                        preformatted_style = ParagraphStyle(doc, 
                            'Preformatted')
                        p = Paragraph(doc, text, [], 
                            use_style=preformatted_style)
                        return [p]
                
                
                class list(Node):

                    def handleAfter(self, node, doc, handle_result,
                            walk_result):
                        assert handle_result == []
                        type = node.getAttribute('type')
                        style = ListStyle(doc, type)
                        lst = List(doc, walk_result, style=style)
                        return [lst]
                  
                    class li(ParagraphNode):
                        
                        def handle(self, node, doc):
                            result = ParagraphNode.handle(self, node, doc)
                            result = [ComponentList(doc, result)]
                            return result

                class nlist(list):

                    class li(Node):
                        
                        def init(self):
                            _doc = silva.silva_folder.silva_document.doc
                            self.nlist = _doc.nlist
                            self.list = _doc.list
                            self.pre = _doc.pre
                            self.p = _doc.p
                            self.dlist = _doc.dlist

                        def handleAfter(self, node, doc, handle_result, 
                                walk_result):
                            return [ComponentList(doc, walk_result)]


                class table(Node):

                    def getMeta(self, node):
                        type = node.getAttribute('type')
                        return {'type': type}
                    
                    def handleAfter(self, node, doc, handle_after, 
                            walk_result):
                        data = []
                        borders = []
                        for row in walk_result:
                            data_row = []
                            data.append(data_row)
                            border_row = []
                            borders.append(border_row)
                            for datum, border in row:
                                data_row += datum
                                border_row.append(border)
                        widths = self.getWidths(node)
                        t = Table(doc, data, borders=borders, widths=widths)
                        return [t]

                    def getWidths(self, node):
                        col_info = node.getAttribute('column_info')
                        widths = map(lambda x: int(x.split(':')[1]), 
                            col_info.split())
                        return widths
                   
                   
                    class row_heading(_TableElement):

                        def handle(self, node, doc):
                            text = node.firstChild.data
                            style = ParagraphStyle(doc, 'Table Heading')
                            para = Paragraph(doc, text, [], 
                                    use_style=style, endmark=None)
                            border = self.getBorder(node)
                            return [[([para], border)]]

                        def isLastColumn(self, node):
                            # heading spans whole table width, thus it's always 
                            # the last column
                            return True

                        def getBorder(self, node):
                            type = self.getTable(node).getAttribute('type')
                            top, bottom, left, right = 0, 0, 0, 0
                            if type == 'listing':
                                bottom = 1
                            elif type == 'grid':
                                top = 1
                                left = 1
                                if self.isLastRow(node):
                                    bottom = 1
                                if self.isLastColumn(node):
                                    right = 1
                            return CellBorder(top, bottom, left, right)


                    class row(_TableElement):

                        def handleAfter(self, node, doc, handle_result, 
                                walk_result):
                            return [walk_result]
                            
                        
                        class field(_TableElement):
                            
                            def init(self):
                                _doc = silva.silva_folder.silva_document.doc
                                self.nlist = _doc.nlist
                                self.list = _doc.list
                                self.pre = _doc.pre
                                self.p = _doc.p
                                self.dlist = _doc.dlist
                               
                            def handleAfter(self, node, doc, handle_result, 
                                    walk_result):
                                last = walk_result[-1]
                                while not isinstance(last, Paragraph):
                                    last = last.getSubComponents()[-1]
                                last.endmark = None
                                alignment = self._getColumnAlignment(node)
                                for item in walk_result:
                                    self.applyAlignment(item, alignment)
                                border = self.getBorder(node)
                                return [(walk_result, border)]
                                            
                            def getBorder(self, node):
                                type = self.getTable(node).getAttribute('type')
                                top, bottom, left, right = 0, 0, 0, 0
                                if type in ('grid', 'datagrid'):
                                    top = 1
                                    left = 1
                                    if self.isLastRow(node):
                                        bottom = 1
                                    if self.isLastColumn(node):
                                        right = 1
                                return CellBorder(top, bottom, left, right)
                           
                            def _getRow(self, node):
                                return node.parentNode

                            def _getColumnId(self, node):
                                row = self._getRow(node)
                                columns = filter(lambda x: x.nodeType == \
                                            x.ELEMENT_NODE, 
                                        row.childNodes)
                                for id, column in enumerate(columns):
                                    if node is column:
                                        return id
                                raise RuntimeError
                            
                            def _getColumnAlignment(self, node):
                                row_id = self._getColumnId(node)
                                table = self.getTable(node)
                                info = table.getAttribute('column_info')
                                info = info.split()
                                try:
                                    info = info[row_id]
                                except IndexError:
                                    return Paragraph.LEFT
                                info = info.split(':')[0]
                                return self._column_alignment.get(info, 
                                    Paragraph.LEFT)
                            
                            def applyAlignment(self, component, alignment):
                                if isinstance(component, Paragraph):
                                    component.adjust = alignment
                                for sub in component.getSubComponents():
                                    self.applyAlignment(sub, alignment)
                            
                          
                class dlist(Node):

                    class dt(ParagraphNode):
                        style = 'Definition Title'

                    class dd(ParagraphNode):
                        style = 'Definition Description'

    class silva_publication(silva_folder):
        
        def getMeta(self, node):
            id = node.getAttribute('id')
            return {
                'id': id,
                'obj': 'silva_publication',
            }
        
