# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: style.py,v 1.7 2003/03/21 17:34:10 zagy Exp $

from types import IntType

from twisted.python.components import Interface

import uno
import unohelper
from com.sun.star.lang import XEventListener
from com.sun.star.container import NoSuchElementException
from com.sun.star.beans import PropertyValue

class Style(unohelper.Base, XEventListener):

    style_class = "com.sun.star.style.Style"
    style_family = 'NotExistent'
    
    def __init__(self, doc, name, create=True, parent=None):
        self.doc = doc
        self.name = name
        self.create = create
        self.parent = parent
        self.style = None
    
    # XEventListener methods
     
    def disposing(self, event):
        del(self.style)
        del(self.doc)
   
    
    # Style methods
   
    def getStyle(self):
        if self.style is not None:
            return self.style
        styles = self.getFamily()
        try:
            style = styles.getByName(self.name)
        except NoSuchElementException:
            if not self.create:
                raise ValueError, "Style does not exist"
            style = self.createStyle()
        return style
        
    def createStyle(self):
        style = self.doc.createInstance(self.style_class)
        if self.parent is not None:
            style.setParentStyle(self.parent)
        family = self.getFamily()
        family.insertByName(self.name, style)
        return style

    def getFamily(self):
        return self.doc.getStyleFamilies().getByName(self.style_family)

    def apply_to(self, textrange):
        raise NotImplementedError, "Implemented in subclasses"

class ParagraphStyle(Style, XEventListener):
    """paragraph style"""

    style_class = "com.sun.star.style.ParagraphStyle"
    style_family = 'ParagraphStyles'
    
    def __init__(self, doc, name, create=True, parent=None):
        Style.__init__(self, doc, name, create=create, parent=parent)
        if self.parent is None:
            self.parent = 'Text body'
    
    def apply_to(self, textrange):
        textrange.setPropertyValue('ParaStyleName', self.getStyle().getName())


class ListStyleProperties:

    _list_xml = {
        'bullet': 'List Bullet',
        'disc': 'List Bullet',
        'circle': 'List Circle',
        'square': 'List Square',
        'dash': 'List Dash',
        'none': 'List None',
        '1': 'List Number',
        'a': 'List Letter',
        'A': 'List Letter Upper', 
        'i': 'List Roman',
        'I': 'List Roman Upper',
    }

    _list_char = {
        'bullet': ('OpenSymbol', 0x25cf),
        'disc': ('OpenSymbol', 0x25cf),
        'circle': ('OpenSymbol', 0x25cf), # XXX
        'square': ('OpenSymbol', 0x25a0),
        'dash': ('OpenSymbol', 0x25a0),
        'dash': ('OpenSymbol', 0x2013),
    }

    _list_NumberingType = {
        'bullet': 'CHAR_SPECIAL',
        'disc': 'CHAR_SPECIAL',
        'circle': 'CHAR_SPECIAL',
        'square': 'CHAR_SPECIAL',
        'dash': 'CHAR_SPECIAL',
        'none': 'NUMBER_NONE',
        '1': 'ARABIC',
        'a': 'CHARS_LOWER_LETTER',
        'A': 'CHARS_UPPER_LETTER',
        'i': 'ROMAN_LOWER',
        'I': 'ROMAN_UPPER',
    }

    def __init__(self, kind):
        if kind not in self._list_xml.keys():
            raise ValueError, "Unkown list kind (%s)." % (kind, )
        self.kind = kind

    def getNumberingType(self):
        constant = "com.sun.star.style.NumberingType.%s" % (
            self._list_NumberingType[self.kind], )
        return uno.getConstantByName(constant)

    def getBullet(self):
        """return tuple of (Fontname, CharId) or (None, None)]
        
            (None, None) is returned if the style does not required a bullet
         """
        return self._list_char.get(self.kind, (None, None))

    def getName(self):
        return self._list_xml[self.kind]

    def getNumberingRules(self, style, level):
        rules = style.getPropertyValue('NumberingRules').getByIndex(level)
        rules = dict(map(lambda x: (x.Name, x.Value), rules))
        return rules
    
    def setNumberingRules(self, style, level, rules):
        numbering_rules = []
        for key, value in rules.items():
            p = PropertyValue()
            p.Name = key
            p.Value = value
            numbering_rules.append(p)
        nr = style.getPropertyValue('NumberingRules')
        # there is a bug in either UNO or PyUNO preventing this:
        #nr.replaceByIndex(level, tuple(numbering_rules))
            
    
    def apply_to(self, style):
        """apply property to (list) style"""
        for level in range(0, 8):
            rules = self.getNumberingRules(style, level)
            rules['NumberingType'] = self.getNumberingType()
            font, char = self.getBullet()
            if font is not None:
                rules['BulletFontName'] = font
                rules['BulletId'] = char
            self.setNumberingRules(style, level, rules)

            
class ListStyle(Style, XEventListener):
    
    style_class = "com.sun.star.style.NumberingStyle"
    style_family = "NumberingStyles"

    def __init__(self, doc, name, create=True):
        self.properties = ListStyleProperties(name)
        name = self.properties.getName()
        Style.__init__(self, doc, name, create=create, parent=None)
        
    def createStyle(self):
        list_style = Style.createStyle(self)
        self.properties.apply_to(list_style)
        return list_style

    def apply_to(self, textrange):
        textrange.NumberingStyleName = self.getStyle().getName()

