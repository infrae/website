# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: base.py,v 1.6 2003/03/28 11:42:41 zagy Exp $

import unittest

import uno
from com.sun.star.beans import PropertyValue

from silva2ooo.openoffice import initialize


class TestBase(unittest.TestCase):

    texts = [
        'Achtung!',
        'Dieser Blindtext wird gerade durch 130 Millionen Rezeptoren Ihrer Netzhaut erfasst.',
        'Die Zellen werden dadurch in einen Erregungszustand versetzt, der sich �ber den Sehnerv in dem hinteren Teil Ihres Gehirns ausbreitet.',
        'Von dort aus �bertr�gt sich die Erregung in Sekundenbruchteilen auch in andere Bereiche Ihres Grosshirns.',
        'Ihr Stirnlappen wird stimuliert.',
        'Von dort aus gehen jetzt Willensimpulse aus, die Ihr zentrales Nervensystem in konkrete Handlungen umsetzt.',
        'Kopf und Augen reagieren bereits.',
        'Sie folgen dem Text, nehmen die darin enthaltenen Informationen auf wie ein Schwamm.',
        'Nicht auszudenken, was mit Ihnen h�tte passieren k�nnen, wenn dieser Blindtext durch einen echten Text ersetzt worden w�re.',
    ]

    def setUp(self):
        self.text_id = 0
        self.desktop = initialize()
   
    def getText(self):
        text = None
        while text is None:
            try:
                text = self.texts[self.text_id]
            except IndexError:
                self.text_id = 0
        self.text_id += 1
        return unicode(text, 'iso-8859-1')
   
    def getNewDocument(self):
        desktop = self.desktop
        hide = PropertyValue()
        hide.Name = 'Hidden'
        hide.Value = False
        return desktop.loadComponentFromURL("private:factory/swriter",
            "_blank", 0, (hide, ))



