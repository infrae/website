# Copyright (c) 2002 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_convert.py,v 1.8 2003/03/28 11:42:41 zagy Exp $

import os
from tempfile import mktemp
import unittest

from xml.dom import minidom

from silva2ooo.convert import Node, convert, silva
from silva2ooo.openoffice import Paragraph

class ParagraphTest(unittest.TestCase):
    def test_markupConverter(self):
        xml = "<p>asdf</p>"
        dom = minidom.parseString(xml)
        p_node = dom.firstChild
        HandleP = silva.silva_folder.silva_document.doc.p
        text, markup = HandleP().getParagraphTextAndMarkup(p_node)
        self.assertEqual(text, 'asdf')
        self.assertEqual(markup, [])
     
    def test_markupConverterWithSimpleMarkup(self):
        xml = "<p>asdf<strong>foo</strong>bar</p>"
        dom = minidom.parseString(xml)
        p_node = dom.firstChild
        HandleP = silva.silva_folder.silva_document.doc.p
        text, markup = HandleP().getParagraphTextAndMarkup(p_node)
        self.assertEqual(text, 'asdffoobar')
        self.assertEqual(len(markup), 1, `markup`)
        self.assertEqual(markup[0].start, 4)
        self.assertEqual(markup[0].end, 7)
        self.assertEqual(markup[0].markup, 'strong')
       
    def test_markupConverterWithNestedMarkup(self):
        xml = "<p>asdf<strong>foo<em>bar</em></strong>baz</p>"
        dom = minidom.parseString(xml)
        p_node = dom.firstChild
        HandleP = silva.silva_folder.silva_document.doc.p
        text, markup = HandleP().getParagraphTextAndMarkup(p_node)
        self.assertEqual(text, 'asdffoobarbaz')
        self.assertEqual(len(markup), 2)
        self.assertEqual(markup[0].start, 4)
        self.assertEqual(markup[0].end, 10)
        self.assertEqual(markup[0].markup, 'strong')
        self.assertEqual(markup[1].start, 7)
        self.assertEqual(markup[1].end, 10)
        self.assertEqual(markup[1].markup, 'em')
       
    def test_markupConverterWithSerialMarkup(self):
        xml = "<p>asdf<strong>foo</strong>baz<em>bar</em></p>"
        dom = minidom.parseString(xml)
        p_node = dom.firstChild
        HandleP = silva.silva_folder.silva_document.doc.p
        text, markup = HandleP().getParagraphTextAndMarkup(p_node)
        self.assertEqual(text, 'asdffoobazbar')
        self.assertEqual(len(markup), 2)
        self.assertEqual(markup[0].start, 4)
        self.assertEqual(markup[0].end, 7)
        self.assertEqual(markup[0].markup, 'strong')
        self.assertEqual(markup[1].start, 10)
        self.assertEqual(markup[1].end, 13)
        self.assertEqual(markup[1].markup, 'em')

class ConvertTest(unittest.TestCase):

    def test_p(self):   
        xml = "<silva><silva_folder><silva_document><doc><p>asdf<strong>foo</strong>baz<em>bar</em></p></doc></silva_document></silva_folder></silva>"
        dom = minidom.parseString(xml)
        c = convert(dom)
        c.run()

    def test_all(self):
        xml_file = os.path.join(os.path.dirname(__file__), 'alltags.xml')
        dom = minidom.parse(xml_file)
        c = convert(dom, hide=False)
        c.run()
        filename = mktemp('.sxw')
        url = 'file://%s' % (filename, )
        try:
            c.doc.storeToURL(url, ())
            f = file(filename, 'r')
            f.close()
        finally:
            #os.remove(filename)
            pass

    def test_field(self):
        xml = '''<silva>
        <table columns="3" column_info="L:3 C:1 R:2">
            <row>
                <field>
                    <p>foobar</p>
                </field>
                <field>
                    <p>foobar</p>
                </field>
                <field>
                    <p>foobar</p>
                </field>
            </row>
        </table>
        </silva>
        '''
        dom = minidom.parseString(xml)
        table = dom.firstChild.childNodes[1]
        row = table.childNodes[1]
        field = row.childNodes[1]
        self.assertEqual(field.nodeType, field.ELEMENT_NODE)
        self.assertEqual(field.nodeName, 'field')
        field_handler = silva.silva_folder.silva_document.doc.table.row.field()
        self.assertEqual(field_handler._getRow(field), row)
        self.assertEqual(field_handler._getColumnId(field), 0)
        self.assertEqual(field_handler._getColumnAlignment(field),
            Paragraph.LEFT)
        self.assertEqual(field_handler.getTable(field), table)

        field = row.childNodes[3]
        self.assertEqual(field.nodeType, field.ELEMENT_NODE)
        self.assertEqual(field.nodeName, 'field')
        field_handler = silva.silva_folder.silva_document.doc.table.row.field()
        self.assert_(field_handler._getRow(field) is row)
        self.assertEqual(field_handler._getColumnId(field), 1)
        self.assertEqual(field_handler._getColumnAlignment(field),
            Paragraph.CENTER)
        self.assertEqual(field_handler.getTable(field), table)
        
        field = row.childNodes[5]
        self.assertEqual(field.nodeType, field.ELEMENT_NODE)
        self.assertEqual(field.nodeName, 'field')
        field_handler = silva.silva_folder.silva_document.doc.table.row.field()
        self.assert_(field_handler._getRow(field) is row)
        self.assertEqual(field_handler._getColumnId(field), 2)
        self.assertEqual(field_handler._getColumnAlignment(field),
            Paragraph.RIGHT)
        self.assertEqual(field_handler.getTable(field), table)
       
    def test_marshal(self):
        node = Node()
        meta = node.marshalMeta(foo="bar", baz="baz")
        # hum... a semantical test would be better, eh? 
        self.assertEqual(meta, '<meta>\n    <item name="foo">bar</item>\n'
            '    <item name="baz">baz</item>\n</meta>')
       
def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(ParagraphTest))
    suite.addTest(unittest.makeSuite(ConvertTest))
    return suite



if __name__=='__main__':
    unittest.TextTestRunner().run(test_suite())


