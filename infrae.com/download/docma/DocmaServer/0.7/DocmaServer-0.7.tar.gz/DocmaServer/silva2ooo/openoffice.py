import uno
import unohelper
from com.sun.star.lang import XEventListener
from com.sun.star.style import XStyleFamiliesSupplier
from com.sun.star.text import TableColumnSeparator
from com.sun.star.text.ControlCharacter import APPEND_PARAGRAPH

from util import enumerate

desktop = None

class TextMarkup:

    def __init__(self, start, end, markup, context=None):
        """constructor

            start -- start index
            end -- end index
            markup -- name of silva tag
            context -- markup dependend context information
            """
        self.start = start
        self.end = end
        self.markup = markup
        self.context = context

    def __repr__(self):
        return "<TextMarkup %s (%d-%d)>" % (self.markup, self.start, self.end)


class CellBorder:

    def __init__(self, top, bottom, left, right):
        self.top = top
        self.bottom = bottom
        self.left = left
        self.right = right

    def applyTo(self, cell):
        descriptions = [self.top, self.bottom, self.left, self.right]
        border_names = ['TopBorder', 'BottomBorder', 'LeftBorder', 
            'RightBorder']
        for desc, border_name in zip(descriptions, border_names):
            if desc is None:
                continue
            border = cell.getPropertyValue(border_name)
            border.InnerLineWidth = 0
            border.OuterLineWidth = desc
            cell.setPropertyValue(border_name, border)
            

class OpenOfficeComponent(unohelper.Base, XEventListener):
    
    def __init__(self, doc):
        self.doc = doc
        self.cursor = None
        self._attached = []
        self.doc.addEventListener(self)

    # OpenOfficeComponent:
     
    def createCursor(self, textrange):
        cursor = textrange.getText().createTextCursorByRange(
            textrange.getEnd())
        cursor.gotoNextParagraph(False)
        return cursor
    
    def render(self, cursor=None):
        """render component

            cursor: component should be rendered in cursor.
            If cursor is none, document end will be used
        """
        if cursor is None:
            cursor = self.doc.getText().getEnd()
        self.cursor = self.createCursor(cursor)
        self._render()
        for attachable in self._attached:
            self._attach(attachable)
       
    def getSubComponents(self):
        """return sequence of sub components"""
        return ()

    def attach(self, attachable):
        assert isinstance(attachable, Attachable)
        self._attached.append(attachable)

    def _attach(self, attachable):
        attachable.attachTo(self.cursor)

    # XEventListener:
     
    def disposing(self, event):
        del(self.cursor)
        del(self.doc)

class ComponentList(OpenOfficeComponent):

    def __init__(self, doc, items):
        OpenOfficeComponent.__init__(self, doc)
        self.items = items

    def getSubComponents(self):
        return tuple(self.items)

    def _render(self):
        cursor = self.cursor
        for item in self.items:
            item.render(cursor)
            cursor = self.createCursor(item.cursor)
        self.cursor.gotoRange(self.items[0].cursor.getStart(), uno.Bool(0))
        self.cursor.collapseToStart()
        self.cursor.gotoRange(self.items[-1].cursor.getEnd(), uno.Bool(1))
   
class Paragraph(OpenOfficeComponent):

    APPEND_PARAGRAPH = APPEND_PARAGRAPH
    LINE_BREAK = u'\n'

    LEFT = uno.getConstantByName('com.sun.star.style.ParagraphAdjust.LEFT')
    RIGHT = uno.getConstantByName('com.sun.star.style.ParagraphAdjust.RIGHT')
    CENTER = uno.getConstantByName('com.sun.star.style.ParagraphAdjust.CENTER')
    BLOCK = uno.getConstantByName('com.sun.star.style.ParagraphAdjust.BLOCK')

    def __init__(self, doc, text, markup, use_style=None, 
            endmark=APPEND_PARAGRAPH, adjust=LEFT):
        OpenOfficeComponent.__init__(self, doc)
        self.setText(text)
        self.setMarkup(markup)
        self.use_style = use_style
        self.endmark = endmark
        self.adjust = adjust
   
    def setText(self, text):
        self.text = text

    def setMarkup(self, markup):
        if not isinstance(markup, (list, tuple)):
            markup = [markup]
        for m in markup:
            assert isinstance(m, TextMarkup)
        self.markup = markup

    def renderMarkup(self, markup):
        meth = getattr(self, '_markup_%s' % (markup.markup), )
        cur = self.cursor.getText().createTextCursorByRange(
            self.cursor.getStart())
        cur.goRight(markup.start, False)
        cur.goRight(markup.end - markup.start, True)
        meth(markup, cur)

    def _markup_strong(self, markup, cur):
        cur.setPropertyValue('CharWeight', uno.getConstantByName(
            'com.sun.star.awt.FontWeight.BOLD'))

    def _markup_underline(self, markup, cur):
        cur.setPropertyValue('CharUnderline', 1)
        
    def _markup_em(self, markup, cur):
        cur.setPropertyValue('CharPosture', 1)
        
    def _markup_index(self, markup, cur):
        return
        # this is how it should work, but see \
        # http://api.openoffice.org/project/www/issues/show_bug.cgi?id=12611
        mark = self.doc.createInstance("com.sun.star.text.ContentIndexMark")
        mark.setPropertyValue('Level', 1)
        mark.setPropertyValue('AlternativeText', markup.context)
        cur.getText().insertTextContent(cur, mark, True)

    def _markup_link(self, markup, cur):
        cur.setPropertyValue('HyperLinkURL', markup.context)

    def _markup_super(self, markup, cur):
        cur.setPropertyValue('CharEscapement', 33)
        cur.setPropertyValue('CharScaleWidth', 58)
        
    def _markup_sub(self, markup, cur):
        cur.setPropertyValue('CharEscapement', -33)
        cur.setPropertyValue('CharScaleWidth', 58)
    
    def _render(self):
        text = self.text
        if self.endmark == self.LINE_BREAK:
            text += self.endmark
        self.cursor.setString(text)
        if self.endmark == self.APPEND_PARAGRAPH:
            self.cursor.getText().insertControlCharacter(self.cursor.getEnd(),
                self.endmark, True)
        for markup in self.markup:
            self.renderMarkup(markup)
        if self.use_style is not None:
            self.use_style.apply_to(self.cursor)
        self.cursor.ParaAdjust = self.adjust

class List(OpenOfficeComponent):

    def __init__(self, doc, items, style=None):
        """constructor

            doc: the document
            items: sequence of OpenOfficeComponents to be rendered
            style: list style to apply

        """
        OpenOfficeComponent.__init__(self, doc)
        assert isinstance(items, (list, tuple))
        for item in items:
            assert isinstance(item, ComponentList)
        self.items = items
        self.style = style

    def getSubComponents(self):
        return tuple(self.items)

    def _render(self):
        cursor = self.cursor
        for item_id, item in enumerate(self.items):
            item.render(cursor)
            self.style.apply_to(item.cursor)
            for sub_id, sub in enumerate(item.getSubComponents()):
                if item_id == 0 and sub_id == 0:
                    sub.cursor.ParaIsNumberingRestart = True
                    sub.cursor.NumberingIsNumber = True
                if isinstance(sub, List):
                    level = sub.cursor.NumberingLevel
                    sub.cursor.NumberingLevel = level + 1
                elif sub_id > 0:
                        sub.cursor.NumberingIsNumber = False
            cursor = self.createCursor(item.cursor)
            
        self.cursor.gotoRange(self.items[0].cursor.getStart(), uno.Bool(0))
        self.cursor.collapseToStart()
        self.cursor.gotoRange(self.items[-1].cursor.getEnd(), uno.Bool(1))


class Table(OpenOfficeComponent):

    def __init__(self, doc, content, borders=[], widths=[]):
        OpenOfficeComponent.__init__(self, doc)
        self.content = content
        self.borders = borders
        self.widths = widths
        
    def getSubComponents(self):
        result = []
        for column_content in self.content:
            result += column_content
        return tuple(result)
    
    def getRows(self):
        return len(self.content)

    def getColumns(self):
        try:
            return max(map(len, self.content))
        except ValueError:
            return 0

    def getCellName(row, column):
        name = '%s%s' % (chr(column+ord('A')), row+1)
        return name
    getCellName = staticmethod(getCellName)

    def applyWidths(self):
        if not self.widths:
            return
        table_width = self.table.TableColumnRelativeSum
        widths = map(float, self.widths)
        unitWidth = table_width/reduce(lambda x, y: x+y, widths)
        widths = \
            map(int, 
            map(lambda x: x*unitWidth, 
                widths))
        widths.pop()
        separators = []
        last = 0
        for width in widths:
            sep = TableColumnSeparator(width+last, True)
            last += width
            separators.append(sep)
        self.table.TableColumnSeparators = tuple(separators)

    def _attach(self, attachable):
        attachable.attachTo(self.content[0][0].cursor)

    def _render(self):
        rows, columns = self.getRows(), self.getColumns()
        if columns == 0:
            return
        table = self.doc.createInstance("com.sun.star.text.TextTable")
        self.table = table
        table.initialize(rows, columns)
        self.cursor.getText().insertTextContent(self.cursor.getEnd(), 
            table, uno.Bool(0))
        self.applyWidths()
        for row in range(0, rows):
            content_row = self.content[row]
            for column in range(0, columns):
                try:
                    content = content_row[column]
                except IndexError:
                    cur = table.createCursorByCellName(
                        self.getCellName(row, column-1))
                    cur.gotoCellByName(self.getCellName(row, columns-1), True)
                    cur.mergeRange()
                    cell = table.getCellByPosition(column-1, row)
                    text_cursor = cell.createTextCursorByRange(
                        cell.getText().getStart())
                    text_cursor.gotoRange(cell.getText().getEnd(), True)
                    self.content[row][column-1].cursor = text_cursor
                    break
                else:
                    cell = table.getCellByPosition(column, row)
                    cur = cell.createTextCursor()
                    assert cur.queryInterface(uno.getTypeByName(
                        "com.sun.star.text.XTextCursor"))
                    content.render(cur)
                    try:
                        border = self.borders[row][column]
                    except IndexError:
                        pass
                    else:
                        border.applyTo(cell)
        table.TopMargin = 0
        table.BottomMargin = 1000 # 1 cm?


class Attachable(OpenOfficeComponent):

    def __init__(self, *args, **kwd):
        OpenOfficeComponent.__init__(self, *args, **kwd)

    def getAttachable(self):
        raise NotImplementedError, "Implemented in subclasses"
   
    def attachTo(self, cursor):
        """attach attachable to cursor"""
        attachable = self.getAttachable()
        assert attachable.queryInterface(uno.getTypeByName(
            "com.sun.star.text.XTextContent"))
        assert cursor.queryInterface(uno.getTypeByName(
            "com.sun.star.text.XTextCursor"))
        cursor.getText().insertTextContent(cursor.getStart(), 
            attachable, False)
        
    def _render(self, cursor):
        return
        
class Annotation(Attachable):

    def __init__(self, doc, text):
        Attachable.__init__(self, doc)
        self._text = text
        
    def getAttachable(self):
        a = self.doc.createInstance("com.sun.star.text.TextField.Annotation")
        a.Author = "Silva2OOo"
        a.Content = self._text
        return a


def initialize():
    global desktop
   
    if desktop is not None:
        return desktop
    
    localContext = uno.getComponentContext()
    unohelper.addComponentsToContext(localContext, localContext,
        ("connectr","uuresolver","remotebridge","brdgfctr"),
        "com.sun.star.loader.SharedLibrary")
    resolver = localContext.ServiceManager.createInstanceWithContext(
        "com.sun.star.bridge.UnoUrlResolver", localContext)

    smgr = resolver.resolve(
        "uno:socket,host=localhost,port=2002;urp;StarOffice.ServiceManager")
    remoteContext = smgr.getPropertyValue("DefaultContext")

    desktop = smgr.createInstanceWithContext("com.sun.star.frame.Desktop",
        remoteContext)
    return desktop


