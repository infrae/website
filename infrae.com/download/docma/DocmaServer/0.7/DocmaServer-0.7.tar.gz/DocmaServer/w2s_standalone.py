# requierd for the framework
import getopt, sys, traceback, glob, os

from word2silva.convert import Converter
from xml.dom.minidom import parseString

from cl_app import CommandLineApp

class w2sStandalone(CommandLineApp):
    # if the app processes files, set the following switch to 1
    # this will glob args and use stdin as fallback if not args are
    # provided
    processes_files = 1

    # if set to true, argument 1 of the main method will be the content of
    # the file. Else arg 1 will be None
    preload = 0

    # the getopt_args will be used to parse the commandline args
    # into a dict, key the value in this dict and value the cl value
    getopt_args = {}
    # the result dict
    opts = {}

    # enter the mandatory opts
    required_opts = []

    # enter whether we expect non-opt args as well
    # this only needs to be set if self.processes_files is not set
    # to true
    require_args = 1

    def main(self, data, filename):
        """The main part of the program, this has to be modified for each app

        This method will be called with args if self.processes_files is false,
        and for each path in globbed args or the contents of stdin (read fully)
        if self.processes_files is true
        """
        filename = os.path.abspath(os.path.normpath(filename))
        print 'Going to process', filename
        try:
            c = Converter(filename)
            c.run()
            root, ext = os.path.splitext(filename)
            open('%s.slv' % root, 'wb').write(c.getXML().encode('utf8'))
        except:
            exc, e,  tb = sys.exc_info()
            print self.format_exc(exc, e, tb)
            del tb
        print

    def usage(self, error=None):
        u = ''
        if error:
            u += '%s\n\n' % error
        u += ('Usage: %s [-t <template>] [-v] <paths>\n'
                '\ttemplate is a Word template to use'
                '\t-v toggles visibility\n' % sys.argv[0])
        return u

if __name__ == '__main__':
    w2sStandalone()
