from cl_app import CommandLineApp
import xmlrpclib, time, os
from xml.dom.minidom import parseString

class SlvRoundtrip(CommandLineApp):

    # Arguments for the main method
    host = 'localhost'
    port = 8888
    username = 'foo' # just a formality
    password = 'secret'
    email_address = 'guido@infrae.com'
    fronttemplate = 'veryplain'
    
    def main(self, data, filename):
        server = xmlrpclib.Server("http://%s:%s" % (self.host, self.port))
        res = self.slv2doc(data, filename, server)
        if res:
            data, filename = res
            self.doc2slv(data, filename, server)

    def slv2doc(self, data, filename, server):
        print 'Slv 2 doc: ', filename

        # first write a pretty printed version to disk for easier diffing
        open('%s.pretty' % filename, 'w').write(self.pretty_print_left_aligned(data))
    
        if self.fronttemplate.startswith('.doc'):
            self.fronttemplate = self.fronttemplate[:-4]
        ident, storageid = server.silva2word(self.username, self.password,
                            self.email_address, self.fronttemplate, 
                            xmlrpclib.Binary(data),
                            'Command line generation of %s' % filename,
                            2)
                            
        self.wait_until_finished(server, ident)
        
        print 'Silva 2 Word conversion of %s finished' % ident

        result = server.getResult(self.username, self.password, storageid)

        if hasattr(result, 'data'):
            root = 'stdin'
            if filename.find('.') > -1:
                root, ext = os.path.splitext(filename)
            d = '%s/results' % os.path.dirname(filename)
            if not os.path.isdir(d):
                os.mkdir(d)
            open('%s/%s.doc' % (d, os.path.basename(root)), 'wb').write(result.data)
            return (result.data, '%s/%s.doc' % (d, os.path.basename(root)))
        else:
            print 'Error: no document returned!'

    def doc2slv(self, data, filename, server):
        print 'Doc 2 slv:', filename

        ident, storageid = server.word2silva(self.username, self.password,
                            xmlrpclib.Binary(data), self.email_address,
                            'Command line generation of %s' % filename)
        
        self.wait_until_finished(server, ident)

        result = server.getResult(self.username, self.password, storageid)
        if hasattr(result, 'data'):
            root = 'stdin'
            if filename.find('.') > -1:
                root, ext = os.path.splitext(filename)
            d = os.path.dirname(filename)
            if not os.path.isdir(d):
                os.mkdir(d)
            open('%s/%s.slv' % (d, os.path.basename(root)), 'w').write(result.data)
            open('%s/%s.slv.pretty' % (d, os.path.basename(root)), 'w').write(
                    self.pretty_print_left_aligned(result.data))
            print 'Result written'
        else:
            print 'Error: no XML returned!'

    def wait_until_finished(self, server, ident):
        last_status = None
        while 1:
            status = server.getJobStatus(ident)
            if last_status != status:
                print 'Status of %s: %s' % (ident, status)
                last_status = status
            if status not in ['processing', 'queued']:
                break
            time.sleep(1)

    def pretty_print_left_aligned(self, xml):
        dom = parseString(xml)
        la_pretty = '\n'.join([l.strip() for l in dom.toprettyxml().split('\n')])
        del dom
        return la_pretty.encode('UTF-8')

if __name__ == '__main__':
    import sys
    app = SlvRoundtrip()
