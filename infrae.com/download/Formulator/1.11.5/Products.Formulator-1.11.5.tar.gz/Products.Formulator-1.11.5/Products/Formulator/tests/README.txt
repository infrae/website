This directory now contains some unit tests for Formulator.

