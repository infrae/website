# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

class ProxyNotFoundError(Exception):
    pass
