# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

from Interface import Interface

class IRailroadService(Interface):
    """
    """

    # ACCESSORS

    def get_railroad_service(self):
        pass
    
    def repository_url():
        """Return the base URL of the repository.
        """
        pass

    def services_url():
        """Return the URL of the upload cgi.
        """
        pass

    def storage_id():
        """Return the name the storage was configured with.
        """
        pass

    def client_id():
        """Return the name this CMS is registered with on the RR server.
        """
        pass

    def generate_uuid(type=None, REQUEST=None):
        """Return a UUID as 36 character string.

        The optional type parameter defines which type of
        UUID is generated. Possible values are:
          1. time - time based UUID (default)
          2. random - completely random UUID
          3. choose - server systems choice
        """
        pass
    
    def resource_url_for(proxy):
        """Return the repository url for the given proxy object.

        The url is constructed out of the configured repository url
        and the path of the resource on the repository.
        """
        pass
    
    def register_proxy(proxy):
        """Register the given proxy object with this service instance.

        The registration allow the mapping between the uuid of the
        proxy object and the object itself.
        See proxy_for_uuid.
        """
        pass

    def unregister_proxy(proxy):
        """Unregister (forget) the given proxy object.

        The mapping for the proxy is removed from this service instance.
        """
        pass

    def proxy_for_uuid(uuid):
        """Get the Railroad proxy object for this uuid.
        
        Return None if there's no proxy object to be found.
        """
        pass
    
    def fetch_properties_for ( proxy, user=None, pw=None ):
        """Return a dict with all WebDAV properties (in unicode)
        """
        pass
    
    # AUTHORIZATION
    
    def authorize(uuid, method='GET'):
        """Check if the proxy with the given uuid (id parameter) allows the
        request given by method.
        """
        pass
    
     # MANIPULATORS

    def set_properties_for ( proxy, props, user=None, pw=None ):
        """Set WebDAV properties where props is a dict with unicode
        keys and value.

        The keys are tuples in the form of (name, namespace-uri).
        """
        pass
    
    # RR SERVER EVENTS
    
    # XXX somehow check permissions - e.g. a "railroad" user
    # with the right permissions to trigger events, in the CMS.
    
    def available(path):
        """
        """
        pass
    
    def added(uuid, path):
        """
        """
        pass
    
    def removed(uuid):
        """
        """
        pass
    
    def changed(uuid):
        """
        """
        pass
    
class IRailroadProxy(Interface):
    """
    """
    
    def __init__(id, title, uuid):
        """
        """
        pass
    
    # ACCESSORS

    def get_railroad_service():
        ''' gets the railroad_service object '''
    
    def set_railroad_service(service):
        ''' connects the resource to a railroad_service '''
    
    def uuid():
        """
        """
        pass

    def resource_path():
        """The path portion only, of the resource on the RR server
        """
        pass
    
    def resource_url():
        """Probably is delegated to resource_url_for on the
        RailroadService object.
        """
        pass
    
    # MANIPULATORS
    
    def set_resource_path(resourcepath):
        """
        """
        pass
    
    # AUTHORIZATION
    
    def auth_get():
        """Auth get"""
        pass

    def auth_head():
        """Auth head"""
        pass

    def auth_options():
        """Auth options"""
        pass

    def auth_post():
        """Auth post"""
        pass

    def auth_put():
        """Auth put"""
        pass

    def auth_propfind():
        """Auth propfind"""
        pass

    def auth_proppatch():
        """Auth proppatch"""
        pass

    def auth_delete():
        """Auth delete"""
        pass
    
    # ZOPE EVENTS
    
    def on_add():
        """Probably gets called in manage_afterAdd
        """
        pass
    
    def on_copy():
        """Probably gets called in manage_afterCopy
        """
        pass
    
    def on_delete():
        """Probably gets called in manage_beforeDelete
        """
        pass
