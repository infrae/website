Copyright (c) 2004 Infrae. All rights reserved.
See also LICENSE.txt

This is very basic Zope Product containing the interfaces and base classes
for creating Railroad content types.

See also TODO.txt

See also README.txt of the railroad 'server' package

Dependencies
============

* pydavclient

  http://www.infrae.com/download/pydavclient

Thank you
=========

The Infrae team would like to thank UK Defence Academy for their
support and encouragement during the initial development of Railroad.


Appendix
========

If you have comments, you can use one (or more:) of the following
methods to contact the developers:

Mailinglist subscription:
  http://codespeak.net/mailman/listinfo/railroad-dev

Mailinglist for checkin messages:
  http://codespeak.net/mailman/listinfo/rr-checkins

Issue tracker:
  http://codespeak.net/issues/railroad/

IRC:
  irc.freenode.net, #railroad

Project homepage:
  http://www.infrae.com/products/railroad
