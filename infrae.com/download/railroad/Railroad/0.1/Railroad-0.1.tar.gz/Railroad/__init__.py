# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import service

def initialize(context):
    context.registerClass(
        service.RailroadService,
        constructors = (
            service.manage_addRailroadServiceForm,
            service.manage_addRailroadService 
            ),
        icon = "www/railroad_service.png"
        )
