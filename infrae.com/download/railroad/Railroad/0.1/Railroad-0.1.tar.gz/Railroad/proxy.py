# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

from interfaces import IRailroadProxy
import urlparse

class RailroadProxy:
    """
    """
    __implements__ = (IRailroadProxy,)
    
    _resource_path=''
    
    def __init__(id, title, uuid):
        """
        """
        pass
    
    # ACCESSORS
    
    def uuid():
        """
        """
        pass

    def resource_path(self):
        """The path portion only, of the resource on the RR server
        """
        return self._resource_path
        
    def resource_url(self):
        """Return the full URL of the resource this proxy refers to.

        The actual work is delegated to resource_url_for on the
        RailroadService object.
        """
        return self.get_railroad_service().resource_url_for(self)
    
    # MANIPULATORS
    
    def set_resource_path(self,v):
        """sets the path portion only, of the resource on the RR server"""
        if v and v[0]=='/':
            v=v[1:]
        self._resource_path=v.strip()
    
    # ZOPE EVENTS
    
    def on_add(self):
        """Probably gets called in manage_afterAdd
        """
        pass
    
    def on_copy(self):
        """Probably gets called in manage_afterCopy
        """
        pass
    
    def on_delete(self):
        """Probably gets called in manage_beforeDelete
        """
        pass
