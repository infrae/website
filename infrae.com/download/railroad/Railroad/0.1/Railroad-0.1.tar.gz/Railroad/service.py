# -*- coding: iso-8859-1 -*-
# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

# Python
import os
import string
import urllib
import urlparse
import time
from pprint import pprint

import dav

# Zope
from OFS import SimpleItem
from OFS import Folder
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo, Unauthorized
from Globals import InitializeClass, package_home
from AccessControl import Permissions
# Railroad
from utils import checkPermission

import errors, utils

DC_NS = u'http://purl.org/dc/elements/1.1/'

class RailroadService(SimpleItem.SimpleItem):

    meta_type = 'Railroad Service'

    security = ClassSecurityInfo()
    
    manage_options = (
        {'label':'Edit', 'action':'manage_railroadServiceEditForm'},
        {'label':'Test', 'action':'manage_railroadServiceTestForm'},
        ) + SimpleItem.SimpleItem.manage_options

    management_page_charset = 'utf-8'

    security.declareProtected('View management screens', 
        'manage_railroadServiceEditForm')
    manage_railroadServiceEditForm = PageTemplateFile(
        'www/railroadServiceEdit', globals(),  
        __name__='manage_railroadServiceEditForm')

    security.declareProtected('View management screens', 
        'manage_railroadServiceTestForm')
    manage_railroadServiceTestForm = PageTemplateFile(
        'www/railroadServiceTest', globals(),  
        __name__='manage_railroadServiceTestForm')

    security.declareProtected('View management screens', 'manage_main')
    manage_main = manage_railroadServiceEditForm

    def __init__(
        self, id, title='', repo_url='', services_url='', repository_name='', client_name=''):
        self.id = id
        self.title = title
        self._repo_url = repo_url or ''
        self._services_url = services_url or ''
        self._repository_name = repository_name or ''
        self._client_name = client_name or ''
        self._uuid_to_path = {}
        self._path_to_uuid = {}

    # ACCESSORS

    def _get_user_pw ( self, req ):
        try:
            user, pw = req._authUserPW()
        except TypeError:
            user, pw = ('', '')
        return (user, pw)
    
    get_user_pw=_get_user_pw
    
    def get_railroad_service(self):
        """Return reference to self, to be used via aqcuisition
        to get to this service
        """
        return self.aq_inner

    def repository_url(self):
        """Return the base URL of the repository.
        """
        return self._repo_url

    def services_url(self):
        """Return the base URL for the rr services.
        """
        return self._services_url

    def repository_name(self):
        """Return the name the storage was configured with.
        """
        return self._repository_name

    def repo_url(self):
        """Return the url the storage was configured with.
        """
        return self._repo_url

    def client_name(self):
        """Return the name this CMS is registered with on the RR server.
        """
        return self._client_name

    def generate_uuid(self, type=None, REQUEST=None):
        """Return a UUID as 36 character string.

        The optional type parameter defines which type of
        UUID is generated. Possible values are:
          1. time - time based UUID (default)
          2. random - completely random UUID
          3. choose - server systems choice
        """
        # there is a service/uuid/ on railroad now
        # we'll use it for now
        # prepare the request
        uuid_url = urlparse.urljoin(self.services_url(), 'uuid') + '/'
        params = { 'type': 'time' }
        if type is not None:
            params['type'] = type.strip().lower()
        data = urllib.urlencode(params)
        # do request an read result,
        # which is one line with uuid in text form
        r = urllib.urlopen(uuid_url, data)
        uuid = r.read()
        return uuid
    
    def resource_url_for(self, proxy):
        """Return the repository url for the given proxy object.

        The url is constructed out of the configured repository url
        and the path of the resource on the repository.
        """
        resource_path = proxy.resource_path()
        url = urlparse.urljoin(self._repo_url, resource_path)
        return url
    
    def register_proxy(self, proxy):
        """Register the given proxy object with this service instance.

        The registration allow the mapping between the uuid of the
        proxy object and the object itself.
        See proxy_for_uuid.
        """
        self._p_changed = 1
        uuid = proxy.uuid()
        path = proxy.getPhysicalPath()
        self._path_to_uuid[path] = uuid
        self._uuid_to_path[uuid] = path

    def unregister_proxy(self, proxy):
        """Unregister (forget) the given proxy object.

        The mapping for the proxy is removed from this service instance.
        """
        self._p_changed = 1
        uuid = proxy.uuid()
        path = proxy.getPhysicalPath()
        del self._path_to_uuid[path]
        del self._uuid_to_path[uuid]
    
    def proxy_for_uuid(self, uuid):
        """Get the Railroad proxy object for this uuid.
        
        Return None if there's no proxy object to be found.
        """
        try:
            path = self._uuid_to_path[uuid]
            proxy = self.restrictedTraverse(path)
        except KeyError, e:
            raise errors.ProxyNotFoundError
        return proxy
    
    def fetch_properties_for ( self, proxy, user=None, pw=None ):
        """Return a dict with all WebDAV properties
        """
        #unassigned proxies cannot retrieve properties
        if not proxy.resource_path():
            return {}
        
        url = self.resource_url_for(proxy)
        dfile = dav.DAVResource(url)
        dfile.connect()
        if not (user and pw):
            user, pw = self._get_user_pw(self.REQUEST)
            
        dfile._conn.set_auth(user, pw)
        dfile._conn._realm = self.repository_name()
        dfile.update()
        ret = dfile.get_all_properties()
        ret = self._unicodify_property_dict(ret)
        return ret

    # AUTHORIZATION

    def _getPermissionForMethod(self,method):
        ''' returns the CMS permission that is associated 
        with a certain RR method'''

        return Permissions.view
    
    def authorize(self, id, method='GET'):
        """Check if the proxy with the given uuid (id parameter) allows the
        request given by method.

        The authorization is done by calling the appropriate method on
        the proxy object, which triggers Zopes security mechanism.
        """
        #print 'authoriz:',id,self.get_user_pw(self.REQUEST),self.REQUEST['AUTHENTICATED_USER'],method
        try:  
            proxy = self.proxy_for_uuid(id)
        except errors.ProxyNotFoundError, e:
            # XXX should we setStatus 404 when the proxy is not found?
            return self._error_response(e)
        maydo=checkPermission(self._getPermissionForMethod(method),proxy)
        if not maydo:
            # XXX shouldn't that be an instance of the exception?
            res= self._error_response(Unauthorized)
            return res
        ret = repr(proxy) + '\n'
        self.REQUEST.RESPONSE.setStatus(200)
        ret = ret + 'ok\n'
        return ret

    def _error_response(self, exception):
        #import pdb;pdb.set_trace()
        request = self.REQUEST
        response = request.RESPONSE
        # seen in Zopes HTTPResponse
        respone._unauthorized()
        response.setStatus(401)
##         realm = utils.get_realm()
##         response.setHeader('WWW-Authenticate', 'basic realm="%s"' % realm, 1)
        ret = repr(exception) + '\n' + 'failed\n'
        return ret
          
    # MANIPULATORS

    def set_client_name(self,v):
        """set the name this CMS is registered with on the RR server.
        """
        self._client_name=v
    
    def set_repo_url(self,v):
        """set the url the storage was configured with.
        """
        v=v.strip()
        if v and v[-1] != '/':
            v += '/'
        self._repo_url=v
    
    def set_repository_name(self,v):
        """set the name the storage was configured with.
        """
        self._repository_name=v

    def set_repository_url(self,v):
        """set the base URL of the repository.
        """
        v=v.strip()
        if v and v[-1]!='/':
            v += '/'
        self._repository_url=v
        
    def set_services_url(self,v):
        """set the base URL of the railroad services.
        """
        v=v.strip()
        if v and v[-1]!='/':
            v += '/'
        self._services_url=v
        
    def set_properties_for ( self, proxy, props, user=None, pw=None ):
        """Set WebDAV properties for given url from props dict.

        The keys are tuples in the form of (name, namespace-uri).
        """
        #unassigned proxies cannot set properties
        if not proxy.resource_path():
            return

        url = self.resource_url_for(proxy)
        dfile = dav.DAVResource(url)
        dfile.connect()
        if not (user and pw):
            user, pw = self._get_user_pw(self.REQUEST)
        dfile._conn.set_auth(user, pw)
        dfile._conn._realm = self.repository_name()
        props = self._encode_property_dict(props)
        res = dfile.set_properties(props)
        return

    def _unicodify_property_dict(self, propdict, source_encoding='UTF-8'):
        """ Return a dict where all keys and values are unicode
        """
        ret = {}
        for (n, ns), value in propdict.iteritems():
            n = n.decode(source_encoding)
            ns = ns.decode(source_encoding)
            value = value.decode(source_encoding)
            ret[(n, ns)] = value
        return ret

    def _encode_property_dict(self, propdict, target_encoding='UTF-8'):
        """ Return a dict where all keys and values are encoded
        """
        ret = {}
        for (n, ns), value in propdict.iteritems():
            n = n.encode(target_encoding)
            ns = ns.encode(target_encoding)
            value = value.encode(target_encoding)
            ret[(n, ns)] = value
        return ret
    
    security.declareProtected('View management screens', 'manage_railroadServiceEdit')
    def manage_railroadServiceEdit(
        self, repo_url='', services_url='', repository_name='', client_name='', 
        REQUEST=None):
        """Sets the URL's for repository/upload
        """
        if repo_url and self._repo_url != repo_url:
            self._repo_url = repo_url
        if services_url and self._services_url != services_url:
            self._services_url = services_url
        if repository_name and self._repository_name != repository_name:
            self._repository_name = repository_name
        if client_name and self._client_name != client_name:
            self._client_name = client_name
        if REQUEST is not None:
            return self.manage_railroadServiceEditForm(
                manage_tabs_message='Settings Changed')

    security.declareProtected('View management screens', 'manage_railroadServiceTest')
    def manage_railroadServiceTest(self, uuid=None, REQUEST=None):
        """Do some tests.
        """
        if REQUEST is not None:
            return self.manage_railroadServiceTestForm(
                manage_tabs_message='Test done.')

    # RR SERVER EVENTS
    
    # XXX somehow check permissions - e.g. a "railroad" user
    # with the right permissions to trigger events, in the CMS.
    
    def available(self, path):
        """
        """
        pass
    
    def added(self, uuid, path):
        """
        """
        pass
    
    def removed(self, uuid):
        """
        """
        pass
    
    def changed(self, uuid):
        """
        """
        pass                
                
InitializeClass(RailroadService)

manage_addRailroadServiceForm = PageTemplateFile(
    "www/railroadServiceAdd", globals(), __name__='manage_addRailroadServiceForm')

def manage_addRailroadService(
    context, title, repo_url, services_url, repository_name, client_name, REQUEST=None):    
    """Add Railroad service."""
    id = 'railroad_service'
    object = RailroadService(
        id, title, repo_url, services_url, repository_name, client_name)
    context._setObject(id, object)
    utils.add_and_edit(context, id, REQUEST)
    return ''
