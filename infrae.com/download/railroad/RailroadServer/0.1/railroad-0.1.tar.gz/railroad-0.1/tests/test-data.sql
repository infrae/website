
INSERT INTO repositories(name, master_user, master_pw, host, path,
                         upload_path, upload_user, upload_pw, incomming_path, admin_mail,
                         fs_top_dir)
  VALUES ('railroad_data', 'root', 'rootix', 'nova.infrae', '/rrr/',
          '/cgi-bin/rrr-upload.cgi', 'root', 'rootix', '/rrr-incomming/', 'gst@infrae.com',
          '/home/gst/prog/rrr/');

INSERT INTO clients(name, admin_mail, auth_url, auth_domain)
  VALUES ('test-silva', 'gst@infrae.com', 'http://nova.infrae:8080/rr/checkauth', 'Zope');

INSERT INTO repoclient VALUES (1, 1, 'A');

INSERT INTO resources (repo_id, owner_client_id, path, owner, object_id)
  VALUES (1, 1, '/rrr/image/jpeg/000/Girls_are_Evil.jpg', 'gst', '/rr/rr01');
