# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import os

import testconf
from request import Request

import unittest
import urllib

import rr_config
import db_pg as DB
import rr_util

###

CON = None
# reset database
os.system('psql tests <../db_pg.sql >/dev/null 2>&1')

###

class UtilTests ( unittest.TestCase ):
    """Test the rr_util module.
    """

    def setUp ( self ):
        # reset rr_config
        rr_config.initialized = False
        rr_config.repo_name = None
        rr_config.DB = None
        rr_config.do_auth = False
        rr_config.do_search = False
        rr_config.repo_master = {}
        return

    def tearDown ( self ):
        if rr_config.DB is not None:
            rr_config.DB = None
        return

    def test_ap_notice ( self ):
        """Test ap_notice function.
        """
        req = Request()
        rr_util.ap_notice(req, 'TEST')
        expected = ('RR-NOTICE TEST', 5)
        res = req.get_test_result()
        self.assertEqual(expected, res)
        return

    def test_ap_warn ( self ):
        """Test ap_warn function.
        """
        req = Request()
        rr_util.ap_warn(req, 'TEST')
        expected = ('RR-WARNING TEST', 4)
        res = req.get_test_result()
        self.assertEqual(expected, res)
        return

    def test_ap_error ( self ):
        """Test ap_error function.
        """
        req = Request()
        rr_util.ap_error(req, 'TEST')
        expected = ('RR-ERROR TEST', 3)
        res = req.get_test_result()
        self.assertEqual(expected, res)
        return

    def test_redirect ( self ):
        """Test redirect function.
        """
        req = Request()
        url = 'http://xxx.yyy/com/a'
        rr_util.redirect(req, url)
        expected = url
        res = req.get_test_result()
        self.assertEqual(expected, res)
        msg = 'blabla'
        rr_util.redirect(req, url, msg)
        expected = url + '?errormsg=%s' % urllib.quote(msg)
        res = req.get_test_result()
        self.assertEqual(expected, res)
        return

    def test_get_option ( self ):
        """Test get_option function.
        """
        opt = {'key1':'Value1', 'key2':'Value2'}
        req = Request(options=opt)
        expected = opt['key1']
        res = rr_util.get_option('key1', req)
        self.assertEqual(expected, res)
        return

    def test_init_railroad_1 ( self ):
        """Test one of init_railroad function.

        No authorization no search.
        """
        opt = {'repository':'repo', 'authorize':'off', 'search':'off'}
        req = Request(options=opt)
        rr_util.init_railroad(req)
        self.assertEqual(rr_config.initialized, True)
        self.assertEqual(rr_config.repo_name, 'repo')
        self.assertEqual(rr_config.do_auth, False)
        self.assertEqual(rr_config.do_search, False)
        return

    def test_init_railroad_2 ( self ):
        """Test two of init_railroad function.

        Authorization on and no search.
        No matching repository in db.
        """
        opt = {'repository':'repo', 'authorize':'on', 'search':'off',
               'db_module':'db_pg', 'dbname':'tests', 'dbuser':'gst'}
        req = Request(options=opt)
        rr_util.init_railroad(req)
        self.assertEqual(rr_config.initialized, True)
        self.assertEqual(rr_config.repo_name, 'repo')
        self.assertEqual(rr_config.do_auth, True)
        self.assertEqual(rr_config.do_search, False)
        self.assertEqual(rr_config.repo_master['repo'], (None, None, None))
        return

    def test_init_railroad_3 ( self ):
        """Test three of init_railroad function.

        Authorization on and no search.
        Matching repository is in db.
        """
        # add repository
        repo = ('repo', 'host1', '/path/to/repo1', '/path/to/upload1',
                'master', 'password', '/home/gst/downloads')
        DB.add_repository(*repo)
        # do test
        opt = {'repository':'repo', 'authorize':'on', 'search':'off',
               'db_module':'db_pg', 'dbname':'tests', 'dbuser':'gst'}
        req = Request(options=opt)
        rr_util.init_railroad(req)
        self.assertEqual(rr_config.initialized, True)
        self.assertEqual(rr_config.repo_name, 'repo')
        self.assertEqual(rr_config.do_auth, True)
        self.assertEqual(rr_config.do_search, False)
        self.assertEqual(rr_config.repo_master['repo'], (1, 'master', 'password'))
        return
#
###

if __name__ == '__main__':
    unittest.main()
