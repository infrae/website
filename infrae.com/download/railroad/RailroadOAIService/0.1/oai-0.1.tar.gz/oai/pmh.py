"""Module exposing the OAI harvesting protocoll.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


# allow only index and query
__allowed__ = ('index', 'query')

from mod_python import apache

import rr_config
import rr_util

import oai_config
import oai_errors
import oai_util
import oai_handler

###

VERBS = (u'GetRecord',
         u'ListSets',
         u'Identify',
         u'ListIdentifiers',
         u'ListMetadataFormats',
         u'ListRecords')

FORMATS = (u'oai_dc',)

ALLOWED_PARAMS = ('verb', 'from', 'until', 'identifier', 'metadataPrefix', 'responseToken')

###

def index ( req, form ):
    """Requests oai/pmh/ and oai/pmh/index will end up here.
    """
    # XXX
    # spit out form values
    ret = []
    for k in form.keys():
        v = form[k]
        ret.append("%s: %s" % (k, v))
    txt = '\n'.join(ret)
    req.content_type = 'text/plain'
    req.set_content_length(len(txt))
    req.write(txt)
    return apache.OK
#

def query ( req, form ):
    """The queries from harvesters do arrive here.
    """
    args = {}
    # basic sanity checking
    # checks for presence of verb and if verb is ok
    try:
        verb = form['verb'].strip()
        if verb not in VERBS:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_VERB, 'Unknown verb was given!')
        args['verb'] = verb
    except KeyError:
        # no verb at all
        return oai_errors.oai_error(req, form,
                                    oai_errors.BAD_VERB, 'No verb was given!')
    # verb seems to be ok
    # look for date attributes and check them
    ed = rr_util.parse_timestamp(oai_config.EARLIESTDATE)
    if form.has_key('from'):
        ts = form['from'].strip()
        try:
            dt = rr_util.parse_timestamp(ts)
        except ValueError:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT,
                                        'Invalid from timestamp %s!' % ts)
        if dt < ed:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT,
                                        'Invalid from timestamp %s!' % ts)
        args['from'] = dt
    if form.has_key('until'):
        ts = form['until'].strip()
        try:
            dt = rr_util.parse_timestamp(ts)
        except ValueError:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT,
                                        'Invalid until timestamp %s!' % ts)
        if dt < ed:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT,
                                        'Invalid until timestamp %s!' % ts)
        args['until'] = dt
    # check metadataPrefix
    if form.has_key('metadataPrefix'):
        mp = form['metadataPrefix'].strip()
        if mp not in FORMATS:
            return oai_errors.oai_error(req, form,
                                        oai_errors.CANNOT_DISSEMINATE_FORMAT,
                                        'Unknown metadataPrefix %s!' % mp)
        args['metadataPrefix'] = mp
    # check identifier
    if form.has_key('identifier'):
        idf = form['identifier'].strip().decode('utf-8')
        repo = rr_config.repo_name.decode('utf-8')
        expected = u'oai:%s:/' % rr_config.repo_name
        if not idf.startswith(expected):
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT,
                                        'Invaild identifier %s!' % idf)
        args['identifier'] = idf
    # check for allowed parameters
    for k in form.keys():
        if k not in ALLOWED_PARAMS:
            return oai_errors.oai_error(req, form,
                                        oai_errors.BAD_ARGUMENT, 'Unknown parameter %s!' % k)
    # dispatch verb to handler function
    fnc = getattr(oai_handler, verb, None)
    if fnc is None:
        return apache.HTTP_NOT_IMPLEMENTED
    ret = fnc(req, args)
    return ret
#
###
