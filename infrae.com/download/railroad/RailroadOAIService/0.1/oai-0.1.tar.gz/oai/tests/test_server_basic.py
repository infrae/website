import sys
## sys.path.insert(0, '../')

from pprint import pprint

import libxml2

import oaipmh

import unittest

###

class TestServerBasic ( unittest.TestCase ):

    URL = 'http://nova.infrae:82/rrr/service/oai/pmh/query'
##     URL = 'http://plato:82/rrr/service/oai/pmh/query'
##     URL = 'http://nathan.a-nugget.local:2081/rrr/service/oai/pmh/query'

    def setUp ( self ):
        self.schema = file('./oaipmh-rng.xml', 'rb').read()
        pass

    def tearDown ( self ):
        pass

    def check_error ( self, res ):
        doc = libxml2.parseDoc(res)
        xtxt = doc.xpathNewContext()
        xtxt.xpathRegisterNs('A', "http://www.openarchives.org/OAI/2.0/")
        res = xtxt.xpathEval('//A:OAI-PMH/A:error')
        if res:
            ret = res[0].get_content()
            ret = ret.decode('utf-8')
        else:
            ret = None
        xtxt.xpathFreeContext()
        doc.freeDoc()
        return ret

    def parse_check_error ( self, res ):
        rngp = libxml2.relaxNGNewMemParserCtxt(self.schema, len(self.schema))
        rngs = rngp.relaxNGParse()
        ctxt = rngs.relaxNGNewValidCtxt()
        doc = libxml2.parseDoc(res)
        err = doc.relaxNGValidateDoc(ctxt)
        if err:
            return 'Schema validation'
        else:
            xtxt = doc.xpathNewContext()
            xtxt.xpathRegisterNs('A', "http://www.openarchives.org/OAI/2.0/")
            res = xtxt.xpathEval('//A:OAI-PMH/A:error')
            if res:
                ret = res[0].get_content()
                ret = ret.decode('utf-8')
            else:
                ret = None
            xtxt.xpathFreeContext()
        doc.freeDoc()
        return ret

    def test_01_missing_verb ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'from':'xxx'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.check_error(ret), u'No verb was given!')
        return

    def test_02_unknown_verb ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'xxx'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.check_error(ret), u'Unknown verb was given!')
        return

    def test_03_bad_argument_01 ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'Identify', 'from':'2004-01-01'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), u'Identify accepts no arguments!')
        return

    def test_04_idenify ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'Identify'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
##         print ret.decode('utf-8').encode('iso8859-15')
        self.assertEqual(self.parse_check_error(ret), None)
        return

    def test_05_getrecord ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'GetRecord',
              'identifier': 'oai:railroad_data:/rrr/repo/image/jpeg/000/WatchOut.jpg',
##               'identifier': 'oai:rr_nathan:/rrr/repo/image/jpeg/000/WatchOut.jpg',
              'metadataPrefix': 'oai_dc'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), None)
        return

    def test_10_listrecords_01 ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'ListRecords',
              'metadataPrefix': 'oai_dc'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), None)
        return

    def test_20_listidentifiers_01 ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'ListIdentifiers',
              'metadataPrefix': 'oai_dc'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), None)
        return

    def test_30_listmetadataformats_01 ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'ListMetadataFormats'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), None)
        return

    def test_40_listsets_01 ( self ):
        sp = oaipmh.ServerProxy(self.URL)
        kw = {'verb':'ListSets'}
        try:
            ret = sp.makeRequest(**kw)
        except Exception, ex:
            print 'EX', `ex`
            return
        self.assertEqual(self.parse_check_error(ret), u'Sets are not implemented yet!')
        return
#

if __name__ == '__main__':
    unittest.main()
