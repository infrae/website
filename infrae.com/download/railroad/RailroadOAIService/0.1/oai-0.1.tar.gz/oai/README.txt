# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

OAI
===

OAI is a service extension for the Railroad system which provides an
OAI-PMH server so the metadata in the Railroad repository can be
harvested.

For installation instructions see INSTALL.txt.

License
=======

The license is BSD, see LICENSE.txt.
