"""OAI specifig configuration data.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


EARLIESTDATE = u'2004-01-01T00:00:00'

