"""Module containing some utilities.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


from datetime import datetime
import rr_util

###

def make_request_attrs ( form ):
    """Return a string of the oai request attributes suitable for inclusion
    in the <request> tag of an oai response.
    """
    rkeys = (u'verb', u'from', u'until', u'identifier', u'metadataPrefix')
    ret = []
    for k in rkeys:
        try:
            v = form[k]
            if type(v) == datetime:
                v = rr_util.make_utc_timestamp(v)
            else:
                v = str(v).decode('utf-8')
            s = u'%s="%s"' % (k, v)
            ret.append(s)
        except KeyError:
            pass
    return u' '.join(ret)
#
###
