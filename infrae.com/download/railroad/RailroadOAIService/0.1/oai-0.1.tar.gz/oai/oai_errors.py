"""Module defining the error handling for oai.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


from mod_python import apache

import rr_util
import oai_util

###

# oai errors
BAD_VERB = 1
BAD_ARGUMENT = 2
BAD_RESUMPTION_TOKEN = 3
CANNOT_DISSEMINATE_FORMAT = 4
ID_DOES_NOT_EXIST = 5
NO_RECORDS_MATCH = 6
NO_METADATA_FORMATS = 7
NO_SET_HIERARCHY = 8

# mapping codes to text
_code2txt = { BAD_VERB: u'badVerb',
              BAD_ARGUMENT: u'badArgument',
              BAD_RESUMPTION_TOKEN: u'badResumptionToken',
              CANNOT_DISSEMINATE_FORMAT: u'cannotDisseminateFormat',
              ID_DOES_NOT_EXIST: u'idDoesNotExist',
              NO_RECORDS_MATCH: u'noRecordsMatch',
              NO_METADATA_FORMATS: u'noMetadataFormats',
              NO_SET_HIERARCHY: u'noSetHierarchy' }


_error_template = u"""\
<?xml version="1.0" encoding="UTF-8" ?>
<OAI-PMH xmlns="http://www.openarchives.org/OAI/2.0/"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/
                             http://www.openarchives.org/OAI/2.0/OAI-PMH.xsd" >
  <responseDate>%(rdate)s</responseDate>
  <request %(attrs)s>%(requesturl)s</request>
  <error code="%(errorcode)s">%(errormsg)s</error>
</OAI-PMH>
"""


###

# Exceptions

class OaiError ( Exception ):
    pass
#

class InvalidErrorCode ( OaiError ):
    pass
#
###


def oai_error ( req, form, err, errormsg=u'' ):
    """Return a OAI compliant error message. 
    """
    if type(errormsg) != unicode:
        errormsg = errormsg.decode('utf-8')
    try:
        errorcode = _code2txt[err]
    except KeyError:
        raise InvalidErrorCode, (err, req)
    rdate = rr_util.make_utc_timestamp()
    attrs = oai_util.make_request_attrs(form)
    requesturl = req.uri
    ret = _error_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#
###
