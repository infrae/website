# -*- coding: iso-8859-15 -*-
"""Module containing the request handlers.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


from mod_python import apache

import rr_config
import rr_util

import oai_config
import oai_util
import oai_errors
err = oai_errors.oai_error

###

_response_template = u"""\
<?xml version="1.0" encoding="UTF-8" ?>
<OAI-PMH xmlns="http://www.openarchives.org/OAI/2.0/"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/
                             http://www.openarchives.org/OAI/2.0/OAI-PMH.xsd" >
  <responseDate>%(rdate)s</responseDate>
  <request %(attrs)s>%(requesturl)s</request>
  <%(command)s>
    %(body)s
  </%(command)s>
</OAI-PMH>
"""

_metadata_formats = (u'oai_dc', )

NS_DC = 'http://purl.org/dc/elements/1.1/'

###

def Identify ( req, args ):
    """The Identify request.
    """
    if len(args) > 1:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u'Identify accepts no arguments!')
    template = u"""
    <repositoryName>%(repo_name)s ~</repositoryName>
    <baseURL>%(requesturl)s</baseURL>
    <protocolVersion>2.0</protocolVersion>
    <adminEmail>xxx@yyy.com</adminEmail>
    <earliestDatestamp>%(earliestdate)sZ</earliestDatestamp>
    <deletedRecord>no</deletedRecord>
    <granularity>YYYY-MM-DDThh:mm:ssZ</granularity>
"""
    # create identify result
    command = u'Identify'
    rdate = rr_util.make_utc_timestamp().decode('utf-8')
    earliestdate = oai_config.EARLIESTDATE
    attrs = oai_util.make_request_attrs(args)
    requesturl = req.uri
    repo_name = rr_config.repo_name
    body = template % locals()
    ret = _response_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#

def make_record ( args, props, headeronly=False ):
    # build dict with header data
    headers = {}
    headers['identifier'] = u"oai:%s:%s" % (rr_config.repo_name, props[0][0])
    # last changed time
    last = None
    rows = []
    for path, ns, name, value in props:
        if ns == 'RR:' and name == 'lastmodified':
            last = rr_util.parse_timestamp(value)
            continue
        if ns != NS_DC:
            continue
        name = name.decode('utf-8')
        name = name.lower()
        value = value.decode('utf-8')
        rows.append(u"<dc:%(name)s>%(value)s</dc:%(name)s>" % locals())
    if last is None:
        last = rr_util.parse_timestamp('1970-01-01T00:00:00Z')
    headers['datestamp'] = rr_util.make_utc_timestamp(last)
    # prepare response header
    if headeronly:
        record = u"""<header>
        <identifier>%(identifier)s</identifier>
        <datestamp>%(datestamp)s</datestamp>
      </header>""" % headers
    else:
        record = u"""<record>
      <header>
        <identifier>%(identifier)s</identifier>
        <datestamp>%(datestamp)s</datestamp>
      </header>""" % headers
    _md_template = u"""
      <metadata>
        <oai_dc:dc 
         xmlns:oai_dc="http://www.openarchives.org/OAI/2.0/oai_dc/" 
         xmlns:dc="http://purl.org/dc/elements/1.1/" 
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
         xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/oai_dc/ 
         http://www.openarchives.org/OAI/2.0/oai_dc.xsd">
          %s
        </oai_dc:dc>
      </metadata>
"""
    if not headeronly:
        rows = u'\n          '.join(rows)
        md = _md_template % rows
        body = record + md + u'    </record>\n'
    else:
        body = record + u'\n'
    return body
#

def GetRecord ( req, args ):
    """Handle the GetRecord request.
    """
    #
    # check params
    #
    if 'identifier' not in args:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"identifier missing!")
    if 'metadataPrefix' not in args:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"metadataPrefix missing!")
    mdp = args['metadataPrefix']
    if mdp not in _metadata_formats:
        return err(req, args,
                   oai_errors.CANNOT_DISSEMINATE_FORMAT,
                   u"Unknown metadata format %s!" % mdp)
    #
    # find record
    #
    DB = rr_config.DB
    pparts = args['identifier'].split(':')
    rpath = pparts[2]
    reponame = pparts[1]
    rid, roid = DB.get_resource_id(req, rpath, reponame)
    if roid is None:
        # record not found
        return err(req, args,
                   oai_errors.ID_DOES_NOT_EXIST,
                   u'Record withd id %s not in database!' % rpath)
    # XXX for now go to the database directly
    # XXX sould be changed later
    db = DB._db
    curs = db.cursor()
    q = """SELECT r.path, p.nsuri, p.name, p.value
             FROM rr.properties p, rr.resources r
            WHERE p.resource_id = %s AND r.id = p.resource_id;"""
    try:
        curs.execute(q, (rid,))
        props = curs.fetchall()
        curs.commit()
    except:
        raise
    # build metadata
    command = u'GetRecord'
    body = make_record(args, props)
    rdate = rr_util.make_utc_timestamp()
    requesturl = req.uri
    attrs = oai_util.make_request_attrs(args)
    ret = _response_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#

def sql_query_iter ( db, sql, args ):
    curs = db.cursor()
    curs.execute("SET enable_seqscan TO off ;")
    q = "DECLARE qx1 CURSOR FOR " + sql
    try:
        curs.execute(q, args)
    except:
        raise
    while True:
        try:
            curs.execute("FETCH NEXT FROM qx1 ;")
            ret = curs.fetchone()
            if ret:
                yield ret
            else:
                break
        except:
            raise
    try:
        curs.execute("CLOSE qx1;")
        curs.commit()
    except:
        raise
    return
#

def make_query ( args ):
    # build db query
    if 'from' in args and 'until' in args:
        # build between
        q = """\
SELECT r.path, p.nsuri, p.name, p.value
  FROM rr.properties p, rr.resources r,
      (SELECT DISTINCT resource_id as rid FROM rr.properties
        WHERE (qname = 'RR: lastmodified')
              AND (rr.to_tsz(value) BETWEEN %(from)s::timestamp AND %(until)s::timestamp)) as A
 WHERE r.id = p.resource_id AND r.id = A.rid
 ORDER by r.path;"""
    elif 'from' in args:
        # build >
        q = """\
SELECT r.path, p.nsuri, p.name, p.value
  FROM rr.properties p, rr.resources r,
      (SELECT DISTINCT resource_id as rid FROM rr.properties
        WHERE (qname = 'RR: lastmodified') AND (rr.to_tsz(value) >= %(from)s)) as A
 WHERE r.id = p.resource_id AND r.id = A.rid
 ORDER by r.path;"""
    elif 'until' in args:
        # build <
        q = """\
SELECT r.path, p.nsuri, p.name, p.value
  FROM rr.properties p, rr.resources r,
      (SELECT DISTINCT resource_id as rid FROM rr.properties
        WHERE (qname = 'RR: lastmodified') AND (rr.to_tsz(value) <= %(until)s::timestamp)) as A
 WHERE r.id = p.resource_id AND r.id = A.rid
 ORDER by r.path;"""
    else:
        # return all
        q = """SELECT r.path, p.nsuri, p.name, p.value FROM rr.properties p, rr.resources r WHERE r.id = p.resource_id ;"""
    return q
#

def ListRecords ( req, args ):
    """Handle the ListRecords request.
    """
    #
    # check params
    #
    if 'metadataPrefix' not in args:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"metadataPrefix missing!")
    mdp = args['metadataPrefix']
    if mdp not in _metadata_formats:
        return err(req, args,
                   oai_errors.CANNOT_DISSEMINATE_FORMAT,
                   u"Unknown metadata format %s!" % mdp)
    DB = rr_config.DB
    # XXX for now go to the database directly
    # XXX sould be changed later
    db = DB._db
    eargs = args.copy()
    for k, v in eargs.items():
        if k not in ('from', 'until'):
            continue
        t = rr_util.make_utc_timestamp(v)
        eargs[k] = t
    q = make_query(eargs)
    # build metadata
    command = u'ListRecords'
    rdate = rr_util.make_utc_timestamp()
    requesturl = req.uri
    attrs = oai_util.make_request_attrs(args)
    rows = []
    res = []
    qresult = sql_query_iter(db, q, eargs)
    for r in qresult:
        if rows and r[0] != rows[0][0]:
            # one record complete, process it
            ret = make_record(args, rows)
            res.append(ret)
            rows = [ r ]
        else:
            rows.append(r)
    if rows:
        # process last record
        args['identifier'] = u'oai:%s:%s' % (rr_config.repo_name, r[0])
        ret = make_record(args, rows)
        res.append(ret)
    # was something found?
    if len(res) < 1:
        # no, return error
        return err(req, args,
                   oai_errors.NO_RECORDS_MATCH,
                   u"No matching records found!")

    body = u'\n    '.join(res)
    ret = _response_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#

def ListIdentifiers ( req, args ):
    """Handle the ListIdentifiers request.
    """
    #
    # check params
    #
    if 'metadataPrefix' not in args:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"metadataPrefix missing!")
    mdp = args['metadataPrefix']
    if mdp not in _metadata_formats:
        return err(req, args,
                   oai_errors.CANNOT_DISSEMINATE_FORMAT,
                   u"Unknown metadata format %s!" % mdp)
    DB = rr_config.DB
    # XXX for now go to the database directly
    # XXX sould be changed later
    db = DB._db
    eargs = args.copy()
    for k, v in eargs.items():
        if k not in ('from', 'until'):
            continue
        t = rr_util.make_utc_timestamp(v)
        eargs[k] = t
    q = make_query(eargs)
    # build metadata
    command = u'ListIdentifiers'
    rdate = rr_util.make_utc_timestamp()
    requesturl = req.uri
    attrs = oai_util.make_request_attrs(args)
    rows = []
    res = []
    qresult = sql_query_iter(db, q, eargs)
    for r in qresult:
        if rows and r[0] != rows[0][0]:
            # one record complete, process it
            ret = make_record(args, rows, True)
            res.append(ret)
            rows = [ r ]
        else:
            rows.append(r)
    if rows:
        # process last record
        args['identifier'] = u'oai:%s:%s' % (rr_config.repo_name, r[0])
        ret = make_record(args, rows, True)
        res.append(ret)
    # was something found?
    if len(res) < 1:
        # no, return error
        return err(req, args,
                   oai_errors.NO_RECORDS_MATCH,
                   u"No matching records found!")

    body = u'\n      '.join(res)
    ret = _response_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#

def ListMetadataFormats ( req, args ):
    """Handle the ListMetadataFormats request.
    """
    #
    # check params
    #
    if len(args) > 2:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"Invalid arguments! 1")
    elif len(args) == 2 and not 'identifier' in args:
        return err(req, args,
                   oai_errors.BAD_ARGUMENT,
                   u"Invalid arguments! 2")
    elif len(args) == 2 and 'identifier' in args:
        ident = args['identifier']
    else:
        ident = None
    if ident is not None:
        DB = rr_config.DB
        pparts = ident.split(':')
        rpath = pparts[2]
        reponame = pparts[1]
        rid, roid = DB.get_resource_id(req, rpath, reponame)
        if roid is None:
            # record not found
            return err(req, args,
                       oai_errors.ID_DOES_NOT_EXIST,
                       u'Record withd id %s not in database!' % rpath)
    command = u'ListMetadataFormats'
    rdate = rr_util.make_utc_timestamp()
    requesturl = req.uri
    attrs = oai_util.make_request_attrs(args)
    body = u"""<metadataFormat>
     <metadataPrefix>oai_dc</metadataPrefix>
     <schema>http://www.openarchives.org/OAI/2.0/oai_dc.xsd
       </schema>
     <metadataNamespace>http://www.openarchives.org/OAI/2.0/oai_dc/
       </metadataNamespace>
   </metadataFormat>
"""
    ret = _response_template % locals()
    ret = ret.encode('utf-8')
    req.content_type = 'text/xml; charset=UTF-8'
    req.set_content_length(len(ret))
    req.write(ret)
    return apache.OK
#

def ListSets ( req, args ):
    """Handle the ListSets request.
    """
    return err(req, args,
               oai_errors.NO_SET_HIERARCHY,
               u"Sets are not implemented yet!")
#
###
