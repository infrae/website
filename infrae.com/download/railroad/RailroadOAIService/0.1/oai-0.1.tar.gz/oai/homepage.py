"""Module responsible for displaying the oai service homepage.
"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt


from mod_python import apache

import os.path

###

_oai_dir = os.path.dirname(__file__)

_page_file = os.path.join(_oai_dir, 'page.html')

###


def index ( req, form ):
    """Main entry point to the oai service.
    """
    # for now read the page.html file and deliver it
    html = file(_page_file, 'rb').read()
    req.content_type = 'text/html'
    req.set_content_length(len(html))
    req.write(html)
    return apache.OK
#
###
