# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

# allow access for everyone
__auth__ = True

# the allowed callables and modules
__allowed__ = ('index', 'pmh')

# manage imports

# make the pmh index a callable in this module
import pmh as p
pmh = p.index

# make index available
from homepage import index
