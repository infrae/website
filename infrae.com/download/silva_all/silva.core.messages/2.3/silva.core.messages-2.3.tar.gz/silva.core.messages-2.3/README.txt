===================
silva.core.messages
===================


Library for flash messages, similar to z3c.flashmessage but simpler.
