# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# package

from silva.core.xml import registerNamespace

NS_LAYOUT_URI = 'http://infrae.com/namespace/silva-core-contentlayout'
registerNamespace('silva-core-contentlayout', NS_LAYOUT_URI)


