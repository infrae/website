"""
Author: kapil thangavelu <k_vertigo@objectrealms.net>
"""

from silva.core import conf as silvaconf

silvaconf.extensionName('SilvaMetadata')
silvaconf.extensionTitle('Silva Metadata')
silvaconf.extensionSystem()
