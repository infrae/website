# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt
"""
Author: kapil thangavelu <k_vertigo@objectrealms.net>
"""

from silva.core import conf as silvaconf

silvaconf.extension_name('SilvaMetadata')
silvaconf.extension_title('Silva Metadata')
silvaconf.extension_system()
