==================
silva.app.document
==================

The default document content type for `Silva`_ 3.0. It is based on
``silva.core.editor`` that uses `CKEditor`_, and replace the old
``SilvaDocument`` extension who was based on `Kupu`_.

This document type can be extend by other Silva extensions.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.app.document/.


.. _CKEditor: http://ckeditor.com/
.. _Silva: http://silvacms.org/
.. _Kupu: http://infrae.com/products/kupu_editor
