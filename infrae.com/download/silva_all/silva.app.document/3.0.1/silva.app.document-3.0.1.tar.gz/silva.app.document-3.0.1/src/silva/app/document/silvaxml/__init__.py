# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# package

from silva.core.xml import registerNamespace

NS_DOCUMENT_URI = 'http://infrae.com/namespace/silva-app-document'
registerNamespace('silva-app-document', NS_DOCUMENT_URI)
