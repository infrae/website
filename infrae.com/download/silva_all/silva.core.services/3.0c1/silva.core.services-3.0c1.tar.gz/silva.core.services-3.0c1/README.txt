===================
silva.core.services
===================

This package contains default Silva services definition (API), and
implementation of mandatory Silva services.

You can have more information on how to use this package in the `Silva
developer documentation`_.

Code repository
===============

The code for this extension can be found in Mercurial:
https://hg.infrae.com/silva.core.services

.. _Silva developer documentation: http://docs.infrae.com/silva/

