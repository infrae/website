# Copyright (c) 2009-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.services')
silvaconf.extensionTitle('Silva Core Services')
silvaconf.extensionSystem()
