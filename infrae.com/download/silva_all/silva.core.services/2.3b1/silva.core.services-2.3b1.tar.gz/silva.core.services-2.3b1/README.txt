===================
silva.core.services
===================

This package contains default Silva services definition.



