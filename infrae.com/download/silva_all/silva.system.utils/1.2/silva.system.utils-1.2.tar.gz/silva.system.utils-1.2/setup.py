# -*- coding: utf-8 -*-
# Copyright (c) 2008-2012 Infrae. All rights reserved.
# See also LICENSE.txt

from setuptools import setup, find_packages
import os

version = '1.2'

setup(name='silva.system.utils',
      version=version,
      description="command line utils to manage Silva sites",
      long_description=open("README.txt").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      classifiers=[
          "Environment :: Web Environment",
          "Intended Audience :: Developers",
          "License :: OSI Approved :: Zope Public License",
          "Programming Language :: Python",
          "Topic :: Software Development :: Libraries :: Python Modules",
          "Framework :: Zope2",
          ],
      keywords='system utils silva',
      author='Infrae',
      author_email='info@infrae.com',
      url='https://hg.infrae.com/silva',
      license='BSD',
      package_dir={'': 'src'},
      packages=find_packages('src'),
      namespace_packages=['silva', 'silva.system'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
        'Zope2',
        'Products.Silva >= 2.3.6, < 3.0',
        'argparse',
        'infrae.wsgi',
        'setuptools',
        'silva.core.interfaces',
        'silva.core.services',
        'silva.core.upgrade',
        'zope.component',
        'zope.location',
        'zope.security',
        'zope.site',
        ],
      entry_points = """
      [console_scripts]
      silva = silva.system.utils.script:script [script]
      [silva.system.utils]
      manage = silva.system.utils.commands.manage:ManageCommand
      pack = silva.system.utils.commands.pack:PackCommand
      files = silva.system.utils.commands.files:FilesCommand
      clear_version = silva.system.utils.commands.version:CleanupVersionCommand
      """
      )
