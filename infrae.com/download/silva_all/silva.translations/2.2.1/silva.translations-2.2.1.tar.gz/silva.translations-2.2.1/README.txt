==================
silva.translations
==================

``silva.translations`` contains all translations for the Silva CMS in many languages.

