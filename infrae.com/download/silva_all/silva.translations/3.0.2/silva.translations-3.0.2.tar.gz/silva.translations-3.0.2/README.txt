==================
silva.translations
==================

``silva.translations`` contains all translations for `Silva`_ in many
languages.

If you wish to help to translate `Silva`_ in your language, you can
help us by doing it on Launchpad:
https://translations.launchpad.net/silva/. This package is updated
with the translations done on Launchpad.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.translations/.


.. _Silva: http://silvacms.org

