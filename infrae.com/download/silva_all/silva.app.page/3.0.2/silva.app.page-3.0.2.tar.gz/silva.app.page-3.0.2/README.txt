==============
silva.app.page
==============

``silva.app.page`` provides new content type for `Silva`_, *Silva
Page*, and if ``silva.app.news`` is installed, *Silva News Page* and
*Silva Agenda Page*. Those content types let editors create public
content with the help of ``silva.core.contentlayout``.

Credits
=======

Thanks to `UCL`_ for the port of this extension to Silva 3.0.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.app.page/.

.. _Silva: http://silvacms.org/
.. _UCL: http://www.ucl.ac.uk/
