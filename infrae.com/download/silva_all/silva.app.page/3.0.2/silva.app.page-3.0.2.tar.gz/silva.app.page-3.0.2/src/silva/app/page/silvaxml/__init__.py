# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# this is a package

from silva.core.xml import registerNamespace

NS_PAGE_URI = 'http://infrae.com/namespace/silva-app-page'
registerNamespace('silva-app-page', NS_PAGE_URI)

