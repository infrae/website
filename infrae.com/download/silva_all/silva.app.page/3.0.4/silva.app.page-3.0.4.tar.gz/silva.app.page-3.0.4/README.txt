==============
silva.app.page
==============

``silva.app.page`` provides new content type for `Silva`_ 3, *Silva
Page*, and if ``silva.app.news`` is installed, *Silva News Page* and
*Silva Agenda Page*. Those content types let editors create public
content with the help of ``silva.core.contentlayout``.

Credits
=======

Thanks to `UCL`_ for the port of this extension to Silva 3.0.

Code repository
===============

You can find the code of this extension in Git:
https://github.com/silvacms/silva.app.page

.. _Silva: http://silvacms.org/
.. _UCL: http://www.ucl.ac.uk/
