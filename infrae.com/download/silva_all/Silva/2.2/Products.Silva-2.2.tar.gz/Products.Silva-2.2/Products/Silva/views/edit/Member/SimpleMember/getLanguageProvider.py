from Products.Silva.adapters import languageprovider
return languageprovider.getLanguageProvider(context)

