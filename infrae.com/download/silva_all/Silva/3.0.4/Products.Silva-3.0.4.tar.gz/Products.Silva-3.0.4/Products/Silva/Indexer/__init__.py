# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt

# BBB
from Products.Silva.Indexer.content import Indexer, IndexerReferenceValue

__all__ = ['Indexer', 'IndexerReferenceValue']
