# -*- coding: utf-8 -*-
# Copyright (c) 2011-2013 Infrae. All rights reserved.
# See also LICENSE.txt

from Products.Silva.Folder.content import Folder
from Products.Silva.Folder.views import FolderAddForm
