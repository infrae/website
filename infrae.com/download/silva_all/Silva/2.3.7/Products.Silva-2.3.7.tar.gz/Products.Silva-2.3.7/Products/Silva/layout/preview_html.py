return context.index_html(view_method='public_preview')
