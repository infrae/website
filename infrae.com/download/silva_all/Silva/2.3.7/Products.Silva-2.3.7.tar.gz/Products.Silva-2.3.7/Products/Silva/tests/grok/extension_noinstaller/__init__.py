# Copyright (c) 2008-2011 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$


from silva.core import conf as silvaconf

silvaconf.extensionName('TestExtension')
silvaconf.extensionTitle('Test Extension')
