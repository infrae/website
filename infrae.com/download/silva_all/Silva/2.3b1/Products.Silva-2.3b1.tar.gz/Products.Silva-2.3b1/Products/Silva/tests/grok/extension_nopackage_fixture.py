# -*- coding: utf-8 -*-
# Copyright (c) 2008-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: extension_nopackage_fixture.py 38845 2010-01-05 10:33:29Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('BadExtension')
silvaconf.extensionTitle('Bad Extension')

