#this script is here just to import and return
#we always have PIL
return True
