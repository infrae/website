# this is a package

NS_SILVA_URI = 'http://infrae.com/namespace/silva'
NS_SILVA_CONTENT_URI = 'http://infrae.com/namespace/metadata/silva-content'
NS_SILVA_EXTRA_URI = 'http://infrae.com/namespace/metadata/silva-extra'


