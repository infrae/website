from Products.Silva.i18n import translate as _

return unicode(_("This is just a placeholder so this directory won't get pruned."))
