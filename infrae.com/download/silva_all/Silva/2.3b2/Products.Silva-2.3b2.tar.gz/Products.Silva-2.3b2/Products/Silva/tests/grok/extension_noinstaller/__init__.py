# Copyright (c) 2008-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 38845 2010-01-05 10:33:29Z sylvain $


from silva.core import conf as silvaconf

silvaconf.extensionName('TestExtension')
silvaconf.extensionTitle('Test Extension')
