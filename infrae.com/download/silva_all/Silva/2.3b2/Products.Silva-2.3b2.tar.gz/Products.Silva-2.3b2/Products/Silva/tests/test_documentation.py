# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: test_documentation.py 45515 2010-09-27 13:57:12Z sylvain $

import unittest

from Products.Silva.testing import FunctionalLayer
from Products.Silva.ExtensionService import install_documentation


class DocumentationTestCase(unittest.TestCase):
    layer = FunctionalLayer

    def setUp(self):
        self.root = self.layer.get_application()
        self.layer.login('chiefeditor')

    def test_install_documentation(self):
        """Test documentation installation. That should not make any
        error at all.
        """
        install_documentation(self.root)
        self.failUnless('docs' in self.root.objectIds())


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(DocumentationTestCase))
    return suite
