# Copyright (c) 2008-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: contents_publication_fixture.py 32946 2009-01-12 16:26:47Z sylvain $

from silva.core import conf as silvaconf
from Products.Silva.Publication import Publication


class MyPublication(Publication):

    meta_type = 'My Publication'


