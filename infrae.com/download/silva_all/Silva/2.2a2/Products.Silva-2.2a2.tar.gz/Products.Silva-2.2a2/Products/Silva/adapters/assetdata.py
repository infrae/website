# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: assetdata.py 32946 2009-01-12 16:26:47Z sylvain $

from five import grok
from Products.Silva import interfaces

class FileData(grok.Adapter):

    grok.implements(interfaces.IAssetData)
    grok.context(interfaces.IFile)

    def getData(self):
        return self.context.get_content()

class ImageData(grok.Adapter):

    grok.implements(interfaces.IAssetData)
    grok.context(interfaces.IImage)

    def getData(self):
        image = getattr(self.context, 'hires_image', None)
        if image is None:
            # Fallback to 'normal' image, which, if there isn't a hires
            # version, should be the original.
            image = self.context.image
        return image.get_content()

