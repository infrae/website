# -*- coding: utf-8 -*-
# Copyright (c) 2008-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: extension_nopackage_fixture.py 32946 2009-01-12 16:26:47Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('BadExtension')
silvaconf.extensionTitle('Bad Extension')

