return context.get_root().get_silva_product_version()
