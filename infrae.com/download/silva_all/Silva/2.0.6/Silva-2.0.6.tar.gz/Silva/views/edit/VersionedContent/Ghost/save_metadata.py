# This script needs to be here!!
# It prevents settings metadata via Ghosts on ghosted objects.
pass