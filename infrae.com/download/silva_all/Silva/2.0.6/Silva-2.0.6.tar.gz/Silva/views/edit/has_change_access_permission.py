return context.get_silva_permissions()['ChangeSilvaAccess']
