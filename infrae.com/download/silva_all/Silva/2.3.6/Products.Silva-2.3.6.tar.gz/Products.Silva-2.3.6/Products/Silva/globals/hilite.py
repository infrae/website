return 'Silva %s' % context.get_root().get_silva_software_version()
