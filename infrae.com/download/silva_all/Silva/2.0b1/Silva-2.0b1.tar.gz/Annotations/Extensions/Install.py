from Products.Annotations.AnnotationTool import AnnotationTool

def install(self):

    portal = self.portal_url.getPortalObject()
    portal._setObject(AnnotationTool.id, AnnotationTool())

    return 'Annotation Tool Installed'
