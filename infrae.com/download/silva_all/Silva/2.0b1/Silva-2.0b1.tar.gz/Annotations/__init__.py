from AnnotationTool import getAnnotations, AnnotationTool
from helpers import setupIcon

setupIcon(AnnotationTool, 'www/annotations.png', 'Annotations', globals())
