UsingCMF = 0
