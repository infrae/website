Copyright (c) 2003-2005 Infrae. All rights reserved.
See also LICENSE.txt

Meta::
  
  Valid for:  Annotations 0.4.x
  Author:     Martijn Faassen
  Email:      faassen@infrae.com
  CVS:        $Revision: 1.2 $

Introductions

  Annotations allows you to add information to any Zope object. It is
  used by Silva Metadata to store metadata on objects.
