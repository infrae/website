PROJECTNAME = 'Kupu'

TOOLNAME = 'kupu_library_tool'
TOOLTITLE = 'Kupu visual editor'
