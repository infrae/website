return context.REQUEST.model.image.tag()
