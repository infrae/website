import os
import OFS
from Globals import ImageFile

# XXX I don't like setting up icon like this either, but Annotations
# doesn't install itself through normal registerClass mechanism in
# __init__. It probably should really be altered so it does work that way.
def setupIcon(klass, icon, repository, g):
    """Load icon into Zope image object and put it in Zope's
    repository for use by the ZMI, for a particular class.
    klass -- the class of the field we're adding
    icon  -- the icon
    """
    # set up misc_ respository if not existing yet
    if not hasattr(OFS.misc_.misc_, repository):
        setattr(OFS.misc_.misc_, 
                repository, 
                OFS.misc_.Misc_(repository, {}))
        
    # get name of icon in the misc_ directory
    icon_name = os.path.split(icon)[1]
        
    # set up image object from icon file
    icon_image = ImageFile(icon, g)
    icon_image.__roles__ = None

    # put icon image object in misc_/Formulator/
    getattr(OFS.misc_.misc_, repository)[icon_name] = icon_image

    # set icon attribute in field_class to point to this image obj
    setattr(klass, 'icon', 'misc_/%s/%s' %
            (repository, icon_name))     
