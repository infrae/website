from Products.Annotations.AnnotationTool import AnnotationTool

def install(self):

    silvan_id = 'service_annotations'
    portal = self.get_root()
    ob = AnnotationTool()
    ob.id = silvan_id
    portal._setObject(silvan_id, ob)

    return 'Silva Annotation Service Installed'
