# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: contents_publication_fixture.py 30514 2008-08-26 15:02:37Z sylvain $

from silva.core import conf as silvaconf
from Products.Silva.Publication import Publication


class MyPublication(Publication):

    meta_type = 'My Publication'


