# -*- coding: utf-8 -*-
# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: extension_nopackage_fixture.py 30481 2008-08-26 10:37:20Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('BadExtension')
silvaconf.extensionTitle('Bad Extension')

