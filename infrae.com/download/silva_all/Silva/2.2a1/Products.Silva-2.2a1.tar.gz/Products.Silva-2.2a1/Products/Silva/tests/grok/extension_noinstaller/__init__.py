# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 30481 2008-08-26 10:37:20Z sylvain $


from silva.core import conf as silvaconf

silvaconf.extensionName('TestExtension')
silvaconf.extensionTitle('Test Extension')
