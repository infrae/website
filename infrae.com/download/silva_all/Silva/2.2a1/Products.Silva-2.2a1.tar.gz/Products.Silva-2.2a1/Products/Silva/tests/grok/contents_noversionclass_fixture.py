# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: contents_noversionclass_fixture.py 30493 2008-08-26 11:40:43Z sylvain $

from silva.core import conf as silvaconf
from Products.Silva.VersionedContent import CatalogedVersionedContent
from Products.Silva.Version import CatalogedVersion


class MyVersionContent(CatalogedVersion):

    meta_type = 'My Version Content'


class MyVersionedContent(CatalogedVersionedContent):

    meta_type = 'My Versioned Content'
