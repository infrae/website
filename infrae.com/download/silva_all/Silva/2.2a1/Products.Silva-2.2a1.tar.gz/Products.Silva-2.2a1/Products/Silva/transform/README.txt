For a short HowTo on creating your own renderers, refer to the file 
'xslt_renderers_howto.txt', in the Silva/doc/ directory.