# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: interfaces.py 31152 2008-10-01 09:52:57Z sylvain $

import zope.deprecation 
zope.deprecation.moved('Products.Silva.interfaces.adapters', 'Silva 2.3')


