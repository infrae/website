#this script is here just to import and return
#the havePIL variable defined in Products.Silva.__init__.py
#I don't seem to be able to get havePIL directly from
#the Image formulator form
from Products.Silva import havePIL

return havePIL
