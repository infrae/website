return '<span class="punctuation">&nbsp;:&nbsp;</span>'
