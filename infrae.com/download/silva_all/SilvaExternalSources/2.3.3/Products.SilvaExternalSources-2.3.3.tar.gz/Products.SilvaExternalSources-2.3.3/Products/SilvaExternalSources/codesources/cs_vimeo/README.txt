﻿README for Vimeo Code Source
============================

This README should reside inside a Silva Code Source named 'cs_vimeo'. The
Code Source allows Authors to place an exisitng Vimeo video in a document
using it's unique ID.


Customizing YouTube Code Source
-------------------------------
The code in the page template named 'youtube_source' can be easily adjusted to
your personal requirements.


Parameters
----------
You can adjust the fields in the parameters form.
Video height: the height of the video, by default set to 270 pixels
Video width: the width of the video, by default set to 480 pixels
Vimeo ID: the unique ID to embed the Vimeo video you want to include.

--
Improvements and variants are welcome.
