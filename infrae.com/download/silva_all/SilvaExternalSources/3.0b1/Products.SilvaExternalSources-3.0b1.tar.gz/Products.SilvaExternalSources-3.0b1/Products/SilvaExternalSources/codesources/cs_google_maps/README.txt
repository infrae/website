README for Google Maps Code Source
==================================

This README should reside inside a Silva Code Source named 'cs_google_maps'.
The Code Source allows Authors to embed a Google Calendar in a document.

Customizing Google Maps Code Source
-----------------------------------

The code in the page template named 'google_maps_source' can be easily
adjusted to your personal requirements. 

Parameters
----------
You can add the iFrame code. 

--
Improvements and variants are welcome.
