# package

NS_URI = "http://infrae.com/namespace/silva-external-sources"


