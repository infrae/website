# -*- coding: utf-8 -*-
# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 32942 2009-01-12 16:20:11Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.layout')
silvaconf.extensionTitle('Silva Core Layout')
silvaconf.extensionSystem()
