# -*- coding: utf-8 -*-
# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 30356 2008-08-21 13:17:38Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.layout')
silvaconf.extensionTitle('Silva Core Layout')
silvaconf.extensionSystem()
