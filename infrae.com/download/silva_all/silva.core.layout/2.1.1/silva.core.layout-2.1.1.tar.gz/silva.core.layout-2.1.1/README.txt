silva.core.layout
=================

``silva.core.layout`` helps you to create and customize public layouts
for Silva. It's the base system for new generation filesystem based
layouts.



