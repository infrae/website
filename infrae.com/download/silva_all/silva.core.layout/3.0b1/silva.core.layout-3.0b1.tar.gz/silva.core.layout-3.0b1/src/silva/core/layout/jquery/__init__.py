# -*- coding: utf-8 -*-
# Copyright (c) 2010-2011 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core.layout.jquery.interfaces import IJQueryResources
from silva.core.layout.jquery.interfaces import IJQueryUIResources

__all__ = ['IJQueryResources', 'IJQueryUIResources']
