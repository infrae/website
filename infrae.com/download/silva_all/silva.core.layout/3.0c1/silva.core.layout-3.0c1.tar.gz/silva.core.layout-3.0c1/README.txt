=================
silva.core.layout
=================

Introduction
============

``silva.core.layout`` helps you to create and customize public layouts
for Silva. It's the base system for new generation filesystem based
layouts.

You can have more information on how to use this package in the `Silva
developer documentation`_.

.. _Silva developer documentation: http://docs.infrae.com/silva/

Code repository
===============

You can find the code in a Mercurial repository at:
https://hg.infrae.com/silva.core.layout
