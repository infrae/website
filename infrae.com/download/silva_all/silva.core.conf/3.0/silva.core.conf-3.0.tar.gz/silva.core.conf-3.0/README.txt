===============
silva.core.conf
===============

Introduction
============

``silva.core.conf`` is an extension which let you configure and
register Silva contents and extensions using `Grok`_ technologies. For
documentation, please refer to the `Silva developer documentation`_.

.. _Grok: http://grok.zope.org/
.. _Silva developer documentation: http://docs.infrae.com/silva/

Code repository
===============

The code for this extension can be found in Mercurial at:
https://hg.infrae.com/silva.core.conf


