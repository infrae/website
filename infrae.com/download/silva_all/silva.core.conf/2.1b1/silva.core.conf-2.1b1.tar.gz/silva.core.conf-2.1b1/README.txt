silva.core.conf
===============

``silva.core.conf`` is an extension which let you configure and register
Silva components using ZCML.

