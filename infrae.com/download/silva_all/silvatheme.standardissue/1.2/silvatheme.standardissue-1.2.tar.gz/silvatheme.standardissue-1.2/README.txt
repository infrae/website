========================
silvatheme.standardissue
========================

Standard Issue is a visual design (theme) for Silva 2.2 and higher.

