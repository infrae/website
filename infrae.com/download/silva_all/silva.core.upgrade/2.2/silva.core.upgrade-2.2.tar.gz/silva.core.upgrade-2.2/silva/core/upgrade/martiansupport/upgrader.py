# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: upgrader.py 38855 2010-01-05 15:40:05Z sylvain $

from silva.core.upgrade.upgrade import registry
from silva.core.upgrade.upgrade import BaseUpgrader

import martian


class UpgradeGrokker(martian.InstanceGrokker):
    """This lookup Upgrade instance and register them.
    """

    martian.component(BaseUpgrader)
    martian.priority(200)

    def grok(self, name, instance, module_info, config, **kw):
        registry.registerUpgrader(instance)
        return True
