silva.core.upgrade
==================

``silva.core.upgrade`` contains code which helps you to upgrade your
Silva setup between different versions.



