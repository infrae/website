# -*- coding: utf-8 -*-
# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 31217 2008-10-03 11:09:19Z sylvain $

