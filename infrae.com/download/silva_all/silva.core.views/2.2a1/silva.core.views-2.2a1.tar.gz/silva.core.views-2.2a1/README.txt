silva.core.views
================

``silva.core.views`` let users defines Zope 3 view elements in Silva:
Views, ViewletManager, Viewlet, Forms. It uses ``silva.core.conf`` for
an easy configuration.

You can either use Formlib forms, or Z3C Forms.




