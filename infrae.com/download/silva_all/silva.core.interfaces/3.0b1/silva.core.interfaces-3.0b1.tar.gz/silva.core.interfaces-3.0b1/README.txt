=====================
silva.core.interfaces
=====================

``silva.core.interfaces`` defines interfaces describing default Silva
API, theirs contents and functionalities.


