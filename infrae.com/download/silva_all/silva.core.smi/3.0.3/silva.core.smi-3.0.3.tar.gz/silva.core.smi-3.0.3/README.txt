==============
silva.core.smi
==============

Introduction
============

``silva.core.smi`` is a core `Silva`_ 3 extension that contains the
implementations of the different SMI screens, the Silva Management
Interface. It is built using ``silva.ui``.

For more information on how to extend the SMI, please check the `Silva
developer documentation`_.

Code repository
===============

This code can be found in Git at:
https://github.com/silvacms/silva.core.smi

.. _Silva developer documentation: http://docs.silvacms.org/latest/
.. _Silva: http://silvacms.org
