==============
silva.core.smi
==============

Introduction
============

``silva.core.smi`` contains the different SMI screens, the Silva
Management Interface. It is built using ``silva.ui``.

For more information on how to extend the SMI, please check the `Silva
developer documentation`_.

Code repository
===============

This code can be found in Mercurial at:
https://hg.infrae.com/silva.core.smi/.

.. _Silva developer documentation: http://docs.infrae.com/silva/
