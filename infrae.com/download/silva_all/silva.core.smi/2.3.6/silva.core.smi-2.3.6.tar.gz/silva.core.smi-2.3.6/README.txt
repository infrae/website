==============
silva.core.smi
==============

``silva.core.smi`` contains parts of the SMI, Silva Management
Interface. It is built using ``silva.core.views`` and ``silva.core.layout``.

