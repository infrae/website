===============
zeam.form.silva
===============

``zeam.form.silva`` is the integration of `Zeam Form
<http://pypi.python.org/pypi/zeam.form.base>`_ in Silva.

This packages provides forms for SMI (including default add and edit
forms for content), ZMI (service configuration forms), and public
views usage (page forms, and viewlet/content provider forms).

