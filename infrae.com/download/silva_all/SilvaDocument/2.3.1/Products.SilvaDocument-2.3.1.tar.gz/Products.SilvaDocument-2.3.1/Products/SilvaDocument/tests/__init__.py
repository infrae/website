# Copyright (c) 2003-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 32948 2009-01-12 16:27:53Z sylvain $
#
