Silva Document
==============

Silva Document is an extension to Silva allowing to create structured
documents, using the Kupu or Forms-based editor.

