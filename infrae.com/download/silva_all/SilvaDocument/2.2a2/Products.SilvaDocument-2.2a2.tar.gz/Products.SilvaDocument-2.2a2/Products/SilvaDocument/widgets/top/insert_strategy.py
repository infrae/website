## Script (Python) "insert_strategy"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=node, new
##title=
##
node.insertBefore(new, node.firstChild)
