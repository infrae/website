## Script (Python) "get_widget_path"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
return context.getPhysicalPath()[2:]
