Copyright (c) 2002-2007 Infrae. All rights reserved.
See also LICENSE.txt

Meta::
  
  Valid for:  Silva 1.6.x
  Author:     Martijn Faassen
  Email:      faassen@infrae.com
  CVS:        $Id: README.txt,v 1.12 2006/01/24 16:15:05 faassen Exp $

Silva Document

  Silva Document is an extension to Silva allowing to create
  structured documents, using the Kupu or Forms-based editor.
 
License
  
  Silva Document is released under the BSD license. See 'LICENSE.txt'.
