content = context.REQUEST.model
return content.view()
