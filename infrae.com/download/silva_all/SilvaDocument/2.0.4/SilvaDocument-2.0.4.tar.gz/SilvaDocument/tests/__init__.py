# Copyright (c) 2003-2007 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py,v 1.5 2006/01/24 16:15:05 faassen Exp $
#
