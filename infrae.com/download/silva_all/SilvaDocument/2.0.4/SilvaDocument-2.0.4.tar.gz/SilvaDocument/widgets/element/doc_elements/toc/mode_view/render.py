return context.content(append_to_url=None, public=1)
