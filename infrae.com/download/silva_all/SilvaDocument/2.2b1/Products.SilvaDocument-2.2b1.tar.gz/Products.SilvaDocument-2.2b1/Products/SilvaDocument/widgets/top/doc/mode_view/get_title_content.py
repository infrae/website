return context.REQUEST.node.get_version().get_title()
