## Script (Python) "done_mode"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
context.done_mode_helper()
return context.redirect()
