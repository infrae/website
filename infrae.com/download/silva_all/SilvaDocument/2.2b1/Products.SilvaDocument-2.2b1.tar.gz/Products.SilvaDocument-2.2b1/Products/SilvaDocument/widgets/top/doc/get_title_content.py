return context.REQUEST.node.get_content().get_title_editable()
