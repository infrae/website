# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: indexable.py 37394 2009-10-22 13:57:01Z sylvain $

from grokcore import component

from Products.SilvaDocument.interfaces import IDocument, IDocumentVersion
from Products.Silva.adapters.indexable import IndexableAdapter
from silva.core.interfaces.adapters import IIndexable


class DocumentIndexableAdapter(IndexableAdapter):

    component.context(IDocument)

    def getIndexes(self):
        version = self.context.get_viewable()
        if version:
            return IIndexable(version).getIndexes()
        return []


class DocumentVersionIndexableAdapter(IndexableAdapter):

    component.context(IDocumentVersion)

    def getIndexes(self):
        indexes = []
        docElement = self.context.content.firstChild
        nodes = docElement.getElementsByTagName('index')
        for node in nodes:
            indexTitle = node.getAttribute('title')
            if indexTitle:
                indexName = node.getAttribute('name')
                indexes.append((indexName, indexTitle))
        return indexes
