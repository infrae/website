from persistent import Persistent

from zope import component
from zope.interface import implements

from zope.app.component.hooks import getSiteManager
from zope.app.container.contained import Contained

from ldapadapter.interfaces import ILDAPAdapter

from documentlibrary.ldapauth.interfaces import ILDAP

class ProxyProperty(object):
    def __init__(self, name):
        self._name = name

    def _getProxied(self):
        raise NotImplementedError
    
    def __get__(self, inst, klass):
        return getattr(self._getProxied(), self._name)

    def __set__(self, inst, value):
        setattr(self._getProxied(), self._name, value)

class LDAPAdapterProperty(ProxyProperty):
    def _getProxied(self):
        return component.getUtility(ILDAPAdapter, name='ldapadapter')
    
class LDAPPasProperty(ProxyProperty):
    def _getProxied(self):
        mgr = getSiteManager()
        default = mgr['default']
        pau = default['PluggableAuthentication']
        return pau['LDAPAuthenticator']

class LDAPUtility(Persistent, Contained):
    implements(ILDAP)

    def __init__(self):
        self.groupsAttribute = ''
        self.membersAttribute = ''
        self.emailAttribute = ''
    
    host = LDAPAdapterProperty('host')
    port = LDAPAdapterProperty('port')
    useSSL = LDAPAdapterProperty('useSSL')
    bindDN = LDAPAdapterProperty('bindDN')
    bindPassword = LDAPAdapterProperty('bindPassword')

    searchBase = LDAPPasProperty('searchBase')
    searchScope = LDAPPasProperty('searchScope')
    groupsSearchBase = LDAPPasProperty('groupsSearchBase')
    groupsSearchScope = LDAPPasProperty('groupsSearchScope')
    
    loginAttribute = LDAPPasProperty('loginAttribute')
    principalIdPrefix = LDAPPasProperty('principalIdPrefix')
    idAttribute = LDAPPasProperty('idAttribute')
    titleAttribute = LDAPPasProperty('titleAttribute')
    groupIdAttribute = LDAPPasProperty('groupIdAttribute')
