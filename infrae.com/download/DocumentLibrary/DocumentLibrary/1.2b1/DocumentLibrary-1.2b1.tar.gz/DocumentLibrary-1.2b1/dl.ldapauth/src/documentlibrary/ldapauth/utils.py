from zope import component
from documentlibrary.ldapauth import interfaces
from ldapadapter.interfaces import ILDAPAdapter

def get_ldap_conn():
    adapter = component.getUtility(ILDAPAdapter, 'ldapadapter')
    return adapter.connect()
    
