from zope.interface import implements

from zope.app.form.interfaces import IDisplayWidget
from zope.app.form.browser import DisplayWidget

class UsersDisplayWidget(DisplayWidget):
    implements(IDisplayWidget)

    def __call__(self):
        users = self._data
        result = '\n'.join('<li>%s</li>' % user for user in users)
        return '<ul>%s</ul>' % result
