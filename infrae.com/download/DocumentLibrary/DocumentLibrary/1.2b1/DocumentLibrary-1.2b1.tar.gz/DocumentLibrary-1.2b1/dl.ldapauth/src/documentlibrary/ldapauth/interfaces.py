import re

from zope.interface import Interface
from zope import schema
from ldapadapter.interfaces import ILDAPAdapter
from ldappas.interfaces import ILDAPAuthentication

from documentlibrary.core.interfaces import IUserFolder, IUserInfo
from documentlibrary.core.interfaces import IGroupFolder, IGroupInfo

class ILDAPUserFolder(IUserFolder):
    pass

class ILDAPUserInfo(IUserInfo):
    pass

class ILDAPGroupFolder(IGroupFolder):
    pass

class ILDAPGroupInfo(IGroupInfo):
    pass

class ILDAP(Interface):
    host = ILDAPAdapter['host']
    port = ILDAPAdapter['port']
    useSSL = ILDAPAdapter['useSSL']
    bindDN = ILDAPAdapter['bindDN']
    bindPassword = ILDAPAdapter['bindPassword']

    searchBase = ILDAPAuthentication['searchBase']
    searchScope = ILDAPAuthentication['searchScope']
    groupsSearchBase = ILDAPAuthentication['groupsSearchBase']
    groupsSearchScope = ILDAPAuthentication['groupsSearchScope']
    
    loginAttribute = ILDAPAuthentication['loginAttribute']
    idAttribute = ILDAPAuthentication['idAttribute']
    titleAttribute = ILDAPAuthentication['titleAttribute']
    groupIdAttribute = ILDAPAuthentication['groupIdAttribute']
    
    groupsAttribute = schema.TextLine(
        title=(u"Groups listing attribute"),
        description=(u"Groups listing attribute on the user"),
        required=True,
        )
    
    membersAttribute = schema.TextLine(
        title=(u"Members listing attribute"),
        description=(u"Members listing attribute on the group"),
        required=True,
        )

    emailAttribute = schema.TextLine(
        title=(u"E-Mail attribute"),
        description=_(
            u"The LDAP attribute used to determine a principal's e-mail."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'mail',
        required=True,
        )

class IUserGroupsFilter(Interface):
    def __call__(ldap_groups):
        """Given a list of groups retrieved from LDAP, this will
        return a list of actual groupnames.
        """

class IGroupMembersFilter(Interface):
    def __call__(ldap_users):
        """Given a list of users retrieved from LDAP, this will
        return a list of actual usernames.
        """
