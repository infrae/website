# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

import os.path, glob

# Zope 3
from zope.interface import implements

from zope.app import zapi

from zope.app.component.interfaces import ISite
from zope.app.component.site import LocalSiteManager
from zope.app.component.hooks import setSite, getSite
from zope.app.authentication.authentication import PluggableAuthentication

from zope.app.catalog.interfaces import ICatalog
from zope.app.catalog.catalog import Catalog
from zope.app.catalog.field import FieldIndex

from zope.app.intid.interfaces import IIntIds
from zope.app.intid import IntIds

from zope.app.container.interfaces import INameChooser

from zope.app.folder import Folder
from zope.app.authentication.interfaces import IAuthenticatorPlugin
from zope.app.security.interfaces import IAuthentication
from zope.sendmail.interfaces import ISMTPMailer, IQueuedMailDelivery

from zc.catalog.catalogindex import SetIndex
from hurry.workflow.interfaces import IWorkflowState, IWorkflowInfo
from hurry.workflow import workflow
from hurry.workflow.interfaces import IWorkflowVersions, IWorkflow
from hurry.file.interfaces import IFileRetrieval

from documentlibrary.core import configuration

# documentlibrary
from documentlibrary.core.authentication import\
     DocumentLibraryAuthenticator
from documentlibrary.core import flow, handle, email, interfaces, user
from documentlibrary.core.category import CategoryTree, CategoriesUtility
from documentlibrary.core.foitopic import FOITopicTree, FOITopicsUtility
from documentlibrary.core.foitopic import setupTopics
from documentlibrary.core.history import HistoryFolder

class DocumentLibrary(Folder):

    implements(interfaces.IDocumentLibrary)

    def __init__(self):
        super(DocumentLibrary, self).__init__()
        self['categories'] = CategoryTree()
        self['foi_topics'] = FOITopicTree()
        self['templates'] = Folder()
        self['history'] = HistoryFolder()
        self['users'] = user.UserFolder()
        self['groups'] = user.GroupFolder()
        self['handle'] = handle.Root()
        
def setupDocumentLibrary(documentlibrary):
    sitemanager = LocalSiteManager(documentlibrary)
    documentlibrary.setSiteManager(sitemanager)

    setSite(documentlibrary)
    default = zapi.traverse(documentlibrary, '++etc++site/default')

    # create pluggable authentication and principal folder
    _registerAuthentication(default)
    
    # set up catalog facilities
    _registerUtility(default, IntIds, IIntIds)
    _registerUtility(default, Catalog, ICatalog, u'document_catalog')
    _registerUtility(default, Catalog, ICatalog, u'history_catalog')
    _registerUtility(default, Catalog, ICatalog, u'user_catalog')
    _registerDocumentIndices(documentlibrary)
    _registerHistoryIndices(documentlibrary)
    _registerUserIndices(documentlibrary)
    
    # set up categories and foi topics
    
    categories_utility = _registerUtility(
        default, CategoriesUtility, interfaces.IHierarchicalTermsUtility,
        'categories')
    
    # XXX: demo content creation
    from testcontent import createTestCategories
    createTestCategories(documentlibrary)
        
    foi_topics_utility = _registerUtility(
        default, FOITopicsUtility, interfaces.IHierarchicalTermsUtility,
        'foi_topics')

    setupTopics(documentlibrary)

    # history and email action templates
    _registerTemplates(documentlibrary)

    # register configuration
    _registerConfiguration(default)
    
    # set up emailing facility
    _registerEmail(default)
    
    # workflow
    _registerWorkflow(default)

def _registerUtility(context, class_, interface, name=u''):
    if not name:
        cname = class_.__name__
    else:
        cname = name
    if name and name in context:
        raise ValueError, u'Utility %s already registered!' % name
    utility = class_()
    context[cname] = utility
    getSite().getSiteManager().registerUtility(
        utility, interface, name)
    return utility

def _registerAuthentication(default):
    pau = _registerUtility(default, PluggableAuthentication,
                           IAuthentication)
    pf = DocumentLibraryAuthenticator()
    pau['DocumentLibraryAuthenticator'] = pf
    # do *NOT* set prefix in PAU
    pf.prefix = u'documentlibrary'
    # and set plugins
    pau.credentialsPlugins = ['No Challenge if Authenticated',
                              'Zope Realm Basic-Auth']
    pau.authenticatorPlugins = [pf.__name__]
    
def _registerDocumentIndices(documentlibrary):
    from interfaces import IDocument
    catalog = zapi.getUtility(ICatalog, u'document_catalog')
    catalog['state'] = FieldIndex('state', IDocument)
    catalog['last_changed'] = FieldIndex('last_changed', IDocument)
    catalog['category'] = FieldIndex('category', IDocument)
    catalog['owner'] = FieldIndex('owner', IDocument)
    catalog['name'] = FieldIndex('__name__', IDocument)
    catalog['emails'] = SetIndex('authorEmails', IDocument, True)
    catalog['deletion_requested'] = FieldIndex('deletion_requested', IDocument)
    catalog['access'] = SetIndex('access', IDocument)
    
    catalog['workflow_state'] = FieldIndex('getState', IWorkflowState, True)
    catalog['workflow_id'] = FieldIndex('getId', IWorkflowState, True)
    catalog['workflow_auto'] = FieldIndex('hasAutomaticTransitions',
                                          IWorkflowInfo, True)

def _registerHistoryIndices(documentlibrary):
    from interfaces import IDocument, IHistoryEntry
    catalog = zapi.getUtility(ICatalog, u'history_catalog')
    catalog['docid'] = FieldIndex('docid', IHistoryEntry)
    catalog['action'] = FieldIndex('action', IHistoryEntry)
    catalog['change_time'] = FieldIndex('change_time', IHistoryEntry)
    catalog['actor'] = FieldIndex('actor', IHistoryEntry)

def _registerUserIndices(documentlibrary):
    from interfaces import IUserInfo
    catalog = zapi.getUtility(ICatalog, u'user_catalog')
    catalog['login'] = FieldIndex('login', IUserInfo)
    catalog['email'] = FieldIndex('email', IUserInfo)
    catalog['groups'] = SetIndex('groups', IUserInfo)
    catalog['role'] = FieldIndex('role', IUserInfo)

def _registerTemplates(documentlibrary):
    from zope.app.dtmlpage.dtmlpage import DTMLPage

    templates = documentlibrary['templates']

    # read all initial templates in templates directory
    templates_dir = os.path.join(_getModuleDir(), 'templates')

    for entry in glob.glob(os.path.join(templates_dir, '*.txt')):
        dummy, filename = os.path.split(entry)
        name, dummy = os.path.splitext(filename)
        f = open(entry, 'rb')
        data = unicode(f.read(), 'UTF-8')
        f.close()
        template = DTMLPage()
        template.setSource(data, 'text/plain')
        templates[name] = template

def _registerEmail(default):
    _registerUtility(default, email.PersistentSMTPMailer, ISMTPMailer)
    _registerUtility(default, email.PersistentQueuedMailDelivery,
                     IQueuedMailDelivery)

def _registerConfiguration(default):
    _registerUtility(default, configuration.Timezone, interfaces.ITimezone)
    _registerUtility(default, configuration.FilenameValidation,
                     interfaces.IFilenameValidation)
    _registerUtility(default, configuration.CustomText,
                     interfaces.ICustomText)
    _registerUtility(default, configuration.MaximumRetentionPeriod,
                     interfaces.IMaximumRetentionPeriod)
    _registerUtility(default, configuration.Tramline,
                     IFileRetrieval)
    
def workflowUtilityFactory():
    return workflow.Workflow(flow.createWorkflow())

def _registerWorkflow(default):
    _registerUtility(default, workflowUtilityFactory, IWorkflow)
    _registerUtility(default, flow.WorkflowVersions, IWorkflowVersions)
                     
def documentLibraryAddedHandler(event):
    if interfaces.IDocumentLibrary.providedBy(event.object):
        setupDocumentLibrary(event.object)

def _getModuleDir():
    P = os.path
    d = P.dirname(__file__)
    d = P.normpath(P.abspath(d))
    return d
