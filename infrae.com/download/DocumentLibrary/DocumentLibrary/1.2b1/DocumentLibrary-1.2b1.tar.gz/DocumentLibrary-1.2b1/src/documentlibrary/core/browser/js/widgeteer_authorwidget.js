widgeteer.AuthorWidget = function() {
    /* A widget that displays a simple matrix-like widget to manage author data

        author data always consists of first name, last name and email adress
    */
};

widgeteer.AuthorWidget.prototype = new widgeteer.Widget;

widgeteer.AuthorWidget.prototype.initialize = function(textarea) {
    textarea.style.display = 'none';
    
    var table = this.table = document.createElement('table');
    table.className = 'authorstable';

    var tbody = document.createElement('tbody');
    table.appendChild(tbody);

    // create the row with the column names
    var headrow = document.createElement('tr');
    var th = document.createElement('td');
    th.appendChild(document.createTextNode('first name'));
    var span = document.createElement('span');
    th.appendChild(span);
    span.appendChild(document.createTextNode('*'));
    span.className = 'required'
    headrow.appendChild(th);
    th = document.createElement('td');
    th.appendChild(document.createTextNode('last name'));
    var span = document.createElement('span');
    th.appendChild(span);
    span.appendChild(document.createTextNode('*'));
    span.className = 'required'
    headrow.appendChild(th);
    th = document.createElement('td');
    th.appendChild(document.createTextNode('email address'));
    var span = document.createElement('span');
    th.appendChild(span);
    span.appendChild(document.createTextNode('*'));
    span.className = 'required'
    headrow.appendChild(th);
    // empty cell for plus and minus signs
    th = document.createElement('td');
    th.className = 'plusminus'
    th.appendChild(document.createTextNode('\xa0'));
    headrow.appendChild(th);
    tbody.appendChild(headrow);

    // now create the rows with authors
    var value = textarea.value;
    var lines = value.split('\n');
    var lines_clean = [];
    for (var i=0; i < lines.length; i++) {
        if (lines[i]) {
            lines_clean.push(lines[i]);
        };
    };
    if (lines_clean.length == 0) {
        // XXX nasty! nice! ;)
        lines_clean.push('||||');
    };
    for (var i=0; i < lines_clean.length; i++) {
        var chunks = lines_clean[i].split('||');
        var row = document.createElement('tr');
        for (var j=0; j < chunks.length; j++) {
            var td = document.createElement('td');
            var input = document.createElement('input');
            td.appendChild(input);
            input.value = chunks[j];
            row.appendChild(td);
        };
        var pmtd = document.createElement('td');
        pmtd.appendChild(document.createTextNode('\xa0'));
        row.appendChild(pmtd);
        tbody.appendChild(row);
    };
    textarea.parentNode.insertBefore(table, textarea);
    this._managePlusMinusImages();
};

widgeteer.AuthorWidget.prototype.value = function() {
    var values = [];
    var rows = this.table.getElementsByTagName('tr');
    // skip the first, it's the one with the table headers
    for (var i=1; i < rows.length; i++) {
        var tds = rows[i].getElementsByTagName('td');
        var rowvalues = [];
        // skip the last, it contains the plus and minus signs
        for (var j=0; j < tds.length - 1; j++) {
            rowvalues.push(tds[j].childNodes[0].value);
        };
        values.push(rowvalues.join('||'));
    };
    ret = values.join('\n');
    return ret;
};

widgeteer.AuthorWidget.prototype.addRow = function(event, row) {
    var newtr = document.createElement('tr');
    for (var i=0; i < 3; i++) {
        var td = document.createElement('td');
        var input = document.createElement('input');
        td.appendChild(input);
        newtr.appendChild(td);
    };
    var pmtd = document.createElement('td');
    pmtd.appendChild(document.createTextNode('\xa0'));
    newtr.appendChild(pmtd);
    row.parentNode.appendChild(newtr);
    this._managePlusMinusImages();
};

widgeteer.AuthorWidget.prototype.delRow = function(event, row) {
    row.parentNode.removeChild(row);
    this._managePlusMinusImages();
};

widgeteer.AuthorWidget.prototype._managePlusMinusImages = function() {
    var rows = this.table.getElementsByTagName('tr');
    for (var i=1; i < rows.length; i++) {
        // delete the images
        var row = rows[i];
        var tds = row.getElementsByTagName('td');
        var lasttd = tds[tds.length - 1];
        // remove the current images (not very elegant, but nice 
        // and understandable)
        while (lasttd.hasChildNodes()) {
            lasttd.removeChild(lasttd.childNodes[0]);
        };
        if (i != 1 || rows.length > 2) {
            // make minus image appear
            var mimg = document.createElement('img');
            mimg.src = '++resource++images/minussymbol.gif';
            addEventHandler(mimg, 'click', this.delRow, this, row);
            lasttd.appendChild(mimg);
        };
        if (i == rows.length - 1) {
            // make plus image appear
            var pimg = document.createElement('img');
            pimg.src = '++resource++images/plussymbol.gif';
            addEventHandler(pimg, 'click', this.addRow, this, row);
            lasttd.appendChild(pimg);
        };
    };
};

widgeteer.widget_registry.register('authors', widgeteer.AuthorWidget);
