
"""This module contains routines that create some reasonable content
for presentations and testing.
"""

from sets import Set

from zope.app import zapi
from zope.app.container.interfaces import INameChooser

from category import Category
import interfaces

_categories = [
    ( u"Announcements", [
     (u"Personel",
       [(u"Management", []),
        (u"Staff", [])]),
     (u"Development", []) ],
      ),
    ( u"Support",[
     (u"Systems",
      [(u"NetAdminThing", []),
       (u"GlobalUserWatch", [])]),
     (u"Web-Services", [])],
      ),
    ]

def createTestCategories(documentlibrary):
    def create_cats(parent, node):
        title, subs = node
        # create category in parent
        # XXX
        cat = Category(title, 0, Set(), Set())
        name = INameChooser(parent).chooseName(title, cat)
        parent[name] = cat
        # create sub categories
        for sub in subs:
            create_cats(cat, sub)
        return
    util = zapi.getUtility(
        interfaces.IHierarchicalTermsUtility, name='categories', 
        context=documentlibrary)
    tree = util.getTop()
    for cat in _categories:
        create_cats(tree, cat)
