from zope.publisher.browser import applySkin
from zope.publisher.interfaces.browser import ILayer, IDefaultBrowserLayer
from zope.publisher.interfaces.browser import IBrowserRequest

from zope.app.rotterdam import rotterdam as RotterdamLayer

from documentlibrary.core import interfaces

class IDocumentLibraryLayer(ILayer, IBrowserRequest):
    pass

class IDocumentLibraryLocalLayer(ILayer, IBrowserRequest):
    pass

class IDocumentLibrarySkin(
    IDocumentLibraryLocalLayer,
    IDocumentLibraryLayer, 
    RotterdamLayer, 
    IDefaultBrowserLayer):
    pass

def documentLibraryTraverseSubscriber(event):
    """A subscriber to BeforeTraverseEvent.
    """
    if (interfaces.IDocumentLibrary.providedBy(event.object) and
        IBrowserRequest.providedBy(event.request)):
        applySkin(event.request, IDocumentLibrarySkin)
