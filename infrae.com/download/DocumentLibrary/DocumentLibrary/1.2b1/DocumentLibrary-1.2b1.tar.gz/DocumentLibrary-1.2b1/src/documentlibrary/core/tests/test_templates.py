# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt
# unittests
import unittest
# Zope3
from zope.app.testing.placelesssetup import PlacelessSetup

from documentlibrary.core.template import renderTemplate
        
class TemplateRendererTestCase(PlacelessSetup, unittest.TestCase):

    def setUp(self):
        PlacelessSetup.setUp(self)

    def test_renderer(self):
        self.assertEquals(
            'alphaBetagammaDeltaepsilon',
            renderTemplate('alpha${b}gamma${d/sub}epsilon',
                           b='Beta',
                           d={'sub': 'Delta'}))

    def test_renderer(self):
        self.assertEquals(
            'alpha:Beta',
            renderTemplate('alpha:${b}',
                           b='Beta'))
        
def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TemplateRendererTestCase))
    return suite

if __name__ == '__main__':
    unittest.main()
