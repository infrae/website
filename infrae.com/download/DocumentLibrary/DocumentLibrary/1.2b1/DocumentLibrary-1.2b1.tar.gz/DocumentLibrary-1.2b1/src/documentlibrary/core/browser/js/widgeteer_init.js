function addEventHandler(element, event, handler, context) {
    /* Method to add an event handler in both IE and Mozilla style
    
        Arguments:
        
            * element - the object to register the event on
            
            * event - a string describing the event (Mozilla style, so 
                without the 'on')
            
            * handler - a reference to the function to be called when 
                the event occurs

            * context - the 'this' variable inside the function

        The arguments passed to the handler:

            * event - a reference to the event fired

            * all arguments passed in to this function besides the ones
                described
                
    */
    var args = new Array();
    for (var i=4; i < arguments.length; i++) {
        args.push(arguments[i]);
    };
    var wrapper = function(event) {
        args.unshift(event);
        handler.apply(context, args)
    };
    if (element.addEventListener) {
        element.addEventListener(event, wrapper, false);
    } else if (element.attachEvent) {
        element.attachEvent("on" + event, wrapper);
    } else {
        throw("Unsupported browser or element doesn't support events");
    };
    // return the wrapper so the event can be unregistered later on
    return wrapper;
};

function submitForm(event) {
    var is_valid = widgeteer.formSubmitHandler(this);
    if (!is_valid) {
        if (event.stopPropagation) {
            event.stopPropagation();
        } else {
            event.returnValue = false;
        };
        return false;
    };
    return true;
};

function init_widgeteer_and_forms() {
    window.widgeteer.initialize();
    var forms = document.getElementsByTagName('form');
    for (var i=0; i < forms.length; i++) {
        var form = forms[i];
        addEventHandler(form, 'submit', submitForm, form);
    };
};

addEventHandler(window, 'load', init_widgeteer_and_forms);
