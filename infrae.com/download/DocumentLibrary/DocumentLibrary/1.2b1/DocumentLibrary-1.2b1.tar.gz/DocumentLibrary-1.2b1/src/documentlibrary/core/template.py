from zope.tales.tales import ExpressionEngine
from zope.tales.expressions import StringExpr, PathExpr

class Data(object):
    def __init__(self, **kw):
        self.vars = kw

def Engine():
    e = ExpressionEngine()
    e.registerType('standard', StringExpr)
    e.registerType('path', PathExpr)
    return e

engine = Engine()

def renderTemplate(text, **kw):
    # XXX awful hack to let it accept ':', which is otherwise recognized
    # as a tales prefix..
    text = text.replace(':', '@@@')
    result = engine.compile(text)(Data(**kw))
    return result.replace('@@@', ':')
