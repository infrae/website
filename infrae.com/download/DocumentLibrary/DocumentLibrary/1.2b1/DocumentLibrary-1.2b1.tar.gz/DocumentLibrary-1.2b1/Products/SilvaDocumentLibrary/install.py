# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt

from Products.FileSystemSite.DirectoryView import manage_addDirectoryView
from Products.Silva.install import add_fss_directory_view

from documentlisting import DocumentListing
from documentsearch import DocumentSearch
from cherrypicking import DocumentCherry

types = [
    DocumentListing.meta_type, 
    DocumentSearch.meta_type, 
    ]

def install(root):
    add_fss_directory_view(
        root.service_views, 'DocumentLibrary', __file__, 'views')
    registerViews(root.service_view_registry)
    configureSecurity(root)
    configureMetadata(root)
    configureAddables(root)
    configureLayout(root)

def uninstall(root):
    unregisterViews(root.service_view_registry)
    root.service_views.manage_delObjects(['DocumentLibrary'])
    
def is_installed(root):
    return hasattr(root.service_views, 'DocumentLibrary')

def registerViews(reg):
    type = DocumentListing.meta_type
    reg.register('add', type, ['add', 'DocumentListing'])
    reg.register('edit', type, ['edit', 'Asset', 'DocumentListing'])
    reg.register('public', type, ['public', 'DocumentListing', 'view'])
    reg.register('preview', type, ['public', 'DocumentListing', 'preview'])
    
    type = DocumentSearch.meta_type
    reg.register('add', type, ['add', 'DocumentListing']) # reuse add view
    reg.register('edit', type, ['edit', 'Asset', 'DocumentListing']) # reuse edit view
    reg.register('public', type, ['public', 'DocumentSearch', 'view'])
    reg.register('preview', type, ['public', 'DocumentSearch', 'preview'])

    # The DocumentCherry is not an object that is meant to be editable
    # within the SMI. It however, is a SilvaObject derivative, to be able
    # to register and reuse views. We reuse the (pre)view registrations
    # for the Listing object - we only need to get to the records.zpt anyway.
    type = DocumentCherry.meta_type
    reg.register('public', type, ['public', 'DocumentListing', 'view'])
    reg.register('preview', type, ['public', 'DocumentListing', 'preview'])
    
def unregisterViews(reg):
    for type in types:
        reg.unregister('add', type)    
        reg.unregister('edit', type)
        reg.unregister('public', type)
        reg.unregister('preview', type)
    type = DocumentCherry.meta_type
    reg.unregister('public', type)
    reg.unregister('preview', type)
    
def configureSecurity(root):
    # cut & paste from Products.Silva.install.configureSecurity
    all_author = ['Author', 'Editor', 'ChiefEditor', 'Manager']
    for type in types:
        root.manage_permission('Add %ss' % type, all_author)    
    
def configureMetadata(root):
    for type in types:
        setids = ['silva-content, silva-extra']
        root.service_metadata.addTypeMapping(type, setids, default='')
    
def configureAddables(root):
    addables = types
    new_addables = root.get_silva_addables_allowed_in_publication()
    for addable in addables:
        if addable not in new_addables:
            new_addables.append(addable)
    root.set_silva_addables_allowed_in_publication(new_addables)
    
def configureLayout(root, default_if_existent=0):
    from Products.Silva import install
    for id in ['dl_oai.js', 'dl_oai.css']:
        install.add_helper(
            root, id, globals(), install.dtml_add_helper, 1)
    