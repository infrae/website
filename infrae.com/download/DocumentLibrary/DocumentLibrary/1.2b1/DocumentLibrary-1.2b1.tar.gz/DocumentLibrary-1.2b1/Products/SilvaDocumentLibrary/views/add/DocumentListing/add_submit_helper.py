##parameters=model, id, title, result

service_path = result.get('oai_service')
service = context.restrictedTraverse(service_path)

if result['object_type'] == 'Document Library Search':
    factory = model.manage_addProduct[
        'SilvaDocumentLibrary'].manage_addDocumentSearch
else:
    factory = model.manage_addProduct[
        'SilvaDocumentLibrary'].manage_addDocumentListing
    
factory(id, title, service)
    
return getattr(model, id)
