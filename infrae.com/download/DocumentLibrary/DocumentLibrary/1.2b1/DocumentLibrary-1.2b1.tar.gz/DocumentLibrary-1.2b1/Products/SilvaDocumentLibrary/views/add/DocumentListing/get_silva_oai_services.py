# XXX Copied from SilvaOAI - needs refactoring!
service_ids = []
for parent in context.REQUEST.PARENTS:
    objects = parent.objectValues(['OAIPMH Service'])
    for object in objects:
        service_ids.append((object.id, '/'.join(object.getPhysicalPath())))
return service_ids
