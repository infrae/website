model = context.REQUEST.model
service = model.getService()
toplevel_sets = service.getSubSets(None)

#XXX import from helpers
def sorted_keys_by_value(dict):
    result = [(value, key) for key, value in dict.items()]
    result.sort()
    result = [key for value, key in result]
    return result

result = [('All sets', 'none')]
for key in sorted_keys_by_value(toplevel_sets):
    result.append((toplevel_sets[key], key))
    sets = service.getSubSets(key)
    for subkey in sorted_keys_by_value(sets):
        result.append(('... %s' % sets[subkey], subkey))

return result
