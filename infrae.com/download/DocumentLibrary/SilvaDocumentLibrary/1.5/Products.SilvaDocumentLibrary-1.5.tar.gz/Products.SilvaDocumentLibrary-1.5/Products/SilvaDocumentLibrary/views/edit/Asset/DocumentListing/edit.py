model = context.REQUEST.model

if model.getMetadataFormat() is not None:
    return context.query_edit()
return context.format_edit()
    
