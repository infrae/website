from zope import component

from zope.app.component.hooks import getSite, getSiteManager

from ldapadapter.interfaces import ILDAPAdapter
from ldapadapter.utility import ManageableLDAPAdapter

from ldappas.interfaces import ILDAPAuthentication
from documentlibrary.ldapauth.authentication import LDAPAuthentication

from documentlibrary.ldapauth.interfaces import (ILDAPUserFolder,
                                                 ILDAPGroupFolder)
from documentlibrary.ldapauth.user import (LDAPUserFolder,
                                           LDAPGroupFolder)
from documentlibrary.ldapauth.interfaces import ILDAP
from documentlibrary.ldapauth.utility import LDAPUtility

def addLDAPUtility():
    if component.queryUtility(ILDAP) is not None:
        return

    mgr = getSiteManager()
    default = mgr['default']
    
    utility = LDAPUtility()
    default['ldap'] = utility
    mgr.registerUtility(utility, ILDAP)

    return utility

def addLDAPAdapter():
    if component.queryUtility(ILDAPAdapter, name='ldapadapter') is not None:
        return
    
    mgr = getSiteManager()    
    default = mgr['default']

    adapter = ManageableLDAPAdapter()
    default['ldapadapter'] = adapter
    mgr.registerUtility(adapter, ILDAPAdapter, 'ldapadapter')

    return adapter

def addLDAPAuth():
    mgr = getSiteManager()
    default = mgr['default']

    pau = default['PluggableAuthentication']
    if 'LDAPAuthenticator' in pau:
        return

    pau['LDAPAuthenticator'] = auth = LDAPAuthentication()
    mgr.registerUtility(auth, ILDAPAuthentication, 'LDAPAuthenticator')
    
    auth.adapterName = 'ldapadapter'
    auth.principalIdPrefix = 'documentlibrary'
    auth.searchScope = 'sub'
    pau.authenticatorPlugins = [auth.__name__] 

    return auth

def replaceUserFolder():
    site = getSite()
    if ILDAPUserFolder.providedBy(site['users']):
        return
    del site['users']
    site['users'] = LDAPUserFolder()
    return site['users']

def replaceGroupFolder():
    site = getSite()
    if ILDAPGroupFolder.providedBy(site['groups']):
        return
    del site['groups']
    site['groups'] = LDAPGroupFolder()
    return site['users']
