
import ldappas.authentication
import gocept.cache.method


login_count = 0
MAX_LOGIN_COUNT = 200

class LDAPAuthentication(ldappas.authentication.LDAPAuthentication):


    @gocept.cache.method.Memoize(600)
    def _authenticateCredentials(self, login, password):
        global login_count
        if login_count > MAX_LOGIN_COUNT:
            goceptcache.clear()
            login_count = 0
        login_count += 1
        credentials = {'login': login, 'password': password}
        return super(LDAPAuthentication, self).authenticateCredentials(credentials)


    def authenticateCredentials(self, credentials):
        """See zope.app.authentication.interfaces.IAuthenticatorPlugin."""

        if not isinstance(credentials, dict):
            return None
        if not ('login' in credentials and 'password' in credentials):
            return None

        return self._authenticateCredentials(
            credentials['login'], credentials['password'])
