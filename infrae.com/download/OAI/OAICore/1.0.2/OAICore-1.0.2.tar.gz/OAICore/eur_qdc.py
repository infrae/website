from oaischema import OAISchema, OAIDateField, OAIKeywordField, \
    OAIFulltextField, OAINoIndexField, OAIMultiSortable, OAIColumn, \
    OAIItemField

# fields is a lists of definitions of the fields we want to harvest. For
# each field we create a type of OAIField[*] object with two arguments:
#
# 1. the id of the field as we want to use it in Zope/Silva. Can be pretty
#    much anything, but of course informative ids are useful.
# 2. an xpath expression that gets the data in a specific field from the xml
#    that the server spews. This is used for harvesting the actual metadata.
#    Because of this, ANY xml format can be harvested. Be sure to use the 
#    correct namespaces and to declare those namespaces on the schema below.
#
# [*]: The currently implemented OAIField types are: 
#    
#     - OAINoIndexField: This field is harvested but not indexed, so it
#       can't be searched on.
#     - OAIKeywordField: This field is indexed as a Keyword index, and
#       can be restricted and searched by one or more keywords.
#     - OAIFulltextField: This field is indexed as a ZCText index, and
#       is searched by fulltext searches.
#     - OAIDateField: This field is indexed as a Date index, and can
#       be restricted and searched by date ranges.       

fields = [
    OAIDateField(
        'date_issued',
        'eur_qdc:dc/dc:date[attribute::value="issued"]/text()'
        ),
    OAIKeywordField(
        'contributor_author',
        'eur_qdc:dc/dc:contributor[attribute::value="author"]/text()',
        ),
    OAINoIndexField(
        'date_accessioned',
        'eur_qdc:dc/dc:date[attribute::value="accessioned"]/text()',
        ),
    OAINoIndexField(
        'date_created', 
        'eur_qdc:dc/dc:date[attribute::value="created"]/text()', 
        ),
    OAIFulltextField(
        'description',
        'eur_qdc:dc/dc:description[attribute::value="null"]/text()',
        ),
    OAIFulltextField(
        'description_abstract',
        'eur_qdc:dc/dc:description[attribute::value="abstract"]/text()', 
        ),
    OAINoIndexField(
        'description_sponsorship',
        'eur_qdc:dc/dc:description[attribute::value="sponsorship"]/text()', 
        ),
    OAINoIndexField(
        'format_extent', 
        'eur_qdc:dc/dc:format[attribute::value="extent"]/text()', 
        ),
    OAINoIndexField(
        'format_mimetype', 
        'eur_qdc:dc/dc:format[attribute::value="mimetype"]/text()', 
        ),
    OAINoIndexField(
        'identifier_citation', 
        'eur_qdc:dc/dc:identifier[attribute::value="citation"]/text()', 
        ),
    OAINoIndexField(
        'identifier_isbn', 
        'eur_qdc:dc/dc:identifier[attribute::value="isbn"]/text()', 
        ),
    OAINoIndexField(
        'identifier_other', 
        'eur_qdc:dc/dc:identifier[attribute::value="other"]/text()', 
        ),
    OAINoIndexField(
        'identifier_repec', 
        'eur_qdc:dc/dc:identifier[attribute::value="repec"]/text()', 
        ),
    OAINoIndexField(
        'identifier_uri', 
        'eur_qdc:dc/dc:identifier[attribute::value="uri"]/text()', 
        ),
    OAINoIndexField(
        'identifier_webdoc',
        'eur_qdc:dc/dc:identifier[attribute::value="webdoc"]/text()', 
        ),
    OAIKeywordField(
        'language', 
        'eur_qdc:dc/dc:language[attribute::value="null"]/text()', 
        ),
    OAIKeywordField(
        'language_iso', 
        'eur_qdc:dc/dc:language[attribute::value="iso"]/text()', 
        ),
    OAINoIndexField(
        'publisher', 
        'eur_qdc:dc/dc:publisher[attribute::value="null"]/text()', 
        ),
    OAINoIndexField(
        'relation_hasversion', 
        'eur_qdc:dc/dc:relation[attribute::value="hasversion"]/text()', 
        ),
    OAIKeywordField(
        'relation_ispartofseries', 
        'eur_qdc:dc/dc:relation[attribute::value="ispartofseries"]/text()', 
        ),
    OAINoIndexField(
        'rights', 
        'eur_qdc:dc/dc:rights[attribute::value="null"]/text()', 
        ),
    OAIKeywordField(
        'keyword', 
        'eur_qdc:dc/dc:subject[attribute::value="null"]/text()', 
        ),
    OAINoIndexField(
        'subject_ebslg', 
        'eur_qdc:dc/dc:subject[attribute::value="ebslg"]/text()', 
        ),
    OAINoIndexField(
        'subject_jel', 
        'eur_qdc:dc/dc:subject[attribute::value="jel"]/text()', 
        ),
    OAINoIndexField(
        'subject_lcc', 
        'eur_qdc:dc/dc:subject[attribute::value="lcc"]/text()', 
        ),
    OAIFulltextField(
        'title', 
        'eur_qdc:dc/dc:title[attribute::value="null"]/text()', 
        ),
    OAIKeywordField(
        'type', 
        'eur_qdc:dc/dc:type[attribute::value="null"]/text()', 
        )
    ]

# multi_sortables optionally defines multifield indexes that can be used for
# sorting query results. Again an arbitrary id, followed by a list of ids
# of fields (as defined in 'fields' above) to be sorted on (in that order.)

multi_sortables = [
    OAIMultiSortable(
        'date_author_title',
        ['date_issued', 'contributor_author','title']
        ),
    OAIMultiSortable(
        'author_title_date', 
        ['contributor_author','title', 'date_issued']
        ),
    OAIMultiSortable(
        'title_author_date', 
        ['title', 'contributor_author','date_issued']
        ),
    ]

# result_columns defines the columns of the results table that the end user
# sees when running a query. The order in which the columns are defined is
# significant, as they will be displayed in the same order. The three
# arguments are:
#
# 1. Id of the field (as defined in 'fields' above)
# 2. Name of the field that will be displayed to the end user in the column
#    heading of the results table.
# 3. The field or multisortable on which to sort if the sort button of this
#    column is clicked.

result_columns = [
    OAIColumn('contributor_author','Author', 'author_title_date'),
    OAIColumn('title', 'Title', 'title_author_date'),
    OAIColumn('date_issued', 'Date', 'date_author_title')
    ]

# user_searchables is a list of fields the end user is allowed to filter or
# search on.

user_searchables = [
    'contributor_author', 'language_iso',
    'keyword', 'type', 'title', 'date_issued']

# item_fields defines what fields are to be displayed to the end user and
# how, when a specific item is viewed. The arguments:
#
# 1. Id of the field (as defined in 'fields' above)
# 2. Name of the field that will be displayed to the end user
# 3. The way the field is displayed to the end user. For now choose one
#    from:
#    
#    title: displayed as <h2> element, should really only be used once
#           and only for the first element
#    text: display as a normal paragraph.
#    list: display as an unordered list.
#    link: display as a clickacble link.
#    date: display as a (european) date.

item_fields = [
    OAIItemField('title', None, 'title'),
    OAIItemField('contributor_author', 'Author(s)', 'list'),
    OAIItemField('date_issued', 'Date', 'date'),
    OAIItemField('description', 'Description', 'text')
    ]

# fulltext_fields defines the fields that can have their contents searched
# by the fulltext search, in addition to any fulltext documents, optionally
# scraped from the server.

fulltext_fields =['description', 'description_abstract']

# the schema is defined for a specific prefix. Namespaces and the lists
# defined above are added.

eur_qdc_schema = OAISchema('eur_qdc')
eur_qdc_schema.addNamespace('eur_qdc', 'http://ubib.eur.nl/eur_qdc/1.0')
eur_qdc_schema.addNamespace('dc', 'http://ubib.eur.nl/dc/')
eur_qdc_schema.setFields(fields)
eur_qdc_schema.setMultiSortables(multi_sortables)
eur_qdc_schema.setInitialSortOn('date_author_title')
eur_qdc_schema.setInitialSortOrder('descending')
eur_qdc_schema.setResultColumns(result_columns)
eur_qdc_schema.setItemFields(item_fields)
eur_qdc_schema.setFulltextFields(fulltext_fields)
eur_qdc_schema.setUserSearchables(user_searchables)