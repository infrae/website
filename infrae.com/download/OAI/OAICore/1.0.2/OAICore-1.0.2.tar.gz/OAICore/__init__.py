import core
import unicodesplitter

def initialize(context):
    context.registerClass(
        core.OAIService,
        constructors = (
            core.manage_addOAIServiceForm,
            core.manage_addOAIService),
        icon = "www/oai_service.png"
        )
