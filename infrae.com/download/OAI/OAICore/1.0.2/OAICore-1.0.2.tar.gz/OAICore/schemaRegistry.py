from eur_qdc import eur_qdc_schema
from oai_dc import oai_dc_schema


schemaRegistry =  {
    'eur_qdc': eur_qdc_schema,
    'oai_dc': oai_dc_schema 
    }        