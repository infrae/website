#
# Skeleton ZopeTestCase
#
import os, sys

if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from Testing import ZopeTestCase

ZopeTestCase.installProduct('OAICore')
ZopeTestCase.installProduct('BTreeFolder2')
ZopeTestCase.installProduct('ZCatalog')
ZopeTestCase.installProduct('ZCTextIndex')
from Products.OAICore import oaischema
from DateTime import DateTime

class OAIServiceTest(ZopeTestCase.ZopeTestCase):

    def beforeSetUp(self):
        self.root = self._app()
        ZopeTestCase.utils.setupCoreSessions(self.root)
        self.root.manage_addProduct['OAICore'].manage_addOAIService(
            'service_oai', 'http://dspace.ubib.eur.nl/oai/', 'fakeserver')
        self._service = self.root.service_oai
        
    def test_createStorage(self):
        self._service.createStorage('oai_dc')
        self.assertEquals(self._service.getStorage('oai_dc').id, 'oai_dc')
        self.assertEquals(self._service.getMetadataFormats(),['oai_dc'])

    def test_createCatalog(self):
        self._service.createStorage('oai_dc')
        self._service.createCatalog('oai_dc')
        self.assertEquals(self._service.getCatalog(
            'oai_dc').id, 'service_oai_catalog')

    def test_Update(self):
        self._service.createStorage('eur_qdc')
        self._service.createCatalog('eur_qdc')
        self._service._registerSchema(
            'eur_qdc',
            self._service.getSchema('eur_qdc'))
        self._service.update(DateTime('2004-01-30T00:00:00Z'), DateTime('2004-01-31T00:00:00Z'))

        #service is updated
        self.assertEquals(self._service._datestamp, DateTime('2004-01-31T00:00:00Z'))
        #record 1162 is added
        record = self._service.getRecordByIdentifier('eur_qdc', 'hdl:1765/1162')
        self.assertEquals(record.metadata_title,
            [u'Pricing default swaps: empirical evidence'])
        #and it alone
        self.assertEquals(len(self._service.getCatalog('eur_qdc')), 1)

        self._service.update(DateTime('2004-02-01T00:00:00Z'), DateTime('2004-03-01T00:00:00Z'))

        #service is updated
        self.assertEquals(self._service._datestamp, DateTime('2004-03-01T00:00:00Z'))

        #record 1162 is deleted
        self.assertEquals(self._service.getRecordByIdentifier(
            'eur_qdc', 'hdl:1765/1162'), None)
        #record 904 is added
        self.assertEquals(self._service.getRecordByIdentifier(
            'eur_qdc', 'hdl:1765/904').metadata_title,
            [u'Risk managing bermudan swaptions in the libor BGM model'])
        self.assertEquals(self._service.getRecordByIdentifier(
            'eur_qdc',
            'hdl:1765/904').metadata_author_title_date,
            ([u'Pietersz, R.', u'Pelsser, A.A.J.'],
            [u'Risk managing bermudan swaptions in the libor BGM model'],[u'2003-09-19T09:55:00Z']))
        #as are 34 others
        self.assertEquals(len(self._service.getCatalog('eur_qdc')), 35)

    def test_Update_oai(self):
        self._service.createStorage('oai_dc')
        self._service.createCatalog('oai_dc')
        self._service._registerSchema(
            'oai_dc',
            self._service.getSchema('oai_dc'))

        self._service.update(DateTime('2004-02-01T00:00:00Z'), DateTime('2004-03-01T00:00:00Z'))

        #service is updated
        self.assertEquals(self._service._datestamp, DateTime('2004-03-01T00:00:00Z'))

        #record 1162 is deleted
        self.assertEquals(self._service.getRecordByIdentifier(
            'oai_dc', 'hdl:1765/1162'), None)
        #record 904 is added
        self.assertEquals(self._service.getRecordByIdentifier(
             'oai_dc', 'hdl:1765/904').metadata_title,
             [u'Risk managing bermudan swaptions in the libor BGM model'])
        self.assertEquals(self._service.getRecordByIdentifier(
            'oai_dc',
            'hdl:1765/904').metadata_creator,
            ([u'Pietersz, R.', u'Pelsser, A.A.J.']))
        #as are 34 others
        self.assertEquals(len(self._service.getCatalog('oai_dc')), 35)

#     def test_OAIDateField(self):
#         self._service.createStorage('eur_qdc')
#         self._service.createCatalog('eur_qdc')
#         self._service._registerSchema(
#             'eur_qdc',
#             self._service.getSchema('eur_qdc'))
#         fields = self._service.getSchema(
#             'eur_qdc').getFields()
#         for field in fields:
            
            
if __name__ == '__main__':
    framework()
else:
    from unittest import TestSuite, makeSuite
    def test_suite():
        suite = TestSuite()
        suite.addTest(makeSuite(OAIServiceTest))
        return suite