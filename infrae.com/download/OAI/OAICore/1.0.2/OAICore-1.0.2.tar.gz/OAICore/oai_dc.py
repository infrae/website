from oaischema import OAISchema, OAIDateField, OAIKeywordField, \
    OAIFulltextField, OAINoIndexField, OAIMultiSortable, OAIColumn, \
    OAIItemField

fields = [
        OAIFulltextField('title', 'oai_dc:dc/dc:title/text()'),
        OAIKeywordField('creator', 'oai_dc:dc/dc:creator/text()'),
        OAIFulltextField('subject', 'oai_dc:dc/dc:subject/text()'),
        OAINoIndexField('description', 'oai_dc:dc/dc:description/text()'),
        OAINoIndexField('publisher', 'oai_dc:dc/dc:publisher/text()'),
        OAIKeywordField('contributor', 'oai_dc:dc/dc:contributor/text()'),
        OAIDateField('date', 'oai_dc:dc/dc:date/text()'),
        OAINoIndexField('type', 'oai_dc:dc/dc:type/text()'),
        OAINoIndexField('format', 'oai_dc:dc/dc:format/text()'),
        OAINoIndexField('identifier', 'oai_dc:dc/dc:identifier/text()'),
        OAINoIndexField('source', 'oai_dc:dc/dc:source/text()'),
        OAIKeywordField('language', 'oai_dc:dc/dc:language/text()'),
        OAINoIndexField('relation', 'oai_dc:dc/dc:relation/text()'),
        OAINoIndexField('coverage', 'oai_dc:dc/dc:coverage/text()'),
        OAINoIndexField('rights', 'oai_dc:dc/dc:rights/text()')
        ]

user_searchables = ['title', 'creator', 'subject']

multi_sortables = [
    OAIMultiSortable('creator_title_date', ['creator','title', 'date']),
    OAIMultiSortable('title_creator_date', ['title', 'creator','date']),
    OAIMultiSortable('date_creator_title', ['date', 'creator','title']),
    ]

result_columns = [
    OAIColumn('title', 'Title', 'title_creator_date'),
    OAIColumn('creator', 'Author', 'creator_title_date'),
    OAIColumn('date', 'Date', 'date_creator_title')
    ]

item_fields = [
    OAIItemField('title', None, 'title'),
    OAIItemField('creator', 'Author(s)', 'list'),
    OAIItemField('date', 'Date', 'date'),
    OAIItemField('description', 'Description', 'text')
    ]

oai_dc_schema = OAISchema('oai_dc')
oai_dc_schema.addNamespace('oai_dc', 'http://www.openarchives.org/OAI/2.0/oai_dc/')
oai_dc_schema.addNamespace('dc', 'http://purl.org/dc/elements/1.1/')
oai_dc_schema.setFields(fields)
oai_dc_schema.setMultiSortables(multi_sortables)
oai_dc_schema.setResultColumns(result_columns)
oai_dc_schema.setItemFields(item_fields)
oai_dc_schema.setUserSearchables(user_searchables)
