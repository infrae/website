import core
from schemaRegistry import registerSchemaForDefaultReader

from oai_dc import oai_dc_schema

def initialize(context):
    
    import unicodesplitter # registers the splitter
    
    context.registerClass(
        core.OAIService,
        constructors = (
            core.manage_addOAIServiceForm,
            core.manage_addOAIService),
        icon = "www/oai_service.png"
        )
        
    registerSchemaForDefaultReader('oai_dc', oai_dc_schema)
                