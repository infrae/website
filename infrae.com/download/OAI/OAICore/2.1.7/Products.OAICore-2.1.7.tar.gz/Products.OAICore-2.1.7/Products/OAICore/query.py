from datetime import datetime

from OFS.CopySupport import _cb_encode, _cb_decode
from Globals import InitializeClass

from Globals import Persistent
import Acquisition

from AccessControl.Permissions import access_contents_information, view_management_screens
from AccessControl import ClassSecurityInfo
from Products.Formulator.Form import ZMIForm
from Products.OAICore.item import Item
from Products.OAICore.helpers import keysSortedByValue
import schemaRegistry
import string

class BaseQuery:
    """Query base class.
    """

    security = ClassSecurityInfo()

    # default values for old query version.
    _sort = None
    _display_letter = None
    
    def __init__(
            self, service, metadata_format=None, name=None, filters={}, 
            setSpec=None):
        self._service_path = service.getPhysicalPath()
        self._metadata_format = metadata_format
        self._schema_name = name
        self._filters = filters
        self._setSpec = setSpec
        self._sort = None
        self._display_letter = None
        
    # ACCESSORS
    
    security.declareProtected(view_management_screens, 'getService')
    def getService(self):
        """Get the OAI service the query is to use.
        """
        return self.unrestrictedTraverse(self._service_path)

    security.declareProtected(view_management_screens, 'getMetadataFormat')
    def getMetadataFormat(self):
        return self._metadata_format

    security.declareProtected(view_management_screens, 'getSchemaName')
    def getSchemaName(self):
        return self._schema_name

    security.declarePrivate('getCatalog')
    def getCatalog(self):
        return self.getService().getCatalog(self._metadata_format)
    
    security.declarePrivate('getSchema')
    def getSchema(self):
        return schemaRegistry.getSchema(
            self._metadata_format, self._schema_name)

    security.declareProtected(access_contents_information, 'getSet')
    def getSet(self):
        return self._setSpec

    security.declareProtected(access_contents_information, 'getFields')
    def getFields(self):
        return self.getSchema().getFields()

    security.declareProtected(
        access_contents_information, 'getManageableFields')
    def getManageableFields(self):
        return self.getSchema().getManageableFields()
    
    security.declareProtected(
        access_contents_information, 'getInitialSortOn')
    def getInitialSortOn(self):
        return self._sort or self.getSchema().getInitialSortOn()

    security.declareProtected(
        access_contents_information, 'getInitialSortOrder')
    def getInitialSortOrder(self):
        return self.getSchema().getInitialSortOrder()

    security.declareProtected(
        access_contents_information, 'getDisplayOn')
    def getDisplayOn(self):
        return self.getSchema().getDisplayOn()

    security.declareProtected(access_contents_information, 'getDisplayLetter')
    def getDisplayLetter(self):
        return self._display_letter
            
    security.declareProtected(access_contents_information, 'getColumns')
    def getColumns(self):
        return self.getSchema().getResultColumns()
    
    security.declarePrivate('getFilters')
    def getFilters(self):
        return self._filters

    security.declareProtected(access_contents_information, 'queryResults')
    def queryResults(self, query):
        catalog = self.getCatalog()
        query.setdefault('sort_order', self.getInitialSortOrder())
        query.setdefault('sort_on', self.getInitialSortOn())
        display_on = self.getDisplayOn()
        display_letter = self.getDisplayLetter()
        if display_on and display_letter:
            query[display_on] = '%c*' % display_letter
        if self._setSpec is not None:
            query['setSpec'] = self._setSpec
        filters = self.getFilters()
        for field in self.getManageableFields():
            field.updateQuery(query, filters)
        self.restrictQuery(query)
        return catalog.searchResults(**query)
    
    security.declarePrivate('restrictQuery')
    def restrictQuery(self, query):
        """ Just before the catalog is queried, this hook is called.
        
        Override it in your sub class to enforce extra restrictions on the
        query.
        """
        pass

InitializeClass(BaseQuery)

class ManageableQuery(BaseQuery):

    security = ClassSecurityInfo()

    # MANIPULATORS

    security.declareProtected(view_management_screens, 'setDisplayLetter')
    def setDisplayLetter(self, letter):
        if not letter or letter == 'none':
            letter = None
        self._display_letter = letter
    
    security.declareProtected(view_management_screens, 'setFilters')
    def setFilters(self, filters):
        """Set the filters dictionary (Filter results to be returned on
        values of fields in self._filters.)
        """
        self._filters = {}
        for key in filters.keys():
            if filters[key]:
                self._filters[key] = filters[key]

    security.declareProtected(view_management_screens, 'setSet')
    def setSet(self, setSpec):
        """Only return items in particular set.
        """
        # XXX I think the 'and setSpec != ['none']' can be phased out,
        # at least SilvaOAI No longer needs it
        if setSpec and setSpec != ['none']:
            self._setSpec = setSpec
        else:
            self._setSpec = None

    security.declareProtected(view_management_screens, 'setSchema')
    def setSchema(self, format, name):
        """Set the schema.
        """
        self._metadata_format = format
        self._schema_name = name
        self._sort = self.getSchema().getInitialSortOn()
        
    security.declareProtected(view_management_screens, 'setSort')
    def setSort(self, sort_on):
        """Set the index to sort on."""
        self._sort = sort_on
        
    security.declarePrivate('addFilterFields')
    def addFilterFields(self, form):
        catalog = self.getCatalog()
        filters = self.getFilters()
        for field in self.getManageableFields():
            field.addEditField(form, filters, catalog)

    security.declarePrivate('addSortField')
    def addSortField(self, form):
        form.manage_addField('sort_on', 'Sort On', 'ListField')
        values = form.get_field('sort_on').values
        sortables = self.getSchema().getMultiSortables()
        values['items'] = [(', '.join(
            sortable.id.split('_')[1:]), sortable.id) for sortable in sortables]
        sort_on = self.getInitialSortOn()
        if sort_on:
            values['default'] = sort_on
                
    security.declarePrivate('addDisplayField')
    def addDisplayField(self, form):
        if self.getDisplayOn():
            form.manage_addField('display_letter', 'Display Only', 'ListField')
            values = form.get_field('display_letter').values
            values['size'] = 1
            values['description'] = 'Display only entries starting with the following letter.'
            values['items'] = [('All values', 'none'),]
            for letter in string.ascii_lowercase:
                values['items'].append((letter, letter),)
            for digit in string.digits:
                values['items'].append((digit, digit),)
            if self.getDisplayLetter():
                values['default'] = self.getDisplayLetter()
            else:
                values['default'] = 'All values'

    security.declarePrivate('addSetField')
    def addSetField(self, form):
        form.manage_addField('set', 'Set', 'MultiCheckBoxField')
        values = form.get_field('set').values
        values['size'] = 5
        values['required'] = 0
        values['unicode'] = 1
        filters = self.getFilters()
        if filters.has_key('set'):
            values['default'] = self._filters['set']
        service = self.getService()
        toplevel_sets = service.getSubSets(None)
        # set up the 'Set' form field
        values['items'] = result = []
        for key in keysSortedByValue(toplevel_sets):
            result.append((toplevel_sets[key], key))
            sets = service.getSubSets(key)
            for subkey in keysSortedByValue(sets):
                result.append(('... %s' % sets[subkey], subkey))

    security.declareProtected(view_management_screens, 'updateManageForm')
    def updateManageForm(self, form):
        """
        Override this method to ad custom fields to the manage form.
        Remember to call addFilterFields (and optionally addSetField
        and/or addSortField) when you do.
        """
        self.addFilterFields(form)
        self.addDisplayField(form)
        self.addSortField(form)
        
InitializeClass(ManageableQuery)    

class UniqueValues(Acquisition.Implicit, Persistent):
    
    """Cache for the unique values for catalog 'metadata' columns.
    """
    
    def __init__(self):
        self._timestamp = datetime(1970, 1, 1) # a long time ago, to
                                               # start with an invalid
                                               # cache
        self._unique_values_for_column = {}
    
    def _uniqueValuesForColumn(self, column, query):
        # We cannot use the uniqueValuesFor method on the catalog, because
        # we need to apply the filters.
        unique = {}
        for brain in self.queryResults(query):
            values = brain[column]
            if values is None:
                continue
            if type([]) is not type(values):
                values = [values]
            for value in values:
                unique[value] = None
        unique_values = unique.keys()
        unique_values.sort()
        return unique_values
    
    def __call__(self, column, query=None):
        # First check the cache timestamp against the
        # last time the service harvested.
        service_timestamp = self.getService().getDatestamp()
        if service_timestamp > self._timestamp:
            self._unique_values_for_column = {}
            self._timestamp = datetime.utcnow()
        # See if it is cached already
        values = self._unique_values_for_column.get(column, None)
        if values is not None:
            return values
        # No, it isn't, so compute (and cache) it now
        if query is None:
            query = {}
        values = self._uniqueValuesForColumn(column, query)
        self._unique_values_for_column[column] = values
        return values

class SearchQuery(ManageableQuery):

    security = ClassSecurityInfo()

    def __init__(self, service):
        ManageableQuery.__init__(self, service)
        self._resetCache()

    def _resetCache(self):
        self._unique_values = UniqueValues()
    
    security.declareProtected(view_management_screens, 'setFilters')
    def setFilters(self, filters):
        """Set the filters dictionary (Filter results to be returned on
        values of fields in self._filters.)
        """
        self._resetCache()
        ManageableQuery.setFilters(self, filters)

    security.declareProtected(access_contents_information, 'getSearchables')
    def getSearchables(self):
        return self.getSchema().getUserSearchables()

    # XXX The __getitem__ interface might be better placed in a Mixin class.
    def __getitem__(self, id):
        """Return item with id wrapped in context of query.
        """
        # could do a catalog query here to check whether this object
        # is within query parameters, but we won't for performance
        # reasons
        obj = self.getService().getStorage(self._metadata_format)._getOb(id)
        fields = self.getSchema().getItemFields()
        return self.createItem(obj, fields).__of__(self)
        
    security.declarePrivate('createItem')
    def createItem(self, obj, fields):
        return Item(obj, fields)

    security.declareProtected(
        access_contents_information, 'updateSearchForm')
    def updateSearchForm(self, form):
        pass
    
    security.declarePrivate('addSearchFields')
    def addSearchFields(self, form):
        searchables = self.getSearchables()
        filters = self.getFilters()
        #XXX change so that the fields are looked up by id, to ensure
        #the order in user_searchables is preserved.
        for field in self.getFields():
            id = field.getId()
            # XXX Users can not search on filtered fields, which sucks:
            # let's change this, once the (z3) Catalog allows us to do
            # easy intersections.
            if id not in searchables or filters.has_key(id):
                continue
            unique_values = []
            if field.getIndexType() != 'KeywordIndex':
                continue
            for value in self.getUniqueValues(id):
                unique_values.append((value[:60], value))
            field.addPublicField(form, unique_values)

    security.declarePrivate('addFulltextSearchField')
    def addFulltextSearchField(self, form):
        form.manage_addField('fulltext', 'Fulltext Search', 'StringField')
        values = form.get_field('fulltext').values
        values['required'] = 0
        values['unicode'] = 1
    
    security.declareProtected(access_contents_information, 'getUniqueValues')
    def getUniqueValues(self, column):
        return self._unique_values(column)
    
InitializeClass(SearchQuery)
