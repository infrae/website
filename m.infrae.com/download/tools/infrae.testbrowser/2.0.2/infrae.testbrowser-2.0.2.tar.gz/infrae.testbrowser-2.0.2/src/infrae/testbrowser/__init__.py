# -*- coding: utf-8 -*-
# Copyright (c) 2010-2013 Infrae. All rights reserved.
# See also LICENSE.txt

import python26  # 2.6 compat
from infrae.testbrowser.browser import Browser

__all__ = ['Browser']
