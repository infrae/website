You should readme.
Now.
