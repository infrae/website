
class ConnectionError(Exception):
    pass

class DatabaseError(Exception):
    pass

class QueryError(Exception):
    pass
