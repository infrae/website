# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt

import sys
import shutil
import os
import pkg_resources
from optparse import OptionParser

from infrae.copyright.directories import update_directories

LICENSES = {
    'BSD': os.path.join(os.path.dirname(__file__), 'LICENSE_BSD.txt'),
    'ZPL 2.1': os.path.join(os.path.dirname(__file__), 'LICENSE_ZPL.txt')
    }


def get_license(distribution):
    for entry in distribution._get_metadata('pkg-info'):
        if entry.startswith('License:'):
            return entry[8:].strip()
    print>>sys.stderr, 'Missing license for:', distribution.egg_name
    return 'BSD'

def update_packages(packages, change=False):
    total_file_count, total_changed_count = 0, 0
    for package in packages:
        print 'Processing package %s...' % package
        product = True
        requirement = list(pkg_resources.parse_requirements(package))[0]
        distribution = pkg_resources.working_set.find(requirement)
        if distribution is None:
            print>>sys.stderr, 'Missing package: %s.' % package
            continue
        path = distribution.location
        if os.path.basename(path) == 'src':
            path = os.path.dirname(path)
            product = False
        file_count, changed_count = update_directories([path], change)
        if change:
            license_name = get_license(distribution)
            license_wanted = LICENSES.get(license_name)
            print 'License for %s: %s' % (package, license_name)
            if license_wanted is not None:
                license_txt = os.path.join(path, 'LICENSE.txt')
                if not product:
                    license_txt = os.path.join(path, 'docs', 'LICENSE.txt')
                shutil.copy2(license_wanted, license_txt)
        total_file_count += file_count
        total_changed_count += changed_count
    return total_file_count, total_changed_count


def main_packages(default_packages):
    parser = OptionParser()
    parser.add_option(
        "--apply", dest="changes", action="store_true", default=False)

    (options, args) = parser.parse_args()
    if args:
        packages = set(args)
    else:
        packages = set(default_packages)
    file_count, changed_count = update_packages(packages, options.changes)
    print 'Number of files checked: %d' % file_count
    if options.changes:
        print 'Number of files changed: %d' % changed_count
    else:
        print 'Number of files needing updating: %d' % changed_count


def egg_entry_point(kwargs):
    return main_packages(**kwargs)

