#! /usr/local/bin/python2.7
# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt
"""Script to check and fix the copyright years.
"""

import fnmatch
import os
from os.path import join, abspath
import re
import sys
import time

YEAR = time.localtime()[0]

_charset_coding_pattern = re.compile(
    r'^#[\s]*-\*-[\s]*coding:[\s]*[-a-z0-9]+[\s]*-\*-[\s]*$')
_copyright_pattern = re.compile(
    r'^(\#.*Copyright.*?)(?P<years>[0-9]{4}[-0-9,\s]*)(.*)$')

new_encoding = '# -*- coding: utf-8 -*-\n'
new_copyright = '# Copyright (c) ' + str(YEAR) + '  Infrae. All rights reserved.\n'
new_license = '# See also LICENSE.txt\n'

def find_files(topdir):
    """Return a list of all filenames which match the given extensions.

    The returned list of filenames are as absolute paths.
    """
    patterns = ('*.py',)

    for dirpath, dirnames, filenames in os.walk(topdir):
        files = []
        for pattern in patterns:
            files.extend(fnmatch.filter(filenames, pattern))
        for thefile in files:
            yield abspath(join(dirpath, thefile))


def check_copyright(line, match):
    """A copyright was found. Check it for up-to-date year(s).

    Return a tuple containing two values: the (possibly updated)
    copyright string and a True/False value reflecting whether the
    string was changed.
    """
    copyright = line

    years = match.group('years').strip()
    year_separator = re.search(r'([-0-9, ]+)*([0-9]{4})$', years)

    if year_separator.group(2) != str(YEAR):
        if year_separator.group(1) is not None:
            has_dash = re.search(r'[0-9]{4}-$', year_separator.group(1))
            if has_dash is not None:
                new_year = year_separator.group(1) + str(YEAR) + ' '
            else:
                new_year = year_separator.group(0) + '-' + str(YEAR) + ' '
        else:
            new_year = year_separator.group(2) + '-' + str(YEAR) + ' '

        copyright = match.group(1) + new_year + match.group(3) + '\n'
        return (True, copyright)

    return (False, copyright)


def check_python_files(filename, change=False, svn=False):
    """Each file is checked for shebang, encoding-cookie, copyright

    If they don't exist and DO_CHANGES is True, prepend them. If
    copyright exists, check if it has the current year.
    If not, update the year.
    """
    try:
        text = open(filename, 'r+b')
    except IOError as error:
        print 'Could not open ' + filename, error
        return

    lines = []
    dash_bang = None
    encoding_line = None
    copyright_line = None
    update_copyright = False
    license_line = None
    needs_changes = False

    for lineno, line in enumerate(text.readlines()):
        if line.startswith('#!') and not lineno:
            dash_bang = line
            continue

        #check for encoding cookie
        enc_match = _charset_coding_pattern.search(line)
        if enc_match:
            encoding_line = line
            continue

        #check for copyright line
        cr_match = _copyright_pattern.search(line)
        if cr_match:
            update_copyright, copyright_line = check_copyright(line, cr_match)
            continue

        #check for license line
        if line.startswith(new_license.strip()):
            license_line = line
            continue

        # Remove SVN special line
        if not svn and line.startswith('# $Id'):
            needs_changes = True
            continue

        lines.append(line)

    if (encoding_line is None or
          copyright_line is None or
          update_copyright is True or
          license_line is None):
        needs_changes = True

    # if we're not writing
    if needs_changes == False or change == False:
        text.close()
        return needs_changes

    # if we're writing and need changes
    text.truncate(0)
    text.seek(0)
    if dash_bang is not None:
        text.write(dash_bang)
    if encoding_line is None:
        text.write(new_encoding)
    else:
        text.write(encoding_line)

    if copyright_line is None:
        text.write(new_copyright)
    else:
        text.write(copyright_line)

    if license_line is None:
        text.write(new_license)
    else:
        text.write(license_line)

    text.writelines(lines)
    text.close()

    return needs_changes


def update_directories(directories, change=False):
    file_count = 0
    change_count = 0

    for directory in directories:
        svn = os.path.isdir(os.path.join(directory, '.svn'))
        for result in find_files(directory):
            file_count += 1
            if check_python_files(result, change, svn):
                change_count += 1

    return file_count, change_count


def main_directories():
    changes = False
    directories = []

    params = sys.argv[1:]
    print params
    if params:
        for p in params:
            if p.lower() == '--apply':
                changes = True
            else:
                directories.append(p)
    else:
        print >>sys.stderr, "usage: %s [--apply] <start dir> ..." % sys.argv[0]
        print >>sys.stderr, "       --apply: make changes to the files"
        sys.exit(1)
    file_count, change_count = update_directories(directories, changes)
    print 'Number of files checked: %d' % file_count
    if changes:
        print 'Number of files changed: %d' % change_count
    else:
        print 'Number of files needing updating: %d' % change_count


if __name__ == '__main__':
    main_directories()
