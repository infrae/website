# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt

import zc.recipe.egg
import zc.buildout.easy_install


SCRIPT_REQUIRES = [
    'setuptools',
    'infrae.copyright']


def string_to_lines(string):
    return filter(
        lambda v: v, map(
            lambda s: s.strip(), string.split('\n')))


class Recipe(object):

    def __init__(self, buildout, name, options):
        self.buildout = buildout
        self.name = name
        self.options = options
        self.options['eggs'] = self.options.get('eggs', '') + '\n' + \
            '\n '.join(SCRIPT_REQUIRES) + \
            '\n ' + options.get('packages', '')
        self.packages = string_to_lines(options.get('packages', ''))
        self.egg = zc.recipe.egg.Egg(buildout, name, options)

    def install(self):
        requirements, ws = self.egg.working_set()

        arguments = {'default_packages': self.packages}
        return zc.buildout.easy_install.scripts(
            [('%s'% self.name,
              'infrae.copyright.packages',
              'egg_entry_point')],
            ws, self.options['executable'],
            self.buildout['buildout']['bin-directory'],
            arguments = arguments,
            extra_paths = self.egg.extra_paths)

    update = install
