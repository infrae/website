================
infrae.copyright
================

This is a buildout recipe that create a script to help to update
copyright information in source files.
