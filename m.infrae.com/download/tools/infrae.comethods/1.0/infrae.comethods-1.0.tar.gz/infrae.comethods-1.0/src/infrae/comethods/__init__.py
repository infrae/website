# This is a package.

from infrae.comethods.decorators import cofunction

__all__ = ['cofunction']
