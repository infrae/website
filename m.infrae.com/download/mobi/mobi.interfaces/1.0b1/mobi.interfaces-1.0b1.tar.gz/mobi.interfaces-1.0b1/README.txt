===============
mobi.interfaces
===============


Interfaces package for mobi.* libs.

