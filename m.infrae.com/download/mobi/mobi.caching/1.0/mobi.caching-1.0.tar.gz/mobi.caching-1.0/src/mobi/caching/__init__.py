# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt.
# init

from mobi.caching.cache import *
from mobi.caching.backend import NoCacheBackend
