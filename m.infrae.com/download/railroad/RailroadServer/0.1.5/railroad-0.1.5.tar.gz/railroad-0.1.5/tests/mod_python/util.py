# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
#


###

def redirect ( request, url ):
    """Dummy redirect function for testing.
    """
    request._result = url
    return
#
