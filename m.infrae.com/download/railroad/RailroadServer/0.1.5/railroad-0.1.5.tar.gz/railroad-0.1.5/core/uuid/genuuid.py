from mod_python import apache

import commands

###


def _get_uuid ():
    return commands.getoutput('uuidgen')
#

def index ( req, form ):
    """Simple function that returns a new UUID in text form.
    """
##     genf = libuuid.generate_time
##     if form.has_key('type'):
##         t = form['type'].strip().lower()
##         if t == 'time':
##             pass
##         elif t == 'random':
##             genf = libuuid.generate_random
##         elif t == 'choose':
##             genf = libuuid.generate
##         else:
##             pass
##     raw_uuid = genf()
##     uuid = libuuid.unparse(raw_uuid)
    uuid = _get_uuid()
    req.content_type = 'text/plain; charset="UTF-8"'
    req.set_content_length(len(uuid))
    req.write(uuid)
    return apache.OK
#
