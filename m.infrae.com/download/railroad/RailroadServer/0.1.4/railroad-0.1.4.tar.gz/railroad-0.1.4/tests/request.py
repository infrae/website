# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

###

class Request ( object ):
    """Dummy Request class for testing.
    """

    def __init__ ( self, **kwargs ):
        for k, v in kwargs.items():
            setattr(self, k, v)
        self._result = None
        return

    def get_test_result ( self ):
        return self._result

    def get_basic_auth_pw ( self ):
        self.user = self._user
        return self._password

    def get_options ( self ):
        return self.options

    def log_error ( self, msg, level ):
        self._result = (msg, level)
        print level, msg
        return
#
