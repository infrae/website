from genuuid import index

# allow access for everyone
__auth__ = True

# only index
__allowed__ = ('index',)

