# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import testconf
import unittest

import xmlquery

###

Q = u"""<?xml version="1.0" encoding="utf-8" ?>
<query>
  <conditions>
      <and>
          <match>
            <property name="getcontenttype" namespace="DAV:" />
            <literal value="image/%" />
          </match>
          <or>
              <greater>
                  <property name="getlastmodified" namespace="DAV:" />
                  <literal value="2004-08-01T00:00:00.00" />
              </greater>
              <equal>
                  <property name="getetag" namespace="DAV:" />
                  <literal value="4bda6-5f60-856b30c0" />
              </equal>
              <between>
                  <property name="getcontentlength" namespace="DAV:" />
                  <literal value="190" />
                  <literal value="210" />
              </between>
          </or>
      </and>
  </conditions>
</query>
"""

###

class XmlQueryTests ( unittest.TestCase ):
    """Test the xmlquery module.
    """

    def setUp ( self ):
        return

    def tearDown ( self ):
        return

    def test_01_parse_string ( self ):
        """Test xmlquery.XmlQueryParser class
        """
        parser = xmlquery.XmlQueryParser()
        parser.parse_string(Q)
        res = str(parser.get_prerendered())
        expected = "(DAV: getcontenttype AND (value LIKE 'image/%')) INTERSECT (DAV: getlastmodified AND (value > '2004-08-01T00:00:00.00')) UNION (DAV: getetag AND (value = '4bda6-5f60-856b30c0')) UNION DAV: getcontentlength AND (value BETWEEN '190' AND '210')"
        self.assertEqual(expected, res)
        return

    def test_10_build_sql ( self ):
        """Test xmlquery.SqlBuilder class
        """
        parser = xmlquery.XmlQueryParser()
        parser.parse_string(Q)
        builder = xmlquery.SqlBuilder(parser)
        res = builder.get_statement()
        expected = """SELECT resource_id FROM rr.properties WHERE ((qname = 'DAV: getcontenttype') AND (value LIKE 'image/%'))
INTERSECT
SELECT resource_id FROM (
    SELECT resource_id FROM rr.properties WHERE ((qname = 'DAV: getlastmodified') AND (value > '2004-08-01T00:00:00.00'))
    UNION
    SELECT resource_id FROM rr.properties WHERE ((qname = 'DAV: getetag') AND (value = '4bda6-5f60-856b30c0'))
    UNION
    SELECT resource_id FROM rr.properties WHERE (qname = 'DAV: getcontentlength') AND (value BETWEEN 190 AND 210)) as A;"""
        self.assertEqual(expected, res)
        return
#
###

if __name__ == '__main__':
    unittest.main()
