About Railroad
==============

Railroad is a standards-based repository for large binary files such
as digital media, along with their metadata. It is designed to be easy
to integrate with content management systems and other client
software.

Many CMSes are more suitable for document-style content than they are
for managing large files. Managing such large-file content in a CMS
can result in scalability issues and deteriorating
performance. Railroad instead is dedicated to the task of managing
large files and their metadata.

Railroad can be seamlessly integrated into CMSes, leveraging the open
WebDAV protocol and simple HTTP messaging. While uploads and downloads
of files are fully managed by Railroad and thus routed "around" the
CMS, authorization of who can upload or download is still under full
control of the CMS using whatever authorization scheme it needs.

Railroad aims to allow multiple clients (such as CMSes) to access the
resources in the repository at the same time, thus allowing large data
files and their metadata to be centrally managed and shared.

Railroad also makes management of large file data on the filesystem
easier for the system administrator. Railroad takes care to categorize
files of a different type into separate directories. If a system
administrator determines one file type is taking up a lot of space, it
is simple to move this information off onto another, larger,
partition. It is also possible to run multiple repositories in one
Apache instance or on different machines but using the same database.

Technology and Standards
========================

Railroad uses the industry-standard Apache HTTP server. It uses
Apache's mod_dav and mod_python, and metadata is stored in a
PostgreSQL database.  Information about metadata in a repository can
be accessed and manipulated using WebDAV.

CMS support
===========

Preliminary Zope integration including support for Plone.


Thank you
=========

The Infrae team would like to thank ETH Z�rich for their support and
encouragement during the initial development of Railroad.


Appendix
========

For installation information, see: ``doc/install.txt``

For information on how to integrate this with your own CMS, see:
``doc/cms_integration.txt``.

If you have comments, you can use one (or more:) of the following
methods to contact the developers:

Mailinglist subscription:
  http://codespeak.net/mailman/listinfo/railroad-dev

Mailinglist for checkin messages:
  http://codespeak.net/mailman/listinfo/rr-checkins

Issue tracker:
  http://codespeak.net/issues/railroad/

IRC:
  irc.freenode.net, #railroad

Project homepage:
  http://www.infrae.com/products/railroad
