# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import testconf

import os
import unittest

import db_pg as DB

###

CON = None

###

class PgTests ( unittest.TestCase ):
    """Test the PostgeSQL database module.
    """

    DBOPTS = {'dbname':'tests', 'dbuser':'gst'}

    REPO_1 = ('repo1', 'host1', '/path/to/repo1', '/path/to/upload1',
              'master1', 'password1', '/home/gst/downloads')
    REPO_2 = ('repo2', 'host2', '/path/to/repo2', '/path/to/upload2',
              'master2', 'password2', '/home/gst/downloads')

    CLIENT_1 = ('client1', 'http://client1.com:8080/auth', 'Test1')

    CLIENT_2 = ('client2', 'http://client2.com/auth2', 'Test2')

    def setUp ( self ):
        global CON
        os.system('psql tests <../db_pg.sql >/dev/null 2>&1')
        return

    def tearDown ( self ):
        return

    def test_add_delete_repo ( self ):
        """Test insert and deletion of a repository.
        """
        # empty tables, first entry of REPO_1
        DB.add_repository(*self.REPO_1)
        # second try should raise exception
        self.failUnlessRaises(DB.IntegrityError, DB.add_repository, *self.REPO_1)
        # delete repo
        DB.delete_repository(self.REPO_1[0])
        # second delete should be ok too
        DB.delete_repository(self.REPO_1[0])
        return

    def test_get_all_repos ( self ):
        """Test repository overview.
        """
        # empty tables, insert two repos
        DB.add_repository(*self.REPO_1)
        DB.add_repository(*self.REPO_2)
        expected = [{'upload_pw': None, 'upload_user': None, 'name': 'repo1', 'fs_top_dir': '/home/gst/downloads', 'incomming_path': None, 'host': 'host1', 'master_user': 'master1', 'upload_path': '/path/to/upload1', 'path': '/path/to/repo1', 'admin_mail': None, 'id': 1, 'master_pw': 'password1'}, {'upload_pw': None, 'upload_user': None, 'name': 'repo2', 'fs_top_dir': '/home/gst/downloads', 'incomming_path': None, 'host': 'host2', 'master_user': 'master2', 'upload_path': '/path/to/upload2', 'path': '/path/to/repo2', 'admin_mail': None, 'id': 2, 'master_pw': 'password2'}]
        res = DB.get_all_repos()
        self.assertEqual(expected, res)
        return

    def test_add_delete_client ( self ):
        """Test insert and deletion of a client
        """
        # empty tables, first entry of CLIENT_1
        DB.add_client(*self.CLIENT_1)
        # second try should raise exception
        self.failUnlessRaises(DB.IntegrityError, DB.add_client, *self.CLIENT_1)
        # delete client
        DB.delete_client(self.CLIENT_1[0])
        # second delete should be ok too
        DB.delete_client(self.CLIENT_1[0])
        return

    def test_get_all_clients ( self ):
        """Test client overview.
        """
        # empty tables, insert two repos
        DB.add_client(*self.CLIENT_1)
        DB.add_client(*self.CLIENT_2)
        expected = [{'name': 'client1', 'admin_mail': None, 'state': None, 'auth_url': 'http://client1.com:8080/auth', 'auth_domain': 'Test1', 'id': 1}, {'name': 'client2', 'admin_mail': None, 'state': None, 'auth_url': 'http://client2.com/auth2', 'auth_domain': 'Test2', 'id': 2}]
        res = DB.get_all_clients()
        self.assertEqual(expected, res)
        return
#
###

if __name__ == '__main__':
    CON = DB.connect(PgTests.DBOPTS)
    unittest.main()
