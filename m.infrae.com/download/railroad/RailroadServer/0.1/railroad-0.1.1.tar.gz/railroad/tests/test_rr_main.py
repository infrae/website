# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import os

import testconf
from mod_python import apache
from request import Request

import unittest
import urllib


import rr_config
import db_pg as DB
import rr_util
import rr_main

###

CON = None
# reset database
os.system('psql tests <../db_pg.sql >/dev/null 2>&1')

###

class MainTests ( unittest.TestCase ):
    """Test the rr_main module.
    """

    def setUp ( self ):
        # reset rr_config
        rr_config.initialized = False
        rr_config.repo_name = None
        rr_config.DB = None
        rr_config.do_auth = False
        rr_config.do_search = False
        rr_config.repo_master = {}
        # fake rr_util.call_cms
        rr_util.call_cms = self._call_cms
        return

    def tearDown ( self ):
        if rr_config.DB is not None:
            rr_config.DB = None
        return

    def _call_cms ( self, url, user, passwd ):
        self._url = url
        self._user = user
        self._passwd = passwd
        return apache.OK

    def test_init_handler ( self ):
        opt = {'repository':'repo', 'authorize':'off', 'search':'off'}
        req = Request(method='GET', options=opt, _user='xxx', _password='xxx', headers_in={})
        rr_util.init_railroad(req)
        res = rr_main.inithandler(req)
        self.assertEqual(apache.OK, res)
        return

    def test_authenhandler ( self ):
        opt = {'repository':'repo', 'authorize':'off', 'search':'off'}
        req = Request(uri='/rrr/repo/image/jpeg/000/xxx.jpg', method='GET',
                      options=opt, _user='xxx', _password='xxx', headers_in={})
        res = rr_main.authenhandler(req)
        return
#
###

if __name__ == '__main__':
    unittest.main()
