# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import testconf
import unittest

import query

###

class QueryTests ( unittest.TestCase ):
    """Test the query module.
    """

    def setUp ( self ):
##         self.renderer = query.SimpleRenderer()
        self.renderer = query.SQLRenderer()
        return

    def tearDown ( self ):
        return

    def test_01_terminal ( self ):
        """Test query.Terminal class
        """
        terminal = query.Terminal('terminal')
        res = terminal.render_with(self.renderer)
        expected = 'terminal'
        self.assertEqual(res, expected)
        return
        
    def test_02_condition ( self ):
        """Test query.Condition class
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond = query.Condition(qleft, 'op', qright)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value op 'right'))"
        self.assertEqual(res, expected)
        return

    def test_03_equal ( self ):
        """Test query.Equal class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond = query.Equal(qleft, qright)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value = 'right'))"
        self.assertEqual(res, expected)
        return

    def test_04_notequal ( self ):
        """Test query.NotEqual class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond = query.NotEqual(qleft, qright)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value <> 'right'))"
        self.assertEqual(res, expected)
        return

    def test_05_and ( self ):
        """Test query.And class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond1 = query.NotEqual(qleft, qright)
        cond2 = query.Equal(qleft, qright)
        cond = query.And(cond1, cond2)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value <> 'right')) AND ((qname = 'left') AND (value = 'right'))"
        self.assertEqual(res, expected)
        return

    def test_06_or ( self ):
        """Test query.Or class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond1 = query.NotEqual(qleft, qright)
        cond2 = query.Equal(qleft, qright)
        cond = query.Or(cond1, cond2)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value <> 'right')) OR ((qname = 'left') AND (value = 'right'))"
        self.assertEqual(res, expected)
        return

    def test_07_in ( self ):
        """Test query.Or class.
        """
        qleft = query.Variable('left')
        qright = (query.Value('right1'), query.Value('right2'))
        cond = query.In(qleft, *qright)
        res = cond.render_with(self.renderer)
        expected = "(qname = 'left') AND (value IN ('right1','right2'))"
        self.assertEqual(res, expected)
        return

    def test_08_between ( self ):
        """Test query.Between class.
        """
        qleft = query.Variable('left')
        qright1 = query.Value('right1')
        qright2 = query.Value('right2')
        cond = query.Between(qleft, qright1, qright2)
        res = cond.render_with(self.renderer)
        expected = "(qname = 'left') AND (value BETWEEN 'right1' AND 'right2')"
        self.assertEqual(res, expected)
        return

    def test_09_like ( self ):
        """Test query.Like class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond = query.Like(qleft, qright)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value LIKE 'right'))"
        self.assertEqual(res, expected)
        return

    def test_10_ilike ( self ):
        """Test query.Like class.
        """
        qleft = query.Variable('left')
        qright = query.Value('right')
        cond = query.ILike(qleft, qright)
        res = cond.render_with(self.renderer)
        expected = "((qname = 'left') AND (value ILIKE 'right'))"
        self.assertEqual(res, expected)
        return

    def test_20_complex_term_1 ( self):
        """Test more complex compound term.
        """
        qleft = query.Variable('a')
        qright = query.Value('b')
        qright1 = query.Value('2')
        qright2 = query.Value('4')
        cond1 = query.NotEqual(qleft, qright)
        cond2 = query.Equal(qleft, qright)
        cond3 = query.Between(qleft, qright1, qright2)
        br1 = query.Bracketed(query.And(cond1, cond2))
        cond = query.Or(br1, cond3)
        res = cond.render_with(self.renderer)
        expected = "(((qname = 'a') AND (value <> 'b')) AND ((qname = 'a') AND (value = 'b'))) OR (qname = 'a') AND (value BETWEEN 2 AND 4)"
        self.assertEqual(res, expected)
        cond = query.Or(cond3, br1)
        res = cond.render_with(self.renderer)
        expected = "(qname = 'a') AND (value BETWEEN 2 AND 4) OR (((qname = 'a') AND (value <> 'b')) AND ((qname = 'a') AND (value = 'b')))"
        self.assertEqual(res, expected)
        return
#
###

if __name__ == '__main__':
    unittest.main()
