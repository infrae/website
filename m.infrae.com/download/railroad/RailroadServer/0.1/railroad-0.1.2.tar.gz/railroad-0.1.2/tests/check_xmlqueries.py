# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt
import sys
sys.path.insert(0, '../')

import time

from pprint import pprint

import psycopg as SQL

import xmlquery

###

Q1 = u"""\
<?xml version="1.0" encoding="utf-8" ?>
<query>
  <conditions>
      <and>
          <equal>
              <property name="getcontenttype" namespace="DAV:" />
              <literal value="text/html" />
          </equal>
          <greater>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-05-15T00:00:00" function="to_ts" />
          </greater>
      </and>
  </conditions>
</query>
"""

Q2 = u"""\
<?xml version="1.0" encoding="utf-8" ?>
<query>
  <conditions>
        <and>
          <match>
              <property name="getcontenttype" namespace="DAV:" />
              <literal value="application/%" />
          </match>
          <and>
            <less>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-01-15T00:00:00" function="to_ts" />
            </less>
            <greater>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-01-01T00:00:00" function="to_ts" />
            </greater>
          </and>
        </and>
  </conditions>
</query>
"""

Q3 = u"""\
<?xml version="1.0" encoding="utf-8" ?>
<query>
  <conditions>
      <or>
        <and>
          <match>
              <property name="getcontenttype" namespace="DAV:" />
              <literal value="application/%" />
          </match>
          <and>
            <less>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-01-15T00:00:00" function="to_ts" />
            </less>
            <greater>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-01-01T00:00:00" function="to_ts" />
            </greater>
          </and>
        </and>
        <and>
          <equal>
              <property name="getcontenttype" namespace="DAV:" />
              <literal value="text/html" />
          </equal>
          <greater>
              <property name="getlastmodified" namespace="DAV:" />
              <literal value="2004-05-15T00:00:00" function="to_ts" />
          </greater>
        </and>
      </or>
  </conditions>
</query>
"""

##           <match>
##               <property name="getcontenttype" namespace="DAV:" />
##               <literal value="text/%" />
##           </match>
##           <between>
##               <property name="getlastmodified" namespace="DAV:" />
##               <literal value="2004-05-01T00:00:00" function="to_ts" />
##               <literal value="2004-06-30T00:00:00" function="to_ts" />
##           </between>

qs = []
parser = xmlquery.XmlQueryParser()
for q in (Q1, Q2, Q3):
    parser.parse_string(q)
    builder = xmlquery.SqlBuilder(parser)
    builder.table = 'properties'
    sql = builder.get_statement()
    qs.append(sql)
    print sql
    print '-'*60

con = SQL.connect('dbname=guido host=nathan user=guido', minconn=1, maxconn=2, serialize=0)
c = con.cursor()
c.execute('set enable_seqscan to off;')

for sql in qs:
    t0 = time.time()
    c.execute(sql)
    rows = c.fetchall()
    print len(rows)
    c.commit()
    td = time.time() - t0
    print td*1000.0
#

## pprint(rows)
