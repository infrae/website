#!/usr/bin/env python2.3

"""Script to add/change/delete client entries in the database.
"""

import sys

import admconf

###

stderr = sys.stderr

CMDS = ('add', 'show', 'update', 'delete', 'activate', 'deactivate')

###

DB = admconf.DB

CON = DB.connect(admconf.dbopts)

###

def usage():
    print >>stderr, 'usage clientdm.py cmd [cmd options]'
    print >>stderr, ' cmds are: %s' % str(CMDS)
    print >>stderr, 'Options:'
    print >>stderr, ' add:'
    print >>stderr, '     client name'
    print >>stderr, '     authorization URL'
    print >>stderr, '     authorization domain'
    print >>stderr, ' activate:'
    print >>stderr, '     client name'
    print >>stderr, '     repository name'
    print >>stderr, ' deactivate:'
    print >>stderr, '     client name'
    print >>stderr, '     repository name'
    print >>stderr, ' delete:'
    print >>stderr, '     client name'
    print >>stderr, ' show:'
    print >>stderr, '     no arguments'
    return
#

def do_add ( name, authurl, authdomain ):
    print 'adding client %s' % name
    try:
        DB.add_client(name, authurl, authdomain)
    except DB.IntegrityError, ex:
        print >>stderr, "Couldn't add client %s" % name
        print >>stderr, str(ex)
        pass
    return

def do_delete ( name ):
    print 'deleting client %s' % name
    try:
        DB.delete_client(name)
    except DB.IntegrityError, ex:
        print >>stderr, "Couldn't delete client %s" % name
        print >>stderr, str(ex)
        pass
    return

def do_activate ( cname, rname ):
    print 'activating client %s on repository %s' % (cname, rname)
    try:
        DB.activate_client(cname, rname)
    except DB.IntegrityError, ex:
        print >>stderr, "Couldn't activate client %s" % cname
        print >>stderr, str(ex)
        pass
    return

def do_deactivate ( cname, rname ):
    print 'deactivating client %s on repository %s' % (cname, rname)
    try:
        DB.deactivate_client(cname, rname)
    except DB.IntegrityError, ex:
        print >>stderr, "Couldn't deactivate client %s" % cname
        print >>stderr, str(ex)
        pass
    return

def do_show ():
    print "client listing:"
    repos = DB.get_all_clients()
    for r in repos:
        print 'Client: %s' % r['name']
        print '            Id: %s' % r['id']
        print '      Auth URL: %s' % r['auth_url']
        print '   Auth domain: %s' % r['auth_domain']
        print '        Status: %s' % r['state']
    return

def parse_options( optlist ):
    if not optlist:
        print >>stderr, 'No arguments supplied!'
        usage()
        sys.exit(1)
    cmd = optlist.pop(0).strip().lower()
    if cmd not in CMDS:
        print >>stderr, 'Unknown command: %s' % cmd
        sys.exit(1)
    args = optlist[:]
    try:
        fnc = globals()['do_'+cmd]
    except KeyError, ex:
        print >>stderr, 'No function for command %s found!' % cmd
        sys.exit(2)
    try:
        fnc(*args)
    except TypeError, ex:
        print >>stderr, 'Error: %s' % str(ex)
        usage()
        sys.exit(2)
    return
#
###

if __name__ == '__main__':
    parse_options(sys.argv[1:])
    CON.close()

