"""Global configuration for rr_* modules.

"""

# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import sys
import os.path

from mod_python import apache

###

# base path to installation
base_path = os.path.dirname(__file__)
core_path = os.path.join(base_path, 'core/')
service_path = os.path.join(base_path, 'services/')
extension_path = [core_path, service_path]

# config data
initialized = False
repo_name = None
DB = None
do_auth = False
do_search = False
repo_master = {}

hook_registry = {}

###
