from doupload import upload as index

__allowed__ = ('index',)
