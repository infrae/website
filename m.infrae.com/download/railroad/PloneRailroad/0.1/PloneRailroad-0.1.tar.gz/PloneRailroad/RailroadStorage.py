# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

from Products.Archetypes.interfaces.storage import IStorage
from Products.Archetypes.Storage import Storage
from AccessControl import ClassSecurityInfo
from dav import DAVNotFoundError
from DateTime import DateTime

#RailroadStorage stores fields as into metadata dictionaries inside
#the Railroad Server
#yet totally unoptimized code

class RailroadStorage(Storage):
    """Stores data as an attribute inside RR Server."""

    __implements__ = IStorage

    security = ClassSecurityInfo()
    
    #Field to string and back mappers
    def map_object(self, field, value):
        if value is None:
            return 'None'
        else:
            return value

    def unmap_object(self, field, value):
        if value == 'None':
            return None
        else:
            return value

    def map_datetime(self, field, value):
        # we don't want to lose even 0.001 second
        try:
            return value.ISO()[:-2] + str(value.second())
        except:
            return None

    def map_fixedpoint(self, field, value):
        __traceback_info__ = repr(value)
        template = '%%d%%0%dd' % field.precision
        return template % value

    def unmap_fixedpoint(self, field, value):
        __traceback_info__ = repr(value)
        if value is None or value == '':
            return (0, 0)
        if type(value) == type(''):   # Gadfly return integers as strings
            value = int(value)
        split = 10 ** field.precision
        return (value / split), (value % split)

    def map_lines(self, field, value):
        __traceback_info__ = repr(value)
        return '\n'.join(value)

    def unmap_lines(self, field, value):
        __traceback_info__ = repr(value)
        return value.split('\n')

    def map_boolean(self, field, value):
        __traceback_info__ = repr(value)
        if not value:
            return 0
        else:
            return 1

    def map_datetime(self, field, value):
        if value is None:
            return 'None'
        else:
            return value.ISO()

    def unmap_datetime(self, field, value):
        if value == 'None':
            return None
        else:
            return DateTime(value)
        
    #end of mappers

    def initTempPropDicts(self,req):
        if not hasattr(req,'_rr_props'):
            req._rr_props={}
            
        return req._rr_props
    
    def getTempPropDict(self,instance):
        req=instance.REQUEST
        dicts=self.initTempPropDicts(req)
            
        res=dicts.get(instance.UID(),None)
        
        return res
        
    def setTempPropDict(self,instance,dict):
        req=instance.REQUEST
        dicts=self.initTempPropDicts(req)

        dicts[instance.UID()]=dict
        
    security.declarePrivate('get')
    def get(self, name, instance, **kwargs):
        try:
            inst=instance.aq_base
                
            field=instance.Schema()[name]
            tname=(unicode(field.getName()),unicode(getattr(field,'urn',field.getName())))
            dict=self.getTempPropDict(instance)
            
            if not dict:
                dict=instance.get_railroad_service().fetch_properties_for(instance)
                self.setTempPropDict(instance,dict)
            
            if not dict.has_key(tname):
                raise AttributeError(name)
            result=dict[tname]
        
            mapper = getattr(self, 'unmap_' + field.type, None)
            if mapper is not None:
                result = mapper(field, result)
    
            #print 'get:',name,repr(result),mapper
            return result
        except DAVNotFoundError:
            return None
        
    security.declarePrivate('set')
    def set(self, name, instance, value, **kwargs):
        field=instance.Schema()[name]

        mapper = getattr(self, 'map_' + field.type, None)
        if mapper is not None:
            value = mapper(field, value)

        tname=(unicode(field.getName()),unicode(getattr(field,'urn',field.getName())))
        srv=instance.get_railroad_service()
        if not srv:
            return
        dict={tname:unicode(str(value))}
        srv.set_properties_for(instance,dict)

        #print 'done railroad storage for field ',field.getName(),field

    security.declarePrivate('unset')
    def unset(self, name, instance, **kwargs):
        try:
            delattr(aq_base(instance), name)
        except AttributeError:
            pass    
        instance._p_changed = 1
