# File: PloneRailroadService.py
# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

"""\
unknown

RCS-ID $Id: codesnippets.py 2927 2004-08-30 01:59:11Z zworkb $
"""

# Generated: Tue Aug 31 02:21:07 2004
# Generator: ArchGenXML Version 1.2 devel 1 http://sf.net/projects/archetypes/

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <sales@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *

from Products.Railroad.service import RailroadService

##code-section module-header #fill in your manual code here
from Products.CMFCore.utils import getToolByName
from Products.CMFCore import CMFCorePermissions
from Products.Railroad import errors
##/code-section module-header


class PloneRailroadService(BaseContent,RailroadService):
    security = ClassSecurityInfo()
    portal_type = meta_type = 'PloneRailroadService' 
    archetype_name = 'PloneRailroadService'   #this name appears in the 'add' box 
    allowed_content_types = [] + getattr(RailroadService,'allowed_content_types',[])

    ##code-section class-header #fill in your manual code here

    #dict mapping RR operations to CMF permissions
    permission_map={'get':CMFCorePermissions.View,
                    'head':CMFCorePermissions.View,
                    'options':CMFCorePermissions.View,
                    'post':CMFCorePermissions.ModifyPortalContent,
                    'put':CMFCorePermissions.ModifyPortalContent,
                    'propfind':CMFCorePermissions.AccessContentsInformation,
                    'proppatch':CMFCorePermissions.ModifyPortalContent,
                    'delete':CMFCorePermissions.ModifyPortalContent,}
    
    ##/code-section class-header

    schema=BaseSchema  + getattr(RailroadService,'schema',Schema(())) + Schema((
        StringField('client_name',
            accessor='''client_name''',
            mutator='''set_client_name''',
            widget=StringWidget(description='Enter a value for client_name.',
                description_msgid='PloneRailroad_help_client_name',
                i18n_domain='PloneRailroad',
                label='Client_name',
                label_msgid='PloneRailroad_label_client_name',
            ),
        ),
        
        StringField('repo_url',
            accessor='''repo_url''',
            mutator='''set_repo_url''',
            widget=StringWidget(description='Enter a value for repo_url.',
                description_msgid='PloneRailroad_help_repo_url',
                i18n_domain='PloneRailroad',
                label='Repo_url',
                label_msgid='PloneRailroad_label_repo_url',
            ),
        ),
        
        StringField('repository_name',
            accessor='''repository_name''',
            mutator='''set_repository_name''',
            widget=StringWidget(description='Enter a value for repository_name.',
                description_msgid='PloneRailroad_help_repository_name',
                i18n_domain='PloneRailroad',
                label='Repository_name',
                label_msgid='PloneRailroad_label_repository_name',
            ),
        ),
        
        StringField('services_url',
            accessor='''services_url''',
            mutator='''set_services_url''',
            widget=StringWidget(description='Enter a value for services_url.',
                description_msgid='PloneRailroad_help_services_url',
                i18n_domain='PloneRailroad',
                label='Services_url',
                label_msgid='PloneRailroad_label_services_url',
            ),
        ),
        
    ),
    )

    #Methods
    #manually created methods

    def proxy_for_uuid(self, uuid):
        """Get the Railroad proxy object for this uuid.
        
        Return None if there's no proxy object to be found.
        here we simply have to consult the AT uid catalog
        """
        try:
            return getToolByName(self,'reference_catalog').lookupObject(uuid)
        except KeyError, e:
            raise errors.ProxyNotFoundError
        return proxy

    def register_proxy(self, proxy):
        """from IRailroadService: Register the given proxy object with this service instance.

        this method i overloaded by a dummy, since in the AT world we have automatic UID handling.
        """

    def __init__(self,*a,**kw):
#        import pdb;pdb.set_trace()
        BaseContent.__init__(self,*a,**kw)
        RailroadService.__init__(self,*a,**kw)

    def unregister_proxy(self, proxy):
        """from IRailroadService: Unregister (forget) the given proxy object.

        The mapping for the proxy is removed from this service instance.

        this method i overloaded by a dummy, since in the AT world we have automatic UID handling.
        """

    def _getPermissionForMethod(self,method):
        ''' returns the CMS permission that is associated 
        with a certain RR method'''
        
        perm= self.permission_map[method.strip().lower()]
        #print 'perm:',perm
        return perm


    # uncomment lines below when you need
    factory_type_information={
        'allowed_content_types':allowed_content_types,
        'allow_discussion': 0,
        #'content_icon':'PloneRailroadService.gif',
        'immediate_view':'base_view',
        'global_allow':0,
        'filter_content_types':1,
        }

        
    actions=  (
        

       {'action':      '''string:$object_url/railroad_service_test_form''',
        'category':    '''object''',
        'id':          'railroad_service_test_form',
        'name':        'Test Form',
        'permissions': ('''View''',),
        'condition'  : 'python:1'},
        

          )
        

registerType(PloneRailroadService)
# end of class PloneRailroadService

##code-section module-footer #fill in your manual code here
##/code-section module-footer


