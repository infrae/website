# File: PloneRailroadProxy.py
# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

"""\
unknown

RCS-ID $Id: codesnippets.py 2927 2004-08-30 01:59:11Z zworkb $
"""

# Generated: Tue Aug 31 02:21:07 2004
# Generator: ArchGenXML Version 1.2 devel 1 http://sf.net/projects/archetypes/
#

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <sales@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *

from Products.Railroad.proxy import RailroadProxy

##code-section module-header #fill in your manual code here
import urlparse
from RailroadStorage import RailroadStorage
from DateTime import DateTime
from Products.CMFCore.utils import getToolByName
from Products.CMFCore import CMFCorePermissions
class RailroadMetadataSchema(Schema):
    """Schema that enforces MetadataStorage."""

    def addField(self, field):
        """Strictly enforce the contract that metadata is stored w/o
        markup and make sure each field is marked as such for
        generation and introspcection purposes.
        """
        _properties = {'isMetadata': 1,
                       'storage':RailroadStorage(),
                       'schemata': 'metadata',
                       'generateMode': 'mVc',
                       'urn':'http://purl.org/dc/elements/1.1/'
                       }

        field.__dict__.update(_properties)
        field.registerLayer('storage', field.storage)

        Schema.addField(self, field)


dcRailroadSchema = RailroadMetadataSchema(
        (
        LinesField(
            'subject',
            multiValued=1,
            accessor="Subject",
            widget=KeywordWidget(
                label="Keywords",
                label_msgid="label_keywords",
                description_msgid="help_keyword",
                i18n_domain="plone"),
        ),
        TextField(
            'description',
            default='',
            searchable=1,
            accessor="Description",
            widget=TextAreaWidget(
                label='Description',
                description="An administrative summary of the content",
                label_msgid="label_description",
                description_msgid="help_description",
                i18n_domain="plone"),
        ),
        LinesField(
            'contributors',
            accessor="Contributors",
            widget=LinesWidget(
                label='Contributors',
                label_msgid="label_contributors",
                description_msgid="help_contributors",
                i18n_domain="plone"),
        ),
        LinesField(
            'creators',
            accessor="Creators",
            widget=LinesWidget(
                label='Creators',
                label_msgid="label_creators",
                description_msgid="help_creators",
                visible={'view':'hidden', 'edit':'hidden'},
                i18n_domain="plone"),
        ),
        DateTimeField(
            'effectiveDate',
            mutator = 'setEffectiveDate',
            languageIndependent = True,
            #default=FLOOR_DATE,
            widget=CalendarWidget(
                label="Effective Date",
                description=("Date when the content should become available "
                             "on the public site"),
                label_msgid="label_effective_date",
                description_msgid="help_effective_date",
                i18n_domain="plone"),
        ),
        DateTimeField(
            'expirationDate',
            mutator = 'setExpirationDate',
            languageIndependent = True,
            #default=CEILING_DATE,
            widget=CalendarWidget(
                label="Expiration Date",
                description=("Date when the content should no longer be "
                             "visible on the public site"),
                label_msgid="label_expiration_date",
                description_msgid="help_expiration_date",
                i18n_domain="plone"),
        ),

        StringField(
            'language',
            accessor="Language",
            default="en",
            default_method="defaultLanguage",
            vocabulary='languages',
            widget=SelectionWidget(
                label='Language',
                label_msgid="label_language",
                description_msgid="help_language",
                i18n_domain="plone"),
        ),
        TextField(
            'rights',
            accessor="Rights",
            widget=TextAreaWidget(
                label='Copyright',
                description="A list of copyright info for this content",
                label_msgid="label_copyrights",
                description_msgid="help_copyrights",
                i18n_domain="plone")),
        ))


##  Schema((
##        # XXX change this to MetadataSchema in AT 1.4
##        # Currently we want to stay backward compatible without migration
##        # between beta versions so creation and modification date are using the
##        # standard schema which leads to AttributeStorage
##        DateTimeField(
##            'creation_date',
##            accessor='created',
##            mutator='setCreationDate',
##            default_method=DateTime,
##            languageIndependent=True,
##            isMetadata=True,
##            schemata='metadata',
##            generateMode='mVc',
##            widget=CalendarWidget(
##                label="Creation Date",
##                description=("Date this object was created"),
##                label_msgid="label_creation_date",
##                description_msgid="help_creation_date",
##                i18n_domain="plone",
##                visible={'edit':'invisible', 'view':'invisible'}),
##        ),
##        DateTimeField(
##            'modification_date',
##            accessor='modified',
##            mutator = 'setModificationDate',
##            default_method=DateTime,
##            languageIndependent=True,
##            isMetadata=True,
##            schemata='metadata',
##            generateMode='mVc',
##            widget=CalendarWidget(
##                label="Modification Date",
##                description=("Date this content was modified last"),
##                label_msgid="label_modification_date",
##                description_msgid="help_modification_date",
##                i18n_domain="plone",
##                visible={'edit':'invisible', 'view':'invisible'}),
##        ),
##        ))

##/code-section module-header


class PloneRailroadProxy(BaseContent,RailroadProxy):
    security = ClassSecurityInfo()
    portal_type = meta_type = 'PloneRailroadProxy' 
    archetype_name = 'PloneRailroadProxy'   #this name appears in the 'add' box 
    allowed_content_types = [] + getattr(RailroadProxy,'allowed_content_types',[])

    ##code-section class-header #fill in your manual code here
    BaseSchema=BaseSchema+dcRailroadSchema
    ##/code-section class-header

    schema=BaseSchema  + getattr(RailroadProxy,'schema',Schema(())) + Schema((
        StringField('resource_path',
            accessor='''resource_path''',
            mutator='''set_resource_path''',
            mode='r',
            widget=StringWidget(description='Enter a value for resource_path.',
                description_msgid='PloneRailroad_help_resource_path',
                i18n_domain='PloneRailroad',
                label='Resource_path',
                label_msgid='PloneRailroad_label_resource_path',
                modes='''view''',
            ),
        ),

        ReferenceField('railroad_service',
            accessor='''get_railroad_service''',
            allowed_types=('RailroadService', 'PloneRailroadService'),
            multiValued=0,
            mutator='''set_railroad_service''',
            relationship='railroad_service',
            widget=ReferenceWidget(description='Enter a value for railroad_service.',
                description_msgid='PloneRailroad_help_railroad_service',
                i18n_domain='PloneRailroad',
                label='Railroad_service',
                label_msgid='PloneRailroad_label_railroad_service',
            ),
        ),
        
    ),
    )

    #Methods

    security.declareProtected('''''','uuid')
    def uuid(self):
        ''' '''
        return self.UID()

    #manually created methods

    def rr_upload_ok(self, url, errormsg, REQUEST):
        ''' '''
        service=self.get_railroad_service()
        repo_url_splitted=urlparse.urlsplit(service.repository_url())
        url_splitted=urlparse.urlsplit(url)
        
        parent_path=repo_url_splitted[2]
        new_path=list(repo_url_splitted[0:])
        new_path[2]=url_splitted[2][len(repo_url_splitted[2]):]
        
        #import pdb;pdb.set_trace()
        self.set_resource_path(new_path[2])
        REQUEST.RESPONSE.redirect(self.absolute_url()+'?portal_message='+errormsg)

    def rr_upload_error(self,url,errormsg,REQUEST):
        ''' '''
        raise 'RailroadException',errormsg

    def manage_afterAdd(self,item, container):
        BaseContent.manage_afterAdd(self,item,container)
        if self == item:
            srv=self.get_default_service()
            self.set_railroad_service(srv)

    def get_default_service(self):
        portal_railroad=getToolByName(self,'portal_railroad')
        res=self.portal_railroad.get_default_service()
        return res


    # uncomment lines below when you need
    factory_type_information={
        'allowed_content_types':allowed_content_types,
        'allow_discussion': 0,
        #'content_icon':'PloneRailroadProxy.gif',
        'immediate_view':'base_view',
        'global_allow':1,
        'filter_content_types':1,
        }

        
    actions=  (
        

       {'action':      '''string:$object_url/railroad_resource_test_form''',
        'category':    '''object''',
        'id':          'railroad_resource_test_form',
        'name':        'Test Form',
        'permissions': ('''View''',),
        'condition'  : 'python:1'},
        

       {'action':      '''string:$object_url/railroad_resource_upload_form''',
        'category':    '''object''',
        'id':          'railroad_resource_upload_form',
        'name':        'Upload',
        'permissions': ('''View''',),
        'condition'  : 'python:1'},
        

       {'action':      '''string:$object_url/railroad_resource_view''',
        'category':    '''object''',
        'id':          'view',
        'name':        'view',
        'permissions': ('''View''',),
        'condition'  : 'python:1'},
        

          )
        

registerType(PloneRailroadProxy)
# end of class PloneRailroadProxy

##code-section module-footer #fill in your manual code here
##/code-section module-footer


