# File: RailroadTool.py
# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

"""\
unknown

RCS-ID $Id: codesnippets.py 2927 2004-08-30 01:59:11Z zworkb $
"""

# Generated: Tue Aug 31 02:21:07 2004
# Generator: ArchGenXML Version 1.2 devel 1 http://sf.net/projects/archetypes/

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <sales@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *


##code-section module-header #fill in your manual code here
##/code-section module-header



from Products.CMFCore.utils import UniqueObject

    
class RailroadTool(UniqueObject,BaseFolder):
    security = ClassSecurityInfo()
    portal_type = meta_type = 'RailroadTool' 
    archetype_name = 'RailroadTool'   #this name appears in the 'add' box 
    allowed_content_types = ['PloneRailroadService'] 

    ##code-section class-header #fill in your manual code here
    ##/code-section class-header

    schema=BaseFolderSchema  + Schema((

        ReferenceField('default_service',
            accessor='''get_default_service''',
            allowed_types=('PloneRailroadService',),
            multiValued=0,
            mutator='''set_default_service''',
            relationship='sm$99176f:fe810ccaa5:-7481',
            widget=ReferenceWidget(description='Enter a value for default_service.',
                description_msgid='PloneRailroad_help_default_service',
                i18n_domain='PloneRailroad',
                label='Default_service',
                label_msgid='PloneRailroad_label_default_service',
            ),
        ),
        
    ),
    )

    # tool-constructors have no id argument, the id is fixed
    def __init__(self, id=None):
        BaseFolder.__init__(self,'portal_railroad')
        
        ##code-section constructor-footer #fill in your manual code here
        ##/code-section constructor-footer



    #Methods


    # uncomment lines below when you need
    factory_type_information={
        'allowed_content_types':allowed_content_types,
        'allow_discussion': 0,
        #'content_icon':'RailroadTool.gif',
        'immediate_view':'base_view',
        'global_allow':0,
        'filter_content_types':1,
        }

        
    actions=  (
        

          )
        

registerType(RailroadTool)
# end of class RailroadTool

##code-section module-footer #fill in your manual code here
##/code-section module-footer


