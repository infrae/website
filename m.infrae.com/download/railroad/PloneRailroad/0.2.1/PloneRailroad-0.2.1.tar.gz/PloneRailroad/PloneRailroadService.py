# File: PloneRailroadService.py
# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <jw@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *

from Products.CMFCore.utils import getToolByName
from Products.CMFCore import CMFCorePermissions

from Products.Railroad import errors, service

class PloneRailroadService(BaseContent, service.Service):
    
    security = ClassSecurityInfo()

    portal_type = meta_type = 'Plone Railroad Service' 
    
    archetype_name = 'Railroad Service'   #this name appears in the 'add' box 
    
    allowed_content_types = []

    # Dict mapping RR operations to CMF permissions
    _permission_map = {
        'get': CMFCorePermissions.View,
        'head': CMFCorePermissions.View,
        'options': CMFCorePermissions.View,
        'post': CMFCorePermissions.ModifyPortalContent,
        'put': CMFCorePermissions.ModifyPortalContent,
        'propfind': CMFCorePermissions.AccessContentsInformation,
        'proppatch': CMFCorePermissions.ModifyPortalContent,
        'delete': CMFCorePermissions.ModifyPortalContent,
        }
    
    schema = BaseSchema + Schema((
        StringField('my_client_name',
            accessor='client_name',
            mutator='set_client_name',
            widget=StringWidget(description='Enter a value for client_name.',
                description_msgid='PloneRailroad_help_client_name',
                i18n_domain='PloneRailroad',
                label='Client_name',
                label_msgid='PloneRailroad_label_client_name',
            ),
        ),
        
        StringField('my_repository_url',
            accessor='repository_url',
            mutator='set_repository_url',
            widget=StringWidget(description='Enter a value for repo_url.',
                description_msgid='PloneRailroad_help_repo_url',
                i18n_domain='PloneRailroad',
                label='Repo_url',
                label_msgid='PloneRailroad_label_repo_url',
            ),
        ),
        
        StringField('my_repository_name',
            accessor='repository_name',
            mutator='set_repository_name',
            widget=StringWidget(description='Enter a value for repository_name.',
                description_msgid='PloneRailroad_help_repository_name',
                i18n_domain='PloneRailroad',
                label='Repository_name',
                label_msgid='PloneRailroad_label_repository_name',
            ),
        ),
        
        StringField('my_services_url',
            accessor='services_url',
            mutator='set_services_url',
            widget=StringWidget(description='Enter a value for services_url.',
                description_msgid='PloneRailroad_help_services_url',
                i18n_domain='PloneRailroad',
                label='Services_url',
                label_msgid='PloneRailroad_label_services_url',
            ),
        ),
        
    ),
    )

    factory_type_information = {
        'allowed_content_types': allowed_content_types,
        'allow_discussion': 0,
        #'content_icon':'PloneRailroadService.gif',
        'immediate_view':'base_view',
        'global_allow':0,
        'filter_content_types':1,
        }

    actions = (
        {'action':      'string:$object_url/railroad_service_test_form',
        'category':    'object',
        'id':          'railroad_service_test_form',
        'name':        'Test Form',
        'permissions': ('View',),
        'condition'  : 'python:1'},
        )

    client_name = AT_GENERATE_METHOD
    
    repository_url = AT_GENERATE_METHOD
    
    repository_name = AT_GENERATE_METHOD
    
    services_url = AT_GENERATE_METHOD
        
    def __init__(self, *a, **kw):
        service.Service.__init__(
            self, '/foo/bar/', '/foo/bar/', 'baz', 'qux')
        BaseContent.__init__(self, *a, **kw)
    
    def proxy_for_unique_id(self, unique_id):
        """Get the Railroad proxy object for this unique id.
        
        Return None if there's no proxy object to be found.
        here we simply have to consult the AT uid catalog
        """
        try:
            tool = getToolByName(self, 'reference_catalog' )
            object = tool.lookupObject(unique_id)
            return object
        except KeyError, e:
            raise errors.ProxyNotFoundError

    def register_proxy(self, proxy):
        """from IRailroadService: Register the given proxy object with 
        this service instance.

        This method is overloaded by a dummy, since in the AT world 
        we have automatic UID handling.
        """
        pass

    def unregister_proxy(self, proxy):
        """from IRailroadService: Unregister (forget) the given proxy object.

        The mapping for the proxy is removed from this service instance.

        This method I overloaded by a dummy, since in the AT world 
        we have automatic UID handling.
        """
        pass

    def _getPermissionForMethod(self,method):
        """Returns the CMS permission that is associated 
        with a certain RR method
        """
        method = method.strip().lower()
        perm = self._permission_map[method]
        return perm

registerType(PloneRailroadService)
