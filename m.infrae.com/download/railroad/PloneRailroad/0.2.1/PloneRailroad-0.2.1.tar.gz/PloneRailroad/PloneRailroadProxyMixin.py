# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <jw@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *

import urlparse
from DateTime import DateTime
from Products.CMFCore.utils import getToolByName
from Products.CMFCore import CMFCorePermissions

from Products.Railroad import proxy
from Products.PloneRailroad import RailroadStorage

class RailroadMetadataSchema(Schema):
    """Schema that enforces MetadataStorage.
    """

    def addField(self, field):
        """Strictly enforce the contract that metadata is stored w/o
        markup and make sure each field is marked as such for
        generation and introspcection purposes.
        """
        
        _properties = {
            'isMetadata': 1,
            'storage': RailroadStorage.RailroadStorage(),
            'schemata': 'metadata',
            'generateMode': 'mVc',
            'urn':'http://purl.org/dc/elements/1.1/'
            }

        field.__dict__.update(_properties)
        field.registerLayer('storage', field.storage)

        Schema.addField(self, field)

dcRailroadSchema = RailroadMetadataSchema(
        (
        LinesField(
            'subject',
            multiValued=1,
            accessor="Subject",
            widget=KeywordWidget(
                label="Keywords",
                label_msgid="label_keywords",
                description_msgid="help_keyword",
                i18n_domain="plone"),
        ),
        TextField(
            'description',
            default='',
            searchable=1,
            accessor="Description",
            widget=TextAreaWidget(
                label='Description',
                description="An administrative summary of the content",
                label_msgid="label_description",
                description_msgid="help_description",
                i18n_domain="plone"),
        ),
        LinesField(
            'contributors',
            accessor="Contributors",
            widget=LinesWidget(
                label='Contributors',
                label_msgid="label_contributors",
                description_msgid="help_contributors",
                i18n_domain="plone"),
        ),
        LinesField(
            'creators',
            accessor="Creators",
            widget=LinesWidget(
                label='Creators',
                label_msgid="label_creators",
                description_msgid="help_creators",
                visible={'view':'hidden', 'edit':'hidden'},
                i18n_domain="plone"),
        ),
        DateTimeField(
            'effectiveDate',
            mutator = 'setEffectiveDate',
            languageIndependent = True,
            #default=FLOOR_DATE,
            widget=CalendarWidget(
                label="Effective Date",
                description=("Date when the content should become available "
                             "on the public site"),
                label_msgid="label_effective_date",
                description_msgid="help_effective_date",
                i18n_domain="plone"),
        ),
        DateTimeField(
            'expirationDate',
            mutator = 'setExpirationDate',
            languageIndependent = True,
            #default=CEILING_DATE,
            widget=CalendarWidget(
                label="Expiration Date",
                description=("Date when the content should no longer be "
                             "visible on the public site"),
                label_msgid="label_expiration_date",
                description_msgid="help_expiration_date",
                i18n_domain="plone"),
        ),

        StringField(
            'language',
            accessor="Language",
            default="en",
            default_method="defaultLanguage",
            vocabulary='languages',
            widget=SelectionWidget(
                label='Language',
                label_msgid="label_language",
                description_msgid="help_language",
                i18n_domain="plone"),
        ),
        TextField(
            'rights',
            accessor="Rights",
            widget=TextAreaWidget(
                label='Copyright',
                description="A list of copyright info for this content",
                label_msgid="label_copyrights",
                description_msgid="help_copyrights",
                i18n_domain="plone")),
        ))

class Mixin(proxy.Proxy):

    security = ClassSecurityInfo()
    
    schema = dcRailroadSchema + Schema((
        StringField('my_resource_path',
            accessor='resource_path',
            mutator='set_resource_path',
            widget=StringWidget(description='Enter a value for resource_path.',
                description_msgid='PloneRailroad_help_resource_path',
                i18n_domain='PloneRailroad',
                label='Resource_path',
                label_msgid='PloneRailroad_label_resource_path',
                modes='view',
                ),
            ),
        ReferenceField('railroad_service',
            accessor='get_railroad_service',
            mutator='set_railroad_service',
            allowed_types=('Railroad Service', 'Plone Railroad Service'),
            multiValued=0,
            relationship='railroad_service',
            widget=ReferenceWidget(description='Enter a value for railroad_service.',
                description_msgid='PloneRailroad_help_railroad_service',
                i18n_domain='PloneRailroad',
                label='Railroad_service',
                label_msgid='PloneRailroad_label_railroad_service',
                ),
            ),
        ),
    )
       
    resource_path = AT_GENERATE_METHOD
    
    set_resource_path = AT_GENERATE_METHOD
    
    get_railroad_service = AT_GENERATE_METHOD
    
    set_railroad_service = AT_GENERATE_METHOD
    
    actions = (
       {'action':      '''string:$object_url/proxy_metadata''',
        'category':    '''object''',
        'id':          'metadata',
        'name':        'Properties',
        'permissions': ('''Modify Portal Content''',),
        'condition'  : 'python:1'},
       {'action':      'string:$object_url/railroad_resource_upload_form',
       'category':    'object',
       'id':          'railroad_resource_upload_form',
       'name':        'Upload',
       'permissions': ('View',),
       'condition'  : 'python:1'},
       )
       
    security.declareProtected('View', 'unique_id')
    def unique_id(self):
        """Return the unique id of this proxy.
        """
        return self.UID()
    
    security.declareProtected('View', 'on_upload_succeeded')
    def on_upload_succeeded(self, url, errormsg):
        """Notifies proxy of a succesful resource upload to the Railroad
        repository.
        
        Method should be publishable (i.e., the implementation needs
        to have a doc string).
        """
        proxy.Proxy.on_upload_succeeded(self, url, errormsg)
        request = self.REQUEST
        redirect_url = self.absolute_url() + '?portal_message=' + errormsg
        request.RESPONSE.redirect(redirect_url)
    
    security.declareProtected('View', 'on_upload_failed')
    def on_upload_failed(self, url, errormsg):
        """Notifies proxy of a failed resource upload to the Railroad
        repository.
        
        Method should be publishable (i.e., the implementation needs
        to have a doc string).
        """
        proxy.Proxy.on_upload_failed(self, url, errormsg)
        raise errors.RailroadError(errormsg + ' ' + url)
    
    def manage_afterAdd(self, item, container):
        if self == item:
            srv = self.get_default_service()
            self.set_railroad_service(srv)

    def get_default_service(self):
        portal_railroad = getToolByName(self, 'portal_railroad')
        res = self.portal_railroad.get_default_service()
        return res
