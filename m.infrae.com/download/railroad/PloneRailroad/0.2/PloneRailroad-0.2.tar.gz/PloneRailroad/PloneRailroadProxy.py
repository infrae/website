# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

__author__  = 'Philipp Auersperg, Jan Wijbrand Kolman <jw@infrae.com>'
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.public import *

import urlparse
from DateTime import DateTime
from Products.CMFCore.utils import getToolByName
from Products.CMFCore import CMFCorePermissions

from Products.Railroad import proxy
from Products.PloneRailroad import RailroadStorage, PloneRailroadProxyMixin

class PloneRailroadProxy(BaseContent, PloneRailroadProxyMixin.Mixin):
    
    security = ClassSecurityInfo()

    portal_type = meta_type = 'Plone Railroad Proxy' 
    
    archetype_name = 'PloneRailroadProxy'
    
    allowed_content_types = []

    schema = BaseSchema + PloneRailroadProxyMixin.Mixin.schema
    
    factory_type_information = {
        'allowed_content_types': allowed_content_types,
        'allow_discussion': 0,
        #'content_icon':'PloneRailroadProxy.gif',
        'immediate_view':'base_view',
        'global_allow':1,
        'filter_content_types':1,
        }
        
    actions = (
       {'action':      'string:$object_url/railroad_resource_test_form',
       'category':    'object',
       'id':          'railroad_resource_test_form',
       'name':        'Test Form',
       'permissions': ('View',),
       'condition'  : 'python:1'},
       {'action':      'string:$object_url/railroad_resource_upload_form',
       'category':    'object',
       'id':          'railroad_resource_upload_form',
       'name':        'Upload',
       'permissions': ('View',),
       'condition'  : 'python:1'},
       {'action':      'string:$object_url/railroad_resource_view',
       'category':    'object',
       'id':          'view',
       'name':        'view',
       'permissions': ('View',),
       'condition'  : 'python:1'},
       )

registerType(PloneRailroadProxy)
