Copyright (c) 2004 Infrae. All rights reserved.
See also LICENSE.txt

This Zope Product is a basic Archetypes based implementation of the
Railroad interfaces for Plone.

See also TODO.txt

See also README.txt of the railroad 'server' package

Dependencies
------------

* Railroad for Zope

  http://www.infrae.com/download/Railroad


Thank you
---------

The Infrae team would also like to thank the UK Defence Academy for their
support during the development of PloneRailroad. 


Credits
-------

Infrae Railroad team:

  Kit Blake <kitblake@infrae.com>
  Jan-Wijbrand Kolman <jw@infrae.com>
  Guido Goldstein <gst@infrae.com>

External developers:

  Godefroid Chapelle <gotcha@swing.be>
  Philipp Auersperg <phil@bluedynamics.com>


Appendix
--------

If you have comments, you can use one (or more:) of the following
methods to contact the developers:

Mailinglist subscription:
  http://codespeak.net/mailman/listinfo/railroad-dev

Mailinglist for checkin messages:
  http://codespeak.net/mailman/listinfo/rr-checkins

Issue tracker:
  http://codespeak.net/issues/railroad/

IRC:
  irc.freenode.net, #railroad

Project homepage:
  http://www.infrae.com/products/railroad
