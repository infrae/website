Directory 'skins/PloneRailroad_public':

This skin layer has highest priority, put templates and scripts here that are
supposed to overload existing ones.

I.e. if you want to change want a site-wide change of Archetypes skins
base_edit, base_view, etc or also Plone skins like main_template or
document_view, put it in here.
