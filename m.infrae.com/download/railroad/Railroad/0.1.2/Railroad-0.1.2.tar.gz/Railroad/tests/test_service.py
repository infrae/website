# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import os, sys, time
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from Testing import ZopeTestCase
from OFS import SimpleItem

ZopeTestCase.installProduct('Railroad')


from sets import Set

class TestProxy(SimpleItem.SimpleItem):
    
    def __init__(self, id, title, uuid):
        self.id = id
        self.title = title
        self._uuid = uuid
    
    def uuid(self):
        return self._uuid

class RailroadServiceTestCase(ZopeTestCase.ZopeTestCase):

    def afterSetUp(self):
        self.root = self._app()
        self.root.manage_addProduct['Railroad'].manage_addRailroadService(
            'Testable Railroad Service', 'http://foo.bar.com/repo', 'services_url', 
            'storage_id', 'client_id')
        self._service = self.root.railroad_service
        
    def test_repository_url(self):
        self.assertEquals(
            self._service.repository_url(), 'http://foo.bar.com/repo')

    def test_services_url(self):
        self.assertEquals(self._service.services_url(), 'services_url')

    def test_storage_id(self):
        self.assertEquals(self._service.repository_name(), 'storage_id')

    def test_client_id(self):
        self.assertEquals(self._service.client_name(), 'client_id')
        
    def test_generate_uuid(self):
        ids = Set()
        for i in range(10):
            id = self._service.generate_uuid()
            self.assert_(id not in ids)
            ids.add(id)
            
    def test_register_proxy(self):
        uuid = self._service.generate_uuid()
        proxy = TestProxy('proxy_1', 'Proxy 1', uuid)
        self._service.register_proxy(proxy)
        self.assert_(uuid in self._service._uuid_to_path)
        path = proxy.getPhysicalPath()
        self.assert_(path in self._service._path_to_uuid)
    
    def test_unregister_proxy(self):
        uuid = self._service.generate_uuid()
        proxy = TestProxy('proxy_1', 'Proxy 1', uuid)
        self._service.register_proxy(proxy)
        self._service.unregister_proxy(proxy)
        self.assert_(uuid not in self._service._uuid_to_path)
        path = proxy.getPhysicalPath()
        self.assert_(path not in self._service._path_to_uuid)
        
    def test_dav(self):
        # Get REQUEST in shape
        request = self.request = self.app.REQUEST
        request['PARENTS'] = [self.app]
        request.setServerURL(
            protocol='http', hostname='foo.bar.com', port='80')
        request.setVirtualRoot(('',))
        davobj = TestProxy('dav_object', 'DAV Object1', 1)
        self.root._setObject('dav_object', davobj)
        davobj = self.root.dav_object
        print davobj.getPhysicalPath()
        url = davobj.absolute_url()
        print 'url ' + url
        pass
    
if __name__ == '__main__':
    framework()
else:
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(RailroadServiceTestCase))
        return suite
