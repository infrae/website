# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

class RailroadError(Exception):
    pass

class ProxyNotFoundError(RailroadError):
    pass

class ProxyNotAssignedError(RailroadError):
    pass

class ServiceNotFoundError(RailroadError):
    pass

class InvalidPathError(ValueError):
    pass

class InvalidURLError(ValueError):
    pass
