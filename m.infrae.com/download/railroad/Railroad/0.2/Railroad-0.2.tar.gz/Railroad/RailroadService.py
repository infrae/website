# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

# Zope
from OFS import SimpleItem
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo, Permissions
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
# Railroad
from Products.Railroad import service, errors, utils

class RailroadService(service.Service, SimpleItem.SimpleItem):
    """Zope wrapped Service object
    """

    meta_type = 'Railroad Service'

    security = ClassSecurityInfo()

    manage_options = (
        {'label':'Edit', 'action':'manage_railroadServiceEditForm'},
        {'label':'Test', 'action':'manage_railroadServiceTestForm'},
        ) + SimpleItem.SimpleItem.manage_options

    management_page_charset = 'utf-8'

    def __init__(
        self, id, title, repo_url, services_url, repository_name, client_name):
        self.id = id
        self.title = title
        service.Service.__init__(
            self, repo_url, services_url, repository_name, client_name)

    security.declareProtected('View management screens', 'set_repository_url')
    def set_repository_url(self, repository_url):
        if not repository_url.endswith('/'):
            raise errors.InvalidURLError(
                'The repository URL should end with a slash')
        self._repository_url = repository_url

    security.declareProtected('View management screens', 'set_services_url')
    def set_services_url(self, services_url):
        if not services_url.endswith('/'):
            raise errors.InvalidURLError(
                'The services URL should end with a slash')
        self._services_url = services_url
        
    security.declareProtected(
        'View management screens', 'set_repository_name')
    def set_repository_name(self, name):
        self._repository_name = name

    security.declareProtected('View management screens', 'set_client_name')
    def set_client_name(self, name):
        self._client_name = name

    security.declareProtected(
        'View management screens', 'manage_railroadServiceEdit')
    def manage_railroadServiceEdit(
        self, title, repository_url, services_url, repository_name, client_name, 
        REQUEST=None):
        """Edit settings for this basic Zope Railroad service object
        """

        msg = ['Settings changed.',]
        
        if title:
            self.title = title
        
        if repository_url:
            if not repository_url.endswith('/'):
                repository_url = repository_url + '/'
                msg.append('"/" appended to repository URL.')
            self.set_repository_url(repository_url)

        if services_url:
            if not services_url.endswith('/'):
                services_url = services_url + '/'
                msg.append('"/" appended to services URL.')
            self.set_services_url(services_url)

        if repository_name:
            self.set_repository_name(repository_name)
            
        if client_name:
            self.set_client_name(client_name)
            
        msg = ' '.join(msg)
        if REQUEST is not None:
            return self.manage_railroadServiceEditForm(manage_tabs_message=msg)
        return msg

    security.declareProtected(
        'View management screens', 'manage_railroadServiceEditForm')
    manage_railroadServiceEditForm = PageTemplateFile(
        'www/railroadServiceEdit', globals(),  
        __name__='manage_railroadServiceEditForm')

    security.declareProtected(
        'View management screens', 'manage_railroadServiceTestForm')
    manage_railroadServiceTestForm = PageTemplateFile(
        'www/railroadServiceTest', globals(),  
        __name__='manage_railroadServiceTestForm')

    security.declareProtected('View management screens', 'manage_main')
    manage_main = manage_railroadServiceEditForm
        
InitializeClass(RailroadService)

manage_addRailroadServiceForm = PageTemplateFile(
    "www/railroadServiceAdd", globals(), __name__='manage_addRailroadServiceForm')

def manage_addRailroadService(
    context, id, title, repository_url, services_url, repository_name, client_name, 
    REQUEST=None):    
    """Add a basic Zope Railroad Service object
    """
    if not repository_url.endswith('/'):
        repository_url = repository_url + '/'

    if not services_url.endswith('/'):
        services_url = services_url + '/'
    
    service = RailroadService(
        id, title, repository_url, services_url, repository_name, client_name)
    context._setObject(id, service)
    service = getattr(context, id)
    utils.add_and_edit(context, id, REQUEST)
    return service
