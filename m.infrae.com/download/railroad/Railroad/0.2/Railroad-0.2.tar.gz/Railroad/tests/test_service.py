# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import os, sys, time
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))
    
# Python
from sets import Set
# Testing
from Testing import ZopeTestCase

ZopeTestCase.installProduct('Railroad')

from OFS import SimpleItem
from Products.Railroad import errors as rr_errors

from testables import TestableService, TestableProxy

class RailroadServiceTestCase(ZopeTestCase.ZopeTestCase):

    _service_url = 'http://localhost:32080/service/'
    _repo_url = 'http://localhost:32080/repo/'
    _test_url = 'http://localhost:32080/repo/image/jpeg/000/xxx.jpg'
    _test_path = 'image/jpeg/000/xxx.jpg'

    def afterSetUp(self):
        self.root = self._app()
        # Setup a service
        service = TestableService(
            'testableservice', 
            'Testable Railroad Service',
            self._repo_url, 
            self._service_url, 
            'storage_id', 
            'client_id')
        self.root.testableservice = service
        self._service = self.root.testableservice

    def test_get_railroad_service(self):
        # See if we can get to the Railroad service via acquisition
        someobject = SimpleItem.SimpleItem()
        self._service.someobject = someobject
        someobject = self._service.someobject
        self.assertEquals(self._service, someobject.get_railroad_service())
        
    def test_repository_url(self):
        expected = self._repo_url
        self.assertEquals(
            expected,
            self._service.repository_url())
        self.assertRaises(
            rr_errors.InvalidURLError,
            TestableService,
            'testableservice', 
            'Testable Railroad Service',
            'http://testing.123.com/rr/repository', 
            'http://testing.123.com/rr/service/', 
            'storage_id', 
            'client_id')

    def test_services_url(self):
        expected = self._service_url
        self.assertEquals(
            expected,
            self._service.services_url())
        self.assertRaises(
            rr_errors.InvalidURLError,
            TestableService,
            'testableservice', 
            'Testable Railroad Service',
            'http://testing.123.com/rr/repository/', 
            'http://testing.123.com/rr/service', 
            'storage_id', 
            'client_id')

    def test_storage_id(self):
        self.assertEquals(self._service.repository_name(), 'storage_id')

    def test_client_id(self):
        self.assertEquals(self._service.client_name(), 'client_id')
        
    def test_generate_unique_id(self):
        pass # disabled for now, dunno how to test this yet
        
    def test_register_proxy(self):
        unique_id = 1 # unique in this context
        proxy = TestableProxy('proxy_1', 'Proxy 1', unique_id)
        self.root._setObject('proxy_1', proxy)
        proxy = self.root.proxy_1
        self._service.register_proxy(proxy)
        self.assertEquals(
            proxy, self._service.proxy_for_unique_id(unique_id))
    
    def test_unregister_proxy(self):
        unique_id = 2 # unique in this context
        proxy = TestableProxy('proxy_2', 'Proxy 2', unique_id)
        self.root._setObject('proxy_2', proxy)
        proxy = self.root.proxy_2
        self._service.register_proxy(proxy)
        self._service.unregister_proxy(proxy)
        self.assertRaises(
            rr_errors.ProxyNotFoundError, 
            self._service.proxy_for_unique_id,
            unique_id)

    #def test_proxy_for_unique_id(self):
    #    # Implicitly tested by test_unregister_proxy and test_register_proxy
    #    # XXX Is this enough?
    #    pass
            
    def test_resource_url_for(self):
        unique_id = 3 # unique in this context
        proxy = TestableProxy('proxy_3', 'Proxy 3', unique_id)
        self.root._setObject('proxy_3', proxy)
        proxy = self.root.proxy_3
        self._service.register_proxy(proxy)
        self.assertRaises(
            rr_errors.ProxyNotAssignedError, 
            self._service.resource_url_for,
            proxy)
        proxy.set_resource_path(self._test_path)
        expected = self._test_url
        self.assertEquals(
            expected,
            self._service.resource_url_for(proxy))
            
    def test_fetch_properties_for(self):
        pass # disabled for now, dunno how to test this yet

    def test_set_properties_for(self):
        pass # disabled for now, dunno how to test this yet

if __name__ == '__main__':
    framework()
else:
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(RailroadServiceTestCase))
        return suite
