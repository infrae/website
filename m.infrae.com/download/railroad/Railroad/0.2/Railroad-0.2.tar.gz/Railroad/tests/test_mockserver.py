# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

import os
import urllib
import urlparse
import time

import dav

import unittest

import testables, mockserver

###

SERVER = testables.SERVER
PID = testables.PID

class MockServerTestCase ( unittest.TestCase ):

    def setUp ( self ):
        self.base_url = SERVER.base_url()
        return

    def test_01_connect ( self ):
        """Test if we can connect to the mock server.
        """
        url = self.base_url
        con = urllib.urlopen(url)
        con.close()
        return

    def test_02_get ( self ):
        """Test if we can get something from the mock server.
        """
        url = urlparse.urljoin(self.base_url, 'repo/image/jpeg/000/xxx.jpg')
        con = urllib.urlopen(url)
        data = con.read()
        con.close()
        self.assertEquals(1000, len(data))
        return

    def test_03_dav_connection ( self ):
        """Test if a dav connection can be established.
        """
        url = urlparse.urljoin(self.base_url, 'repo/image/jpeg/000/xxx.jpg')
        con = dav.DAVConnection('localhost', 32080)
        con.close()
        return

    def test_04_dav_collection ( self ):
        """Test if a dav collection can be used.
        """
        url = urlparse.urljoin(self.base_url, 'repo/image/jpeg/000/xxx.jpg')
        con = dav.DAVConnection('localhost', 32080)
        coll = dav.DAVCollection('/', con)
        coll.update()
        props = coll.get_all_properties()
        del coll
        con.close()
        return

    def test_05_dav_file ( self ):
        """Test if a dav file can be used.
        """
        return # disabled for now - needs some work in the mockserver
        
        url = '/repo/image/jpeg/000/xxx.jpg'
        con = dav.DAVConnection('localhost', 32080)
        dfile = dav.DAVFile(url, con)
        dfile.update()
        props = dfile.get_all_properties()
        del dfile
        con.close()
        return

    def test_20_service_uuid ( self ):
        """Test if the uuid generator works.
        """
        url = urlparse.urljoin(self.base_url, 'service/uuid/')
        con = urllib.urlopen(url)
        data = con.read()
        con.close()
        self.assertEquals('f280a956-0c87-11d9-a3a4-00d0b7e8a31c', data)
        return

if __name__ == '__main__':
    framework()
else:
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(MockServerTestCase))
        return suite
