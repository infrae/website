# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

# testable implementations
# Zope
from OFS import SimpleItem
# Railroad
from Products.Railroad import service, proxy

# Setup and start test Railroad Server
import os, time
import atexit
import mockserver

SERVER = mockserver.MockServer()
PID = SERVER.start()

def _atexit ():
    print 'Killing mock server...'
    os.kill(PID, 15)
    return

atexit.register(_atexit)
time.sleep(0.1)

class TestableService(service.Service, SimpleItem.SimpleItem):
    
    def __init__(self, id, title, *args):
        self.id = id
        self.title = title
        service.Service.__init__(self, *args)
        
class TestableProxy(proxy.Proxy, SimpleItem.SimpleItem):

    def __init__(self, id, title, *args):
        self.id = id
        self.title = title
        proxy.Proxy.__init__(self, *args)
