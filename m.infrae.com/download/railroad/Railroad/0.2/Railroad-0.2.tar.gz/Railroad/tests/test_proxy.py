# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import os, sys, time
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))
    
# Testing
from Testing import ZopeTestCase

ZopeTestCase.installProduct('Railroad')

from OFS import SimpleItem
from Products.Railroad import errors as rr_errors

from testables import TestableService, TestableProxy

class RailroadProxyTestCase(ZopeTestCase.ZopeTestCase):

    _service_url = 'http://localhost:32080/service/'
    _repo_url = 'http://localhost:32080/repo/'
    _test_url = 'http://localhost:32080/repo/image/jpeg/000/xxx.jpg'
    _test_path = 'image/jpeg/000/xxx.jpg'
    
    def afterSetUp(self):
        self.root = self._app()
        # Setup a service
        service = TestableService(
            'testableservice', 
            'Testable Railroad Service',
            self._repo_url, 
            self._service_url, 
            'storage_id', 
            'client_id')
        self.root.testableservice = service
        self._service = self.root.testableservice
        unique_id = 'a' # unique in this context
        proxy = TestableProxy('a_proxy', 'A Proxy', unique_id)
        self.root._setObject('a_proxy', proxy)
        self._proxy = self.root.a_proxy

    def test_get_railroad_service(self):
        self.assertRaises(
            rr_errors.ServiceNotFoundError, self._proxy.get_railroad_service)
        self._proxy.set_railroad_service(self._service)
        self.assertEquals(self._service, self._proxy.get_railroad_service())
        
    def test_unique_id(self):
        self.assertEquals('a', self._proxy.unique_id())

    def test_has_resource(self):
        self.assertEquals(False, self._proxy.has_resource())
        self._proxy.set_resource_path('foo/bar/baz')
        self.assertEquals(True, self._proxy.has_resource())

    def test_is_associated_to_service(self):
        self.assertEquals(False, self._proxy.is_associated_to_service())
        self._proxy.set_railroad_service(self._service)
        self.assertEquals(True, self._proxy.is_associated_to_service())
        
    def test_resource_path(self):
        self.assertEquals(None, self._proxy.resource_path())
        self._proxy.set_resource_path('foo/bar/baz')
        self.assertEquals('foo/bar/baz', self._proxy.resource_path())

    def test_resource_url(self):
        self.assertRaises(
            rr_errors.ServiceNotFoundError, self._proxy.resource_url)
        self._proxy.set_railroad_service(self._service)
        self.assertRaises(
            rr_errors.ProxyNotAssignedError, self._proxy.resource_url)
        self._proxy.set_resource_path('foo/bar/baz')
        self.assertEquals(
            self._service.repository_url() + 'foo/bar/baz', 
            self._proxy.resource_url())
            
    def test_set_railroad_service(self):
        service2 = TestableService(
            'testableservice2', 
            'Testable Railroad Service 2',
            self._repo_url, 
            self._service_url, 
            'storage_id', 
            'client_id')
        self.root.testableservice2 = service2
        service = self.root.testableservice
        service2 = self.root.testableservice2
        proxy = self._proxy
        proxy.set_railroad_service(service)
        self.assertEquals(
            proxy, service.proxy_for_unique_id(proxy.unique_id()))
        proxy.set_railroad_service(service2)
        self.assertRaises(
            rr_errors.ProxyNotFoundError,
            service.proxy_for_unique_id, proxy.unique_id())
        self.assertEquals(
            proxy, service2.proxy_for_unique_id(proxy.unique_id()))
            
    def test_set_resource_path(self):
        # See also test_resource_url and test_resource_path
        self._proxy.set_railroad_service(self._service)
        self.assertRaises(
            rr_errors.InvalidPathError,
            self._proxy.set_resource_path,
            '/foo/bar/baz')
        self._proxy.set_resource_path('foo/bar/baz')
        self.assertEquals('foo/bar/baz', self._proxy.resource_path())

    def test_on_upload_succeeded(self):
        url = self._service.repository_url() + 'foo/bar/baz'
        error_message = 'Something happened'
        self._proxy.set_railroad_service(self._service)
        self.assertEquals(
            None, self._proxy.on_upload_succeeded(url, error_message))
        self.assertEquals('foo/bar/baz', self._proxy.resource_path())
    
    def test_on_upload_failed(self):
        url = self._service.repository_url() + 'foo/bar/baz'
        error_message = 'Something happened'
        self.assertEquals(
            None, self._proxy.on_upload_failed(url, error_message))
        
    # Dunno about these yet..:
    #
    #def test_fetch_properties(self):
    #    pass
    #
    #def test_set_properties(self):
    #    pass
    #
    #def test_on_create():
    #    pass
    #
    #def test_on_paste():
    #    pass
    #
    #def test_on_delete():
    #    pass

if __name__ == '__main__':
    framework()
else:
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(RailroadProxyTestCase))
        return suite
