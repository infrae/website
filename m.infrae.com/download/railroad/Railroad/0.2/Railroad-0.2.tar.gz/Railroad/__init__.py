# Copyright (c) 2004 Infrae. All rights reserved.
# See also LICENSE.txt

import RailroadService, RailroadProxy

def initialize(context):
    context.registerClass(
        RailroadService.RailroadService,
        constructors = (
            RailroadService.manage_addRailroadServiceForm,
            RailroadService.manage_addRailroadService 
            ),
        icon = "www/railroad_service.png"
        )

    context.registerClass(
        RailroadProxy.RailroadProxy,
        constructors = (
            RailroadProxy.manage_addRailroadProxyForm,
            RailroadProxy.manage_addRailroadProxy
            ),
        #icon = "www/railroad_service.png"
        )
        