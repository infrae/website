==================
silva.core.upgrade
==================

Introduction
============

``silva.core.upgrade`` provides an upgrade system that let you upgrade
the Silva version of already created Silva instances.

This is available in Silva, or via the command line tool ``silva`` and
the option ``update``.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.core.upgrade/.

