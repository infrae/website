==================
silva.core.upgrade
==================

`silva.core.upgrade` provides an upgrade system that let you upgrade
the Silva version of already created Silva instances.

