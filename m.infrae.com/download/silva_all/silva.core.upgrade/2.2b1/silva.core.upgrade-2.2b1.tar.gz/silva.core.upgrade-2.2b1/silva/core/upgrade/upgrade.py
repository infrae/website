# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: upgrade.py 39519 2010-02-01 17:06:12Z sylvain $

# Python
from bisect import insort_right
from pkg_resources import parse_version
import logging
import datetime

logger = logging.getLogger('silva.core.upgrade')

# Zope
from zope.interface import implements
import transaction

# Silva
from silva.core.interfaces import IUpgrader, IUpgradeRegistry

threshold = 50

# marker for upgraders to be called for any object
AnyMetaType = object()


class BaseUpgrader(object):
    """All upgrader should inherit from this upgrader.
    """

    implements(IUpgrader)

    def __init__(self, version, meta_type, priority=0):
        self.version = version
        self.meta_type = meta_type
        self.priority = priority

    def upgrade(self, obj):
        raise NotImplementedError

    def __cmp__(self, other):
        sort = cmp(self.priority, other.priority)
        if sort == 0:
            sort = cmp(self.__class__.__name__,
                       other.__class__.__name__)
        return sort


def get_version_index(version_list, wanted_version):
    """Return the index of the version in the list.
    """
    try:
        dev_index = wanted_version.index('dev')
        wanted_version = wanted_version[:dev_index]
    except ValueError:
        # It's not a development version everything is ok.
        pass
    wanted_version = parse_version(wanted_version)
    for index, version in enumerate(version_list):
        parsed_version = parse_version(version)
        if wanted_version < parsed_version:
            return index
        elif wanted_version == parsed_version:
            return index + 1
    # Version outside of scope, return the last upgrader.
    return index + 1


def get_upgrade_chain(versions, from_version, to_version):
    """Return a list of version to upgrade to when upgrading from to
    to version.
    """
    versions.sort(lambda x, y: cmp(parse_version(x), parse_version(y)))
    version_start_index = get_version_index(versions, from_version)
    version_end_index = get_version_index(versions, to_version)
    return versions[version_start_index:version_end_index]


class UpgradeRegistry(object):
    """Here people can register upgrade methods for their objects
    """

    implements(IUpgradeRegistry)

    def __init__(self):
        self.__registry = {}

    def registerUpgrader(self, upgrader, version=None, meta_type=None):
        assert IUpgrader.providedBy(upgrader)
        if not version:
            version = upgrader.version
        if not meta_type:
            meta_type = upgrader.meta_type
        if isinstance(meta_type, str) or meta_type is AnyMetaType:
            meta_type = [meta_type,]
        for type_ in meta_type:
            registry = self.__registry.setdefault(version, {}).setdefault(
                type_, [])
            insort_right(registry, upgrader)

    def getUpgraders(self, version, meta_type):
        """Return the registered upgrade_handlers of meta_type
        """
        upgraders = []
        v_mt = self.__registry.get(version, {})
        upgraders.extend(v_mt.get(AnyMetaType, []))
        upgraders.extend(v_mt.get(meta_type, []))
        return upgraders

    def upgradeObject(self, obj, version):
        mt = obj.meta_type
        for upgrader in self.getUpgraders(version, mt):
            url = None
            if getattr(obj, 'absolute_url', None):
                # Not all objects have an absolute_url ...
                url = obj.absolute_url()
            if url is not None:
                logger.debug('Upgrading %s with %r' % (url, upgrader))

            # sometimes upgrade methods will replace objects, if so
            # the new object should be returned so that can be used
            # for the rest of the upgrade chain instead of the old
            # (probably deleted) one
            __traceback_supplement__ = (
                UpgraderTracebackSupplement, self, obj, upgrader)
            try:
                obj = upgrader.upgrade(obj)
            except ValueError, e:
                if url is not None:
                    logger.error('Error while upgrading object %s with %r: %s' %
                                 (url, upgrader, str(e)))
            assert obj is not None, "Upgrader %r seems to be broken, " \
                "this is a bug." % (upgrader, )
        return obj

    def upgradeTree(self, root, version, blacklist=[]):
        stats = {
            'total': 0,
            'threshold': 0,
            'maxqueue' : 0,
            }

        object_list = [root]
        while object_list:
            obj = object_list.pop()

            if not (obj.meta_type in blacklist):
                obj = self.upgradeObject(obj, version)

            if (hasattr(obj.aq_base, 'objectValues') and
                obj.meta_type != "Parsed XML"):

                object_list.extend(obj.objectValues())
                stats['maxqueue'] = max(
                    stats['maxqueue'], len(object_list))

            stats['total'] += 1
            stats['threshold'] += 1
            if stats['threshold'] > threshold:
                transaction.get().commit()
                if hasattr(obj, '_p_jar') and obj._p_jar is not None:
                    obj._p_jar.cacheGC()
                stats['threshold'] = 0

        return stats

    def upgrade(self, root, from_version, to_version):
        logger.info('upgrading from %s to %s.' %
                    (from_version, to_version))

        start = datetime.datetime.now()
        upgrade_chain = get_upgrade_chain(
            self.__registry.keys(), from_version, to_version)
        if not upgrade_chain:
            logger.info('nothing needs to be done.')

        # First, upgrade Silva Root so Silva services / extensions
        # will be upgraded

        for version in upgrade_chain:
            logger.info('upgrading root to version %s.' % version)
            self.upgradeObject(root, version)

        # Now, upgrade site content
        for version in upgrade_chain:
            logger.info('upgrading content to version %s.' % version)
            self.upgradeTree(root, version, blacklist=['Silva Root',])

        # Now, refresh extensions
        logger.info('refresh extensions.')
        root.service_extensions.refresh_all()

        end = datetime.datetime.now()
        logger.info('upgrade finished in %d seconds.' % (end - start).seconds)


registry = UpgradeRegistry()


class UpgraderTracebackSupplement(object):
    """Implementation of zope.exceptions.ITracebackSupplement,
    to amend the traceback during upgrades so that object
    information is present.
    """

    def __init__(self, context, obj, upgrader):
        self.context = context
        self.obj = obj
        self.upgrader = upgrader

    def getInfo(self, as_html=0):
        import pprint
        data = {"object":self.obj,
                "object_path":'/'.join(self.obj.getPhysicalPath()),
                "upgrader":self.upgrader}
        s = pprint.pformat(data)
        if not as_html:
            return '   - Object Info:\n      %s' % s.replace('\n', '\n      ')
        else:
            from cgi import escape
            return '<b>Names:</b><pre>%s</pre>'%(escape(s))
