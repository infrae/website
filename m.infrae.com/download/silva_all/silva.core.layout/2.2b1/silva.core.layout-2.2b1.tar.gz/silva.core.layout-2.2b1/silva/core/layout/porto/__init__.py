# -*- coding: utf-8 -*-
# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 39316 2010-01-22 18:37:41Z sylvain $
