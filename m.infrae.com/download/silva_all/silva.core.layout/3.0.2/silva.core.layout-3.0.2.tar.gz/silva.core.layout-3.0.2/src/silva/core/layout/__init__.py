# -*- coding: utf-8 -*-
# Copyright (c) 2002-2013 Infrae. All rights reserved.
# See also LICENSE.txt

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.layout')
silvaconf.extensionTitle('Silva Core Layout')
silvaconf.extensionSystem()

