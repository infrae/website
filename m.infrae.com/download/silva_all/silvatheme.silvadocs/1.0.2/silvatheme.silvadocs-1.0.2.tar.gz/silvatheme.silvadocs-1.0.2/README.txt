====================
silvatheme.silvadocs
====================

Silva Docs is a visual design (theme) for `Silva`_ 3 and higher. It is
used by default on the `Silva User Documentation`_.


Code repository
===============

The code for this extension can be found in Mercurial:
https://hg.infrae.com/silvatheme.silvadocs


.. _Silva: http://silvacms.org
.. _Silva User Documentation: http://silvacms.org/docs/user/
