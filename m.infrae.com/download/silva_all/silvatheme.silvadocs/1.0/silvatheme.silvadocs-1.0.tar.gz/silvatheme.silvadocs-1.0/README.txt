====================
silvatheme.silvadocs
====================

Silva Docs is a visual design (theme) for Silva 3 and higher. It is
used by default on the Silva User Documentation.

