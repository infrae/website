===============
silva.fanstatic
===============

This packages provides an integration of `fanstatic`_ into Silva 3.0. In
order to know how to use it, please refer to the `Silva developer
documentation`_.


Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.fanstatic/.


.. _fanstatic: http://www.fanstatic.org
.. _Silva developer documentation: http://docs.infrae.com/silva/
