=====================
silva.core.interfaces
=====================

``silva.core.interfaces`` defines Zope interfaces to describe the
default Silva APIs, theirs contents and functionalities.


