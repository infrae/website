=====================
silva.core.interfaces
=====================

``silva.core.interfaces`` defines Zope interfaces to describe the
default Silva APIs, theirs contents and functionalities.

Those interfaces are used to generate the Developer documentation as
well: http://docs.silvacms.org/latest.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.core.interfaces
