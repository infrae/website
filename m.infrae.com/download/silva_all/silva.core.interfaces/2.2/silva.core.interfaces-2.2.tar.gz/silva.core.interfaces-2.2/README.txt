=====================
silva.core.interfaces
=====================

``silva.core.interfaces`` defines interfaces describing default Silva
contents and functionalities.


