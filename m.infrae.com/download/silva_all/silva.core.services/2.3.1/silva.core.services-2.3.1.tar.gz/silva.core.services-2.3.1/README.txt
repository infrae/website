===================
silva.core.services
===================

This package contains default Silva services definition, and
implementation of mandatory Silva services.
