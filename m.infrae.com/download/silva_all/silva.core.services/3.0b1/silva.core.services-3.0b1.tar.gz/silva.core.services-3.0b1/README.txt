===================
silva.core.services
===================

This package contains default Silva services definition (API), and
implementation of mandatory Silva services.
