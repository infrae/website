# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 40322 2010-03-03 11:41:27Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.references')
silvaconf.extensionTitle('Silva Core References')
silvaconf.extensionSystem()
