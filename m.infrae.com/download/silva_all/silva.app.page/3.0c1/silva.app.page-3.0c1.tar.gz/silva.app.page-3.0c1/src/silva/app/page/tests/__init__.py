# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt
"""
Unit test package for Silva Content Layout, see README.txt in Silva product.
"""