# -*- coding: utf-8 -*-
# Copyright (c) 2012  Infrae. All rights reserved.
# See also LICENSE.txt

from zope.component import getUtility
from zope.publisher.browser import TestRequest

from Products.Silva.tests.test_xml_import import SilvaXMLTestCase
from silva.app.page.news.agenda import AgendaPageVersion, AgendaPage
from silva.app.page.news.blocks import NewsInfoBlock, AgendaInfoBlock
from silva.app.page.news.news import NewsPage, NewsPageVersion
from silva.app.page.page import Page, PageVersion
from silva.core.contentlayout.interfaces import IBlockManager
from silva.core.contentlayout.model import PageModelVersion
from silva.core.messages.interfaces import IMessageService

from ..testing import FunctionalLayer


class TestPageImport(SilvaXMLTestCase):

    layer = FunctionalLayer

    def setUp(self):
        self.root = self.layer.get_application()
        self.layer.login('editor')

    def test_import_page(self):
        self.import_file("test_import_page.silvaxml",
                         globs=globals())
        base = self.root._getOb('exportbase')
        page = base._getOb('apage')
        self.assertIsInstance(page, Page)
        page_version = page.get_editable()
        self.assertIsInstance(page_version, PageVersion)
        design = page_version.get_design()
        self.assertTrue(design)

    def test_import_with_page_model(self):
        self.import_file("test_import_with_page_model.silvaxml",
                         globs=globals())

        message_service = getUtility(IMessageService)
        errors = message_service.receive(TestRequest(), namespace='error')
        self.assertEquals(0, len(errors),
            "import warning: " + "\n".join(map(str, errors)))

        base = self.root._getOb('exportbase')
        page = base._getOb('apage')
        self.assertIsInstance(page, Page)
        page_version = page.get_editable()
        self.assertIsInstance(page_version, PageVersion)
        page_model = page_version.get_design()
        self.assertIsInstance(page_model, PageModelVersion)

    def test_import_news_page(self):
        self.import_file("test_import_news_page.silvaxml", globs=globals())
        message_service = getUtility(IMessageService)
        errors = message_service.receive(TestRequest(), namespace='error')
        self.assertEquals(0, len(errors),
            "import warning: " + "\n".join(map(str, errors)))

        base = self.root._getOb('news')
        news_page = base._getOb('newspage')
        self.assertIsInstance(news_page, NewsPage)
        version = news_page.get_editable()
        self.assertIsInstance(version, NewsPageVersion)
        design = version.get_design()
        self.assertTrue(design)

        manager = IBlockManager(version)
        slot = manager.get_slot('one')
        _, block = slot[0]
        self.assertIsInstance(block, NewsInfoBlock)


    def test_import_agenda_page(self):
        self.import_file("test_import_agenda_page.silvaxml", globs=globals())
        message_service = getUtility(IMessageService)
        errors = message_service.receive(TestRequest(), namespace='error')
        self.assertEquals(0, len(errors),
            "import warning: " + "\n".join(map(str, errors)))

        base = self.root._getOb('news')
        agenda_page = base._getOb('agendapage')
        self.assertIsInstance(agenda_page, AgendaPage)
        version = agenda_page.get_editable()
        self.assertIsInstance(version, AgendaPageVersion)
        design = version.get_design()
        self.assertTrue(design)

        manager = IBlockManager(version)
        slot = manager.get_slot('one')
        _, block = slot[0]
        self.assertIsInstance(block, AgendaInfoBlock)
