# Copyright (c) 2008-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: preview.py 39341 2010-01-25 14:46:54Z sylvain $

from silva.core.smi import smi, edit

from five import grok


grok.view(smi.PreviewTab)


class PublishNowButton(edit.PublishNowButton):
    pass
