# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: preview.py 31688 2008-10-31 15:30:10Z sylvain $

from silva.core.smi import properties
from silva.core.smi import smi
from silva.core import conf as silvaconf

from Products.Silva import interfaces

silvaconf.templatedir('templates')
silvaconf.view(smi.PreviewTab)

class PublishNowButton(properties.PublishNowButton):

    silvaconf.context(interfaces.IVersionedContent)
