# Copyright (c) 2008-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: preview.py 32943 2009-01-12 16:21:12Z sylvain $

from silva.core.smi import smi, edit
from silva.core import conf as silvaconf

from Products.Silva import interfaces

silvaconf.templatedir('templates')
silvaconf.view(smi.PreviewTab)

class PublishNowButton(edit.PublishNowButton):
    pass
