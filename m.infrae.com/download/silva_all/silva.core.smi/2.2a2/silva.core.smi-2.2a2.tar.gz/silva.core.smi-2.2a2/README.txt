silva.core.smi
==============

``silva.core.smi`` contains some parts for the SMI, Silva Management
Interface.



