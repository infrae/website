# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 44764 2010-08-25 14:06:40Z sylvain $

