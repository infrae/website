==============
silva.core.smi
==============

Introduction
============

``silva.core.smi`` contains the different SMI screen, the Silva
Management Interface. It is built using ``silva.ui``.

Code repository
===============

This code can be found in Mercurial at:
https://hg.infrae.com/silva.core.smi.
