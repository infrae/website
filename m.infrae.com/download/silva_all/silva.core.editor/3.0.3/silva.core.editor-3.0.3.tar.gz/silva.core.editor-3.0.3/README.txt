=================
silva.core.editor
=================

Introduction
============

Support to edit rich text using `CKEditor`_ within `Silva`_ 3.

Code repository
===============

You can find the source for this extension in Git:
https://github.com/silvacms/silva.core.editor

.. _CKEditor: http://ckeditor.com/
.. _Silva: http://silvacms.org/
