========================
silvatheme.standardissue
========================

Standard Issue is a visual design (theme) for Silva 3.0 and
higher. For previous versions of Silva, please refer to previous
versions of this extension.

For more information about how to create your own design, please check
the `Silva developer documentation`_.

Code repository
===============

You can find the code for this extension in Mercurial:
https://hg.infrae.com/silvatheme.standardissue/.

.. _Silva developer documentation: http://docs.silvacms.org/latest/

