================
silva.core.views
================

``silva.core.views`` let users build user interfaces using Zope Tool
Kit like elements in Silva: Views, ViewletManager, Viewlet, Page,
Layout. It uses ``Grok`` for an easy configuration.

It care of settings HTTP headers and implementing proper HEAD requests on views
and Silva content. 

You can have more information on how to use this package on
http://docs.infrae.com.

