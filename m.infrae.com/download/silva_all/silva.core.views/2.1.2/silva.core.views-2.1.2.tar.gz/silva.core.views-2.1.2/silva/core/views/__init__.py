# -*- coding: utf-8 -*-
# Copyright (c) 2002-2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 34597 2009-04-10 09:05:23Z sylvain $

# Backward compatibility import for 2.2.
from Products.SilvaLayout.browser import absoluteurl

