# -*- coding: utf-8 -*-
# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 38847 2010-01-05 11:57:45Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.core.views')
silvaconf.extensionTitle('Silva Core Views')
silvaconf.extensionSystem()

