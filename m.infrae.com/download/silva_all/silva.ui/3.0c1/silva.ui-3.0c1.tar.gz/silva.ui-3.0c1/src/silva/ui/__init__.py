# -*- coding: utf-8 -*-
# Copyright (c) 2011-2012 Infrae. All rights reserved.
# See also LICENSE.txt

from silva.core import conf as silvaconf

silvaconf.extension_name("silva.ui")
silvaconf.extension_title(u"Silva UI")
silvaconf.extension_system()
