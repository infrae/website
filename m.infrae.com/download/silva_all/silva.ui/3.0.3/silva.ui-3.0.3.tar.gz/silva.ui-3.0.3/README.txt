========
silva.ui
========

Introduction
============

This `Silva`_ extension contains core functionnality used to build the
Silva Management Interface. Those are low level API, that Silva
extension developer will be able to use as well in their extensions.

For more information about this, please check the `Silva developer
documentation`_.

Code repository
===============

You can find the code of this extension in Git:
https://github.com/silvacms/silva.ui

.. _Silva developer documentation: http://docs.silvacms.org/latest/
.. _Silva: http://silvacms.org
