MetadataNamespace = 'http://www.infrae.com/xml/metadata'
BindingRunTime = 'http://www.infrae.com/xml/metadata/binding'
DefaultPrefix = 'example'
DefaultNamespace = "http://www.example.com/unknown_namespace"
DublinCore = 'http://www.dublincore.org'

