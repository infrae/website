
BindingRunTime = 'http://www.infrae.com/xml/metadata/binding'

DefaultPrefix = 'example'
DefaultNamespace = "http://www.example.com/unknown_namespace"


