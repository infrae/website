==============
silva.core.xml
==============

``silva.core.xml`` provides the basic components required for the
Silva XML import and export feature.

You can find more documentation on how to use those components in the
`Developer documentation`_.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.core.xml


.. _Developer documentation: http://docs.silvacms.org/latest
