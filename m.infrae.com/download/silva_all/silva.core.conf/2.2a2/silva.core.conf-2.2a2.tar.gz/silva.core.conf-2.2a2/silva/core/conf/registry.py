# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: registry.py 32941 2009-01-12 16:19:22Z sylvain $

from zope import interface, component

from Products.Silva.interfaces import IRegistry

class Registry(object):
    """Base class for registry.
    """

    interface.implements(IRegistry)


def getRegistry(name):
    return component.queryUtility(IRegistry, name=name)
