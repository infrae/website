This Code Source allows Flash (swf or flv) files to be embedded in a page and configured.

Original Author: University of Bedfordshire

Contact: info at infrae com
