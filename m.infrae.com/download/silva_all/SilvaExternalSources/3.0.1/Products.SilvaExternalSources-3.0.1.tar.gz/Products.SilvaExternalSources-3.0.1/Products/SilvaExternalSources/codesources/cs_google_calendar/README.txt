﻿README for Google Calendar Code Source
======================================

This README should reside inside a Silva Code Source named 'cs_google_calendar'.
The Code Source allows Authors to embed a Google Calendar in a document.

Customizing Google Calendar CS
------------------------------

The code in the page template named 'google_calendar_source' can be easily
adjusted to your personal requirements. 

Parameters
----------
You can adjust the fields in the parameters form. 


--
Improvements and variants are welcome.
