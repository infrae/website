﻿README for Citation Code Source
===============================

This README should reside inside a Silva Code Source named 'cs_citation'. The
Code Source allows Authors to place a reference, citing an author and a
source.  The refernce, author and source all support html entry via a limited
popup kupu editor.  This code source replaces the deprecated 'citation' 
element.

This Code Source does not provide dynamic content, and so the "Source is
cacheable" option may be turned on (default).

Customizing TOC
--------------------
The code in the page template named 'render_citation' can be easily adjusted
to your personal requirements.

--
Improvements and variants are welcome.
Hard work by aaltepet at infrae com