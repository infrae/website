This code source is fancy and used only for fancy testing.
