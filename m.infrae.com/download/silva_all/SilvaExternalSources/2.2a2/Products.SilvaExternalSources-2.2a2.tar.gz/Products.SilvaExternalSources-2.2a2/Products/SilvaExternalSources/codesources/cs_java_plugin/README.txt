README.txt

Copyright (c) 2005-2009 Samuel Schluep, ETH Zurich and Infrae.
All rights reserved. See also LICENSE.txt

Java Plugin

  Embeds a Java applet with the Java plug-in mechanism.

  Version:      Java Plugin CS 0.3
  Date:         2007-04-13
  Author:       Samuel Schluep
  Email:        schluep@ethz.ch
  Requirements: Silva 1.5.8 and up

Embeds a Java applet using the Java plug-in mechanism. Includes parameters for startup class, reference, codebase, width, height, and arbitrary parameters.

    * Version 0.1 is compatible with Silva 1.4 and up.
    * Version 0.2 is for use with Silva 1.5.8 or greater.
      Improvements include a lookup window launcher for linking
      the image and rollover tooltips in the parameters form.

Author: Samuel Schluep

Contact: schluep at ethz ch


