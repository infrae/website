README for Silva Portlet
========================

This README should reside inside a Silva Code Source named 'cs_portlet_element'. The Code Source allows Authors to embed Silva documents within other Silva documents; the layout of the embedded document can optionally be different.

Author: Marc Petitmermet

Contact: petitmermet at mine ch 
