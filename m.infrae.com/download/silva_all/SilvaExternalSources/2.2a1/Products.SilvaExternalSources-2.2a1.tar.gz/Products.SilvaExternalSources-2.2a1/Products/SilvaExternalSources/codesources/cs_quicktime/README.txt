README.txt

Copyright (c) 2005-2008 Samuel Schluep, ETH Zurich and Infrae.
All rights reserved. See also LICENSE.txt

Quicktime

  Embedder for a Quicktime movie with configuration parameters. 

  Version:      Quicktime CS 0.3
  Date:         2007-04-13
  Author:       Samuel Schluep
  Email:        schluep@ethz.ch
  Requirements: Silva 1.5.8 and up

Embedder for a Quicktime movie with configuration. Includes
parameters for reference, autoplay, controller, width, height, and
arbitrary parameters.

    * Version 0.1 is compatible with Silva 1.2 and up.
    * Version 0.2 is for use with Silva 1.5.8 or greater.
      Improvements include a lookup window launcher for linking
      the image and rollover tooltips in the parameters form.

