return context.service_editorsupport.availableSources(context.REQUEST.model)

