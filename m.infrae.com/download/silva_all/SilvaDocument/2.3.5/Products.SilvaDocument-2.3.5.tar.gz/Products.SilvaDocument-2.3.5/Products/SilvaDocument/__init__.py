# Copyright (c) 2002-2011 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core import conf as silvaconf

silvaconf.extensionName('SilvaDocument')
silvaconf.extensionTitle('Silva Document')
silvaconf.extensionDepends('SilvaExternalSources')



