## Script (Python) "insert_helper"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
# don't put list items into insert mode but in done mode directly
context.done_mode_helper()
