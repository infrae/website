## Script (Python) "content"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
node = context.REQUEST.node
image_path = node.getAttribute('path').encode('ascii', 'ignore')
return context.get_image(node.get_container(), image_path)
