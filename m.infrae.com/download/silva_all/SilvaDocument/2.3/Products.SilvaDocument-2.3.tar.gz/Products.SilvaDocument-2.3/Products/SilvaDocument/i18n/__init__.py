from zope.i18nmessageid import MessageFactory

translate = MessageFactory('silva_document')
