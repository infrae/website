# Copyright (c) 2002-2009 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 42072 2010-05-13 15:39:19Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('SilvaDocument')
silvaconf.extensionTitle('Silva Document')
silvaconf.extensionDepends('SilvaExternalSources')



