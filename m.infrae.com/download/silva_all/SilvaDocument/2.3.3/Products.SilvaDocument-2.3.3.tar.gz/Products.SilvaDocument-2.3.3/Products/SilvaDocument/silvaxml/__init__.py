# XML Import/Export

NS_SILVA_DOCUMENT = 'http://infrae.com/namespace/silva-document'
