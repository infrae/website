# package

NS_DOCUMENT_URI = 'http://infrae.com/namespace/silva-app-document'

