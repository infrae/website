==================
silva.app.document
==================

A document content for Silva 3.0. It is based on
``silva.core.editor``, and replace the old ``SilvaDocument`` based on
`Kupu`_.

This document type can be extend by other Silva extensions.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.app.document/.


.. _Kupu: http://infrae.com/products/kupu_editor
