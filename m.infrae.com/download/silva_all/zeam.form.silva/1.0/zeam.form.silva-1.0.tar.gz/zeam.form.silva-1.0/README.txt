===============
zeam.form.silva
===============

``zeam.form.silva`` is the integration of `Zeam Form
<http://pypi.python.org/pypi/zeam.form.base>`_ in Silva.

This packages provides forms for SMI and ZMI usage.

