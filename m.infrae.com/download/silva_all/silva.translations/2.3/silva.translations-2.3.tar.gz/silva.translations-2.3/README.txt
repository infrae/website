==================
silva.translations
==================

``silva.translations`` contains all translations for the `Silva CMS`_ in many languages.

.. _Silva CMS: http://infrae.com/products/silva

