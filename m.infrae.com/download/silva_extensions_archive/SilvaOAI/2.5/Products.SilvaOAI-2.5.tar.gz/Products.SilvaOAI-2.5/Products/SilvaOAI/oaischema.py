# Copyright (c) 2004-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from string import find, lower
from Products.OAICore.oaischema import OAIField


class OAIAutoCompleteField(OAIField):

    def getIndexType(self):
        return 'KeywordIndex'

    def addEditField(self, form, filters, catalog):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(id, title, 'MultiAutoCompleteField')
        values = form.get_field(id).values
        values['required'] = 0
        values['unicode'] = 1
        values['source_uri'] = 'autoCompleteList'
        values['schema'] = ["resultSet.result", "name", "value"]
        values['display_width'] = 40
        values['extra_params'] = 'keyword=%s' % id
        default_value = filters.get(id, None)
        if default_value is not None:
            values['default'] = default_value
        values['js_array'] = []
        for value in catalog.uniqueValuesFor(id):
            if value:
                values['js_array'].append((value[:60], value))
        values['items'] = values['js_array']


    def addPublicField(self, form, unique_values):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField('txt_0_' + id, title, 'StringField')
        values = form.get_field('txt_0_' + id).values
        values['required'] = 0
        values['unicode'] = 1
        result = [('All values', 'none')]
        result = result + unique_values
        if len(result) > 1:
            form.manage_addField(
                'list_1_' + id, '', 'ListField')
            values = form.get_field('list_1_' + id).values
            values['title'] = ''
            values['size'] = 1
            values['required'] = 0
            values['unicode'] = 1
            values['items'] = result

    def updatePublicQuery(self, query, form_results, unique_values=None):
        id = self.getId()
        txt = lower(form_results.get('txt_0_' + id, ''))
        if txt:
            search_list = []
            for value in unique_values:
                if find(lower(value), txt) > -1:
                    search_list.append(value)
            query[id] = search_list
        else:
            lst = form_results.get('list_1_' + id, 'none')
            if lst is not None and lst != 'none':
                query[id] = lst
