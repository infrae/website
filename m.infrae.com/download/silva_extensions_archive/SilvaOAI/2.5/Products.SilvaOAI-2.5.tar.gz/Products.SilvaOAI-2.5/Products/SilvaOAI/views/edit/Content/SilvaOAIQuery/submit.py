from Products.Formulator.Errors import ValidationError, FormValidationError
request = context.REQUEST
model = request.model
view = context

try:
    result = model.getManageForm().validate_all(context.REQUEST)
except FormValidationError, e:
    return view.tab_edit(message_type="error",
                         message=view.render_form_errors(e))

if result['set'] == ['none'] or result['set'] == 'none' or not result['set']:
    model.setSet(None)
else:
    model.setSet(result['set'])

if not (result['sort_on'] == ['none'] or
        result['sort_on'] == 'none' or not result['sort_on']):
    model.setSort(result['sort_on'])

for key, value in result.copy().items():
    if same_type(value, []):
        if 'none' in value:
            del result[key]
    elif value == 'none':
        del result[key]
    
model.setFilters(result)
model.setIntroText(request['input_intro_text'])

if request.get('input_display_list'):
    model.setDisplayList(True)
else:
    model.setDisplayList(False)
    
return view.tab_edit(message_type="feedback", message="Silva OAI Query Changed")
