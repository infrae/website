SilvaOAI
========

SilvaOAI uses `OAICore`_ to make `OAI-PMH`_ harvested metadata
browseable and searchable in `Silva`_. When installed, Silva has a new
content object called an *OAI Query*. Silva authors can specify which
collection of harvested metadata they want to expose on the query's
public web page, for instance all entries in an OAI-PMH defined
set. End-users can then browse this metadata in the Silva site's
public layout, and request more detailed information. End-users can
further search the collection using an advanced search form.

This package requires Silva 2.3+. For previous version of Silva,
please use a previous version of this package.

Installation and use
--------------------

As a manager, you need first to activate the extension in
*service_extension*. After, still in ZMI, you need to add an OAIPMH
Service in your Silva site.

From the Silva Management Interface, as an editor, you can now add
*Silva OAI Query* content type. Adding one will ask you for a title
and id, and an OAI Storage to query (corresponding to an OAIPMH
Service previously added). After selecting these, you will be
presented with the choice of an enabled metadata format to query
against.

It is then possible to define the actual query. You can select one or more
criteria to filter the data in the OAIPMH Service on. The query will provide
the end-user with a browsable, searchable[*] view of all the OAI records
that satisfy the criteria. If no criteria are specified, that means that
all the records harvested for the selected metadata format are shown.

[*] The fields on which the end user can further filter the result set, are
defined in the metadata-schema for the selected metadata format. See the
OAICore product for two example schemata, and instructions on how to roll
your own, which is quiet easy.

Sponsorship
-----------
Many thanks go to Henk Ellermann at the library of Erasmus University
Rotterdam for making this development possible.


.. _OAICore: http://infrae.com/download/OAI/OAICore
.. _OAI-PMH: http://www.openarchives.org/pmh/
.. _Silva: http://infrae.com/products/silva
