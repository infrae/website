# Copyright (c) 2002-2010 Infrae. All rights reserved.
# See also LICENSE.txt

from itertools import imap

from AccessControl import ClassSecurityInfo
from App.class_init import InitializeClass
from OFS.SimpleItem import SimpleItem

from five import grok
from silva.core import conf as silvaconf
from silva.core.conf.interfaces import ITitledContent
from silva.core.views import views as silvaviews
from zeam.form import silva as silvaforms
from zeam.utils.batch import batch
from zeam.utils.batch.interfaces import IBatching
from zope import schema
from zope.component import getMultiAdapter

from Products.Formulator.Form import ZMIForm
from Products.Silva import SilvaPermissions as permissions
from Products.Silva.Publishable import NonPublishable
from Products.SilvaExternalSources.ExternalSource import ExternalSource

from Products.OAICore.query import ManageableQuery
from Products.SilvaOAI.query import AutocompletionQueryFieldMixIn
from Products.SilvaOAI.interfaces import IExternalSourceCherry, IExternalSourceQuery, oai_storages
from Products.SilvaOAI.i18n import translate as _


class QueryExternalSource(NonPublishable, ExternalSource, AutocompletionQueryFieldMixIn, ManageableQuery, SimpleItem):
    """An OAI Query as an ExternalSource, that can be included in
    documents afterwards to display a listing of items restricted by
    specifics criterias.
    """
    grok.implements(IExternalSourceQuery)
    silvaconf.icon('www/oai_source.png')
    silvaconf.priority(3)

    meta_type = "Silva OAI Source"
    security = ClassSecurityInfo()

    def __init__(self, id):
        NonPublishable.__init__(self, id)
        ManageableQuery.__init__(self)

    security.declareProtected(permissions.ViewManagementScreens, 'get_service')
    get_service = ManageableQuery.getService
    security.declareProtected(permissions.ViewManagementScreens, 'set_service')
    set_service = ManageableQuery.setService

    # OAI
    security.declareProtected(
        permissions.ChangeSilvaContent, 'updateManageForm')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'getManageForm')
    def getManageForm(self):
        query_form = ZMIForm('query_form', 'Query Form', 1)
        self.updateManageForm(query_form)
        return query_form.__of__(self)

    # Override some permissions
    security.declareProtected(
        permissions.ChangeSilvaContent, 'getMetadataFormat')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'getService')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSet')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSort')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSortOrder')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setFilters')

    # ExternalSource
    security.declareProtected(permissions.ChangeSilvaContent, 'get_parameters_form')
    def get_parameters_form(self):
        return None

    security.declareProtected(permissions.AccessContentsInformation, 'to_html')
    def to_html(self, content, request, **parameters):
        """Render HTML for inclusion in Silva Documents.
        """
        view = getMultiAdapter((self, request), name='content.html')
        view.document = content.get_content()
        view.parameters = dict(parameters)
        return view()

    security.declareProtected(permissions.AccessContentsInformation, 'get_description')
    def get_description(self):
        return 'List OAI items'


InitializeClass(QueryExternalSource)


class IExternalSourceQueryAddSchema(ITitledContent):

    service = schema.Choice(
        title = _(u"OAI Storage"),
        description = _("OAI Storage to query."),
        source = oai_storages)


class ExternalSourceQueryAddForm(silvaforms.SMIAddForm):
    grok.context(IExternalSourceQuery)
    grok.name('Silva OAI Source')

    fields = silvaforms.Fields(IExternalSourceQueryAddSchema)


class ExternalSourceQueryView(silvaviews.View):
    """Doc string.
    """
    grok.context(IExternalSourceQuery)

    document = None
    parameters = {}

    def update(self):
        content = self.document
        if content is None:
            content = self.context
        records = batch(self.context.queryResults(self.parameters),
                        name=self.context.getId(), count=10, request=self.request)
        self.records = imap(lambda brain: brain.getObject(), records)
        self.batch = getMultiAdapter((content, records, self.request), IBatching)()


class CherryExternalSource(QueryExternalSource):
    """Code Source-like object that accepts the identifier for a
       cherry picked document, and displays the document's
       metadata.
    """
    grok.implements(IExternalSourceCherry)
    meta_type = 'Silva OAI Cherry'
    security = ClassSecurityInfo()

    # ExternalSource
    security.declareProtected(permissions.ChangeSilvaContent, 'get_parameters_form')
    def get_parameters_form(self):
        form = ZMIForm('cherries', 'Cherries', 1)
        form.manage_addField('metadata_identifier', 'Identifier', 'StringField')
        field = form['metadata_identifier']
        field.values['description'] = 'Identifier for the Record'
        field.values['required'] = 1
        return form.__of__(self)


InitializeClass(CherryExternalSource)


class ExternalSourceCherryAddForm(silvaforms.SMIAddForm):
    grok.context(IExternalSourceCherry)
    grok.name('Silva OAI Cherry')

    fields = silvaforms.Fields(IExternalSourceQueryAddSchema)
