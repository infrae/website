# Copyright (c) 2004-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

import logging

from silva.core.upgrade.upgrade import BaseUpgrader
from Products.OAICore.query import UniqueValues

logger = logging.getLogger('silva.core.upgrade')


# Silva 1.2

class QueryUpgrader(BaseUpgrader):

    def upgrade(self, query):
        if not hasattr(query, '_service_path'):
            logger.info(
                'Changed service property to a physical path on Silva OAI Query %s' %
                '/'.join(query.getPhysicalPath()))
            query._service_path = getattr(query, query._service).getPhysicalPath()
            query._unique_values = UniqueValues()
        return query


query_upgrader_120 =  QueryUpgrader('1.2', 'Silva OAI Query')
