# Copyright (c) 2003-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: SilvaObject.py 45279 2010-09-17 09:47:23Z sylvain $

from Acquisition import aq_parent
from OFS.interfaces import IObjectManager

from five import grok
from silva.core.interfaces import IContent, INonPublishable
from zope.schema.interfaces import IContextSourceBinder
from zope.schema.vocabulary import SimpleVocabulary, SimpleTerm


from Products.SilvaExternalSources.interfaces import IExternalSource


@grok.provider(IContextSourceBinder)
def oai_storages(context):
    storages = []
    lookup = context.get_container()
    while IObjectManager.providedBy(lookup):
        for storage in lookup.objectValues(['OAIPMH Service']):
            storages.append(
                SimpleTerm(
                    value=storage,
                    token=storage.getId(),
                    title=storage.getId()))
        lookup = aq_parent(lookup)
    return SimpleVocabulary(storages)


class IQuery(IContent):
    """Silva OAI Query objects.
    """


class IPublicRecord(IContent):
    """A Silva OAI Record obtained as result of search in a Silva OAI Query.
    """


class IExternalSourceQuery(INonPublishable, IExternalSource):
    """Silva OAI Query Source: an external sources quering OAI data.
    """

class IExternalSourceCherry(IExternalSourceQuery):
    """Silva OAI Query Source restricted to one record.
    """
