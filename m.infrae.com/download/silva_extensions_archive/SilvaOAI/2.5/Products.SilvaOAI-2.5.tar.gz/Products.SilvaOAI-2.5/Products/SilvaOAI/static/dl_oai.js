function get_details_id(id) {
    ids = id.split('_');
    return ids[1];
}

function more_details(element) {
    var id = get_details_id(element.id);
    details_element = document.getElementById('details_'+id);
    details_element.style.display = 'block';
    less_element = document.getElementById('less_'+id);
    less_element.style.display = 'inline';
    element.style.display = 'none';
}

function less_details(element) {
    var id = get_details_id(element.id);
    details_element = document.getElementById('details_'+id);
    details_element.style.display = 'none';
    more_element = document.getElementById('more_'+id);
    more_element.style.display = 'inline';
    element.style.display = 'none';
}
