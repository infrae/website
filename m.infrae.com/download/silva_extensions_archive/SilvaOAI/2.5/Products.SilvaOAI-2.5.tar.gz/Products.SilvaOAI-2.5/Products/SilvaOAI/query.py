# Copyright (c) 2004-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from xml.sax.saxutils import escape
from itertools import imap
from functools import partial
import operator

from AccessControl import ClassSecurityInfo
from Acquisition import aq_parent
from App.class_init import InitializeClass
from DateTime import DateTime
from OFS.SimpleItem import SimpleItem
from zExceptions import NotFound

from five import grok
from localdatetime import get_formatted_date, get_locale_info
from silva.core import conf as silvaconf
from silva.core.interfaces import IContainer
from silva.core.conf.interfaces import ITitledContent
from silva.core.views import views as silvaviews
from zeam.form import silva as silvaforms
from zeam.utils.batch import batch
from zeam.utils.batch.interfaces import IBatching
from zope import schema
from zope.component import getMultiAdapter
from zope.publisher.interfaces.browser import IBrowserRequest
from zope.traversing.browser import absoluteURL
from zope.traversing.interfaces import ITraversable

from Products.Silva.Content import Content
from Products.Silva import SilvaPermissions as permissions
from Products.Formulator.Form import ZMIForm

from Products.OAICore.query import SearchQuery
from Products.OAICore.helpers import keysSortedByValue
from Products.SilvaOAI.interfaces import IPublicRecord, IQuery, oai_storages
from Products.SilvaOAI.i18n import translate as _


# A public record export record information via a query.

class PublicRecord(Content, SimpleItem):
    """A record that is accessible via a query and display to the public in Silva.
    """
    meta_type = 'Silva OAI Public Record'
    security = ClassSecurityInfo()
    grok.implements(IPublicRecord)

    def __init__(self, record, fields):
        # This content is only created with the PublicRecordTraverser.
        # Prepending the record id with ++record++ will create a correct
        # URL triggering again that traverser.
        self.id = '++record++' + record.id
        self.__fields = fields
        self.__record = record

    security.declareProtected(
        permissions.AccessContentsInformation, 'getRecord')
    def getRecord(self):
        return self.__record

    security.declareProtected(
        permissions.AccessContentsInformation, 'getFields')
    def getFields(self):
        return self.__fields


InitializeClass(PublicRecord)


class PublicRecordTraverser(grok.MultiAdapter):
    grok.adapts(IQuery, IBrowserRequest)
    grok.implements(ITraversable)
    grok.provides(ITraversable)
    grok.name('record')

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def traverse(self, name, remaining):
        storage = self.context.getStorage()
        try:
            record = storage[name]
        except KeyError:
            raise NotFound(name)
        fields = self.context.getSchema().getItemFields()
        return PublicRecord(record, fields)


class PublicRecordView(silvaviews.View):
    grok.context(IPublicRecord)

    def render_date(self, value):
        return get_formatted_date(
            value.asdatetime(),
            size='medium', locale=self.locale, display_time=False)

    renderers = {
        'title': lambda self, value: u' '.join(value),
        'list': lambda self, value: u', '.join(value),
        'text': lambda self, value: u' '.join(value),
        'date': render_date}

    def update(self):
        self.query = aq_parent(self.context)
        self.locale = get_locale_info(self.request)
        self.metadata = []
        self.title = None
        self.record = self.content.getRecord()
        for field in self.content.getFields():
            value = getattr(self.record, field['id'], None)
            if value is None:
                continue
            value = self.renderers[field['display']](self, value)
            if field['display'] == 'title':
                self.title = value
            else:
                self.metadata.append({'title': field['title'], 'value': value})
        self.documents = []
        for url in self.record.getDocumentUrls():
            self.documents.append({'name': url.strip('/').split('/')[-1], 'url': url})


# All the following classes are for the SilvaOAIQuery.

class XMLBuffer:
    """Small file-like object for XML output.

    Implicitly converts unicode to UTF-8 and replaces characters to
    entities when required
    """

    def __init__(self):
        self.__buffer = []

    def write(self, data):
        if not isinstance(data, unicode):
            data = unicode(data)
        self.__buffer.append(data)

    def read(self):
        """The semantics are different from the plain file interface's read!

        This will return the full buffer always, and won't move the
        pointer
        """
        return u''.join(self.__buffer).encode('UTF-8')


class FeedMixIn:
    security = ClassSecurityInfo()

    def getFeedItems(self, sort_on=None, sort_order=None, results=10):
        schema = self.getSchema()
        if sort_on or sort_order:
            brains = self.queryResults(
                {'sort_on': schema.getRSSFieldId(sort_on),
                'sort_order': sort_order})
        else:
            brains = self.queryResults(
                {'sort_on': schema.getRSSFieldId('date'),
                'sort_order': 'descending'})
        if results > 0:
            brains = brains[:results]
        return brains

    def _get_uri(self, item):
        schema = self.getSchema()
        url = self.absolute_url()
        uri_field = schema.getRSSFieldId('uri')
        if not uri_field is None:
            if type(uri_field) == list:
                for field in uri_field:
                    uri = getattr(item, field)
                    if uri:
                        break
            if not uri:
                uri = getattr(item, uri_field)
            if uri and type(uri) == list:
                return uri[0]
        return "%s/%s" % (url, item.id)

    security.declareProtected(permissions.AccessContentsInformation,
                              'rss2_all')
    def rss2_all(self, REQUEST=None, sort_on=None, sort_order=None):
        """Return all items of this query as an RSS 2.0 feed"""
        return self.rss2(REQUEST, sort_on, sort_order, 0)

    security.declareProtected(permissions.AccessContentsInformation,
                              'rss2')
    def rss2(self, REQUEST=None, sort_on=None, sort_order=None, results=10):
        """Return the newest items of this query as an RSS 2.0 feed"""
        RDF_HEADER = ('<?xml version="1.0" encoding="UTF-8" ?>\n')
        if REQUEST is not None:
            REQUEST.RESPONSE.setHeader('Content-Type', 'text/xml;charset=UTF-8')
        brains = self.getFeedItems(sort_on, sort_order, results)
        # create RDF/XML for the channel
        xml = XMLBuffer()
        xml.write(RDF_HEADER)

        # get the metadata binding to get the metadata for this viewer
        mdbinding = self.service_metadata.getMetadata(self)
        # create RDF/XML frame
        xml.write('<channel>\n')
        xml.write('<title>%s</title>\n' % escape(self.get_title()))
        xml.write('<link>%s</link>\n' % self.absolute_url())
        xml.write('<description>%s</description>\n' %
            escape(mdbinding.get('silva-extra', 'content_description')))
        # loop over the itemslist and create the RSS/RDF item elements
        for brain in brains:
            self._rss2_item_helper(brain.getObject(), xml)
        # DONE return XML
        xml.write('</channel>\n\n')
        return xml.read()

    def _rss2_item_helper(self, item, xml):
        """convert a single Silva object to an RSS/RDF 'hasitem' element"""
        #XXX this should really go once we get some time
        schema = self.getSchema()
        url = self.absolute_url()
        xml.write('<item>\n')
        # RSS elements
        for id in ['title', 'description']:
            data = item.getFieldText(schema.getRSSFieldId(id), flatten=False)
            if data:
                if type(data) == type([]):
                    for datum in data:
                        xml.write(
                            '<%(id)s>%(data)s</%(id)s>\n' %
                            {'id': id, 'data': escape(datum)})
                elif type(data) == type(DateTime()):
                    xml.write(
                        '<%(id)s>%(data)s</%(id)s>\n' %
                        {'id': id, 'data': escape(data.HTML4())})
                else:
                    xml.write(
                        '<%(id)s>%(data)s</%(id)s>\n' %
                        {'id': id, 'data': escape(data)})
        xml.write('<link>%s</link>\n' % self._get_uri(item))
        names = item.getFieldText(schema.getRSSFieldId('creator'), flatten=False)
        if type(names) != type([]):
            names = [names]
        for name in names:
            if name:
                xml.write('<author>%s</author>' % escape(name))
        subjects = item.getFieldText(schema.getRSSFieldId('subject'), flatten=False)
        if type(subjects) != type([]):
            subjects = [subjects]
        for subject in subjects:
            if subject:
                xml.write('<category>%s</category>' % escape(subject))
        stripped_list = url.split('//')[1].split('/')
        domain = stripped_list[0]
        path = '/'.join(stripped_list[1:])
        published = item.getFieldText(schema.getRSSFieldId('date'), flatten=False)
        if type(published) == type([]):
            published = published[0]
        if type(published) == type(DateTime()):
            published = published.HTML4()
        published = published.split('T')[0]
        xml.write('<pubDate>%s</pubDate>' % item.datestamp().HTML4())
        xml.write('<guid>tag:%s,%s:%s</guid>' % (
            domain,
            escape(published),
            path + '/' + item.id))
        xml.write('<source>%s/rss2</source>' % url)
        xml.write('</item>\n')

    security.declareProtected(permissions.AccessContentsInformation,
                              'atom_all')
    def atom_all(self, REQUEST=None, sort_on=None, sort_order=None):
        """Return all items of this query as an Atom feed"""
        return self.atom(REQUEST, sort_on, sort_order, 0)

    security.declareProtected(permissions.AccessContentsInformation,
                              'atom')
    def atom(self, REQUEST=None, sort_on=None, sort_order=None, results=10):
        """Return the newest items of this query as an Atom feed"""

        ATOM_HEADER = (
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<feed xmlns="http://www.w3.org/2005/Atom">\n')

        if REQUEST is not None:
            REQUEST.RESPONSE.setHeader('Content-Type', 'text/xml;charset=UTF-8')
        # get the newest items
        brains = self.getFeedItems(sort_on, sort_order, results)

        xml = XMLBuffer()
        xml.write(ATOM_HEADER)

        # get the metadata binding to get the metadata for this viewer
        mdbinding = self.service_metadata.getMetadata(self)
        url = self.absolute_url()
        xml.write('<id>%s</id>\n' % escape(url))
        xml.write('<title type="text">%s</title>\n' % escape(self.get_title()))
        description = mdbinding.get('silva-extra', 'content_description')
        if description:
            xml.write('<subtitle>%s</subtitle>\n' % escape(description))
        xml.write('<link rel="self" href="%s/atom" />\n' % url)
        xml.write('<author><name>%s</name></author>\n' %
            escape(mdbinding.get('silva-extra', 'creator')))
        date = self.getService().getDatestamp().strftime(
            '%Y-%m-%dT%H:%M:%SZ%z')
        xml.write('<updated>%s</updated>\n' % escape(date))
        for brain in brains:
            self._atom_item_helper(brain.getObject(), xml)
        xml.write('</feed>')
        return xml.read()

    def _atom_item_helper(self, item, xml):
        """convert a single Silva object to an Atom 'entry' element"""
        schema = self.getSchema()
        url = self.absolute_url()
        xml.write('<entry>\n')
        # Atom elements
        titles = item.getFieldText(schema.getRSSFieldId('title'), flatten=False)
        if type(titles) != type([]):
            titles = [titles]
        for title in titles:
            xml.write('<title>%s</title>\n' % escape(title))
        xml.write(
            '<link rel="alternate" type="text/html" href="%s" />\n' %
            self._get_uri(item))
        stripped_list = url.split('//')[1].split('/')
        domain = stripped_list[0]
        path = '/'.join(stripped_list[1:])
        published = item.getFieldText(schema.getRSSFieldId('date'), flatten=False)
        if type(published) == type([]):
            published = published[0]
        if type(published) == type(DateTime()):
            published = published.HTML4()
        xml.write('<id>tag:%s,%s:%s</id>' % (
            domain,
            escape(published.split('T')[0]),
            path + '/' + item.id))
        xml.write('<published>%s</published>' % escape(published))
        xml.write('<updated>%s</updated>' % item.datestamp().HTML4())
        names = item.getFieldText(schema.getRSSFieldId('creator'), flatten=False)
        if type(names) != type([]):
            names = [names]
        for name in names:
            if name:
                xml.write('<author><name>%s</name></author>' % escape(name))
        subjects = item.getFieldText(schema.getRSSFieldId('subject'), flatten=False)
        if type(subjects) != type([]):
            subjects = [subjects]
        for subject in subjects:
            if subject:
                xml.write('<category term="%s" />' % escape(subject))
        description = item.getFieldText(schema.getRSSFieldId('description'), flatten=False)
        if type(description) == type([]):
            description = description[0]
        if description:
            xml.write('<summary>%s</summary>' % escape(description))
        xml.write('</entry>\n')


class AutocompletionQueryFieldMixIn:
    """MixIn class that adds autocompletion widgets to Query objects
    if SilvaYUI is installed.
    """

    security = ClassSecurityInfo()

    def addAutoCompleteSetField(self, form):
        form.manage_addField('set', 'Set', 'MultiAutoCompleteField')
        values = form.get_field('set').values
        values['required'] = 0
        values['unicode'] = 1
        values['source_uri'] = 'setSpecList'
        values['schema'] = ["resultSet.result", "name", "value"]
        values['display_width'] = 40
        filters = self.getFilters()

        if filters.has_key('set'):
            values['default'] = self._filters['set']
        service = self.getService()
        toplevel_sets = service.getSubSets(None)
        values['js_array'] = [[i[1], i[0]] for i in toplevel_sets.items()]
        # set up the 'Set' form field
        values['items'] = []
        for key in keysSortedByValue(toplevel_sets):
            values['items'].append(key)

    # override addSetField method if SilvaYUI is installed
    try:
        from Products import SilvaYUI
        addSetField = addAutoCompleteSetField
    except:
        pass

    # the two methods below are only used if SilvaYUI is installed,
    # and the metadata set uses OAIAutoCompletionField fields.
    security.declareProtected(permissions.AccessContentsInformation, 'setSpecList')
    def setSpecList(self, query):
        "Return a json list of setspec information, used in ajax requests"
        import simplejson
        service = self.getService()
        toplevel_sets = service.getSubSets(None)
        result = []
        query = query.lower()
        for key in keysSortedByValue(toplevel_sets):
            name = toplevel_sets[key].replace('"', '&quot;')
            if not name.lower().startswith(query):
                continue
            result.append(
                {"name": name, "value": key} )
        result = {'resultSet':{'result':result}}
        self.REQUEST.response.setHeader(
            'Content-Type', 'text/plain; charset=utf-8')
        return simplejson.dumps(result).encode('utf8')

    security.declareProtected(permissions.AccessContentsInformation, 'autoCompleteList')
    def autoCompleteList(self, query, keyword):
        "Return a json list of keyword information, used in ajax requests"
        import simplejson
        result = []
        query = query.lower()
        catalog = self.getCatalog()
        values = catalog.uniqueValuesFor(keyword)
        for name in values:
            if not name:
                continue
            if not name.lower().startswith(query):
                continue
            name = name.replace('"', '&quot;')

            result.append(
                {"name": name, "value": name[:60]})
        result = {'resultSet':{'result':result}}
        self.REQUEST.response.setHeader(
            'Content-Type', 'text/plain; charset=utf-8')
        return simplejson.dumps(result).encode('utf8')


class Query(Content, SimpleItem, AutocompletionQueryFieldMixIn, SearchQuery, FeedMixIn):
    """A query for items.

    An OAI Query returns results of a search within a harvested OAI repository.
    It consists of two parts: one restricts the listing of items by certain
    criteria, the other can be used to search within these items.
    """
    grok.implements(IQuery)
    silvaconf.icon('www/oai_query.png')
    silvaconf.priority(3)

    meta_type = 'Silva OAI Query'
    security = ClassSecurityInfo()

    #XXX Default value for existing query objects
    _display_list = False

    def __init__(self, id):
        Content.__init__(self, id)
        SearchQuery.__init__(self)
        self._intro_text = None
        self._display_list = False

    security.declareProtected(permissions.ViewManagementScreens, 'get_service')
    get_service = SearchQuery.getService
    security.declareProtected(permissions.ViewManagementScreens, 'set_service')
    set_service = SearchQuery.setService

    security.declareProtected(
        permissions.ChangeSilvaContent, 'is_deletable')
    def is_deletable(self):
        """A Query is always deletable. (Since it is always published, the
        choices for deletable are always or never, and never makes the least
        sense ;)
        """
        return 1

    security.declareProtected(
        permissions.AccessContentsInformation, 'is_published')
    def is_published(self):
        """Always be published."""
        return 1

    # MANIPULATORS
    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSet')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSort')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setSortOrder')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setFilters')

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setIntroText')
    def setIntroText(self, text):
        self._intro_text = text

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setDisplayList')
    def setDisplayList(self, display_list):
        self._display_list = display_list

    security.declareProtected(
        permissions.AccessContentsInformation, 'updateSearchForm')
    def updateSearchForm(self, form):
        self.addFulltextSearchField(form)

    security.declareProtected(
        permissions.ChangeSilvaContent, 'updateManageForm')
    def updateManageForm(self, form):
        self.addSetField(form)
        Query.inheritedAttribute('updateManageForm')(self, form)

    # ACCESSORS

    security.declareProtected(
        permissions.AccessContentsInformation, 'getService')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getCatalog')

    security.declarePublic(
        permissions.AccessContentsInformation, 'getMetadataFormat')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getSet')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getFields')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getFilters')

    security.declarePrivate('updateQuery')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getSearchables')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getInitialSortOn')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getInitialSortOrder')

    security.declareProtected(
        permissions.AccessContentsInformation, 'getColumns')

    security.declareProtected(
        permissions.AccessContentsInformation, 'displayList')
    def displayList(self):
        return self._display_list

    security.declareProtected(
        permissions.AccessContentsInformation, 'getIntroText')
    def getIntroText(self):
        return self._intro_text

    security.declareProtected(
        permissions.AccessContentsInformation, 'searchResults')
    def searchResults(self, request, advanced=False):
        # XXX validation should move to outer UI layer?
        form_input = self.getSearchForm(advanced=advanced).validate_all(request)
        search_query = self.getSearchQuery(form_input)
        fulltext = form_input.get('fulltext', None)
        if fulltext:
            search_query['fulltext'] = fulltext
        # Non-Formulator fields, that are in the request anyway
        sort_on = request.form.get('sort_on')
        if sort_on:
            search_query['sort_on'] = sort_on
        sort_order = request.form.get('sort_order')
        if sort_order:
            search_query['sort_order'] = sort_order
        return self.queryResults(search_query)

    def getSearchQuery(self, form_input):
        q = {}
        searchables = self.getSearchables()
        for field in self.getFields():
            id = field.getId()
            if id not in searchables or self._filters.has_key(id):
                continue
            unique_values = None
            if field.getIndexType() != 'KeywordIndex':
                continue
            unique_values = self.getUniqueValues(id)
            field.updatePublicQuery(q, form_input, unique_values)
        return q

    security.declareProtected(
        permissions.ChangeSilvaContent, 'getManageForm')
    def getManageForm(self):
        query_form = ZMIForm('query_form', 'Query Form', 1)
        self.updateManageForm(query_form)
        return query_form.__of__(self)

    security.declareProtected(
        permissions.AccessContentsInformation, 'getSearchForm')
    def getSearchForm(self, advanced=False):
        search_form = ZMIForm('search_form', 'Search Form', 1)
        if advanced:
            self.addSearchFields(search_form)
        self.updateSearchForm(search_form)
        return search_form.__of__(self)

InitializeClass(Query)


class IQueryAddSchema(ITitledContent):

    service = schema.Choice(
        title = _(u"OAI Storage"),
        description = _("OAI Storage to query."),
        source = oai_storages)


class QueryAddForm(silvaforms.SMIAddForm):
    grok.context(IQuery)
    grok.name('Silva OAI Query')

    fields = silvaforms.Fields(IQueryAddSchema)


class QueryView(silvaviews.View):
    grok.context(IQuery)

    def render_field(self, field):
        if isinstance(field, tuple) or isinstance(field, list):
            return u", ".join(field)
        if isinstance(field, DateTime):
            return get_formatted_date(
                field.asdatetime(),
                size='medium', locale=self.locale, display_time=False)
        return unicode(field)

    def prepare_record(self, columns, record):
        info = {}
        metadata = []
        for column in columns:
            metadata.append(
                {'type': column, 'value': self.render_field(record[column])})
        info['metadata'] = metadata
        info['url'] = '/'.join((self.query_url, '++record++' + record.id))
        return info

    def update(self):
        self.as_list = self.context.displayList()
        self.query_url = absoluteURL(self.context, self.request)
        self.locale = get_locale_info(self.request)
        self.advanced = self.request.get('advanced_search', False)
        self.columns = self.content.getColumns()
        records = batch(
            self.context.searchResults(self.request, self.advanced),
            count=20,
            request=self.request)
        self.records = imap(
            partial(
                self.prepare_record,
                map(operator.itemgetter('id'), self.columns)),
            records)
        self.batch = getMultiAdapter((self.context, records, self.request), IBatching)()


class QueryDirectoryIndexView(silvaviews.View):
    grok.context(IQuery)
    grok.name('directory-index.html')

    def update(self):
        self.records = []
        query_url = absoluteURL(self.context, self.request)
        for record in self.context.queryResults({}):
            self.records.append(
                {'identifier': record.id,
                 'url': '/'.join((query_url, '++record++' + record.id))})


class ContainerDirectoryIndexView(silvaviews.View):
    grok.context(IContainer)
    grok.name('directory-index.html')

    def update(self):
        self.queries = []
        catalog = self.context.service_catalog
        for brain in catalog.searchResults({'meta_type': 'Silva OAI Query'}):
            query = brain.getObject()
            self.queries.append(
                {'identifier': query.get_title(),
                 'url': absoluteURL(query, self.request)  + '/directory-index.html'})
