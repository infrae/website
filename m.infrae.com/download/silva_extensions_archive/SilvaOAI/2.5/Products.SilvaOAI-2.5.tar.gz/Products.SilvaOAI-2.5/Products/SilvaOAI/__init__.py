# Copyright (c) 2004-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core import conf as silvaconf
from silva.core.conf.installer import DefaultInstaller
from zope.interface import Interface

# overwrite default oai_dc schema from OAICore to use autocompletion
# widgets if SilvaYUI formulator widgets are available
try:
    import Products.SilvaYUI

    from Products.OAICore import schemaRegistry
    from Products.SilvaOAI.oai_dc import oai_dc_schema

    if 'oai_dc' in schemaRegistry.registeredPrefixes():
        schemaRegistry.removeSchemasForPrefix('oai_dc')
        schemaRegistry.registerSchemaForDefaultReader('oai_dc', oai_dc_schema)

except ImportError:
    pass


silvaconf.extension_name('SilvaOAI')
silvaconf.extension_title('Silva OAI')
silvaconf.extension_depends(["SilvaExternalSources"])


class IExtension(Interface):
    """Silva OAI extension.
    """


class SilvaOAIInstaller(DefaultInstaller):

    def install_custom(self, root):
        reg = root.service_view_registry
        reg.register('edit', 'Silva OAI Query', ['edit', 'Content', 'SilvaOAIQuery'])
        reg.register('edit', "Silva OAI Source", ['edit', 'Asset', 'QuerySourceAsset'])
        reg.register('edit', "Silva OAI Cherry", ['edit', 'Asset', 'QuerySourceAsset'])


install = SilvaOAIInstaller('SilvaOAI', IExtension)


CLASS_CHANGES = {
    'Products.SilvaOAI.silvaoai Query': 'Products.SilvaOAI.query Query',
    'Products.SilvaOAI.cherrypicking Cherry': 'Products.SilvaOAI.source CherryExternalSource',
    'Products.SilvaOAI.oaisource QuerySourceAsset': 'Products.SilvaOAI.source QueryExternalSource'}
