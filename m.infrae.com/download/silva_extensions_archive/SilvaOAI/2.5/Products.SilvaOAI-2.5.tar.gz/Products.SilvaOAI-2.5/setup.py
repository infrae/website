# Copyright (c) 2004-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from setuptools import setup, find_packages
import os

version = '2.5'

setup(name='Products.SilvaOAI',
      version=version,
      long_description=open(os.path.join("Products", "SilvaOAI", "README.txt")).read() + "\n" +
                       open(os.path.join("Products", "SilvaOAI", "HISTORY.txt")).read(),
      description="OAI integration for Silva",
      classifiers=[
              "Development Status :: 5 - Production/Stable",
              "Framework :: Zope2",
              "License :: OSI Approved :: BSD License",
              "Programming Language :: Python",
              "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='zope2 silva harvesting oai oaipmh',
      author='Infrae',
      author_email='info@infrae.com',
      url='http://infrae.com/products/oaipack',
      license='BSD',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'Products.OAICore',
          'Products.Silva',
          'Products.SilvaExternalSources',
          'five.grok',
          'silva.core.conf',
          'silva.core.interfaces',
          'silva.core.upgrade',
          'z3locales',
         ],
      extras_require = {'yui': ['Products.SilvaYUI', 'simplejson']},
      entry_points = """
      [zodbupdate]
      renames = Products.SilvaOAI:CLASS_CHANGES
      """
      )
