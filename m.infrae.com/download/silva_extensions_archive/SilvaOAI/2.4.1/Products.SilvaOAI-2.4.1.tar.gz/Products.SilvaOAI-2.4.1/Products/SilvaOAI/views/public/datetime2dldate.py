##parameters=dt
date = "%(year)04d-%(month)02d-%(day)02d" % {
    'year': dt.year(), 
    'month': dt.month(), 
    'day': dt.day()}

return date
