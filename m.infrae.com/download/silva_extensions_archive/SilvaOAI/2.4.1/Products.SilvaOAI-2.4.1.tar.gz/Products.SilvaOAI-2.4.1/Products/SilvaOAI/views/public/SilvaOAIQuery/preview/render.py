model = context.REQUEST.model
version = model.get_previewable()
return context.render_helper(version=version, mode='preview')
