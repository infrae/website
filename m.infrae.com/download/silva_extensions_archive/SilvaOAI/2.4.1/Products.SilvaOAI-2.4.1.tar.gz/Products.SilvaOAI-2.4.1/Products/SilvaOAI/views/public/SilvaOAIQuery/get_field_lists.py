## Script (Python) "get_field_lists"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=advanced=False
##title=Get current batch from results sequence
##

model = context.REQUEST.model
list_of_lists = []
for field in model.getSearchForm(advanced=advanced).get_fields():
    if field.id[:7] == "list_1_":
        list_of_lists[-1].append(field)
    else:
        list_of_lists.append([field])
        
return list_of_lists