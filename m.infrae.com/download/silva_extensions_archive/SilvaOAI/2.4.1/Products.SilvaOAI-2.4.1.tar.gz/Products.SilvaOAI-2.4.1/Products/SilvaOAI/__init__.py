# SilvaOAI
# Silva objects for OAI

from Products.FileSystemSite.DirectoryView import registerDirectory
from Products.Silva.ExtensionRegistry import extensionRegistry
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata

import silvaoai, oaisource, install, upgrade_12


def initialize(context):
    extensionRegistry.register(
        'SilvaOAI', 'Silva OAI', context, [], install, depends_on='SilvaExternalSources')
    
    context.registerClass(

        silvaoai.Query,
        constructors = (
            silvaoai.manage_addQueryForm, 
            silvaoai.manage_addQuery)
            ,
        icon = "www/oai_query.png"
        )

    context.registerClass(
        oaisource.QuerySourceAsset,
        constructors = (oaisource.manage_addQueryForm, 
                        oaisource.manage_addQuerySourceAsset),
        icon = "www/oai_source.png"
        )
            
    context.registerClass(
        cherrypicking.Cherry,
        constructors = (cherrypicking.manage_addQuerySourceForm,
                        cherrypicking.manage_addCherryFromZMI),
        icon = "www/oai_source.png"
        )
        
    registerDirectory('views', globals())
    registerDirectory('images', globals())    
    
    registerTypeForMetadata(silvaoai.Query.meta_type)
    registerTypeForMetadata(oaisource.QuerySourceAsset.meta_type)

    extensionRegistry.addAddable(silvaoai.Query.meta_type, 3)
    extensionRegistry.addAddable(oaisource.QuerySourceAsset.meta_type, 3)

    # overwrite default oai_dc schema from OAICore to use autocompletion
    # widgets if SilvaYUI formulator widgets are available
    try:
        import Products.SilvaYUI as YUI
    except ImportError:
        YUI = None

    if not YUI is None:
        from Products.OAICore import schemaRegistry
        from oai_dc import oai_dc_schema

        if 'oai_dc' in schemaRegistry.registeredPrefixes():
            schemaRegistry.removeSchemasForPrefix('oai_dc')
            schemaRegistry.registerSchemaForDefaultReader('oai_dc', 
                                                          oai_dc_schema)
