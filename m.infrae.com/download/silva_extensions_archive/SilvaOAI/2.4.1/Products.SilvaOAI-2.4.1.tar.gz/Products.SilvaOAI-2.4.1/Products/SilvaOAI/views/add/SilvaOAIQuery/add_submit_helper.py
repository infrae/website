##parameters=model, id, title, result

oai_service = context.restrictedTraverse(result['oai_service'])

if result['object_type'] == 'Silva OAI Source':
    factory = model.manage_addProduct['SilvaOAI'].manage_addQuerySourceAsset
else:
    factory = model.manage_addProduct['SilvaOAI'].manage_addQuery
    
factory(id, title, oai_service)
    
return getattr(model, id) 

