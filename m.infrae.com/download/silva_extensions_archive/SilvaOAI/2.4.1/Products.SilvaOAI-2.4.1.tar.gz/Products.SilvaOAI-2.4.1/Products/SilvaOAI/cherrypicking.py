# Copyright (c) 2002-2007 Infrae. All rights reserved.
# See also LICENSE.txt

from Globals import InitializeClass, package_home
from AccessControl import ClassSecurityInfo
from OFS import SimpleItem

from Products.PageTemplates.PageTemplateFile import PageTemplateFile

from Products.Formulator.Form import ZMIForm

from Products.Silva import SilvaPermissions as permissions
from Products.Silva import helpers
from Products.SilvaOAI.oaisource import QuerySource

class Cherry(QuerySource):
    """Code Source-like object that accepts the identifier for a
       cherry picked document, and displays the document's
       metadata.
    """
    
    meta_type = 'OAI Cherry'

    security = ClassSecurityInfo()

    def __init__(self, id, service, metadata_format="oai_dc"):
        QuerySource.__init__(self, id, service)
        self.setMetadataFormat(metadata_format)

    # ExternalSource
    security.declareProtected(permissions.ChangeSilvaContent, 'form')
    def form(self):
        f = ZMIForm('cherries', 'Cherries', 1)
        f.manage_addField('identifier', 'Identifier', 'StringField')
        field = f['identifier']
        field.values['description'] = 'Identifier for the Record'
        field.values['required'] = 1
        return f.__of__(self)
        
    security.declareProtected(
        permissions.AccessContentsInformation, 'recordForIdentifier')
    def recordForIdentifier(self, identifier):
        brains = self.queryResults({'metadata_identifier': identifier})
        # What would it mean if I find more than 1 record for a handle?
        if len(brains) > 1:
            # XXX use logging here!
            print 'Huh, more than 1 record?', identifier, len(brains)
        return brains[:1]
    
    security.declareProtected(
        permissions.AccessContentsInformation, 'to_html')
    def to_html(self, REQUEST, **kw):
        """Render HTML for inclusion in Silva Documents.
        """
        identifier = kw.get('identifier', None)
        if identifier is None:
            return self.recordLayout(record=None)
        return self.recordLayout(
            results=self.recordForIdentifier(identifier))
        
    security.declareProtected(
        permissions.AccessContentsInformation, 'recordLayout')
    def recordLayout(self, results):
        return self.public['records'](
            results=results, batching_info=False, topic_links=False)
    
InitializeClass(Cherry)
        
def manage_addCherry(context, id, title, service, metadata_format=None, REQUEST=None):
    """factory
    """
    query = Cherry(id, service, metadata_format=metadata_format)
    # XXX needs id validation
    context._setObject(id, query)
    query = getattr(context, id)
    query.title = title
    helpers.add_and_edit(context, id, REQUEST)
    return query

manage_addQuerySourceForm = PageTemplateFile(
    "www/CherryForm", globals(), __name__='manage_CherryForm')

def manage_addCherryFromZMI(context, id, title, service_id, metadata_format=None, REQUEST=None):
    """factory for ZMI add
    """
    service = context.restrictedTraverse(service_id)
    return manage_addCherry(context, id, title, service, metadata_format=metadata_format, REQUEST=None)
