from Products.Formulator.Errors import ValidationError, FormValidationError
request = context.REQUEST
model = request.model
view = context

try:
    result = model.getManageForm().validate_all(context.REQUEST)
except FormValidationError, e:
    return view.tab_edit(message_type="error",
                         message=view.render_form_errors(e))

if result.has_key('set'):                         
    if result['set'] == 'none':
        model.setSet(None)
    else:
        model.setSet(result['set'])

for key, value in result.copy().items():
    if same_type(value, []):
        if 'none' in value:
            del result[key]
    elif value == 'none':
        del result[key]
        
model.setFilters(result)
    
return view.tab_edit(message_type="feedback", message="Silva OAI Source Changed")
