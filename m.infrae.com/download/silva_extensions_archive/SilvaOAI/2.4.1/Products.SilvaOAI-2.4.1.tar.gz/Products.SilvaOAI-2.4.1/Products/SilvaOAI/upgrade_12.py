
# zope imports
import zLOG
from zope.interface import implements

log_severity = zLOG.INFO

# silva imports
from Products.Silva.upgrade import registry
from Products.Silva.interfaces import IUpgrader
from Products.OAICore.query import UniqueValues

# upgraders for Silva version 1.2 (SilvaOAI 2.0)

class QueryUpgrader:
    
    implements(IUpgrader)

    def upgrade(self, obj):
        zLOG.LOG(
            'SilvaOAI',
            log_severity,
            'Changed service property to a physical path on Silva OAI Query %s' % 
                '/'.join(obj.getPhysicalPath())
            )
        if not hasattr(obj, '_service_path'):
            zLOG.LOG(
                'SilvaOAI',
                log_severity,
                'Changed service property to a physical path on Silva OAI Query %s' % 
                '/'.join(obj.getPhysicalPath())
                )
            obj._service_path = getattr(obj, obj._service).getPhysicalPath()
            zLOG.LOG(
                'SilvaOAI',
                log_severity,
                'Added _unique_values attribute to Silva OAI Query %s' % 
                '/'.join(obj.getPhysicalPath())
                )
            obj._unique_values = UniqueValues()
        return obj
        
registry.registerUpgrader(
    QueryUpgrader(), '1.2', 'Silva OAI Query')
