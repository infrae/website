model = context.REQUEST.model
view = context

prefix, name = context.REQUEST['metadata_format'].split('|')
model.setSchema(prefix, name)
return view.tab_edit(message_type="feedback", message="Silva OAI Query Changed")
