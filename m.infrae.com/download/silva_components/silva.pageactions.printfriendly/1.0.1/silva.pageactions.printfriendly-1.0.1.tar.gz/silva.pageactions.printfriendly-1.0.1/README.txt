silva.pageactions.printfriendly
===============================

This extension provides an page actions to display simply the content
of a page (without layout items) in order to be print.


