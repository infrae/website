silva.pageactions.base
======================

silva.pageactions.base define an infrastructure to write and share
actions on pages (like send this page by mail, do a PDF, translation).




