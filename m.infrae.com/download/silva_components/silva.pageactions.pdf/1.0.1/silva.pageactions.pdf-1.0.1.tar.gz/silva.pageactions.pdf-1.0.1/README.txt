silva.pageactions.pdf
=====================

This extension provides a page actions to download a PDF version of
the current page.

This use the extension silva.pageactions.printfriendly to get a simple
version of the page, and call htmldoc. You *need* to install htmldoc.



