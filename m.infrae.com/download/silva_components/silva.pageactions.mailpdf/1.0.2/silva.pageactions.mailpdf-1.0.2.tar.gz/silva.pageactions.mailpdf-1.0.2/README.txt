silva.pageactions.mailpdf
=========================

This extension let the user to send the current page as a PDF. To
generate the PDF it depends on silva.pageactions.pdf.



