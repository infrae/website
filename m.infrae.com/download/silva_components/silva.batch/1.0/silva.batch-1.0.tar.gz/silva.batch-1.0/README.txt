silva.batch
===========

``silva.batch`` let define pagination in Silva using `zeam.utils.batch
<http://pypi.python.org/pypi/zeam.utils.batch>`_.

