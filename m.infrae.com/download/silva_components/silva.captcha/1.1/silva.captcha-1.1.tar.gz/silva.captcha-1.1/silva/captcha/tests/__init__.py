# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 28983 2008-06-04 10:18:12Z sylvain $


