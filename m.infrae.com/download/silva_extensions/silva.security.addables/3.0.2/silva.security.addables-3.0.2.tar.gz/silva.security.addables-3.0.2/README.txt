======================
silva.security.addable
======================

This small `Silva`_ extension provides an interface in the Silva
management interface to configure which Silva roles have the
permission to add which Silva content type.

It is ensuring that the permissions currently set are correct
according the Silva logic.

It requires at least `Silva`_ 3.0.

Latest version
==============

You can find the code in a Git repository:
https://github.com/silvacms/silva.security.addables

.. _Silva: http://silvacms.org
