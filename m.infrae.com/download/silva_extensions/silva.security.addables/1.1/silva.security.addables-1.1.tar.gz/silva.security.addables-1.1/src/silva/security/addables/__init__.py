# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 45622 2010-10-01 13:30:28Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.security.addables')
silvaconf.extensionTitle('Silva Security Addables')
silvaconf.extensionSystem()
