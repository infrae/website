# -*- coding: utf-8 -*-
# Copyright (c) 2008-2012 Infrae. All rights reserved.
# See also LICENSE.txt

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.security.addables')
silvaconf.extensionTitle('Silva Security Addables')
silvaconf.extensionSystem()
