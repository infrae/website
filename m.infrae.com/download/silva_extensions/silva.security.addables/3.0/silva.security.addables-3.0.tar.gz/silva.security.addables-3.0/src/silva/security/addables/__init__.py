# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.security.addables')
silvaconf.extensionTitle('Silva Security Addables')
silvaconf.extensionSystem()
