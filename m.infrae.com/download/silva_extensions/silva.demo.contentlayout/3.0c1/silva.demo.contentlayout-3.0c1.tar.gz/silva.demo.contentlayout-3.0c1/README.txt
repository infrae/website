========================
silva.demo.contentlayout
========================

This package contains demonstration template for the Silva content
layout system extension, ``silva.core.contentlayout``.

For more information on how to define you own templates, please refer
to the `extension developer documentation`_.

Credits
=======

Thanks to `UCL`_ for sponsoring this extension.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.demo.contentlayout/.

.. _UCL: http://www.ucl.ac.uk/
.. _extension developer documentation: http://docs.infrae.com/silva/trunk/addons/contentlayout/index.html


