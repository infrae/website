=================
silva.export.html
=================

This extension export Silva content to regular HTML pages the export
SMI tab.

Code repository
===============

You can find the code of this extension in Mercurial:
https://hg.infrae.com/silva.export.html/.
