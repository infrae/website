================
smitheme.phoenix
================

Alternate skin for the `Silva`_ Management Interface (SMI) for Silva
2.3.1 and greater.

To use this skin, just activate the extension in your service_extension.

.. _Silva: http://infrae.com/products/silva
