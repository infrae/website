================
smitheme.phoenix
================

Alternate skin for the Silva Management Interface (SMI) for `Silva`_
2.3.1 and greater.

To use this skin, just activate the extension in your `service_extension`.

.. _Silva: http://infrae.com/products/silva
