return "This is just a placeholder so this directory won't get pruned."
