view = context
return view.publish_helper(publish_now=True)

