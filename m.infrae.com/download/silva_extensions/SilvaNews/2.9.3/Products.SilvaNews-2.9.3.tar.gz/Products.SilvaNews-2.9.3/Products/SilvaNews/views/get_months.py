## Script (Python) "get_months"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##

return context.service_news.get_month_abbrs()
