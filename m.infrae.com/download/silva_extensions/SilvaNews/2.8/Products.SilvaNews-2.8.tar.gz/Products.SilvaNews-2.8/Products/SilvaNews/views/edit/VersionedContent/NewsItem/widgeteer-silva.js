/* register the widgeteer load and unload stuff to the handler registries */
window.onload_registry.register(function() 
        {widgeteer.widget_registry.prepareForms()});
