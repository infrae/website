# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 45359 2010-09-20 16:59:47Z sylvain $

from silva.core import conf as silvaconf

silvaconf.extensionName('silva.app.subscriptions')
silvaconf.extensionTitle('Silva Subscriptions')
silvaconf.extensionSystem()
