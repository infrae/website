# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: interfaces.py 45307 2010-09-17 15:30:14Z sylvain $

from Products.PluggableAuthService.interfaces import plugins

class ICookiePlugin(
    plugins.IAuthenticationPlugin,
    plugins.IExtractionPlugin,
    plugins.IChallengePlugin,
    plugins.ICredentialsResetPlugin):
    pass
