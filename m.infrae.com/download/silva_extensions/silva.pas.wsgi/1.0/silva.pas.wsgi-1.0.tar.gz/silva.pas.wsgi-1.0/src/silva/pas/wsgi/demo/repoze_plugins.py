# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from zope.interface import implements

from repoze.who.interfaces import IAuthenticator, IMetadataProvider


USERS = {
    'testuser1': {'password': 'test',
                  'first_name': 'Arthur',
                  'last_name': 'Accroc',
                  'groups': ['group1', 'group2']},
    'testuser2': {'password': 'test',
                  'first_name': 'Torvald',
                  'last_name': 'Boskat',
                  'groups': ['group2', 'group3']},
    }


class DemoMetadataProvider(object):
    """Demo user metadata provider.
    """
    implements(IMetadataProvider)

    def add_metadata(self, environ, identity):
        userid = identity.get('repoze.who.userid')
        info = USERS.get(userid)
        if info is not None:
            identity['first_name'] = info['first_name']
            identity['last_name'] = info['last_name']


def make_metadata_plugin():
    return DemoMetadataProvider()


class DemoAuthenticator(object):
    """Demo authenticator.
    """
    implements(IAuthenticator)

    def authenticate(self, environ, identity):
        try:
            login = identity['login']
            password = identity['password']
        except KeyError:
            return None

        if login in USERS and USERS[login]['password'] == password:
            return login
        return None


def make_authenticator_plugin():
    return DemoAuthenticator()
