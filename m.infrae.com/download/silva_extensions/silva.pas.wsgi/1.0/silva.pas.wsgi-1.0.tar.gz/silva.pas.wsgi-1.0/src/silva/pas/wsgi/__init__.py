# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$


from AccessControl.Permissions import manage_users as ManageUsers
from Products.PluggableAuthService import registerMultiPlugin

from silva.pas.wsgi import user, json

registerMultiPlugin(user.WSGIUserPlugin.meta_type)
registerMultiPlugin(json.JSONLookupUserPlugin.meta_type)
registerMultiPlugin(json.JSONLookupGroupPlugin.meta_type)

def initialize(context):
    context.registerClass(user.WSGIUserPlugin,
                          permission=ManageUsers,
                          constructors=
                          (user.manage_addWSGIUserPluginForm,
                           user.manage_addWSGIUserPlugin),
                          visibility=None,
                          icon="www/user.png")
    context.registerClass(json.JSONLookupUserPlugin,
                          permission=ManageUsers,
                          constructors=
                          (json.manage_addJSONLookupUserPluginForm,
                           json.manage_addJSONLookupUserPlugin),
                          visibility=None,
                          icon="www/lookup.png")
    context.registerClass(json.JSONLookupGroupPlugin,
                          permission=ManageUsers,
                          constructors=
                          (json.manage_addJSONLookupGroupPluginForm,
                           json.manage_addJSONLookupGroupPlugin),
                          visibility=None,
                          icon="www/lookup.png")
