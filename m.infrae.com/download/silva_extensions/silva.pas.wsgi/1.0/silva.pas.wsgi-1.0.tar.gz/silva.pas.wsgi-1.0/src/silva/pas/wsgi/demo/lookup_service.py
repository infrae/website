# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.escape

from silva.pas.wsgi.demo import index

PORT = 8888
USERS = index.WildcardSearch(
    {'arthur': {'id': 'arthur', 'login':'Arthur'},
     'wimbou': {'id':'wimbou', 'login': 'Wim'},
     'torvald': {'id': 'torvald', 'login': 'Torvald'},
     'thor': {'id': 'thor', 'login': 'Thor'},
     'sylvain': {'id': 'sylvain', 'login': 'Sylvain'},
     'silva': {'id': 'silva', 'login': 'Silva Admin'},
     })
GROUPS = index.WildcardSearch(
    {'members': {'id': 'members', 'title': 'Site Members'},
     'admins': {'id': 'admins', 'title': 'Site Administrators'},
     'visitors': {'id': 'visitors', 'title': 'Site Visitors'},
     'moderators': {'id': 'moderators', 'title': 'Site Moderators'},
     })


class JSONSearchHandler(tornado.web.RequestHandler):
    """JSON API to look for users/groups.
    """

    def initialize(self, database):
        self.database = database

    def post(self):
        exact_match = self.get_argument('exact_match', 'false') == 'true'
        users = self.database(self.get_argument('search', '*'), exact_match)
        self.write(tornado.escape.json_encode(users))


application = tornado.web.Application([
    (r"/users", JSONSearchHandler, dict(database=USERS)),
    (r"/groups", JSONSearchHandler, dict(database=GROUPS)),
    ])


def service():
    print 'User lookup url: http://localhost:%d/users' % PORT
    print 'Group lookup url: http://localhost:%d/groups' % PORT
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(PORT)
    print 'Ready.'
    tornado.ioloop.IOLoop.instance().start()
