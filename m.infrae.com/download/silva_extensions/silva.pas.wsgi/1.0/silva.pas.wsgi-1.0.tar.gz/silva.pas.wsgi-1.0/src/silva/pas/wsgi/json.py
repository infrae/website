# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

import urllib
import urllib2
import simplejson
import operator

from AccessControl import ClassSecurityInfo
from App.class_init import InitializeClass

from Products.PluggableAuthService.plugins.BasePlugin import BasePlugin
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

from zope.interface import implements
from silva.pas.wsgi.interfaces import IJSONLookupUserPlugin
from silva.pas.wsgi.interfaces import IJSONLookupGroupPlugin
from silva.core.cache.descriptors import cached_method


class JSONLookupPlugin(BasePlugin):
    """A JSON lookup plugin.
    """
    _properties = ({'id': 'title',
                    'label' : 'Title',
                    'type'  : 'string',
                    'mode'  : 'w'},
                   {'id': 'url',
                    'label' : 'URL of search service',
                    'type'  : 'string',
                    'mode'  : 'w'})

    def __init__(self, id, title=None, url=None):
        # BasePlugin lacks of a default working __init__
        self._setId(id)
        self.title = title
        self.url = url

    def _query(self, search, exact_match):
        query = urllib.urlencode({'search': search, 'exact_match': exact_match})
        return simplejson.load(urllib2.urlopen(self.url, query))

    def _limit(self, results, sort_by, max_results):
        if sort_by:
            results.sort(key=operator.itemgetter(sort_by))
        if max_results:
            results = results[:max_results]
        plugin_id = self.getId()
        for result in results:
            result['pluginid'] = plugin_id
        return results


class JSONLookupUserPlugin(JSONLookupPlugin):
    """A JSON user lookup plugin.
    """
    security = ClassSecurityInfo()
    meta_type = 'JSON Lookup User Plugin'
    implements(IJSONLookupUserPlugin)

    security.declarePrivate('enumerateUsers')
    @cached_method(expire=1200)
    def enumerateUsers(
        self, id=None, login=None, exact_match=False, sort_by=None,
        max_results=None, **kw):
        return self._limit(self._query(id, exact_match), sort_by, max_results)


InitializeClass(JSONLookupUserPlugin)


manage_addJSONLookupUserPluginForm = PageTemplateFile(
    'www/userLookupAddForm',
    globals(),
    __name__="manage_addJSONLookupUserPluginForm")


def manage_addJSONLookupUserPlugin(self, id, title='', url='', RESPONSE=None ):
    """Add a WSGI user pas plugin.
    """
    plugin = JSONLookupUserPlugin(id, title, url)
    self._setObject(id, plugin)

    if RESPONSE is not None:
        RESPONSE.redirect('manage_workspace')


class JSONLookupGroupPlugin(JSONLookupPlugin):
    """A JSON group lookup plugin.
    """
    security = ClassSecurityInfo()
    meta_type = 'JSON Lookup Group Plugin'
    implements(IJSONLookupGroupPlugin)

    security.declarePrivate('enumerateGroups')
    @cached_method(expire=1200)
    def enumerateGroups(
        self, id=None, exact_match=False, sort_by=None, max_results=None, **kw):
        return self._limit(self._query(id, exact_match), sort_by, max_results)


InitializeClass(JSONLookupGroupPlugin)


manage_addJSONLookupGroupPluginForm = PageTemplateFile(
    'www/groupLookupAddForm',
    globals(),
    __name__="manage_addJSONLookupGroupPluginForm")


def manage_addJSONLookupGroupPlugin(self, id, title='', url='', RESPONSE=None ):
    """Add a WSGI group pas plugin.
    """
    plugin = JSONLookupGroupPlugin(id, title, url)
    self._setObject(id, plugin)

    if RESPONSE is not None:
        RESPONSE.redirect('manage_workspace')
