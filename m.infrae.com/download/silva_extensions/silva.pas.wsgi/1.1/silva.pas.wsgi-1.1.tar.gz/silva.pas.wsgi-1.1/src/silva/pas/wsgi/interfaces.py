# -*- coding: utf-8 -*-
# Copyright (c) 2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$


from Products.PluggableAuthService.interfaces import plugins


class IWSGIUserPlugin(plugins.IAuthenticationPlugin,
                      plugins.ICredentialsResetPlugin,
                      plugins.IChallengePlugin,
                      plugins.ILoginPasswordExtractionPlugin,
                      plugins.IUserEnumerationPlugin,
                      plugins.IGroupsPlugin):
    """Authenticate WSGI user in Zope.
    """


class IJSONLookupUserPlugin(plugins.IUserEnumerationPlugin):
    """Remotely look for user information.
    """


class IJSONLookupGroupPlugin(plugins.IGroupEnumerationPlugin):
    """Remotely look for user information.
    """
