==============
silva.pas.wsgi
==============

`silva.pas.wsgi` add support into Zope 2 to WSGI authentication stack by
providing a PAS plugin for it.

