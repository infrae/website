# -*- coding: utf-8 -*-
# Copyright (c) 2008-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 28228 2008-04-04 16:24:55Z sylvain $
