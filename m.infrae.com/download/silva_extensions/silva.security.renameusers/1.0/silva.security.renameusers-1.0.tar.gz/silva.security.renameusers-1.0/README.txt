==========================
silva.security.renameusers
==========================


This extension provides you with a form on the Silva
``service_extensions`` named ``manage_renameUsers`` that let you in
one time rename a lot of Silva users across all the Silva site.

To do this, you upload in this form a CSV file that contains a mapping
from the new user identifier to the old one.
