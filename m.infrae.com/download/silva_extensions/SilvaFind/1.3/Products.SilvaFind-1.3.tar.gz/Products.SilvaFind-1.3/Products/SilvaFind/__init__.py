# Copyright (c) 2006-2010 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id: __init__.py 44207 2010-07-30 16:45:22Z sylvain $

from Products.FileSystemSite.DirectoryView import registerDirectory
from Products.SilvaFind import install
from silva.core import conf as silvaconf


silvaconf.extensionName('SilvaFind')
silvaconf.extensionTitle('Silva Find')

registerDirectory('resources', globals())

