# -*- coding: utf-8 -*-
# Copyright (c) 2012-2013 Infrae. All rights reserved.
# See also LICENSE.txt
# This is a package.

from silva.core.xml import registerNamespace

NS_FIND_URI = 'http://infrae.com/namespace/silva-find'
registerNamespace('silva-find', NS_FIND_URI)
