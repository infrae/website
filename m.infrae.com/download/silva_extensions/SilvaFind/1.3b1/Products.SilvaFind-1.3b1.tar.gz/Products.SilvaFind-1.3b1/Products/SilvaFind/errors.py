
class SilvaFindError(ValueError):
    pass

