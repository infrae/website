
class SilvaFindError(Exception):
    pass

