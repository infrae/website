======================
silva.app.mediacontent
======================

``silva.app.mediacontent`` a set of simple content types to add and
manage local and remote media content in Silva.

This extension requires Silva 3.x.

Code repository
===============

The code for this extension can be found in Mercurial:
https://hg.infrae.com/silva.app.mediacontent

