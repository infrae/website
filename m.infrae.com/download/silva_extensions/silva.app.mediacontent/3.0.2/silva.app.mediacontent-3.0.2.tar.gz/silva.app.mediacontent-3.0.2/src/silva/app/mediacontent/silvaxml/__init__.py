# -*- coding: utf-8 -*-
# Copyright (c) 2013 Infrae. All rights reserved.
# See also LICENSE.txt
# package

from silva.core.xml import registerNamespace

NS_MEDIACONTENT_URI = 'http://infrae.com/namespace/silva-app-mediacontent'
registerNamespace('silva-app-mediacontent', NS_MEDIACONTENT_URI)
