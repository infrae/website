Introduction
============

A Simple OAI Provider for the Silva Content Management System.

See:

http://www.openarchives.org/OAI/openarchivesprotocol.html

for more information on OAI-PMH.

To use in Silva, put the IOAIProvider marker interface on any
container. After that, calling /oaimph with any correct oai pmh
querystring should work.

