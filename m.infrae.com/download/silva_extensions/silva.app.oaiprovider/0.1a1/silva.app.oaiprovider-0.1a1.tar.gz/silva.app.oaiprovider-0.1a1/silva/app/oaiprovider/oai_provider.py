from zope.interface import Interface
from zope import interface
from grokcore import component
from Products.Silva import interfaces as silva_interfaces
from silva.core import conf as silvaconf
from silva.core.views import views as silvaviews
from oaipmh import common, error, server, metadata, datestamp
from interfaces import IOAIProvider
from datetime import datetime

PREFIXES = ('oai_dc',)
CONTENT_TYPES = ('Silva Document',)

class OAIProvider(object):
    _binding = None
    
    def __init__(self, context, baseURL):
        self.context = context
        self.baseURL = baseURL
        self.service_metadata = self.context.service_metadata
        
    def _create_header_and_metadata(self, metadataPrefix, record):
        stamp = datestamp.datetime_to_datestamp(
            ZDateTimeTodatetime(record.get_modification_datetime()))
        header = common.Header(identifier, stamp, [], False)
        metadata = self._get_metadata(metadataPrefix, record)
        return header, metadata

    def _get_metadata(self, metadataPrefix, record):
        binding = self.service_metadata.getMetadata(record.get_viewable())
        if metadataPrefix not in PREFIXES:
            raise error.CannotDisseminateFormatError
        return common.Metadata({
            'identifier': [record.absolute_url()],
            'title': [record.get_title()],
            'creator': [binding.get('silva-extra', 'creator')],
            'subject': [binding.get('silva-extra', 'subject')],
            'description': [binding.get('silva-extra', 'content_description')],
            'date': [datestamp.datetime_to_datestamp(
            ZDateTimeTodatetime(
            binding.get('silva-extra', 'publicationtime')))],
             })
        
    def getRecord(self, metadataPrefix, identifier):
        """Get a record for a metadataPrefix and identifier.

        metadataPrefix - identifies metadata set to retrieve
        identifier - repository-unique identifier of record
        
        Should raise error.CannotDisseminateFormatError if
        metadataPrefix is unknown or not supported by identifier.
        
        Should raise error.IdDoesNotExistError if identifier is
        unknown or illegal.

        Returns a header, metadata, about tuple describing the record.
        """
        if metadataPrefix not in PREFIXES:
            raise error.CannotDisseminateFormatError
        #XXX: maybe look up with interface/adapter
        record_ids = self.context.objectIds(CONTENT_TYPES)
        if identifier not in record_ids:
            raise error.IdDoesNotExistError, identifier
        # create header and metadata
        record = getattr(self.context, identifier)
        header, metadata = self._create_header_and_metadata(
            metadataPrefix, record)
        return header, metadata, None

    def identify(self):
        """Retrieve information about the repository.

        Returns an Identify object describing the repository.
        """
        return common.Identify(
            repositoryName=self.context.title,
            baseURL=self.baseURL,
            protocolVersion='2.0',
            adminEmails=[],
            earliestDatestamp=datetime(2001,1,1,10,00),
            deletedRecord='no',
            granularity='YYYY-MM-DDThh:mm:ssZ',
            compression=['identity'],)
    
    def listIdentifiers(self, metadataPrefix, set=None, from_=None, until=None):
        """Get a list of header information on records.

        metadataPrefix - identifies metadata set to retrieve
        set - set identifier; only return headers in set (optional)
        from_ - only retrieve headers from from_ date forward (optional)
        until - only retrieve headers with dates up to and including
                until date (optional)

        Should raise error.CannotDisseminateFormatError if metadataPrefix
        is not supported by the repository.

        Should raise error.NoSetHierarchyError if the repository does not
        support sets.
        
        Returns an iterable of headers.
        """
        for identifier, document, deleted in self._list(
            metadataPrefix, set, from_, until):
            yield common.Header(
                identifier,
                ZDateTimeTodatetime(document.get_modification_datetime()), 
                setspec=[], deleted=deleted)

    def listMetadataFormats(self, identifier=None):
        """List metadata formats supported by repository or record.

        identifier - identify record for which we want to know all
                     supported metadata formats. if absent, list all metadata
                     formats supported by repository. (optional)


        Should raise error.IdDoesNotExistError if record with
        identifier does not exist.
        
        Should raise error.NoMetadataFormatsError if no formats are
        available for the indicated record.

        Returns an iterable of metadataPrefix, schema, metadataNamespace
        tuples (each entry in the tuple is a string).
        """
        return [
            ('oai_dc', 
            'http://www.openarchives.org/OAI/2.0/oai_dc.xsd', 
            'http://www.openarchives.org/OAI/2.0/oai_dc/'),]
        
    def listRecords(self, metadataPrefix, set=None, from_=None, until=None):
        """Get a list of header, metadata and about information on records.

        metadataPrefix - identifies metadata set to retrieve
        set - set identifier; only return records in set (optional)
        from_ - only retrieve records from from_ date forward (optional)
        until - only retrieve records with dates up to and including
                until date (optional)

        Should raise error.CannotDisseminateFormatError if metadataPrefix
        is not supported by the repository.

        Should raise error.NoSetHierarchyError if the repository does not
        support sets.

        Returns an iterable of header, metadata, about tuples.
        """
        for identifier, document, deleted in self._list(
            metadataPrefix, set, from_, until):
            header = common.Header(
                identifier, ZDateTimeTodatetime(
                document.get_modification_datetime()),
                setspec=[], deleted=deleted)
            if not deleted:
                metadata = self._get_metadata(metadataPrefix, document)
            else:
                metadata = None
            yield header, metadata, None
        

    def listSets(self):
        """Get a list of sets in the repository.

        Should raise error.NoSetHierarchyError if the repository does not
        support sets.

        Returns an iterable of setSpec, setName tuples (strings).
        """
        raise error.NoSetHierarchyError
        
    def _list(self, metadataPrefix, set=None, from_=None, until=None):
        if set is not None:
            raise error.NoSetHierarchyError
        
        if metadataPrefix not in PREFIXES:
            raise error.CannotDisseminateFormatError

        # first expose available/alerted documents
        for document in self._getDocumentsInRange(from_, until):
            identifier = document.absolute_url()
            yield identifier, document, False

    def _getDocumentsInRange(self, from_, until):
        for document in self.context.objectValues(CONTENT_TYPES):
            date = ZDateTimeTodatetime(document.get_modification_datetime())
            if from_ and date < from_:
                continue
            if until and date > until:
                continue
            yield document


class OAIPMH(silvaviews.View):
    silvaconf.context(IOAIProvider)
    silvaconf.name('oaipmh')
    
    def render(self):
        baseURL = self.context.absolute_url() + '/oaipmh'
        oai_provider = OAIProvider(self.context, baseURL)
        oaiserver = server.Server(
            oai_provider, metadata_registry=self._getRegistry(),
            resumption_batch_size=100)
        response = self.request.response
        response.setHeader('Content-type', 'application/xml')
        return oaiserver.handleRequest(self.request.form)
    
    def _getRegistry(self):
        metadata_registry = metadata.MetadataRegistry()
        metadata_registry.registerWriter('oai_dc', server.oai_dc_writer)
        return metadata_registry


def datetimeToZDateTime(datetime):
    return DateTime(
        datetime.year, datetime.month, datetime.day, datetime.hour,
        datetime.minute, datetime.second)

def ZDateTimeTodatetime(ZDateTime):
    return datetime(
        ZDateTime.year(), ZDateTime.month(), ZDateTime.day(), ZDateTime.hour(),
        ZDateTime.minute(), int(ZDateTime.second()))        
