# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt
# $Id$

from zope.interface import Interface

from silva.core.conf.installer import DefaultInstaller
from silva.core import conf as silvaconf

silvaconf.extensionName("SilvaOAIProvider")
silvaconf.extensionTitle("Silva OAI Provider")


class OAIProviderInstaller(DefaultInstaller):
    """Installer for Silva OAI Provider.
    """
    pass


class IOAIProviderExtension(Interface):
    """Silva OAI Provider extension.
    """

install = OAIProviderInstaller("SilvaOAIProvider", IOAIProviderExtension)
