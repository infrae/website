# Copyright (c) 2008 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.interface import Interface

class IOAIProvider(Interface):
    """Allow OAI feeds from this container
    """
    pass

