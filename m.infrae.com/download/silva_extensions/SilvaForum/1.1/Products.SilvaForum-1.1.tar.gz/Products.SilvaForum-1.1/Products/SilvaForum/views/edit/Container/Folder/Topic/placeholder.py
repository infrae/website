# For mercurial, winzip, setuptools and associates.
