# Copyright (c) 2007-2010 Infrae. All rights reserved.
# See also LICENSES.txt
# $Id: __init__.py 42801 2010-06-11 13:25:19Z sylvain $

from Products.FileSystemSite.DirectoryView import registerDirectory

registerDirectory('resources', globals())

