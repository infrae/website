# Copyright (c) 2007-2010 Infrae. All rights reserved.
# See also LICENSES.txt
# $Id: __init__.py 39088 2010-01-15 11:49:27Z sylvain $


def initialize(context):
    from Products.Silva.fssite import registerDirectory
    registerDirectory('resources', globals())
