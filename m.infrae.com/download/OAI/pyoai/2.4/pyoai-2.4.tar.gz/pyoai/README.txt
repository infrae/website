oaipmh
======

The oaipmh module is a Python implementation of an "Open Archives
Initiative Protocol for Metadata Harvesting" (version 2) client and
server. The protocol is described here:

http://www.openarchives.org/OAI/openarchivesprotocol.html

See doc/API.txt for a description of the Python API.
