import Acquisition

class Item(Acquisition.Implicit):
    """An OAI Query result item.
    """
    
    def __init__(self, obj, fields):
        self.id = obj.id
        self._obj = obj
        self.fields = fields
        
    def getObj(self):
        """Get underlying object.
        """
        return self._obj
