import os, sys

from unittest import TestSuite, makeSuite
from Testing import ZopeTestCase

ZopeTestCase.installProduct('OAICore')
ZopeTestCase.installProduct('BTreeFolder2')
ZopeTestCase.installProduct('ZCatalog')
ZopeTestCase.installProduct('ZCTextIndex')

from oaipmh import server
from oaipmh.tests import fakeclient
from Products.OAICore import oaischema
from datetime import datetime

class OAIServiceTest(ZopeTestCase.ZopeTestCase):

    def beforeSetUp(self):
        self.root = self._app()
        ZopeTestCase.utils.setupCoreSessions(self.root)
        # Passing in 'fakeserver' basically makes the created service
        # completely behave as a fake server, it is not just some name or so.
        # This may sound obvious but isn't.
        self.root.manage_addProduct['OAICore'].manage_addOAIService(
            'service_oai', 'http://dspace.ubib.eur.nl/oai/', None, None,
            'fakeserver')
        self._service = self.root.service_oai

    def test_createStorage(self):
        self._service.createStorage('oai_dc')
        self.assertEquals(self._service.getStorage('oai_dc').id, 'oai_dc')
        self.assertEquals(self._service.getMetadataFormats(),['oai_dc'])
        self.assertEquals(self._service.getCatalog(
            'oai_dc').id, 'service_oai_catalog')

    def test_Update(self):
        self._service.createStorage('oai_dc')
        self._service.update(datetime(2004,02,01), datetime(2004,03,01))
        #service is updated
        self.assertEquals(self._service._datestamp, datetime(2004,03,01))
        #record 1162 is deleted
        self.assertEquals(self._service.getRecordByIdentifier(
            'oai_dc', 'hdl:1765/1162'), None)
        #record 904 is added
        self.assertEquals(self._service.getRecordByIdentifier(
             'oai_dc', 'hdl:1765/904').metadata_title,
             [u'Risk managing bermudan swaptions in the libor BGM model'])
        self.assertEquals(self._service.getRecordByIdentifier(
            'oai_dc',
            'hdl:1765/904').metadata_creator,
            ([u'Pietersz, R.', u'Pelsser, A.A.J.']))
        #as are 34 others
        self.assertEquals(len(self._service.getCatalog('oai_dc')), 35)

def test_suite():
    suite = TestSuite()
    suite.addTest(makeSuite(OAIServiceTest))
    return suite

