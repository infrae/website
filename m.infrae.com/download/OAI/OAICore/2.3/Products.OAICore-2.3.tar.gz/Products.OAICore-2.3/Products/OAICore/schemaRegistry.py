from oaipmh import metadata

_schema_registry = {}
    
def registerSchema(prefix, schema, reader):
    if not _schema_registry.has_key(prefix):
        _schema_registry[prefix] = []
    _schema_registry[prefix].append(schema)
    metadata.global_metadata_registry.registerReader(prefix, reader)
    
def registerSchemaForDefaultReader(prefix, schema):
    
    fields = {}
    for schema_field in schema.getFields():
        fields[schema_field.id] = ('textList', schema_field.getXpath())
        
    reader = metadata.MetadataReader(fields, schema.getNamespaces())
    registerSchema(prefix, schema, reader)
    
def registeredPrefixes():
    return _schema_registry.keys()
    
def getSchema(prefix, name=None):
    if name is None:
        # XXX this is almost certainly not what we want
        # the harvesting schema and the presentation schema need to be
        # split up. Each prefix should have 1 harvesting schema, which 
        # harvests and indexes all the necessary data, and possibly
        # multiple presentation schemata.
        return _schema_registry[prefix][0]
    for schema in _schema_registry[prefix]:
        if schema.getName() == name:
            return schema
    return None

def getSchemasForPrefix(prefix):
    return _schema_registry[prefix]

def removeSchemasForPrefix(prefix):
    del _schema_registry[prefix]
