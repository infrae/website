# Copyright (c) 2005-2010 Infrae. All rights reserved.
# See also LICENSE.txt

import time
from string import replace, find, lower

from DateTime import DateTime

from oaipmh.datestamp import tolerant_datestamp_to_datetime
from oaipmh.error import ClientError


class MissingError(ClientError):
    """Error that occurs if a field is missing.
    """
    def __init__(self, field_name):
        self.field_name = field_name

    def details(self):
        return ("Contents were expected in the field %s but are missing." %
                self.field_name)

class Dummy:
    pass


class OAISchema:

    def __init__(self):
        self._name = None
        self._namespaces = {}
        self._fields = []
        self._multi_sortables = []
        self._result_columns = []
        self._item_fields = []
        self._rss_field_ids = {}
        self._fulltext_fields = []
        self._user_searchables = []
        self._manageables = []
        self._sort_on = None
        self._sort_order = 'ascending'
        self._date_field = None

    def setName(self, name):
        self._name = name

    def setFields(self, fields):
        self._fields = fields

    def setMultiSortables(self, sortables):
        self._multi_sortables = sortables

    def setResultColumns(self, columns):
        self._result_columns = columns

    def setItemFields(self, fields):
        self._item_fields = fields

    def setRSSFieldIds(self, fields):
        for key, value in fields.items():
            if type(value) == list:
                self._rss_field_ids[key] = [
                    'metadata_' + fieldname for fieldname in value]
            else:
                self._rss_field_ids[key] = 'metadata_' + value

    def setFulltextFields(self, fields):
        self._fulltext_fields = [
            'metadata_' + fieldname for fieldname in fields]

    def setUserSearchables(self, fields):
        self._user_searchables = [
            'metadata_' + fieldname for fieldname in fields]

    def setManageableFields(self, fields):
        self._manageables = [
            'metadata_' + fieldname for fieldname in fields]

    def setInitialSortOn(self, fieldname):
        self._sort_on = 'metadata_' + fieldname

    def setInitialSortOrder(self, sort_order):
        self._sort_order = sort_order

    def setDate(self, field_name):
        self._date_field = 'metadata_' + field_name

    def getName(self):
        return self._name

    def getInitialSortOn(self):
        return self._sort_on

    def getInitialSortOrder(self):
        return self._sort_order

    def getMultiSortables(self):
        return self._multi_sortables[:]

    def getResultColumns(self):
        return [column.get_dict() for column in self._result_columns]

    def getItemFields(self):
        return [field.get_dict() for field in self._item_fields]

    def getRSSFieldId(self, rss_id):
        return self._rss_field_ids.get(rss_id, None)

    def getFulltextFields(self):
        return self._fulltext_fields[:]

    def getUserSearchables(self):
        return self._user_searchables[:]

    def getFields(self):
        return self._fields[:]

    def getManageableFields(self):
        fields = []
        for field in self._fields:
            if field.id not in self._manageables:
                continue
            fields.append(field)
        return fields

    def getFieldsAndSortables(self):
        return self._fields + self._multi_sortables

    def getNamespace(self):
        return self._namespace

    def getNamespaces(self):
        return self._namespaces.copy()

    def getDate(self):
        return self._date_field

    def addNamespace(self, prefix, namespace):
        self._namespaces[prefix] = namespace

    def installIndexes(self, catalog):
        """install indexes for the fields which are to be indexed in the
        specified catalog
        """
        for field in self._fields:
            field.installIndex(catalog)
        for sortable in self._multi_sortables:
            sortable.installIndex(catalog)
        ids =[]
        for column in self._result_columns:
            id = column.id
            catalog.manage_addColumn(id)
            ids.append(id)
        for field_name in self._user_searchables:
            if not field_name in ids:
                catalog.manage_addColumn(field_name)

    def preprocess(self, map):
        self.addTuplesToMap(map)
        for field in self._fields:
            if map.has_key(field.id):
                map[field.id] = field.preprocess(map[field.id])

    def addTuplesToMap(self, map):
        for sortable in self._multi_sortables:
            values = []
            for fieldname in sortable.getFieldNames():
                if map.has_key(fieldname):
                    value = map[fieldname]
                else:
                    value = []
                values.append(value)
            map[sortable.id] = tuple(values)
        return map


class OAIField:

    def __init__(self, id, xpath):
        self.id = "metadata_" + id
        self._name = id
        self._xpath = xpath

    def getXpath(self):
        """Return the xpath expression for field.
        """
        return self._xpath

    def getIndexType(self):
        """Which index type is used to index field in the catalog.
        """
        raise NotImplementedError

    def getId(self):
        return self.id

    def getName(self):
        return self._name

    def getTitle(self):
        return replace(self._name, '_', ' ').title()

    def installIndex(self, catalog):
        """Creates an index in the catalog for this field, if necessary.
        """
        index_type = self.getIndexType()
        if not index_type is None:
            catalog.manage_addIndex(self.id, index_type)

    def preprocess(self, value):
        """Massage the value into the right data type.
        """
        if len(value) == 0:
            return None
        return value

    def addEditField(self, form, filters, catalog):
        """Add a formulator field to edit form for this OAIField.
        """
        # By default do not add the field
        pass

    def addPublicField(self, form, unique_values):
        """Add a formulator field to public form for this OAIField.
        """
        raise NotImplementedError

    def updateQuery(self, query, filters):
        """Update the query dictionary with query parameter(s) for field.
        """
        id = self.getId()
        value = filters.get(id, None)
        if value:
            query[id] = value

    def updatePublicQuery(self, query, form_results, unique_values=None):
        """Update the query dictionary with query parameter(s) for field.

        This adds further restrictions to the predefined query.
        """
        id = self.getId()
        value = form_results.get(id, None)
        if value:
            query[id] = value

    def renderItemField(self, value):
        """Render the field for use in the public Item Page Template.
        """
        return ' '.join(value)


class OAIDateField(OAIField):

    def getIndexType(self):
        return 'DateIndex'

    def preprocess(self, value):
        # date is missing, report as error
        if not value:
            raise MissingError(self.getId())
        value = value[0]
        # This parses a date in w3cdtf to a datetime object
        if 'T' in value and value.endswith('Z'):
            # use pyoai date parser, using UTC time
            dt = tolerant_datestamp_to_datetime(value)
            return DateTime(dt.year, dt.month, dt.day,
                            dt.hour, dt.minute, dt.second)
        # try to parse date in local time, no need to inforce
        # correct oaipmh datestamp here
        if not 'T' in value:
            value += 'T00:00:00'
        return DateTime(*time.strptime(value, '%Y-%m-%dT%H:%M:%S')[:6])

    def addEditField(self, form, filters, catalog):
        id = self.getId()
        title = self.getTitle()
        start_date  = filters.get('start_dt_' + id, None)
        end_date  = filters.get('end_dt_' + id, None)
        form.manage_addField(
            'start_dt_' + id,
            'From ' + title,
            'DateTimeField')
        values = form.get_field('start_dt_' + id).values
        values['required'] = 0
        values['unicode'] = 1
        values['date_only'] = 1
        if start_date is not None:
            values['default'] = start_date
        form.manage_addField(
            'end_dt_' + id,
            'Until ' + title,
            'DateTimeField')
        values = form.get_field('end_dt_' + id).values
        values['required'] = 0
        values['unicode'] = 1
        values['date_only'] = 1
        if end_date is not None:
            values['default'] = end_date

    def addPublicField(self, form, unique_values):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(
            'year_' + id,
            'Year of ' + title,
            'IntegerField'
            )
        values = form.get_field('year_' + id).values
        values['required'] = 0
        values['unicode'] = 1

    def updateQuery(self, query, filters):
        id = self.getId()
        dates = []
        range = ''
        start_date = filters.get('start_dt_' + id, None)
        if start_date:
            dates.append(start_date)
            range = 'min'
        end_date = filters.get('end_dt_' + id, None)
        if end_date:
            dates.append(end_date)
            range = range + 'max'
        if range:
            query[id] = {'query': dates, 'range': range}

    def updatePublicQuery(self, query, form_results, unique_values=None):
        id = self.getId()
        year = form_results.get('year_' + id, None)
        if year:
            query[id] = {
                'query': [DateTime(year,1,1), DateTime(year,12,31)],
                'range': 'minmax'
                }

    def renderItemField(self, value):
        return value.strftime('%d-%m-%Y')

class OAIKeywordField(OAIField):
    def getIndexType(self):
        return 'KeywordIndex'

    def addEditField(self, form, filters, catalog):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(id, title, 'MultiListField')
        values = form.get_field(id).values
        values['size'] = 3
        values['required'] = 0
        values['unicode'] = 1
        default_value = filters.get(id, None)
        if default_value is not None:
            values['default'] = default_value
        else:
            values['default'] = 'none'
        result = [('All values', 'none')]
        for value in catalog.uniqueValuesFor(id):
            if value:
                result.append((value[:60], value))
        values['items'] = result

    def addPublicField(self, form, unique_values):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField('txt_0_' + id, title, 'StringField')
        values = form.get_field('txt_0_' + id).values
        values['required'] = 0
        values['unicode'] = 1
        result = [('All values', 'none')]
        result = result + unique_values
        if len(result) > 1:
            form.manage_addField(
                'list_1_' + id, '', 'ListField')
            values = form.get_field('list_1_' + id).values
            values['title'] = ''
            values['size'] = 1
            values['required'] = 0
            values['unicode'] = 1
            values['items'] = result

    def updatePublicQuery(self, query, form_results, unique_values=None):
        id = self.getId()
        txt = lower(form_results.get('txt_0_' + id, ''))
        if txt:
            search_list = []
            for value in unique_values:
                if find(lower(value), txt) > -1:
                    search_list.append(value)
            query[id] = search_list
        else:
            lst = form_results.get('list_1_' + id, 'none')
            if lst is not None and lst != 'none':
                query[id] = lst


class OAIFulltextField(OAIField):

    def getIndexType(self):
        return 'ZCTextIndex'

    def installIndex(self, catalog):
        id = self.getId()
        dummy = Dummy()
        dummy.index_type = 'Okapi BM25 Rank'
        dummy.lexicon_id = 'oai_lexicon'
        catalog.manage_addProduct['ZCTextIndex'].manage_addZCTextIndex(
            id, extra=dummy)

    def addPublicField(self, form, unique_values):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(id, title, 'StringField')
        values = form.get_field(id).values
        values['required'] = 0
        values['unicode'] = 1


class OAINoIndexField(OAIField):

    def getIndexType(self):
        return None

    def installIndex(self, catalog):
        # Not to be indexed, so don't install anything
        pass

    def addPublicField(self, form, unique_values):
        pass

    def updateQuery(self, query, value):
        pass

    def updatePublicQuery(self, query, form_results, unique_values=None):
        pass


class OAIMultiSortable:

    def __init__(self, id, fieldnames):
        self.id = "metadata_" + id
        self._fieldnames = ["metadata_" + name for name in fieldnames]

    def getFieldNames(self):
        return self._fieldnames

    def installIndex(self, catalog):
        catalog.manage_addIndex(self.id, 'FieldIndex')


class OAICoreColumn:

    def __init__(self, id, title, sort):
        self.id = id
        self.title = title
        self.sort = sort

    def get_dict(self):
        return {'id' : self.id, 'title' : self.title, 'sort' : self.sort}


class OAIColumn(OAICoreColumn):

    def __init__(self, id, title, sort):
        self.id = "metadata_" + id
        self.title = title
        self.sort = "metadata_" + sort


class OAIItemField:

    def __init__(self, id, title, display):
        self.id = "metadata_" + id
        self.title = title
        self.display = display

    def get_dict(self):
        return {'id' : self.id, 'title' : self.title, 'display' : self.display}
