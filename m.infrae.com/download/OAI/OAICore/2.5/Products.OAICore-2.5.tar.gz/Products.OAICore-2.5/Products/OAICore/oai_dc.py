from oaischema import OAISchema, OAIDateField, OAIKeywordField, \
    OAIFulltextField, OAINoIndexField, OAIMultiSortable, OAIColumn, \
    OAIItemField

# fields is a lists of definitions of the fields we want to harvest. For
# each field we create a type of OAIField[*] object with two arguments:
#
# 1. the id of the field as we want to use it in Zope/Silva. Can be pretty
#    much anything, but of course informative ids are useful.
# 2. an xpath expression that gets the data in a specific field from the xml
#    that the server spews. This is used for harvesting the actual metadata.
#    Because of this, ANY xml format can be harvested. Be sure to use the
#    correct namespaces and to declare those namespaces on the schema below.
#
# [*]: The currently implemented OAIField types are:
#
#     - OAINoIndexField: This field is harvested but not indexed, so it
#       can't be searched on.
#     - OAIKeywordField: This field is indexed as a Keyword index, and
#       can be restricted and searched by one or more keywords.
#     - OAIFulltextField: This field is indexed as a ZCText index, and
#       is searched by fulltext searches.
#     - OAIDateField: This field is indexed as a Date index, and can
#       be restricted and searched by date ranges.

fields = [
    OAIKeywordField('title', 'oai_dc:dc/dc:title/text()'),
    OAIKeywordField('creator', 'oai_dc:dc/dc:creator/text()'),
    OAIKeywordField('subject', 'oai_dc:dc/dc:subject/text()'),
    OAIFulltextField('description', 'oai_dc:dc/dc:description/text()'),
    OAINoIndexField('publisher', 'oai_dc:dc/dc:publisher/text()'),
    OAIKeywordField('contributor', 'oai_dc:dc/dc:contributor/text()'),
    OAIDateField('date', 'oai_dc:dc/dc:date/text()'),
    OAINoIndexField('type', 'oai_dc:dc/dc:type/text()'),
    OAINoIndexField('format', 'oai_dc:dc/dc:format/text()'),
    OAIKeywordField('identifier', 'oai_dc:dc/dc:identifier/text()'),
    OAIKeywordField('source', 'oai_dc:dc/dc:source/text()'),
    OAIKeywordField('language', 'oai_dc:dc/dc:language/text()'),
    OAINoIndexField('relation', 'oai_dc:dc/dc:relation/text()'),
    OAINoIndexField('coverage', 'oai_dc:dc/dc:coverage/text()'),
    OAINoIndexField('rights', 'oai_dc:dc/dc:rights/text()')
    ]

# manageables is a list of fields the query editor is allowed to filter on.

manageables = [
    'title', 'creator', 'subject', 'contributor', 'language', 'source', 'date']

# user_searchables is a list of fields the end user is allowed to filter or
# search on.

user_searchables = ['title', 'creator', 'subject', 'source']

# multi_sortables optionally defines multifield indexes that can be used for
# sorting query results. Again an arbitrary id, followed by a list of ids
# of fields (as defined in 'fields' above) to be sorted on (in that order.)

multi_sortables = [
    OAIMultiSortable('creator_title_date', ['creator','title', 'date']),
    OAIMultiSortable('title_creator_date', ['title', 'creator','date']),
    OAIMultiSortable('date_creator_title', ['date', 'creator','title']),
    ]

# result_columns defines the columns of the results table that the end user
# sees when running a query. The order in which the columns are defined is
# significant, as they will be displayed in the same order. The three
# arguments are:
#
# 1. Id of the field (as defined in 'fields' above)
# 2. Name of the field that will be displayed to the end user in the column
#    heading of the results table.
# 3. The field or multisortable on which to sort if the sort button of this
#    column is clicked.

result_columns = [
    OAIColumn('title', 'Title', 'title_creator_date'),
    OAIColumn('creator', 'Author', 'creator_title_date'),
    OAIColumn('date', 'Date', 'date_creator_title')
    ]

# item_fields defines what fields are to be displayed to the end user and
# how, when a specific item is viewed. The arguments:
#
# 1. Id of the field (as defined in 'fields' above)
# 2. Name of the field that will be displayed to the end user
# 3. The way the field is displayed to the end user. For now choose one
#    from:
#
#    title: displayed as <h2> element, should really only be used once
#           and only for the first element
#    text: display as a normal paragraph.
#    list: display as an unordered list.
#    link: display as a clickacble link.
#    date: display as a (european) date.

item_fields = [
    OAIItemField('title', None, 'title'),
    OAIItemField('creator', 'Author(s)', 'list'),
    OAIItemField('subject', 'Subject(s)', 'list'),
    OAIItemField('date', 'Date', 'date'),
    OAIItemField('description', 'Description', 'text')
    ]

# a dictionary of dublin core fieldnames to OAIItem field ids. Also used
# for the other feed types. Adding fields is okay, but do not remove or
# rename the existing ones, since they are expected by the RSS/Atom
# adapters.

rss_fields = {
    'title': 'title',
    'creator': 'creator',
    'date': 'date',
    'subject': 'subject',
    'description': 'description',
    }

# fulltext_fields defines the fields that can have their contents searched
# by the fulltext search, in addition to any fulltext documents, optionally
# scraped from the server.

fulltext_fields =['description']

# the actual schema object is built.

oai_dc_schema = OAISchema()
oai_dc_schema.addNamespace('oai_dc', 'http://www.openarchives.org/OAI/2.0/oai_dc/')
oai_dc_schema.addNamespace('dc', 'http://purl.org/dc/elements/1.1/')
oai_dc_schema.setName('oai_dc (default schema)')
oai_dc_schema.setFields(fields)
oai_dc_schema.setManageableFields(manageables)
oai_dc_schema.setMultiSortables(multi_sortables)
oai_dc_schema.setResultColumns(result_columns)
oai_dc_schema.setItemFields(item_fields)
oai_dc_schema.setRSSFieldIds(rss_fields)
oai_dc_schema.setFulltextFields(fulltext_fields)
oai_dc_schema.setUserSearchables(user_searchables)
oai_dc_schema.setInitialSortOn('date_creator_title')
oai_dc_schema.setInitialSortOrder('descending')
# we need a datefield to look up things by date, and count records added
# over time. Often there is more than one datetime type field in a metadata
# set. Here we define which one will be used.
oai_dc_schema.setDate('date')
