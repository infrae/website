# Copyright (c) 2005-2010 Infrae. All rights reserved.
# See also LICENSE.txt

import logging
logger = logging.getLogger('OAICore')

from Products.OAICore import core
from Products.OAICore.schemaRegistry import registerSchemaForDefaultReader
from Products.OAICore.oai_dc import oai_dc_schema
from Products.OAICore import unicodesplitter # registers the splitter


def initialize(context):

    context.registerClass(
        core.OAIService,
        constructors = (
            core.manage_addOAIServiceForm,
            core.manage_addOAIService),
        icon = "www/oai_service.png")

registerSchemaForDefaultReader('oai_dc', oai_dc_schema)
