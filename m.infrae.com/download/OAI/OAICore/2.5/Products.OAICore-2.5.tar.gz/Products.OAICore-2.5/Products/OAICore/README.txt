OAICore
=======

Description
-----------

OAICore is a Zope 2 product that provides a service that can harvest and index
records from an OAIPMH compliant Server. The OAIPMH
protocol is described here:

http://www.openarchives.org/OAI/openarchivesprotocol.html

Starting version 2.5, this product requires Zope 2.12. To use in
previous versions of Zope 2, please use previous versions of this
package.
