# Copyright (c) 2005-2010 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.interface import Interface


class IRecord(Interface):


    def updateRecord(setSpec, datestamp, map):
        """Update record information.
        """

    def identifier():
        """Get record identifier identifier.
        """

    def setSpec():
        """Get sets to which the record belongs to as a tuple.
        """

    def setName():
        """Get sets names to which the record belongs to as a tuple.
        """

    def datestamp():
        """Get datestamp of last update.
        """


class IOAIField(Interface):

    def installIndex(catalog):
        """Creates an index in the catalog for this field, if necessary.
        """

    def preprocess(value):
        """Massage the value into the right data type.
        """

    def addPublicField(form):
        """Add a formulator field to form for this OAIField.
        """

    def addEditField(form):
        """Add a formulator field to form for this OAIField.
        """

    def updateQuery(query, value):
        """Update the query dictionary with query parameter(s) for field.
        """

    def updatePublicQuery(query, form_results, unique_values):
        """Update the query dictionary with query parameter(s) for field.

        This adds further restrictions to the predefined query.
        """

    def getXpath():
        """Return the xpath expression for field.
        """

    def renderItemField(value):
        """Render the field for use in the public Item Page Template.
        """

    def getIndexType():
        """Which index type is used to index field in the catalog.
        """
