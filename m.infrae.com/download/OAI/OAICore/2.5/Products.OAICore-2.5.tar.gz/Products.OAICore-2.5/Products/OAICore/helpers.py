# Copyright (c) 2005-2010 Infrae. All rights reserved.
# See also LICENSE.txt

import urllib
from random import randrange


def add_and_edit(self, id, REQUEST):
    """Helper function to point to the object's management screen if
    'Add and Edit' button is pressed.
    id -- id of the object we just added
    """
    if REQUEST is None:
        return
    try:
        u = self.DestinationURL()
    except:
        u = REQUEST['URL1']
    if REQUEST.has_key('submit_edit'):
        u = "%s/%s" % (u, urllib.quote(id))
    REQUEST.RESPONSE.redirect(u+'/manage_main')


def createRandomId(digits):
    digits -= 1
    return str(randrange(int('1' + digits * '0'), int('9' + digits * '9')))


def keysSortedByValue(dict):
    result = [(value, key) for key, value in dict.items()]
    result.sort()
    result = [key for value, key in result]
    return result
