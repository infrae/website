from oaipmh.tests import fakeserver

# tied to the server at EUR..
server = FakeServer(
    'http://dspace.ubib.eur.nl/oai/',
    'fakeserver')

print "ListSets"
for setSpec, setName, setDescription in server.listSets():
    print "setSpec:", setSpec
    print "setName:", setName
    print "setDescription:", setDescription
print

print "Identify"
identify = server.identify()
print "repositoryName:", identify.repositoryName()
print "baseURL:", identify.baseURL()
print "protocolVerson:", identify.protocolVersion()
print "adminEmails:", identify.adminEmails()
print "earliestDatestamp:", identify.earliestDatestamp()
print "deletedRecords:", identify.deletedRecord()
print "granularity:", identify.granularity()
print "compression:", identify.compression()
print

print "ListRecords"
for header, metadata, about in server.listRecords(
    from_="2004-01-30T00:00:00Z", until="2004-01-31T00:00:00Z", metadataPrefix='eur_qdc'):
    print "header"
    print "identifier:", header.identifier()
    print "datestamp:", header.datestamp()
    print "setSpec:", header.setSpec()
    print "isDeleted:", header.isDeleted()
    print "metadata"
    if metadata is not None:
        for fieldname in metadata.getMap().keys():
            print "%s:" % fieldname, metadata.getField(fieldname)
    print "about"
    print about
print

print "ListRecords"
for header, metadata, about in server.listRecords(
    from_="2004-02-01T00:00:00Z", until="2004-03-01T00:00:00Z", metadataPrefix='eur_qdc'):
    print "header"
    print "identifier:", header.identifier()
    print "datestamp:", header.datestamp()
    print "setSpec:", header.setSpec()
    print "isDeleted:", header.isDeleted()
    print "metadata"
    if metadata is not None:
        for fieldname in metadata.getMap().keys():
            print "%s:" % fieldname, metadata.getField(fieldname)
    print "about"
    print about
print

server.save()
