import os, sys

from unittest import TestSuite, makeSuite
from Testing import ZopeTestCase

ZopeTestCase.installProduct('OAICore')
ZopeTestCase.installProduct('BTreeFolder2')
ZopeTestCase.installProduct('ZCatalog')
ZopeTestCase.installProduct('ZCTextIndex')
ZopeTestCase.installProduct('Formulator')

from oaipmh import server
from oaipmh.tests import fakeclient
from Products.OAICore import oaischema
from datetime import datetime

from OFS.SimpleItem import SimpleItem
from Products.Formulator.Form import ZMIForm

from Products.OAICore.query import BaseQuery, ManageableQuery, SearchQuery
from Products.OAICore.schemaRegistry import getSchema

class TestQuery(ManageableQuery, SimpleItem):
    pass        

class TestQuery2(ManageableQuery, SimpleItem):

    def restrictQuery(self, query):
        query['metadata_title'] = u'Dorstige aarde. Het probleem van de 21ste eeuw; groeiend en explosief.'

class TestSearchQuery(SearchQuery, SimpleItem):
    pass

class QueryTestCase(ZopeTestCase.ZopeTestCase):

    def beforeSetUp(self):
        self.root = self._app()
        ZopeTestCase.utils.setupCoreSessions(self.root)
        # Passing in 'fakeserver' basically makes the created service
        # completely behave as a fake server, it is not just some name or so.
        # This may sound obvious but isn't.
        self.root.manage_addProduct['OAICore'].manage_addOAIService(
            'service_oai', 'http://dspace.ubib.eur.nl/oai/', None, None,
            'fakeserver')
        self._service = self.root.service_oai
        self._service.createStorage('oai_dc')
        self._service.update(datetime(2004,02,01), datetime(2004,03,01))
        self.root.testquery = TestQuery(self._service)
        self.root.testquery.setSchema('oai_dc', 'oai_dc (default schema)')
    
    def test_getService(self):
        self.assertEquals(self._service, self.root.testquery.getService())
        
    def test_metadataFormat(self):
        self.assertEquals('oai_dc', self.root.testquery.getMetadataFormat())

    def test_schemaName(self):
        self.assertEquals('oai_dc (default schema)', self.root.testquery.getSchemaName())
        
    def test_catalog(self):
        catalog = self._service.oai_dc.service_oai_catalog
        self.assertEquals(catalog, self.root.testquery.getCatalog())
        
    def test_schema(self):
        self.assertEquals(getSchema('oai_dc', 'oai_dc (default schema)'), self.root.testquery.getSchema())

    def test_set(self):
        self.root.testquery.setSet('FooBar')
        self.assertEquals('FooBar', self.root.testquery.getSet())
        
    def test_fields(self):
        fields = getSchema('oai_dc', 'oai_dc (default schema)').getFields()
        self.assertEquals(fields, self.root.testquery.getFields())

    def test_fields(self):
        fields = getSchema('oai_dc', 'oai_dc (default schema)').getManageableFields()
        self.assertEquals(fields, self.root.testquery.getManageableFields())
        
    def test_initialsorton(self):
        self.assertEquals(
            getSchema('oai_dc', 'oai_dc (default schema)').getInitialSortOn(), 
            self.root.testquery.getInitialSortOn())
    
    def test_initialsortorder(self):
        self.assertEquals(
            getSchema('oai_dc', 'oai_dc (default schema)').getInitialSortOrder(), 
            self.root.testquery.getInitialSortOrder())
    
    def test_columns(self):
        self.assertEquals(
            getSchema('oai_dc', 'oai_dc (default schema)').getResultColumns(), 
            self.root.testquery.getColumns())
            
    def test_filters(self):
        self.assertEquals({}, self.root.testquery.getFilters())
        self.root.testquery.setFilters({'foo': 'bar'})
        self.assertEquals({'foo': 'bar'}, self.root.testquery.getFilters())

    def _compareManageFieldTitles(self, query_form):
        schema_field_titles = []
        for field in getSchema('oai_dc', 'oai_dc (default schema)').getManageableFields():
            if field.getIndexType() == 'KeywordIndex':
                schema_field_titles.append(field.getTitle())
            if field.getIndexType() == 'DateIndex':
                schema_field_titles.append('From ' + field.getTitle())
                schema_field_titles.append('Until ' + field.getTitle())

        form_field_titles = [field['title'] for field in  filter(
            lambda obj: hasattr(obj.aq_explicit, 'is_field'),
            query_form.objectValues())]
        if 'Sort On' in form_field_titles:
            form_field_titles.remove('Sort On')
        self.assertEquals(schema_field_titles, form_field_titles)
            
    def test_addFilterFields(self):
        self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
        query_form = self.root.query_form
        self.root.testquery.addFilterFields(self.root.query_form)
        self._compareManageFieldTitles(query_form)

    def test_updateManageForm(self):
        self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
        query_form = self.root.query_form
        self.root.testquery.updateManageForm(self.root.query_form)
        self._compareManageFieldTitles(query_form)

    def test_queryResults(self):
        # no filtering, we query for all entries, return all entries
        self.assertEquals(35, len(self.root.testquery.queryResults({})))
        # filtering, we query for all entries, return a filtered subset
        self.root.testquery.setFilters({'metadata_creator': [u'Saeijs, H.L.F.']})
        self.assertEquals(2, len(self.root.testquery.queryResults({})))
        # filtering, we query for a particular title in the filtered subset
        title = u'Eco-pragmatisme: Omgaan met rivieren, delta\u2019s, kust en zee in de 21e eeuw'
        self.assertEquals(
            1, len(self.root.testquery.queryResults({'metadata_title': [title]})))
        self.root.testquery2 = TestQuery2(self._service)
        self.root.testquery2.setSchema('oai_dc', 'oai_dc (default schema)')
        self.root.testquery.setFilters({'metadata_creator': [u'Saeijs, H.L.F.']})
        self.assertEquals(
            1, len(self.root.testquery2.queryResults({'metadata_title': [title]})))

class SearchQueryTestCase(QueryTestCase):

    def beforeSetUp(self):
        self.root = self._app()
        ZopeTestCase.utils.setupCoreSessions(self.root)
        # Passing in 'fakeserver' basically makes the created service
        # completely behave as a fake server, it is not just some name or so.
        # This may sound obvious but isn't.
        self.root.manage_addProduct['OAICore'].manage_addOAIService(
            'service_oai', 'http://dspace.ubib.eur.nl/oai/', None, None,
            'fakeserver')
        self._service = self.root.service_oai
        self._service.createStorage('oai_dc')
        self._service.update(datetime(2004,02,01), datetime(2004,03,01))
        self.root.testquery = TestSearchQuery(self._service)
        self.root.testquery.setSchema('oai_dc', 'oai_dc (default schema)')
            
    def test_queryResults2(self):
        # no filtering, we query for all entries, return all entries
        results = self.root.testquery.queryResults({})
        self.assertEquals(titles_by_date, [b.metadata_title for b in results])
        results = self.root.testquery.queryResults({'sort_on':'metadata_title'})
        self.assertEquals(titles_by_title, [b.metadata_title for b in results])

    def test_searchables(self):
        self.assertEquals(
            getSchema('oai_dc', 'oai_dc (default schema)').getUserSearchables(), 
            self.root.testquery.getSearchables())
            
    def test__getitem__(self):
        just_a_record_id = self._service.oai_dc.keys()[0]
        title = self._service.oai_dc[just_a_record_id].metadata_title
        self.assertEquals(
            title,
            self.root.testquery[just_a_record_id].getObj().metadata_title)

    def test_addSetField(self):
        self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
        query_form = self.root.query_form
        self.root.testquery.addSetField(query_form)
        set_field = query_form.get_field('set')
        self.assertEquals(sets, set_field.values['items'])

    def _compareSearchFields(self, filters, query_form):
        schema_field_titles = []
        for field in getSchema('oai_dc', 'oai_dc (default schema)').getUserSearchables():
            if field in filters.keys():
                continue
            schema_field_titles.append('txt_0_' + field)
            schema_field_titles.append('list_1_' + field)
        form_field_titles = [
            field.id for field in query_form.get_fields()]
        self.assertEquals(schema_field_titles, form_field_titles)
        
        #    def test_updateSearchForm(self):
        #        self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
        #        query_form = self.root.query_form
        #        self.root.testquery.updateSearchForm(self.root.query_form)
        #        filters = self.root.testquery.getFilters()
        #        self._compareSearchFields(filters, query_form)

        #    def test_addSearchFields(self):
        #        self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
        #        query_form = self.root.query_form
        #        self.root.testquery.updateSearchForm(self.root.query_form)
        #        filters = self.root.testquery.getFilters()
        #        self._compareSearchFields(filters, query_form)

        def test_addFulltextSearchField(self):
            self.root.query_form = ZMIForm('query_form', 'Query Form', 1)
            query_form = self.root.query_form
            self.root.testquery.addFulltextSearchField(self.root.query_form)
            self.assertEquals('fulltext', query_form.get_fields()[0].id)

def test_suite():
    suite = TestSuite()
    suite.addTest(makeSuite(QueryTestCase))
    suite.addTest(makeSuite(SearchQueryTestCase))
    return suite
    
titles_by_date = [
    ['Diagnosis and Treatment of Transsphincteric Perianal Fistulas'],
    ['Nieuwe sociale bewegingen en postmodernisme : Posttraditionele identiteiten tussen essentialisme en relativisme'],
    ['Communitarisme en vertrouwen in politieke instellingen : Verslag van een empirisch onderzoek', 'Communitarianism and trust in political institutions : An empirical study'],
    ['Developmental aspects of midazolam metabolism'],
    ['Schistosomiasis Morbidity and Management of Cases in Africa'],
    ['Respiratory Syncytial Virus; Anti-viral immunity in humans and macaques.'],
    ['Validation of Clinical Prediction Models: Theory and Applications in Testicular Germ Cell Cancer'],
    ['Globins in space'],
    ['De lerende bureaucratie? Een onderzoek naar de betekenis van ICT voor leren in het openbaar bestuur', 'The Learning Bureaucracy? An Inquiry into the Significance of ICTs for Learning in the Public Sector'],
    ['Explaining Sunday shop policies'],
    ['Naar nieuwe pensioencontracten'],
    ['A 13CO2 Breath Test for Liver Glycogen Oxydation'],
    ['Prognosis after Autograft and Allograft Aortic Root Replacement. Evidence-based Estimates using Meta-analysis and Microsimulation.'],
    ['Objective Measurement of Activity Limitations in Complex Regional Pain Syndrome Type I; Development and Application of an Upper Limb-Activity Monitor'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ["Waardering van overstromingsrisico's"],
    ['Dorstige aarde. Het probleem van de 21ste eeuw; groeiend en explosief.'],
    [u'Eco-pragmatisme: Omgaan met rivieren, delta\u2019s, kust en zee in de 21e eeuw'],
    ['Effects and Costs of Colorectal Cancer Screening and Follow-up after Polypectomy'],
    ['Development of age-related maculopathy: a histochemical and molecular approach'],
    ['Activation, Regulation and Transcription of the Human and Murine Globin Loci.'],
    ['Citizen and City : Developments in Fifteen Local Democracies in Europe'],
    ['Organisational Learning And Multinational Strategy'],
    ['Epstein-Barr Virus Lymphoproliferative Disease following Allogeneic Hematopoietic Stem Cell Transplantation: Prediction and early Prevention'],
    ['Lifetime labor supply in a search model of unemployment'],
    ['Airline revenue management with shifting capacity'],
    ['Network-based business process management: embedding business logic in communications networks'],
    ['Risk managing bermudan swaptions in the libor BGM model'],
    ['Tax policy and labor market performance'],
    ['Strategies, uncertainty and performance of small business startups'],
    ['Early retirement reform: Can it work? Will it work?'],
    ['R&D Networks'],
    ['The Causality of Supply Relationships'],
    ]
    
titles_by_title = [
    ["Waardering van overstromingsrisico's"],
    ['Validation of Clinical Prediction Models: Theory and Applications in Testicular Germ Cell Cancer'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ['The OtoData Project - Quality of Ear Surgery.'],
    ['De lerende bureaucratie? Een onderzoek naar de betekenis van ICT voor leren in het openbaar bestuur', 'The Learning Bureaucracy? An Inquiry into the Significance of ICTs for Learning in the Public Sector'],
    ['The Causality of Supply Relationships'],
    ['Tax policy and labor market performance'],
    ['Strategies, uncertainty and performance of small business startups'],
    ['Schistosomiasis Morbidity and Management of Cases in Africa'],
    ['Risk managing bermudan swaptions in the libor BGM model'],
    ['Respiratory Syncytial Virus; Anti-viral immunity in humans and macaques.'],
    ['R&D Networks'],
    ['Prognosis after Autograft and Allograft Aortic Root Replacement. Evidence-based Estimates using Meta-analysis and Microsimulation.'],
    ['Organisational Learning And Multinational Strategy'],
    ['Objective Measurement of Activity Limitations in Complex Regional Pain Syndrome Type I; Development and Application of an Upper Limb-Activity Monitor'],
    ['Nieuwe sociale bewegingen en postmodernisme : Posttraditionele identiteiten tussen essentialisme en relativisme'],
    ['Network-based business process management: embedding business logic in communications networks'],
    ['Naar nieuwe pensioencontracten'],
    ['Lifetime labor supply in a search model of unemployment'],
    ['Globins in space'],
    ['Explaining Sunday shop policies'],
    ['Epstein-Barr Virus Lymphoproliferative Disease following Allogeneic Hematopoietic Stem Cell Transplantation: Prediction and early Prevention'],
    ['Effects and Costs of Colorectal Cancer Screening and Follow-up after Polypectomy'],
    [u'Eco-pragmatisme: Omgaan met rivieren, delta\u2019s, kust en zee in de 21e eeuw'],
    ['Early retirement reform: Can it work? Will it work?'],
    ['Dorstige aarde. Het probleem van de 21ste eeuw; groeiend en explosief.'],
    ['Diagnosis and Treatment of Transsphincteric Perianal Fistulas'],
    ['Developmental aspects of midazolam metabolism'],
    ['Development of age-related maculopathy: a histochemical and molecular approach'],
    ['Communitarisme en vertrouwen in politieke instellingen : Verslag van een empirisch onderzoek', 'Communitarianism and trust in political institutions : An empirical study'],
    ['Citizen and City : Developments in Fifteen Local Democracies in Europe'],
    ['Airline revenue management with shifting capacity'],
    ['Activation, Regulation and Transcription of the Human and Murine Globin Loci.'],
    ['A 13CO2 Breath Test for Liver Glycogen Oxydation'],
    ]
    
sets = [
    ('Annual Reports', '11'), 
    ('... Erasmus MC Annual Reports', '11:27'), 
    ('... Erasmus Research Institute of Management (ERIM) : Annual Reports', '11:21'), 
    ('... University Library: Annual Reports', '11:26'), 
    ('Arts (FHKW)', '10'), 
    ('... Handbook of Cultural Economics', '10:18'), 
    ('Erasmus MC (University Medical Center Rotterdam)', '3'), 
    ('... EUR Medical Dissertations', '3:5'), 
    ('Erasmus Research Institute of Management (ERIM)', '1'), 
    ('... ERIM Inaugural Addresses Research in Management Series', '1:2'), 
    ('... ERIM Ph.D. Series Research in Management', '1:4'), 
    ('... ERIM Report Series Research in Management ', '1:1'), 
    ('Erasmus School of Law', '14'), 
    ('... Dissertations', '14:50'), 
    ('Erasmus centre for Sustainability and Management (FSW)', '9'), 
    ('... Dissertations ESM', '9:39'), 
    ('... ESM', '9:17'), 
    ('History (FHKW)', '13'), 
    ('... Articles (published)', '13:37'), 
    ('... Papers', '13:36'), 
    ('... The European Metropolis 1920-2000', '13:33'), 
    ('Psychology (FSW)', '12'), 
    ('... Dissertations Psychology', '12:29'), 
    ('... Psychology', '12:28'), 
    ('Public Administration (FSW)', '5'), 
    ('... Centre for Local Democracy', '5:41'), 
    ('... Centre for Public Management', '5:12'), 
    ('... Dissertations Public Administration', '5:22'), 
    ('... Public Governance', '5:11'), 
    ('Research School Safety and Security in Society', '4'), 
    ('... PH D Series Safety and Security in Society', '4:10'), 
    ('... Reports Safety and Security in Society', '4:15'), 
    ('Rotterdam School of Economics (RSE)', '6'), 
    ('... Department of Informatics', '6:13'), 
    ('... Econometric Institute', '6:14'), 
    ('... Research Centre for Economic Policy (OCFEB)', '6:20'), 
    ('Sociology (FSW)', '2'), 
    ('... Database of Happiness', '2:3'), 
    ('... Dissertations Sociology', '2:40'), 
    ('... Sociology', '2:8')
    ]
    
