OAICore
=======

Description
-----------

OAICore is a Zope 2 product that provides a service that can harvest and index
records from an OAIPMH compliant Server. The OAIPMH
protocol is described here:

http://www.openarchives.org/OAI/openarchivesprotocol.html
