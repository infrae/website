##parameters=record

from random import randint

# Add a random int at the end of the id to be sure to be unique on the
# page even if an item is displayed twice.
return '%s-%s' % (record.id, randint(1, 2048))
