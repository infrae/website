from Products.Silva import SilvaPermissions as permissions
from AccessControl import ClassSecurityInfo
from Products.SilvaDocumentLibrary.filesize import file_size
from Globals import InitializeClass

import string

class DocumentLibraryMixin(object):
    """I have a docstring.
    """

    security = ClassSecurityInfo()

    _allow_show_all = False
    _batch_size = 0
    _display_letter = None

    security.declarePublic('file_size')
    def file_size(self, record, name):
        return file_size(record, name)

    security.declareProtected(
        permissions.AccessContentsInformation, 'getDisplayLetter')
    def getDisplayLetter(self):
        return self._display_letter

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setDisplayLetter')
    def setDisplayLetter(self, letter):
        if not letter or letter == 'none':
            letter = None
        self._display_letter = letter

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setAllowShowAll')
    def setAllowShowAll(self, flag):
        self._allow_show_all = flag

    security.declarePublic('getAllowShowAll')
    def getAllowShowAll(self):
        return self._allow_show_all

    security.declareProtected(
        permissions.ChangeSilvaContent, 'setBatchSize')
    def setBatchSize(self, batch_size):
        self._batch_size = batch_size

    security.declarePublic('getBatchName')
    def getBatchName(self):
        # We don't use getId directly in the code because of Silva
        # Views / Acquisition.
        return self.getId()

    security.declarePublic('getBatchSize')
    def getBatchSize(self):
        return self._batch_size

    security.declarePublic('getBatching')
    def getBatching(self):
        return self._batch_size != 0

    security.declarePrivate('addSetField')
    def addSetField(self, form):
        form.manage_addField('set', 'Category', 'MultiListField')
        values = form.get_field('set').values
        filters = self.getFilters()
        if filters.has_key('set'):
            values['default'] = self._filters['set']
        else:
            values['default'] = 'none'
        service = self.getService()
        sets = service.getSets()
        # set up the 'Set' form field
        values['items'] = result = [('All values', 'none'),]
        for spec, name, about in sets:
            result.append((name, spec))
        values['size'] = min(20, max(5, (len(sets) + 1) / 10))
        values['required'] = 0
        values['unicode'] = 1

    security.declarePrivate('addDisplayField')
    def addDisplayField(self, form):
        form.manage_addField('display_letter', 'Display Only', 'ListField')
        values = form.get_field('display_letter').values
        values['size'] = 1
        values['description'] = 'Display only entries starting with the following letter.'
        values['items'] = [('All values', 'none'),]
        for letter in string.ascii_lowercase:
            values['items'].append((letter, letter),)
        for digit in string.digits:
            values['items'].append((digit, digit),)
        if self.getDisplayLetter():
            values['default'] = self.getDisplayLetter()
        else:
            values['default'] = 'All values'

    security.declarePrivate('addExtraManageFields')
    def addExtraManageFields(self, form):
        self.addSortOrderField(form)
        self.addDisplayField(form)
        form.manage_addField('allow_show_all', "Allow Show All", "CheckBoxField")
        values = form.get_field('allow_show_all').values
        values['default'] = self._allow_show_all
        form.manage_addField('batch_size', 'Batch Size',
                             'ListField')
        values = form.get_field('batch_size').values
        values['size'] = 1
        values['items'] = [('no batching', 0), 5, 10, 15, 20, 25, 50, 75, 100]
        values['default'] = self._batch_size

    def restrictQuery(self, query):
        super(DocumentLibraryMixin, self).restrictQuery(query)
        # Add display letter
        display_on = 'metadata_title'
        display_letter = self.getDisplayLetter()
        if display_on and display_letter:
            query[display_on] = '%s*' % display_letter

    security.declareProtected(
        permissions.AccessContentsInformation, 'queryResults')
    def queryResults(self, query):
        result = super(DocumentLibraryMixin, self).queryResults(query)
        display_on = 'metadata_title'
        display_letter = self.getDisplayLetter()

        def display_restriction(brain):
            att = getattr(brain, display_on)
            # We have a list with a string
            if att and att[0] and att[0][0].lower() == display_letter:
                return True
            return False

        if display_on and display_letter:
            return list(filter(display_restriction, result))
        return result


InitializeClass(DocumentLibraryMixin)

