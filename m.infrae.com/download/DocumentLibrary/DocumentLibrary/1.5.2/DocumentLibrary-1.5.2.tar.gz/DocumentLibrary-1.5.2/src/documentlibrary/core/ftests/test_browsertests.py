"""Test Browser Tests

To run these tests against an actual server, make sure you have Zope 3
in your PYTHONPATH.  Then, run ``python test_browsertests.py
test_real_server``.

Note that I'm assuming that for the 'real server tests' you run Apache
on port 8000.  This is my Tramline configuration in Apache:

  LoadModule python_module /home/daniel/lib/apache2/modules/mod_python.so
  PythonInputFilter tramline.core::inputfilter TRAMLINE_INPUT
  PythonOutputFilter tramline.core::outputfilter TRAMLINE_OUTPUT
  SetInputFilter TRAMLINE_INPUT
  SetOutputFilter TRAMLINE_OUTPUT
  PythonOption tramline_path /tmp/tramline-test/

"""

import unittest
import doctest
import shutil
import sys
from os.path import join, dirname
from StringIO import StringIO

from dl.testing import FunctionalDocFileSuite
from zope.testing.doctest import DocFileSuite
import zope.testbrowser.browser
import zope.testbrowser.testing

def add_empty_file(browser, formname, filename):
    browser.getControl(name=formname).add_file(
        StringIO(''), 'text/plain', filename)

def add_empty_file_tramline(browser, formname, filename):
    browser.getControl(name=formname).add_file(
        StringIO(''), 'text/plain', '')

GLOBS = dict(add_empty_file=add_empty_file,
             cfg=dict(
    url='http://localhost',
    credentials='mgr:mgrpw',
    tramline=False,
    zip_file=lambda: open(join(dirname(__file__), 'documents.zip'))),
             )

def test_real_server():
    flags = (doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS |
             doctest.REPORT_NDIFF | doctest.REPORT_ONLY_FIRST_FAILURE)

    globs = GLOBS.copy()
    globs['Browser'] = zope.testbrowser.browser.Browser
    globs['add_empty_file'] = add_empty_file_tramline
    globs['cfg']['url'] = 'http://localhost:8000'
    globs['cfg']['credentials'] = 'bWdyOm1ncnB3' # mgr:mgrpw base64 encoded

    def tearDown(test):
        shutil.rmtree(globs['cfg']['tramline'])
    
    create_doc = DocFileSuite(
        'basic_document_tests.txt',
        globs = globs,
        optionflags = flags,
        )
    
    convert_doc = DocFileSuite(
        'conversion_document_tests.txt',
        globs = globs,
        optionflags = flags,
        )
    
    globs = globs.copy()
    globs['cfg']['tramline'] = '/tmp/tramline-test/'
    create_doc_with_tramline = DocFileSuite(
        'basic_document_tests.txt',
        globs = globs,
        optionflags = flags,
        tearDown = tearDown,
        )

    convert_doc_with_tramline = DocFileSuite(
        'conversion_document_tests.txt',
        globs = globs,
        optionflags = flags,
        tearDown = tearDown,
        )
    
    return unittest.TestSuite((create_doc,
                               convert_doc,
                               create_doc_with_tramline,
                               convert_doc_with_tramline))

def test_suite():
    globs = GLOBS.copy()
    globs['Browser'] = zope.testbrowser.testing.Browser
    
    create_doc = FunctionalDocFileSuite(
        'basic_document_tests.txt',
        package='documentlibrary.core.ftests',
        globs = globs,
        )
    first_logged_in = FunctionalDocFileSuite(
        'first_logged_in.txt',
        package='documentlibrary.core.ftests',
        globs = globs,
        )
    
    return unittest.TestSuite([create_doc, first_logged_in])

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
