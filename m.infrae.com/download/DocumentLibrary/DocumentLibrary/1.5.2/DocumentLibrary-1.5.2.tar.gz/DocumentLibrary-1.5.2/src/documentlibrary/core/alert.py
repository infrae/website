import math
from datetime import timedelta

from zope.interface import implements

from documentlibrary.core import interfaces

class DocumentAlertDates(object):
    implements(interfaces.IDocumentAlertDates)
    
    def __init__(self, context):
        self.context = context
        
    def getExpiryAlertDate(self):
        """Calculate the alert date based on expiry and submission dates.

        This calculation is based on the difference between expiry and
        submission dates. If no submission date is available, the
        calculation is available on the difference between expiry and
        available dates.
        """
        try:
            submissiondate = self.context.submissiondate
        except AttributeError:
            submissiondate = self.context.availabledate
        if submissiondate is None:
            submissiondate = self.context.availabledate
        if submissiondate is None:
            submissiondate = self.context.availabledate
        difference = self.context.expirydate - submissiondate
        if difference >= timedelta(days=140):
            d = timedelta(days=14)
        elif difference > timedelta(days=30):
            d = timedelta(days=int(math.ceil(difference.days / 10.)))
        elif difference > timedelta(days=10):
            d = timedelta(days=3)
        else:
            #d = timedelta(days=100)
            return None # no expiry date, no alert sent
        return self.context.expirydate - d
