import os
import tempfile
import smtplib

from persistent import Persistent
from zope.interface import implements
from zope import component

from zope.app.container.contained import Contained
from zope.sendmail.mailer import SMTPMailer
from zope.sendmail.delivery import DirectMailDelivery, MailDataManager
from zope.sendmail.interfaces import IMailer

from documentlibrary.core import interfaces

# a local persistent version of SMTPMailer
class PersistentSMTPMailer(Persistent, Contained, SMTPMailer):
    implements(interfaces.IPersistentSMTPMailer)

    # overridden to handle smtplib.SMTPRecipientsRefused, see
    # https://bugs.launchpad.net/zope3/+bug/157104
    def send(self, *args, **kwargs):
        try:
            super(PersistentSMTPMailer, self).send(*args, **kwargs)
        except smtplib.SMTPRecipientsRefused:
            pass

class DocumentLibraryDirectMailDelivery(DirectMailDelivery):
    def __init__(self):
        pass

    def createDataManager(self, fromaddr, toaddrs, message):
        mailer = component.getUtility(IMailer)
        return MailDataManager(mailer.send,
                               args=(fromaddr, toaddrs, message))
