# the version number of the document library
_version = "1.6dev"

def getDocumentLibraryVersion():
    return _version
