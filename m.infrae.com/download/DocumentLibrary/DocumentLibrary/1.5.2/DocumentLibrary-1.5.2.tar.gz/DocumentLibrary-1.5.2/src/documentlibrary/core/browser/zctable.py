from hurry.resource import Library, ResourceInclusion

zc_table = Library('zc.table')

sorting = ResourceInclusion(zc_table, 'sorting.js')
