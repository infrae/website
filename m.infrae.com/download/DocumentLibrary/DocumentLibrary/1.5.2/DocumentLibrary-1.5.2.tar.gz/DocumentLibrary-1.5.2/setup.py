from setuptools import setup, find_packages

tests_require = ['zope.testbrowser',
                 'zope.testing',
                 'zope.app.testing', ]

setup(name='DocumentLibrary',

      # Fill in project info below
      version='1.5.2',
      author='Infrae',
      author_email='faassen@infrae.com',
      url='http://www.infrae.com/products/documentlibrary',
      description="""\
Document Library is a document management application intended for the
management and tracking of large amounts of documents in an
organization. The Document Library helps authors maintain their
documents, automatically handling versioning, workflow, and expiration
notification. It provides reviewers (librarians) with updates, fast
approval, and overviews of all activity. Document Library is built with
the Zope 3 web application framework.
""",
      long_description=open("README.txt").read() + "\n" + \
          open("CHANGES.txt").read(),
      keywords='dms cms OAI-PMH xml archive',
      license='BSD',
      # Get more from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=['Programming Language :: Python',
                   'Environment :: Web Environment',
                   'Topic :: Internet :: WWW/HTTP :: WSGI :: Application',
                   'Framework :: Zope3',
                   ],

      packages=find_packages('src'),
      package_dir = {'': 'src'},
      include_package_data=True,
      zip_safe=False,
      install_requires=['setuptools',
                        'ZODB3',
                        'ZConfig',
                        'zdaemon',
                        'grokcore.component',
                        'zope.publisher',
                        'zope.traversing',
                        'zope.app.wsgi>=3.4.0',
                        'zope.app.appsetup',
                        'zope.app.generations',
                        'zope.app.zcmlfiles',
                        # The following packages aren't needed from the
                        # beginning, but end up being used in most apps
                        'zope.annotation',
                        'zope.copypastemove',
                        'zope.formlib',
                        'zope.i18n',
                        'zope.app.authentication',
                        'zope.app.session',
                        'zope.app.intid',
                        'zope.app.keyreference',
                        'zope.app.catalog',
                        'zope.app.securitypolicy',
                        'zope.sendmail',
                        'zope.app.dtmlpage',
                        'lxml',
                        'pyoai',
                        'hurry.query',
                        'hurry.workflow',
                        'hurry.file >= 1.2',
                        'hurry.resource',
                        'hurry.zoperesource',
                        'hurry.yui',
                        'hurry.zopeyui',
                        'hurry.custom >= 0.6.2',
                        'zc.table',
                        'zc.catalog',
                        'jsontemplate'],
      tests_require = [tests_require,],
      test_suite = 'documentlibrary.core.tests',
      extras_require={'test': tests_require,},
      entry_points = """
      [console_scripts]
      dl-debug = dl.startup:interactive_debug_prompt
      dl-ctl = dl.startup:zdaemon_controller
      [paste.app_factory]
      main = dl.startup:application_factory
      """
      )
