# zope3

from zope.app import zapi

from zope.app.pagetemplate import ViewPageTemplateFile
from zope.app.security.interfaces import IUnauthenticatedPrincipal
from zope.app.component.hooks import getSite

class Redirect(object):

    label = u'You will be redirected.'
    
    template = ViewPageTemplateFile('templates/redirect.pt')

    def __init__(self, context, request):
        self.context = context
        self.request = request
        app = getSite()
        self.nextURL = zapi.absoluteURL(app, request) + '/@@effective_logout'

    def __call__(self):
        return self.template()
        
class Logout(object):

    label = u'You have been logged out'
    
    template = ViewPageTemplateFile('templates/logout.pt')

    def __init__(self, context, request):
        self.context = context
        self.request = request
        xx = IUnauthenticatedPrincipal.providedBy(request.principal)

    def __call__(self):
        request = self.request
        request.response.setStatus(401)
        request.response.setHeader(
            'WWW-Authenticate', 'basic realm=Zope', True)
        request.response.setHeader('Content-Type', 'text/html')
        return self.template()
