# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt
"""This module contains the history related classes and functions.
"""

import os

# Zope3
from persistent import Persistent
from zope.interface import implements
from zope import component
from zope.component import ComponentLookupError
from zope.security.interfaces import NoInteraction
from zope.security.management import getInteraction

from zope.traversing.browser import absoluteURL
from zope.app.intid.interfaces import IIntIds
from zope.app.component.hooks import getSite
from zope.app.container.interfaces import INameChooser
from zope.app.container.ordered import OrderedContainer
from zope.sendmail.interfaces import IMailDelivery

# documentlibrary
from documentlibrary.core import interfaces, timezone
from documentlibrary.core.template import render_template
from documentlibrary.core.flow import getStateName


class HistoryFolder(OrderedContainer):
    implements(interfaces.IHistoryFolder)


class HistoryEntry(Persistent):
    implements(interfaces.IHistoryEntryContained)

    def __init__(self, transition_event, principal):
        doc = transition_event.object
        self.doc_title = doc.title
        intids = component.getUtility(IIntIds)
        try:
            self.doc_id = intids.getId(doc)
        except KeyError:
            # object has been deleted, so no way to get doc_id anymore
            self.doc_id = None
        self.action = transition_event.transition.transition_id
        self.source_state = transition_event.source
        self.destination_state = transition_event.destination
        self.actor_id = principal.id
        self.comment = transition_event.comment
        self.timestamp = timezone.nowInUTC()
        self.message = getMessage(transition_event, principal, 'author', 'web')

    def getDocument(self):
        intids = component.getUtility(IIntIds)
        # XXX handle case when document doesn't exist anymore?
        if self.doc_id is None:
            return None
        return intids.getObject(self.doc_id)

    def getCategory(self):
        doc = self.getDocument()
        if doc is None:
            return None
        intids = component.getUtility(IIntIds)
        # XXX handle case where category doesn't exist anymore?
        return intids.getObject(doc.category)


def createEntry(transition_event, principal):
    history = getSite()['history']
    entry = HistoryEntry(transition_event, principal)
    name = INameChooser(history).chooseName('', entry)
    history[name] = entry


def sendEmail(transition_event, principal):
    sendEmailLibrarians(transition_event, principal)
    sendEmailAuthors(transition_event, principal)


def sendEmailAuthors(transition_event, principal):
    doc = transition_event.object
    from_address = getLibrarianFromAddress(doc)

    # there is no librarian for this category, so bail out
    # XXX is this right?
    if from_address is None:
        return

    message = getMessage(transition_event, principal, 'author', 'email',
                         from_address=from_address)
    if message is None:
        return

    to_addresses = [email for (firstname, lastname, email) in doc.authors]

    queueForEmail(
        from_address, to_addresses, message)


def sendEmailLibrarians(transition_event, principal):
    doc = transition_event.object
    from_address = getLibrarianFromAddress(doc)
    # XXX is this right?
    if from_address is None:
        return

    message = getMessage(transition_event, principal, 'librarian', 'email',
                         from_address=from_address)
    if message is None:
        return

    librarians = doc.getCategory().getOwningLibrarians()
    to_addresses = component.getUtility(
        interfaces.IUserInfoLookup).getEmailAddresses(librarians)
    queueForEmail(from_address, to_addresses, message)


def queueForEmail(from_, to_addresses, message):
    # if we have no email addresses, don't send a thing
    if not to_addresses:
        return
    mailer = component.getUtility(IMailDelivery)
    mailer.send(from_, to_addresses, message.encode('UTF-8'))


def getLibrarianFromAddress(doc):
    username = doc.getCategory().getNearestLibrarian()
    if username is None:
        return None
    lookup = component.getUtility(interfaces.IUserInfoLookup)
    userinfo = lookup.getUserInfoDefault(username)
    return userinfo.email


def _getDocFormats(doc):
    # list of formats
    formats = []
    if doc.file_available:
        name, extension = os.path.splitext(doc.file.filename)
        if extension:
            # get rid of leading '.'
            extension = extension[1:]
        else:
            extension = 'unknown format'
        formats.append(extension)
    if not (doc.pdf is None):
        formats.append('pdf')
    if doc.plaintext_available and not (doc.plaintext is None):
        formats.append('plain text')
    return formats


def _getDocGroups(doc):
    groups = sorted(list(doc.access))
    # XXX ugh
    if 'zope.Everybody' in groups:
        groups.remove('zope.Everybody')
        groups.insert(0, 'Everybody')
    return groups


def _getDocExpiryDays(doc):
    if doc.expirydate is not None:
        return (doc.expirydate - timezone.nowInUTC()).days
    else:
        # XXX should this ever happen in practice? it happens in tests
        return None


def _getUserInfo(principal):
    lookup = component.getUtility(interfaces.IUserInfoLookup)
    # XXX frustrating user prefix chaos..
    userid = principal.id
    if userid.startswith('documentlibrary'):
        userid = userid[len('documentlibrary'):]
    userinfo = lookup.getUserInfoDefault(userid)
    return {'user_title': userinfo.title,
            'user_email': userinfo.email}


def getMessage(transition_event, principal, audience, medium, **kw):
    data = {}

    doc = transition_event.object

    data['dl_name'] = component.getUtility(interfaces.ICustomText).dl_name
    data['title'] = doc.title
    data['versionstring'] = doc.versionstring
    data['description'] = doc.description
    data['note'] = doc.note
    data['author_emails'] = ', '.join(doc.authorEmails())
    data['formats'] = ', '.join(_getDocFormats(doc))
    data['groups'] = ', '.join(_getDocGroups(doc))
    data['availabledate'] = formatDate(doc.availabledate)
    data['expirydate'] = formatDate(doc.expirydate)
    data['expiry_days'] = _getDocExpiryDays(doc)

    category = doc.getCategory()
    if category is not None:
        path = category.getPath()
    else:
        path = ['No category']
    data['category_name'] = '/'.join(path)
    topic = doc.getFoiTopic()
    if topic is not None:
        path = topic.getPath()
    else:
        path = ['No FOI topic']
    data['foi_name'] = '/'.join(path)

    if getattr(doc, '__parent__', None) is not None:
        data['doc_url'] = getUrl(doc)
        data['handle_url'] = getHandleUrl(doc)
    else:
        # XXX does this make sense?
        data['doc_url'] = '<object was deleted>'

    transition = transition_event.transition
    data['transition_source'] = getStateName(transition.source)
    data['transition_destination'] = getStateName(transition.destination)

    data.update(_getUserInfo(principal))
    data.update(kw)

    # templating language cannot deal with None, so convert these to empty
    # strings
    noneToEmptyString(data)
    return renderMessage(transition, audience, medium, data)

# XXX not recursive, not needed for now
def noneToEmptyString(data):
    for key, value in data.items():
        if value is None:
            data[key] = ''


class MessageError(Exception):
    pass


class NoTemplateError(MessageError):
    pass


def renderMessage(transition, audience, medium, data):
    """Render message for transition with data.

    audience is either 'author' or 'librarian'.

    medium is either 'web' or 'email'. A web template may contain
    HTML.
    """
    template_name = transition.user_data.get('template')
    if template_name is None:
        # no template name found
        return None
    return render_template(
        '%s_%s_%s' % (template_name, audience, medium),
        data)


def getUrl(obj):
    """This is scary but makes life a lot easier...
    """
    try:
        request = getInteraction().participations[0]
        url = absoluteURL(obj, request)
        return url
    except (NoInteraction, ComponentLookupError):
        return 'Not a real url'


def getHandleUrl(obj):
    try:
        request = getInteraction().participations[0]
        url = '%s/handle/%s' % (
            absoluteURL(getSite(), request), obj.handle_id)
        return url
    except (NoInteraction, ComponentLookupError):
        return 'Not a real url'


def formatDate(date):
    try:
        request = getInteraction().participations[0]
        return request.locale.dates.getFormatter('date', None).format(date)
    except (NoInteraction, ComponentLookupError):
        return 'Not a real date'
