(function() {
/* category tree */
function treeInit() {
    var tree = new YAHOO.widget.TreeView('categories');
    tree.render();
}

YAHOO.util.Event.onDOMReady(treeInit);

})();
