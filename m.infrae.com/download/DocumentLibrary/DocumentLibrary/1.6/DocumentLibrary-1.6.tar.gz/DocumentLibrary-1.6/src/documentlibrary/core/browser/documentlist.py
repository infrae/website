# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.app import zapi
from zope.app.component.hooks import getSite
from zope.app.intid.interfaces import IIntIds
from zope.app.pagetemplate import ViewPageTemplateFile
from zope.app.publisher.browser.menu import getMenu
from zope.formlib import form

from hurry.workflow.interfaces import IWorkflow, IWorkflowState,\
     IWorkflowInfo, IWorkflowVersions, InvalidTransitionError
from hurry.query import Eq, And, In
from hurry.query.set import AnyOf

from documentlibrary.core import flow, interfaces, timezone
from documentlibrary.core.browser.feedback import IFeedback
from documentlibrary.core.browser.form import FormMixin
from documentlibrary.core.browser import batch
from documentlibrary.core.browser.zctable import sorting
from documentlibrary.core.browser import action

from zc.table import table
from zc.table.column import GetterColumn


class DocumentListPage(form.PageForm, FormMixin):

    form_fields = ()
    actions = ()

    label = u'Documents list'

    template = ViewPageTemplateFile('templates/documents.pt')

    def __init__(self, context, request):
        super(DocumentListPage, self).__init__(context, request)
        self._cached_documents = None

    def documents(self):
        """The documents to display on this overview page (unbatched).

        Override this in a subclass.
        """
        raise NotImplementedError

    def cached_documents(self):
        """A simple cache that only persists during the view.

        This allows us to call cached_documents multiple times
        during the lifetime of the view without causing the document
        list being generated more than once.
        """
        if self._cached_documents is not None:
            return self._cached_documents
        result = self._cached_documents = self.documents()
        return result

    def table(self):
        """The zc.table of documents (current batch).
        """
        sorting.need()
        form = self.request.form
        start = int(form.get('start', 0))
        size = int(form.get('size', 20))
        visible_columns = self.columns()
        visible_column_names = [column.name for column in visible_columns]
        hidden_columns = self.hiddenColumns()
        formatter = DocumentListFormatter(
            self.context, self.request, self.cached_documents(),
            columns=visible_columns + hidden_columns,
            visible_column_names=visible_column_names,
            batch_start=start, batch_size=size,
            sort_on=self.sortOn(),
            actions=self.actions)
        formatter.cssClasses['table'] = 'listing'
        return formatter()

    def columns(self):
        """The visible columns in the table.

        Can be overridden/extended in a subclass.
        """
        def noFormat(value, item, formatter):
            return value

        def getCheckbox(i, f):
            intid = zapi.getUtility(IIntIds)
            id = intid.getId(i)
            checkbox_name = self.prefix + '.ids:list'
            return ('<input type="checkbox" '
                    'name="%s" value="%s" label="%s" />' % (
                checkbox_name,
                id,
                id))
        checkbox = GetterColumn(
            name='checkbox',
            title=u'',
            getter=getCheckbox,
            cell_formatter=noFormat,
            )
        def getTitle(i, f):
            if i._alerted:
                alerted = 'class="alerted" '
            else:
                alerted = ''
            return '<a %shref="%s/@@edit_document">%s</a>' % (
                alerted, zapi.absoluteURL(i, f.request), i.title)

        title = GetterColumn(
            name='title',
            title=u'title',
            getter=getTitle,
            cell_formatter=noFormat,
            )
        def getState(i, f):
            wf_state = IWorkflowState(i)
            result = flow.getStateName(wf_state.getState())
            wf_versions = zapi.getUtility(IWorkflowVersions)
            l = []
            for other_state in self.getOtherStateInfo(wf_versions, wf_state):
                l.append('<a href="%(url)s">%(state)s</a>' % other_state)
            if not l:
                return result
            return result + ' (%s)' % ' '.join(l)

        status = GetterColumn(
            name='status',
            title=u'status',
            getter=getState,
            cell_formatter=noFormat,
            )
        last_changed = GetterColumn(
            name='last_changed',
            title=u'last changed',
            getter=lambda i, f: DateTimeDisplay(i.last_changed, f.request)(),
            )
        version = GetterColumn(
            name='version',
            title=u'version',
            getter=lambda i, f: i.versionstring,
            )
        available = GetterColumn(
            name='available',
            title=u'available',
            getter=lambda i, f: DateDisplay(i.availabledate, f.request)(),
            )
        expiry = GetterColumn(
            name='expiry',
            title=u'expiry',
            getter=lambda i, f: DateDisplay(i.expirydate, f.request)(),
            )
        return [checkbox,
                title, status, last_changed, version, available, expiry]

    def hiddenColumns(self):
        """Any hidden columns in the table.

        Hidden columns won't show up in the table, but can be used for
        sorting the table.
        """
        # we can't use the normal last_changed column for sorting, as
        # this does a transformation of the date for display
        last_changed_hidden = GetterColumn(
            name='last_changed_hidden',
            title=u'last changed',
            getter=lambda i, f: i.last_changed
            )
        return [last_changed_hidden]

    def sortOn(self):
        """Indicate which columns to use for sorting, and whether to reverse.

        Tuple of (column_name, reverse) tuples. Reverse set to True reverses
        the sort results.
        """
        return (('last_changed_hidden', True),)

    def batch(self):
        """Batch object used to display batch info.
        """
        form = self.request.form
        start = int(form.get('start', 0))
        size = int(form.get('size', 20))
        return batch.AmountBatch(len(self.cached_documents()), start, size)

    def url(self):
        """URL of this view.
        """
        return zapi.absoluteURL(self, self.request)

    def getOtherStateInfo(self, wf_versions, wf_state):
        state = wf_state.getState()
        id = wf_state.getId()
        for possible_state in flow.getNonArchivedStates():
            if possible_state == state:
                continue
            versions = wf_versions.getVersions(possible_state, id)
            if not versions:
                continue
            assert len(versions) == 1
            version = iter(versions).next()
            url = (zapi.absoluteURL(version, self.request) +
                   '/@@display_document')
            yield {
                'state': flow.getStateName(possible_state),
                'url': url,
                }

    def getSelectedDocuments(self):
        form = self.request.form
        # the checkboxes' name
        ids = form.get(self.prefix+'.ids', [])
        ids = [int(id) for id in ids]
        intid = zapi.getUtility(IIntIds)
        for id in ids:
            try:
                yield intid.getObject(id)
            except KeyError:
                # if any documents are gone, silently ignore them
                pass

    def bulkWorkflow(self, transition_id):
        workflow = zapi.getUtility(IWorkflow)
        transition = workflow.getTransitionById(transition_id)

        handled = []
        not_handled = []
        for document in self.getSelectedDocuments():
            try:
                IWorkflowInfo(document).fireTransition(transition_id)
            except InvalidTransitionError:
                not_handled.append(document)
            else:
                handled.append(document)
        if handled:
            self.addFeedback('Action %s for: %s' %
                             (transition.title, self._listDocuments(handled)))
        if not_handled:
            self.addError(
                'Action %s failed for: %s' %
                (transition.title, self._listDocuments(not_handled)))

    def bulkWorkflowToward(self, state, title):
        handled = []
        not_handled = []
        for document in self.getSelectedDocuments():
            info = IWorkflowInfo(document)
            try:
                info.fireTransitionToward(state)
                handled.append(document)
            except InvalidTransitionError:
                not_handled.append(document)
        if handled:
            self.addFeedback('Action %s for: %s' %
                             (title, self._listDocuments(handled)))
        if not_handled:
            self.addError(
                'Action %s failed for: %s' %
                (title, self._listDocuments(not_handled)))

    def _listDocuments(self, documents):
        return ', '.join(['"%s"' % doc.title for doc in documents])

class MySubmissionsPage(DocumentListPage):

    label = u'My authored documents'

    def documents(self):
        principal_id = self.request.principal.id
        # XXX principal prefix handling sucks.
        if principal_id.startswith('documentlibrary'):
            principal_id = principal_id[len('documentlibrary'):]
        user_info = zapi.getUtility(
            interfaces.IUserInfoLookup).getUserInfo(principal_id)
        if user_info is None:
            return []
        return flow.allVersions(
            AnyOf(('document_catalog', 'emails'), [user_info.email]))

    @action.action('delete', cssClass="EditDocument")
    def handleDeleteAction(self, form, data):
        self.bulkWorkflowToward(None, 'delete')

class SubmissionsPage(DocumentListPage):

    label = u'Submissions'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(
            In(('document_catalog', 'category'), category_ids),
            Eq(('document_catalog', 'workflow_state'), flow.SUBMITTED)))

    @action.action('approve', cssClass="ApproveDocument")
    def handleApproveAction(self, form, data):
        self.bulkWorkflow('approve')

    @action.action('reject', cssClass="ApproveDocument")
    def handleRejectAction(self, form, data):
        self.bulkWorkflow('reject')

    # authors with EditDocument can too but aren't in this screen
    @action.action('delete', cssClass="ApproveDocument")
    def handleDeleteAction(self, form, data):
        self.bulkWorkflowToward(None, 'delete')

class ApprovedPage(DocumentListPage):

    label = u'Approved documents'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                Eq(('document_catalog', 'workflow_state'), flow.APPROVED)))

    @action.action('reject', cssClass="ApproveDocument")
    def handleRejectAction(self, form, data):
        self.bulkWorkflow('reject_from_approved')

    @action.action('make available', cssClass="ApproveDocument")
    def handleMakeAvailableAction(self, form, data):
        self.bulkWorkflow('available')

    # authors with EditDocument can too but aren't in this screen
    @action.action('delete', cssClass="ApproveDocument")
    def handleDeleteAction(self, form, data):
        self.bulkWorkflowToward(None, 'delete')

class AvailablePage(DocumentListPage):
    label = u'Available documents'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                In(('document_catalog', 'workflow_state'),
                   [flow.AVAILABLE, flow.ALERTED])))

    @action.action('expire', cssClass="ApproveDocument")
    def handleExpireAction(self, form, data):
        self.bulkWorkflowToward(flow.EXPIRED, 'expire')

class ExpiredPage(DocumentListPage):
    label = u'Expired documents'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                Eq(('document_catalog', 'workflow_state'), flow.EXPIRED)))

    # authors with EditDocument can too but aren't in this screen
    @action.action('delete', cssClass="ApproveDocument")
    def handleDeleteAction(self, form, data):
        self.bulkWorkflowToward(None, 'delete')

class RejectedPage(DocumentListPage):
    label = u'Rejected documents'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                Eq(('document_catalog', 'workflow_state'), flow.REJECTED)))

    # authors with EditDocument can too but aren't in this screen
    @action.action('delete', cssClass="ApproveDocument")
    def handleEmptyAction(self, form, action):
        self.bulkWorkflowToward(None, 'delete')

class DeletionRequestedPage(DocumentListPage):
    label = u'Documents to be deleted'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                In(('document_catalog', 'workflow_state'),
                   [flow.AVAILABLE, flow.ALERTED, flow.EXPIRED]),
                Eq(('document_catalog', 'deletion_requested'), True)))

class DeletedPage(DocumentListPage):
    label = u'View deletion receipts'

    def documents(self):
        category_ids = getSite()['categories'].getOwnedCategoryIds()
        return flow.allVersions(
            And(In(('document_catalog', 'category'), category_ids),
                In(('document_catalog', 'workflow_state'),
                   [flow.DELETED])))

class CategoryDocumentsPage(DocumentListPage):

    label = u'Documents in &#xab;%s&#xbb;'

    def __init__(self, context, request):
        super(CategoryDocumentsPage, self).__init__(context, request)
        self.label = self.label % self.context.name

    def documents(self):
        intid = zapi.getUtility(IIntIds)
        category_id = intid.getId(self.context)
        return flow.allVersions(
            Eq(('document_catalog', 'category'), category_id))

    # XXX can these be removed? FormMixin is in base classes
    def useFeedback(self):
        return IFeedback(self.request).useFeedback()

    def useErrors(self):
        return IFeedback(self.request).useErrors()

    def getMenu(self):
        return getMenu('category_menu', self.context, self.request)

class DateDisplay(object):

    format = '%d-%b-%Y'

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self):
        return timezone.forDisplay(self.context).strftime(self.format)

class DateTimeDisplay(DateDisplay):

    format = '%d-%b-%Y %H:%M'

class DocumentListFormatter(table.StandaloneFullFormatter):
    def __init__(self, context, request, items, visible_column_names=None,
                 batch_start=None, batch_size=None, prefix=None, columns=None,
                 sort_on=None, ignore_request=False, actions=None):
        super(DocumentListFormatter, self).__init__(
            context, request, items, visible_column_names, batch_start,
            batch_size, prefix, columns, sort_on, ignore_request)
        self.actions = actions

    def renderHeaders(self):
        # make sure the first header is rendered using the right style
        result = self.renderFirstHeader(self.visible_columns[0])
        return result + ''.join(
            [self.renderHeader(col) for col in self.visible_columns[1:]])

    def renderFirstHeader(self, column):
        attr = self._getCSSClass('th')
        attr += ' style="width: 1%"'
        return '      <th%s>\n        %s\n      </th>\n' % (
            attr, self.getHeader(column))

    def renderContents(self):
        result =  super(DocumentListFormatter, self).renderContents()
        result += '<tfoot>%s</tfoot>\n' % self.renderFooter()
        return result

    def renderFooter(self):
        actions = ''.join([action.render() for action in self.actions])
        # XXX pass along batching state after submitting
        result = '''\
<tr class="controls"
tal:condition="items">
  <td colspan="7" class="align-right">
    %s
  </td>
</tr>''' % actions
        return result
