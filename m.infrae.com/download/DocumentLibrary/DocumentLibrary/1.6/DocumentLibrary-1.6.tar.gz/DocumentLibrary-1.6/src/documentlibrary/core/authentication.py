# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.annotation.interfaces import IAttributeAnnotatable
from zope.app.authentication import interfaces
from zope.app.authentication.groupfolder import IGroupFolder
from zope.app.component.hooks import getSite
from zope.app.folder.folder import Folder
from zope.interface import Interface, implements
from zope.schema import TextLine


class IPrincipalPrefix(Interface):
    prefix = TextLine(
        title=u"Prefix",
        description=u"Prefix to be added to all principal ids to assure "
        "that all ids are unique within the authentication service",
        required=False,
        missing_value=u"",
        default=u'',
        readonly=True)

class ISearchSchema(Interface):
    """Search Interface for this Principal Provider"""

    search = TextLine(
        title=u"Search String",
        description=u"A Search String",
        required=False,
        default=u'',
        missing_value=u'')

class PrincipalInfo:

    implements(interfaces.IPrincipalInfo)

    def __init__(self, id, login, title, description):
        self.id = id
        self.login = login
        self.title = title
        self.description = description

    def __repr__(self):
        return 'PrincipalInfo(%r)' % self.id
    
class ContentSpaceAuthenticatorBase(Folder):
    """An AuthenticatorPlugin that defers to content space.
    """

    implements(interfaces.IAuthenticatorPlugin,
               interfaces.IQueriableAuthenticator,
               interfaces.IQuerySchemaSearch,
               IGroupFolder,
               IPrincipalPrefix)

    schema = ISearchSchema

    def __init__(self, prefix=''):
        self.prefix = unicode(prefix)
        super(ContentSpaceAuthenticatorBase, self).__init__()

    def authenticateCredentials(self, credentials):
        """Return principal info if credentials can be authenticated
        """
        if not isinstance(credentials, dict):
            return None
        if not ('login' in credentials and 'password' in credentials):
            return None
        principal = self.getContentSpacePrincipal(credentials['login'])
        if principal is None:
            return None
        # XXX a group won't be authenticated ever, right?
        if principal.password != credentials['password']:
            return None
        return PrincipalInfo(self.prefix + principal.login,
                             principal.login, principal.title,
                             principal.description)

    def principalInfo(self, id):
        if not id.startswith(self.prefix):
            return None
        principal = self.getContentSpacePrincipal(id[len(self.prefix):])
        if principal is None:
            return None
        return PrincipalInfo(id, principal.login, principal.title,
                             principal.description)

    def search(self, query, start=None, batch_size=None):
        """Search through this principal provider."""
        search = query.get('search')
        if search is None:
            return []
        return self.searchContentSpace(search, start, batch_size)

    def getGroupsForPrincipal(self, principal_id):
        if not principal_id.startswith(self.prefix):
            return []
        principal_id = principal_id[len(self.prefix):]
        user = self.getUserFolder().get(principal_id)
        if user is None:
            return []
        return [(self.prefix + groupname) for groupname in user.groups]
    
    def getPrincipalsForGroup(self, groupid):
        # XXX prefix handling may be borked
        group = self.getGroupFolder().get(groupid)
        if group is None:
            return []
        return group.users
    
    def getUserFolder(self):
        """Override this in a subclass.
        """
        raise NotImplementedError

    def getGroupFolder(self):
        """Override this in a subclass.
        """
        raise NotImplementedError
  
    def __contains__(self, groupid):
        return groupid in self.getGroupFolder()
        
    def getContentSpacePrincipal(self, login):
        user = self.getUserFolder().get(login)
        if user is not None:
            return user
        return self.getGroupFolder().get(login)
        
    def searchContentSpace(self, search, start, batch_size):
        # XXX should look in groups too..
        folder = self.getUserFolder()
        search = search.lower()
        i = 0
        n = 1
        for value in folder.values():
            if (search in value.title.lower() or
                search in value.description.lower() or
                search in value.login.lower()):
                if not ((start is not None and i < start)
                        or (batch_size is not None and n > batch_size)):
                    n += 1
                    yield self.prefix + value.login
                i += 1
               
class DocumentLibraryAuthenticator(ContentSpaceAuthenticatorBase):
    """
    Content space in this case is defined as a 'users' folder just under the
    site.
    """

    implements(IAttributeAnnotatable)

    def getUserFolder(self):
        return getSite()['users']

    def getGroupFolder(self):
        return getSite()['groups']
