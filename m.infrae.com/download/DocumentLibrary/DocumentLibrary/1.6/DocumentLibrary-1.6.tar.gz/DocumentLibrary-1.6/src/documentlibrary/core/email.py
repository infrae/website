# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from persistent import Persistent
from zope import component
from zope.app.container.contained import Contained
from zope.interface import implements
from zope.sendmail.delivery import DirectMailDelivery, MailDataManager
from zope.sendmail.interfaces import IMailer
from zope.sendmail.mailer import SMTPMailer

from documentlibrary.core import interfaces


# a local persistent version of SMTPMailer
class PersistentSMTPMailer(Persistent, Contained, SMTPMailer):
    implements(interfaces.IPersistentSMTPMailer)

    # Default setting for BBB
    force_tls = False
    no_tls = False


class DocumentLibraryDirectMailDelivery(DirectMailDelivery):

    def __init__(self):
        pass

    def createDataManager(self, fromaddr, toaddrs, message):
        mailer = component.getUtility(IMailer)
        return MailDataManager(
            mailer.send, args=(fromaddr, toaddrs, message))
