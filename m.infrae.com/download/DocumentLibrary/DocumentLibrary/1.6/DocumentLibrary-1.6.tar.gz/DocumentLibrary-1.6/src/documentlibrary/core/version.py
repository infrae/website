# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

import pkg_resources

def getDocumentLibraryVersion():
    return pkg_resources.get_distribution('documentlibrary').version
