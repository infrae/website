# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.publisher.browser import applySkin
from zope.publisher.interfaces.browser import IBrowserRequest
from zope.app.rotterdam import rotterdam as RotterdamLayer
from zope import component

from documentlibrary.core import interfaces


class IDocumentLibrarySkin(interfaces.IDocumentLibraryLayer, RotterdamLayer):
    pass


def documentLibraryTraverseSubscriber(event):
    """A subscriber to BeforeTraverseEvent.
    """
    if (interfaces.IDocumentLibrary.providedBy(event.object) and
        IBrowserRequest.providedBy(event.request)):
        selector = component.getUtility(interfaces.ISkinSelector)
        applySkin(event.request, selector.getSkin())
