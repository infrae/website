import time

from persistent import Persistent
from zope.app.folder import Folder
from zope.app.container.contained import Contained
from zope.interface import implements

from hurry import custom
from hurry.custom.interfaces import ITemplateDatabase

def render_template(template_id, json):
    """Render template with json.

    If no message can be found, return None.
    """
    try:
        return custom.render('email_templates', template_id + '.jsont', json)
    except IOError:
        return None

class EmailTemplate(Persistent, Contained):
    def __init__(self, source):
        self.source = source
        self.last_updated = time.time()

class EmailTemplatesFolder(Folder):
    id = 'email_templates'
    title = "Email templates"

    implements(ITemplateDatabase)

    def update(self, template_id, source):
        # XXX remove last one?
        if template_id in self:
            del self[template_id]
        self[template_id] = EmailTemplate(source)

    def get_source(self, template_id):
        try:
            return self[template_id].source
        except KeyError:
            return None

    def get_modification_time(self, template_id):
        try:
            return self[template_id].last_updated
        except KeyError:
            return None

    def get_samples(self, template_id):
        return {}

def reset_templates_to_default(dl):
    """Reset template folder to default one.
    """
    if 'email_templates' in dl:
        del dl['email_templates']

    # install new email templates
    dl['email_templates'] = EmailTemplatesFolder()

    # register email templates as local utility
    sitemanager = dl.getSiteManager()
    sitemanager.registerUtility(
        dl['email_templates'], ITemplateDatabase,
        'email_templates')

