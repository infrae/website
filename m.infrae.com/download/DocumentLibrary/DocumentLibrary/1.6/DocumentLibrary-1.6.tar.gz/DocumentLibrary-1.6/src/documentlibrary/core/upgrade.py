# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

import grokcore.component as grok
from zope.app.generations.interfaces import IInstallableSchemaManager
from zope.app.component.hooks import setSite
from zope import component

from hurry.workflow.interfaces import IWorkflow

from documentlibrary.core.library import DocumentLibrary, _registerUtility
from documentlibrary.core import interfaces
from documentlibrary.core import configuration, template, flow


class DocumentLibraryEvolver(object):
    def install(self, context):
        self.evolve(context, self.generation)

    def evolve(self, context, generation):
        root = context.connection.root()['Application']
        for entry in root.values():
            if isinstance(entry, DocumentLibrary):
                setSite(entry)
                self.evolve_dl(entry)


class Update14To15(grok.GlobalUtility, DocumentLibraryEvolver):
    grok.implements(IInstallableSchemaManager)
    grok.name('documentlibrary.core.evolver_14_to_15')

    minimum_generation = 0
    generation = 1

    def evolve_dl(self, dl):
        # remove old templates dir. Might not be wise as it might
        # contain info to be copied over into the new templates
        if 'email_templates' in dl:
            if 'old_email_templates' in dl:
                del dl['old_email_templates']
            dl['old_email_templates'] = dl['email_templates']

        template.reset_templates_to_default(dl)

        # register LoginNotification as local utility
        sitemanager = dl.getSiteManager()
        default = sitemanager['default']
        _registerUtility(default, configuration.LoginNotification,
                         interfaces.ILoginNotification)

        # refresh workflow
        workflow = component.getUtility(IWorkflow)
        workflow.refresh(flow.createWorkflow())


class Update15To16(grok.GlobalUtility, DocumentLibraryEvolver):
    grok.implements(IInstallableSchemaManager)
    grok.name('documentlibrary.core.evolver_15_to_16')

    minimum_generation = 1
    generation = 2

    def evolve_dl(self, dl):
        sitemanager = dl.getSiteManager()
        default = sitemanager['default']
        _registerUtility(default, configuration.SkinSelector,
                         interfaces.ISkinSelector)
