# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

# Core browser package
