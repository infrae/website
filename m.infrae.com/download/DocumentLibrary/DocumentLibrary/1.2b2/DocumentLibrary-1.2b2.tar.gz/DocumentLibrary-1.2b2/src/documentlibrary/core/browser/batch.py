##############################################################################
#
# Copyright (c) 2003 Zope Corporation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.0 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################
"""Batching Support
"""

from zope.interface import implements, Interface

class IAmountBatch(Interface):
    """An amount batch is a minimalistic batching infrastructure.

    It just knows the amount of the items to batch, not which items
    they actually are, but this way is sufficient to use for displaying a
    batching headers.
    """
    def __len__():
        """Return the length of the batch. This might be different than the
        passed in batch size, since we could be at the end of the list and
        there are not enough elements left to fill the batch completely."""

    def nextBatch(self):
        """Return the next batch. If there is no next batch, return None."""
    
    def prevBatch(self):
        """Return the previous batch. If there is no previous batch, return
        None."""

    def total(self):
        """Return the length of the list (not the batch)."""

    def startNumber(self):
        """Give the start **number** of the batch, which is 1 more than the
        start index passed in."""

    def endNumber(self):
        """Give the end **number** of the batch, which is 1 more than the
        final index."""

class AmountBatch(object):
    """A minimalistic implementation of batch.

    This is just sufficient to use for batch headings, and is not
    actually used for batching itself. Only takes the total amount
    of items, not the items themselves.
    """
    implements(IAmountBatch)
    
    def __init__(self, amount, start=0, size=20):
        self.amount = amount
        self.start = start
        if amount == 0:
            self.start = -1
        elif start >= amount:
            raise IndexError("Start index key out of range")
        self.size = size
        self.trueSize = size
        if start + size > amount:
            self.trueSize = amount - start
        self.end = start + self.trueSize - 1

    def __len__(self):
        return self.trueSize

    def nextBatch(self):
        start = self.start + self.size
        if start >= self.amount:
            return None
        return AmountBatch(self.amount, start, self.size)
    
    def prevBatch(self):
        start = self.start - self.size
        if start < 0:
            return None
        return AmountBatch(self.amount, start, self.size)

    def total(self):
        return self.amount
    
    def startNumber(self):
        return self.start+1

    def endNumber(self):
        return self.end+1
