import unittest

from zope.app.testing import functional
from zope.app.testing import placelesssetup, ztapi
from zope.annotation import attribute

class TestAuthorsWidget(functional.FunctionalTestCase):
    
    def test__toFieldValue(self):
        from documentlibrary.core.browser import widgets
        from zope.publisher.browser import TestRequest
        from zope.schema import Field
        from zope.app.form.interfaces import ConversionError
        request = TestRequest()
        field = Field(__name__='authors', title=u'authors', default=[])
        field = field.bind(None)    
        authorswidget = widgets.AuthorsWidget(field, request)
        expected = u'<textarea cols="60" id="field.authors" name="field.authors" rows="5" widget:type="authors"></textarea>'
        self.assertEquals(expected, authorswidget())
        self.assertRaises(
            ConversionError, authorswidget._toFieldValue, 'asdasdasd')
        self.assertRaises(
            ConversionError, authorswidget._toFieldValue, 'asdasd||asdasd')
        self.assertRaises(
            ConversionError, authorswidget._toFieldValue, 'asdasd||asdasd||')
        self.assertRaises(
            ConversionError, authorswidget._toFieldValue, 'asdasd||asdasd||noemailaddress')
        self.assertRaises(
            ConversionError, authorswidget._toFieldValue, 'asdasd||asdasd||sdasd||')
        input = ('foo||bar||foo@bar.com')
        expected = [('foo', 'bar', 'foo@bar.com'),]
        self.assertEquals(expected, authorswidget._toFieldValue(input))
        input = (
            'foo||bar||foo@bar.com\n  baz  || qux || baz@qux.com\n||||\n''')
        expected = [
            ('foo', 'bar', 'foo@bar.com'), 
            ('baz', 'qux', 'baz@qux.com')]
        self.assertEquals(expected, authorswidget._toFieldValue(input))
        
def test_suite():
    return unittest.TestSuite((
        unittest.makeSuite(TestAuthorsWidget),
        ))

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
