# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from zope.interface import Interface
from zope.app.session.interfaces import ISession

class IFeedback(Interface):
    def addFeedback(message):
        """Add feedback message.
        """

    def addError(message):
        """Add error message.
        """

    def useFeedback():
        """Use feedback messages; clears them.
        """

    def useErrors():
        """Use error messages; clears them.
        """

class Feedback(object):
    
    def __init__(self, request):
        self._session = ISession(request)['documentlibrary.feedback']

    def addFeedback(self, message):
        messages = self._session.setdefault('feedback', [])
        messages.append(message)

    def addError(self, message):
        messages = self._session.setdefault('errors', [])
        messages.append(message)
        
    def clearFeedback(self):
        self._session['feedback'] = []

    def clearErrors(self):
        self._session['errors'] = []

    def useFeedback(self):
        messages = self._session.get('feedback', [])
        self.clearFeedback()
        return messages

    def useErrors(self):
        messages = self._session.get('errors', [])
        self.clearErrors()
        return messages
