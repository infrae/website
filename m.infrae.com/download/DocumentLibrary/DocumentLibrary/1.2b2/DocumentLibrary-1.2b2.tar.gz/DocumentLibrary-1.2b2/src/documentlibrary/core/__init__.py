# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

# Document Library package
