# the version number of the document library
_version = "1.1b"

def getDocumentLibraryVersion():
    return _version
