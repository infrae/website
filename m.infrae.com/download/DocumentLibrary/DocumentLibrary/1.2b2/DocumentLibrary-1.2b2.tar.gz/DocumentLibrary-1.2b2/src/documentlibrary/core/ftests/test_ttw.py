import unittest
from zope import component
from zope.app.testing import functional
from zope.sendmail.interfaces import IMailDelivery
from zope.app.component.hooks import setSite
from zope.sendmail.interfaces import IMailDelivery

from documentlibrary.core import library
from documentlibrary.core import interfaces

from documentlibrary.core.ftests.test_documentlibrary import DummyMailDelivery

class DocumentLibraryTestCase(functional.HTTPTestCase):
    def setUp(self):
        super(DocumentLibraryTestCase, self).setUp()
        self._old_maildelivery = component.getUtility(
            IMailDelivery, 'dl-delivery')
        component.provideUtility(
            DummyMailDelivery(), IMailDelivery, 'dl-delivery')
        root = self.getRootFolder()
        self.dl = library.DocumentLibrary()
        root['dl'] = self.dl
        
    def tearDown(self):
        component.provideUtility(
            self._old_maildelivery, IMailDelivery, 'dl-delivery')
        setSite(None)
        super(DocumentLibraryTestCase, self).tearDown()

class TestTTWSecurity(DocumentLibraryTestCase):
    pass

##     def test_ttw(self):
##         self.dl['users']['test'] = user.UserInfo(
##             'test', 'test', 'Test', 'test@infrae.com', 'Test desc')
##         import pdb; pdb.set_trace()
##         response = self.publish('/dl', 'test:test')
        
##         #    '/dl/categories/announcements/documents/+/add_document',
##         #    'test:test')
##         print response

def test_suite():
    return unittest.TestSuite([
        unittest.makeSuite(TestTTWSecurity),
        ])
