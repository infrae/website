from setuptools import setup, find_packages

setup(
    name='DocumentLibrary',
    version='1.2b2',
    author='Infrae',
    author_email='faassen@infrae.com',
    url='http://www.infrae.com/products/documentlibrary',
    description="""\
Document Library is a document management application intended for the
management and tracking of large amounts of documents in an
organization. The Document Library helps authors maintain their
documents, automatically handling versioning, workflow, and expiration
notification. It provides reviewers (librarians) with updates, fast
approval, and overviews of all activity. Document Library is built with
the Zope 3 web application framework.
""",
    long_description="""\
Document Library is a document management application intended for the
management and tracking of large amounts of documents in an
organization. The Document Library helps authors maintain their
documents, automatically handling versioning, workflow, and expiration
notification. It provides reviewers (librarians) with updates, fast
approval, and overviews of all activity. Document Library is built with
the Zope 3 web application framework.

Information in the Document Library can be accessed using the Open
Archives Initiative Protocol for Metadata Harvesting (OAI-PMH),
meaning that besides being open source, the Document Library is an
open data application. Because it's open data, the Document Library
is easy to integrate with other systems, such as the Silva CMS or any
other application capable of OAI-PMH harvesting.
""",    
    packages=find_packages('src'),
    package_dir = {'': 'src'},
    namespace_packages=['documentlibrary'],
    include_package_data = True,
    dependency_links=['http://download.zope.org/distribution/',],
    zip_safe=False,
    license='BSD',
    keywords='dms cms OAI-PMH xml archive',
    
    install_requires=['setuptools',
                      'pyoai >= 2.1.5',
                      'hurry.query >= 0.9.1',
                      'hurry.workflow >= 0.9',
                      'hurry.file >= 0.9',
                      'zc.table'],
)
