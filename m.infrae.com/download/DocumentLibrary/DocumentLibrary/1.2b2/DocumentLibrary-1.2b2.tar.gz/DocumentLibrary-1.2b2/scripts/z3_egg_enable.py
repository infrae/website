#!/usr/bin/python
"""
This is a script that makes a Zope 3 instance's lib/python
directory a place that eggs can be imported from.

It does this by modifying files in a Zope 3 instance's bin directory,
to include a line that makes the instance's lib/python into a site.
"""
import os
import sys

def main():
    try:
        instance_home = sys.argv[1]
    except IndexError:
        print "Usage: z3_egg_enable /path/to/instance"
    egg_enable(instance_home)
    
def egg_enable(instance_home):
    for filename in ['zopectl', 'runzope', 'debugzope',
                     'scriptzope', 'zpasswd', 'pyskel',
                     'i18nextract']:
        filepath = os.path.join(instance_home, 'bin', filename)
        patch(filepath,
              'sys.path[:]', 'basepath',
              '    import site; site.addsitedir(sys.path[0])\n')
    # test currently uses special code
    patch(os.path.join(instance_home, 'bin', 'test'),
          'sys.path', 'SOFTWARE_HOME]',
          'import site; site.addsitedir(sys.path[0])\n')

def patch(filepath, search_pattern, end_pattern, insert_text):
    f = open(filepath, 'r')
    data = f.read()
    f.close()
    if 'addsitedir' in data:
        print "%s: already patched" % filepath
        return
    i = data.find(search_pattern)
    if i == -1:
        print "%s: did not find line to modify" % filepath
        return
    print "%s: modifying" % filepath
    insertion_point = data.find(end_pattern, i) + len(end_pattern) + 1
    data = (data[:insertion_point] + insert_text + data[insertion_point:])
    f = open(filepath, 'w')
    f.write(data)
    f.close()
    
if __name__ == '__main__':
    main()
    
