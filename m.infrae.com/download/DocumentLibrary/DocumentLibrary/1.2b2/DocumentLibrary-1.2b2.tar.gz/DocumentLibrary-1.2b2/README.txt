Document Library
================

The Document Library is an open source web application written on top
of the Zope 3 application server platform. Information in the Document
Library can be accessed using the Open Archives Initiative Protocol
for Metadata Harvesting (OAI-PMH), meaning that besides being open
source, the Document Library is also a good example of an *open data*
application. Because it is open data, the Document Library is easier
to integrate with other applications, such as the Silva CMS or any
other application capable of OAI-PMH harvesting.

For more information about the Document Library itself as well as the
OAI-PMH protocol see the files in the doc directory.

For installation instructions, see INSTALL.txt.

Release status and contact information
--------------------------------------

The documentation status is incomplete: in particular information
about the Silva integration and the installation of conversion
functionality (Word -> PDF, Word -> text) via OpenOffice is
incomplete. There is also no information yet about the installation of
tramline (fast upload and download) integration.

In addition, it is likely users will want to use the Document Library
with slightly or even completely different metadata information. In
order to do this, the Document Library needs to be customized.

The Document Library software was developed by Infrae as open source
software. If you need help with Document Library installation, or are
interested in doing custom development work so the Document Library
becomes more suitable to your organization, please contact Infrae at
info@infrae.com. Infrae specializes in services to make Zope-based
content management software fit your organization's needs.

OAI-PMH URLs
------------

The public OAI-PMH base URL for the Document Library is here:

http://localhost:8080/doclib/oaipmh

The restricted OAI-PMH url for the Document Library (login required) is here:

http://localhost:8080/doclib/oaipmh_private

This second URL exports information about non-public documents, and is
typically used for Silva integration as Silva can take care of access
control.
