from StringIO import StringIO

from zope import component
from zope.app import zapi
from zope.formlib import form
from zope.publisher.browser import BrowserView
from zope.app.publisher.browser.menu import getMenu

from ldapadapter.interfaces import ILDAPAdapter
from ldappas.interfaces import ILDAPAuthentication

from documentlibrary.core.browser.configuration import ConfigureUtilityForm

from documentlibrary.core.browser.user import (
    UserListPage, UserEditFormBase, UserDisplayFormBase,
    GroupListPage, BrowseGroupListPage, BrowseGroupDisplayForm, GroupEditForm,
    GroupDisplayForm)
from documentlibrary.ldapauth import interfaces
from documentlibrary.ldapauth import install
from documentlibrary.ldapauth.interfaces import ILDAP
from documentlibrary.ldapauth.widget import UsersDisplayWidget

class ConfigureLDAPForm(ConfigureUtilityForm):

    form_fields = form.Fields(ILDAP)

    label = u'LDAP Configuration'

    def _getUtility(self):
        return component.getUtility(ILDAP)
    
class InstallLDAP(BrowserView):
    def __call__(self):
        out = StringIO()
        print >> out, ("Install %s" %
                       install.addLDAPUtility())
        print >> out, ("Installed %r and %r" %
                       (install.addLDAPAdapter(), install.addLDAPAuth()))
        print >> out, ("Replaced user folder with %r" %
                       install.replaceUserFolder())
        print >> out, ("Replaced group folder with %r" %
                       install.replaceGroupFolder())
        return out.getvalue()

class UserListPage(UserListPage):
    def getMenu(self):
        return getMenu('ldap_user_menu', self.context, self.request)

class UserEditForm(UserEditFormBase):

    form_fields = form.Fields(interfaces.ILDAPUserInfo).omit('__parent__')
    form_fields['login'].for_display = True
    form_fields['title'].for_display = True
    form_fields['email'].for_display = True
    form_fields['groups'].for_display = True

    # XXX shouldn't have to copy this from form.PageEditForm,
    # actions don't seem to deal with subclassing properly yet
    @form.action('save changes')
    def handleEditAction(self, action, data):
        self.editAction(data)
        return self.redirect(zapi.absoluteURL(
            self.context, self.request) + '/@@edit_user')
    
    @form.action('Update from LDAP')
    def resync(self, action, data):
        self.context.sync()
        self.addFeedback(u'Updated user data from LDAP')

class UserDisplayForm(UserDisplayFormBase):

    form_fields = form.Fields(interfaces.ILDAPUserInfo).omit('__parent__')


class GroupListPage(GroupListPage):
    def getMenu(self):
        return getMenu('ldap_group_menu', self.context, self.request)

    @form.action('Update all groups from LDAP')
    def resync(self, action, data):
        self.context.sync()
    

class BrowseGroupListPage(BrowseGroupListPage):
    pass

class BrowseGroupDisplayForm(BrowseGroupDisplayForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)
    form_fields = form_fields.omit('title')
    form_fields['users'].custom_widget = UsersDisplayWidget

class GroupEditForm(GroupEditForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)
    form_fields = form_fields.omit('title')
    form_fields['users'].custom_widget = UsersDisplayWidget
    form_fields['users'].for_display = True

class GroupDisplayForm(GroupDisplayForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)    
    form_fields = form_fields.omit('title')
    form_fields['users'].custom_widget = UsersDisplayWidget    


