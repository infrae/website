# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt

from Globals import InitializeClass, package_home
from AccessControl import ClassSecurityInfo
from OFS import SimpleItem

from Products.PageTemplates.PageTemplateFile import PageTemplateFile

from Products.Formulator.Form import ZMIForm

from Products.Silva import SilvaPermissions as permissions
from Products.Silva import helpers
from Products.SilvaOAI.oaisource import QuerySourceAsset

from Products.SilvaDocumentLibrary.restrictedquery import QueryRestriction

class DocumentListing(QueryRestriction, QuerySourceAsset):
    """Hybrid Asset, ExternalSource, and OAI Query for the Document Library
    """
    
    meta_type = 'Document Library Listing'

    security = ClassSecurityInfo()

    def __init__(self, id, service):
        QuerySourceAsset.__init__(self, id, service)
        self._metadata_format = 'dl'
    
    security.declareProtected(
        permissions.AccessContentsInformation, 'to_html')
    def to_html(self, REQUEST, **kw):
        """Render HTML for inclusion in Silva Documents.
        """
        results = self.queryResults({})
        return self.recordsLayout(results=results)
        
    security.declareProtected(
        permissions.AccessContentsInformation, 'recordsLayout')
    def recordsLayout(self, results):
        return self.public['records'](
            results=results, resultset_size_info=False)

InitializeClass(DocumentListing)
        
manage_addQuerySourceForm = PageTemplateFile(
    "www/OAIQueryForm", globals(), __name__='manage_addQuerySourceForm')
    
def manage_addDocumentListing(context, id, title, service, REQUEST=None):
    query = DocumentListing(id, service)
    # XXX needs id validation
    context._setObject(id, query)
    query = getattr(context, id)
    query.set_title(title)
    helpers.add_and_edit(context, id, REQUEST)
    return query
