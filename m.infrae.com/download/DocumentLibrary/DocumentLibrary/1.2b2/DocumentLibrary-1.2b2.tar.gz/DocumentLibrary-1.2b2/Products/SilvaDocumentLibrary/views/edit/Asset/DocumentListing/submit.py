from Products.Formulator.Errors import ValidationError, FormValidationError

request = context.REQUEST
model = request.model
view = context

form = model.getManageForm()

try:
    result = form.validate_all(request)
except FormValidationError, e:
    return view.tab_edit(
        message_type="error", message=view.render_form_errors(e))

setSpec = result.get('setSpec', None)
if setSpec is None or setSpec == '':
    model.setSet(None)
else:
    model.setSet(result['setSpec'])

# XXX Hack
for key, value in result.copy().items():
    if 'none' in value:
        del result[key]

model.setFilters(result)

return view.tab_edit(
    message_type="feedback", message="Settings changed")
