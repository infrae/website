# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt
from Products.OAICore.oaischema import OAISchema, OAIDateField, \
    OAIKeywordField, OAIFulltextField, OAINoIndexField, OAIMultiSortable, \
    OAIColumn, OAIItemField

class DocumentLibraryKeywordField(OAIKeywordField):

    # XXX Override the 'default' OAIKeywordField, since it has
    # too much UI in it that is not needed here.
    
    def addPublicField(self, form, unique_values):    
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(id, title, 'MultiListField')
        result = [('All values', '')]
        result = result + unique_values
        # now setup the Formulator field
        values = form.get_field(id).values
        values['title'] = title
        values['size'] = 5
        values['required'] = 0
        values['unicode'] = 1
        values['items'] = result
        values['default'] = ''
        
    def updatePublicQuery(self, query, form_results, unique_values=None):
        id = self.getId()
        value = form_results.get(id, None)
        if value is None:
            return
        if value == '':
            return
        # XXX a bit of a hack for multi select lists that have a first item
        # called 'All values' with '' for its value - meaning "Just gimme
        # everything!"
        if type(value) == type([]):
            if '' in value:
                return
        query[id] = value

class DocumentLibraryTopicsField(DocumentLibraryKeywordField):

    def _sorted_topics(self, values):
        # XXX hack to be able to sort-of-numerically sort on the FOI Topic
        _values = []
        for wys, wyg in values:
            topic_number_string = wys[:wys.find(' ')]
            topic_number = tuple([int(n) for n in topic_number_string.split('.')])
            _values.append((topic_number, (wys, wyg)))
        _values.sort()
        return [v[1] for v in _values]
    
    def addPublicField(self, form, unique_values):
        return DocumentLibraryKeywordField.addPublicField(
            self, form, self._sorted_topics(unique_values))
            
dl_prefix = 'dl'    
    
# create schema and set namespaces    
dl_schema = OAISchema()
dl_schema.addNamespace('dl', 'http://infrae.com/ns/documentlibrary')
dl_schema.addNamespace('oai_dc', 'http://www.openarchives.org/OAI/2.0/oai_dc/')

"""
DL metadata fields:

  title, description, versionstring, note
  category, foi_topic
  state
    
  modificationdate, availabledate, expirydate
  lastchanged
  
  authors
    
  handle
  file_url, pdf_url, plaintext_url
  
  groups
"""
    
fields = [
    OAIFulltextField('title', 'dl:dl/dl:title/text()'),
    OAIFulltextField('description', 'dl:dl/dl:description/text()'),
    
    DocumentLibraryKeywordField('handle', 'dl:dl/dl:handle/text()'),
    
    OAINoIndexField('version', 'dl:dl/dl:versionstring/text()'),
    OAINoIndexField('note', 'dl:dl/dl:note/text()'),

    DocumentLibraryKeywordField(
        'categories', 'dl:dl/dl:categories//dl:category/text()'),
    DocumentLibraryKeywordField('category', 'dl:dl/dl:category/text()'),

    DocumentLibraryTopicsField(
        'foi_topics', 'dl:dl/dl:foi_topics//dl:foi_topic/text()'),
    DocumentLibraryKeywordField('foi_topic', 'dl:dl/dl:foi_topic/text()'),
    
    OAIDateField('modificationdate', 'dl:dl/dl:modificationdate/text()'),
    OAIDateField('availabledate', 'dl:dl/dl:availabledate/text()'),
    OAIDateField('expirydate', 'dl:dl/dl:expirydate/text()'),
    OAIDateField('last_changed', 'dl:dl/dl:last_changed/text()'),
    
    DocumentLibraryKeywordField(
        'author_email_addresses', 
        'dl:dl/dl:authors/dl:author/dl:emailaddress/text()'),
        
    OAINoIndexField(
        'author_display_names', 
        'dl:dl/dl:authors/dl:author/dl:display_name/text()'),
    
    OAINoIndexField('file_url', 'dl:dl/dl:file_urls/dl:file_url/text()'),
    OAINoIndexField('pdf_url', 'dl:dl/dl:file_urls/dl:pdf_url/text()'),
    OAINoIndexField(
        'plaintext_url', 'dl:dl/dl:file_urls/dl:plaintext_url/text()'),

    DocumentLibraryKeywordField(
        'groups', 'dl:dl/dl:groups/dl:group/text()'),
    ]

multi_sortables = [
    OAIMultiSortable(
        'foi_topic_title_date', ['foi_topics', 'title', 'availabledate'])
        ]
        
result_columns = [
    OAIColumn('title', 'Title', 'category_title_date'),
    OAIColumn('handle', 'Handle', 'category_title_date'),
    OAIColumn('category', 'Category', 'category_title_date'),
    OAIColumn('foi_topic', 'FOI Topic', 'category_title_date'),
    ]

manageables = ['categories', 'foi_topics', 'author_email_addresses']

# categories is used a user searchable t be able to search for
# a category and find documents with a sub category too.
user_searchables = ['foi_topics', ]

fulltext_fields =['title', 'description']

item_fields = [] # no Items, so no need to define Item fields.

# define the schema
dl_schema.setFields(fields)
dl_schema.setManageableFields(manageables)
dl_schema.setMultiSortables(multi_sortables)
dl_schema.setInitialSortOn('foi_topic_title_date')
dl_schema.setInitialSortOrder('asceding')
dl_schema.setResultColumns(result_columns)
dl_schema.setItemFields(item_fields)
dl_schema.setFulltextFields(fulltext_fields)
dl_schema.setUserSearchables(user_searchables)
