##parameters=text
if text is not None:
    return text.encode('latin1')
else:
    return text
