from setuptools import setup, find_packages

setup(
    name='bedfordshire.dlldapfilter',
    version='0.1',
    author='Infrae',
    author_email='faassen@infrae.com',
    url='',
    packages=find_packages('src'),
    package_dir = {'': 'src'},
    namespace_packages=['bedfordshire'],
    include_package_data = True,
    zip_safe=False,
    license='BSD',
    keywords='',
    install_requires=['setuptools',
                      #'dl.ldapauth'
                      ],
)
