from zope.interface import implementer

from documentlibrary.ldapauth import interfaces

@implementer(interfaces.IUserGroupsFilter)
def groupsFilter(ldap_groups):
    groups = []
    for ldap_group in ldap_groups:
        if not ldap_group.endswith('ou=groups,o=luton'):
            continue
        parts = ldap_group.split(',')
        groups.append(parts[0][3:])
    return groups

@implementer(interfaces.IGroupMembersFilter)
def membersFilter(ldap_members):
    members = []
    for ldap_member in ldap_members:
        if not ldap_member.endswith('ou=users,o=luton'):
            continue
        parts = ldap_member.split(',')
        members.append(parts[0][3:].lower())
    return members
