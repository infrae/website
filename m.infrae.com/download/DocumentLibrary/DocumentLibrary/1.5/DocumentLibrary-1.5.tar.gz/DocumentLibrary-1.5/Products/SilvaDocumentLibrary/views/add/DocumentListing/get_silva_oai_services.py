# XXX replace this with interface or method call to get parents directly?
service_ids = []
model = context.REQUEST.model.aq_inner
while True:
    try:
        objects = model.objectValues(['OAIPMH Service'])
    except AttributeError: # means model is the request
        break
    for object in objects:
        service_ids.append((object.id, '/'.join(object.getPhysicalPath())))
    model = model.aq_parent
        
return service_ids
