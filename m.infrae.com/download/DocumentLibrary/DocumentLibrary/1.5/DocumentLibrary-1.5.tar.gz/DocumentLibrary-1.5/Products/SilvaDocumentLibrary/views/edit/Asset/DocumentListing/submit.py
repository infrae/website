from Products.Formulator.Errors import ValidationError, FormValidationError

request = context.REQUEST
model = request.model
view = context

form = model.getManageForm()

try:
    result = form.validate_all(request)
except FormValidationError, e:
    return view.tab_edit(
        message_type="error", message=view.render_form_errors(e))

if result['set'] == ['none'] or result['set'] == 'none' or not result['set']:
    model.setSet(None)
else:
    model.setSet(result['set'])

if not (result['sort_on'] == ['none'] or
        result['sort_on'] == 'none' or not result['sort_on']):
    model.setSort(result['sort_on'])

model.setSortOrder(result['sort_order'])

model.setDisplayLetter(result['display_letter'])

allow_show_all = result.pop('allow_show_all')

model.setAllowShowAll(allow_show_all)

batch_size = result.pop('batch_size')
model.setBatchSize(batch_size)

# XXX Hack
for key, value in result.copy().items():
    if 'none' in value:
        del result[key]

model.setFilters(result)
model.sec_update_last_author_info()

return view.tab_edit(
    message_type="feedback", message="Settings changed")
