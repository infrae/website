# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt

class QueryRestriction:
    # Mixin for restricting queries in the DL context.
    def _getUserGroups(self, user):
        groups = []
        gs = getattr(self, 'service_groups', None)
        if gs is not None:
            groups += gs.getGroups(user).keys()
        username = user.getUserName()
        if username != 'Anonymous User':
            groups.append(username)
        return groups
        
    def restrictQuery(self, query):
        # If the current user has a Zope/Silva Manager role in the current
        # context, make sure it can see everything.
        user = self.REQUEST.AUTHENTICATED_USER
        roles = user.getRolesInContext(self)
        if not 'Manager' in roles:
            groups = ['zope.Everybody'] + self._getUserGroups(user)
            query['metadata_groups'] = groups
