from hurry.filesize import size

# Those size doesn't any existing convention names.
richard = [
    (1024 ** 5, 'Pb'),
    (1024 ** 4, 'Tb'),
    (1024 ** 3, 'Gb'),
    (1024 ** 2, 'Mb'),
    (1024 ** 1, 'Kb'),
    (1024 ** 0, ('Byte', 'Bytes')),
    ]

def file_size(record, name):
    s = record.getFieldText(name)
    if s is None:
        return None
    bytes = int(s)
    return size(bytes, system=richard)
