# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt
from Products.OAICore.oaischema import OAISchema, OAIDateField, \
    OAIKeywordField, OAIFulltextField, OAINoIndexField, OAIMultiSortable, \
    OAIColumn, OAIItemField, OAICoreColumn

# the minimum and maximum size of the DocumentLibraryKeywordField
MIN_KEYWORD_FIELD_SIZE = 3
MAX_KEYWORD_FIELD_SIZE = 10

class DocumentLibraryKeywordField(OAIKeywordField):
    """We override the 'default' OAIKeywordField to do some UI tweaks.
    """

    # XXX it's not exactly right to override OAIKeywordField because it
    # has *too much* UI that we don't need here, and part of the
    # work done here for public fields is to suppor that case.

    def addEditField(self, form, filters, catalog):
        """Override addEditfield.

        We change the edit field for keywords to dynamically expand
        depending on how many items it is to display.
        """
        OAIKeywordField.addEditField(self, form, filters, catalog)
        # fix up size for field based on amount of items
        values = form.get_field(self.getId()).values
        amount = len(values['items'])
        # constrain amount of fields between range
        if amount < MIN_KEYWORD_FIELD_SIZE:
            amount = MIN_KEYWORD_FIELD_SIZE
        elif amount > MAX_KEYWORD_FIELD_SIZE:
            amount = MAX_KEYWORD_FIELD_SIZE
        values['size'] = amount

    def addPublicField(self, form, unique_values):
        id = self.getId()
        title = self.getTitle()
        form.manage_addField(id, title, 'MultiListField')
        result = [('All values', '')]
        result = result + unique_values
        # now setup the Formulator field
        values = form.get_field(id).values
        values['title'] = title
        values['size'] = 5
        values['required'] = 0
        values['unicode'] = 1
        values['items'] = result
        values['default'] = ''

    def updatePublicQuery(self, query, form_results, unique_values=None):
        id = self.getId()
        value = form_results.get(id, None)
        if value is None:
            return
        if value == '':
            return
        # XXX a bit of a hack for multi select lists that have a first item
        # called 'All values' with '' for its value - meaning "Just gimme
        # everything!"
        if type(value) == type([]):
            if '' in value:
                return
        query[id] = value

class DocumentLibraryTopicsField(DocumentLibraryKeywordField):

    def _sorted_topics(self, values):
        # XXX hack to be able to sort-of-numerically sort on the FOI Topic
        _values = []
        for wys, wyg in values:
            topic_number_string = wys[:wys.find(' ')]
            topic_number = tuple([int(n) for n in topic_number_string.split('.')])
            _values.append((topic_number, (wys, wyg)))
        _values.sort()
        return [v[1] for v in _values]

    def addPublicField(self, form, unique_values):
        return DocumentLibraryKeywordField.addPublicField(
            self, form, self._sorted_topics(unique_values))

dl_prefix = 'dl'

# create schema and set namespaces
dl_schema = OAISchema()
dl_schema.addNamespace('dl', 'http://infrae.com/ns/documentlibrary')
dl_schema.addNamespace('oai_dc', 'http://www.openarchives.org/OAI/2.0/oai_dc/')
dl_schema.setName('dl (Document Library schema)')

"""
DL metadata fields:

  title, description, versionstring, note
  foi_topic
  state

  modificationdate, availabledate, expirydate
  lastchanged

  authors

  handle
  file_url, pdf_url, plaintext_url

  groups
"""

fields = [
    OAIFulltextField('title', 'dl:dl/dl:title/text()'),
    OAIFulltextField('description', 'dl:dl/dl:description/text()'),
    OAIFulltextField('plaintext', 'dl:dl/dl:plaintext/text()'),

    DocumentLibraryKeywordField('handle', 'dl:dl/dl:handle/text()'),

    DocumentLibraryKeywordField('version', 'dl:dl/dl:versionstring/text()'),
    OAINoIndexField('note', 'dl:dl/dl:note/text()'),

    DocumentLibraryTopicsField(
        'foi_topics', 'dl:dl/dl:foi_topics//dl:foi_topic/text()'),
    DocumentLibraryKeywordField('foi_topic', 'dl:dl/dl:foi_topic/text()'),

    OAIDateField('modificationdate', 'dl:dl/dl:modificationdate/text()'),
    OAIDateField('availabledate', 'dl:dl/dl:availabledate/text()'),
    OAIDateField('expirydate', 'dl:dl/dl:expirydate/text()'),
    OAIDateField('last_changed', 'dl:dl/dl:last_changed/text()'),

    DocumentLibraryKeywordField(
        'author_email_addresses',
        'dl:dl/dl:authors/dl:author/dl:emailaddress/text()'),

    OAINoIndexField(
        'author_display_names',
        'dl:dl/dl:authors/dl:author/dl:display_name/text()'),

    OAINoIndexField('file_url', 'dl:dl/dl:file_urls/dl:file_url/text()'),
    OAINoIndexField('pdf_url', 'dl:dl/dl:file_urls/dl:pdf_url/text()'),
    OAINoIndexField(
        'plaintext_url', 'dl:dl/dl:file_urls/dl:plaintext_url/text()'),

    OAINoIndexField('file_size', 'dl:dl/dl:file_urls/dl:file_url/@size'),
    OAINoIndexField('pdf_size', 'dl:dl/dl:file_urls/dl:pdf_url/@size'),
    OAINoIndexField('plaintext_size', 'dl:dl/dl:file_urls/dl:plaintext_url/@size'),

    DocumentLibraryKeywordField(
        'groups', 'dl:dl/dl:groups/dl:group/text()'),
    ]

multi_sortables = [
    OAIMultiSortable(
        'foitopic_title_availabledate', ['foi_topics', 'title', 'availabledate']),
    OAIMultiSortable(
        'title_availabledate', ['title', 'availabledate']),
    OAIMultiSortable(
        'availabledate_title', ['availabledate', 'title']),
    OAIMultiSortable(
        'modificationdate_title', ['modificationdate', 'title']),
    OAIMultiSortable('version_title', ['version', 'title']),
        ]

result_columns = [
    OAIColumn('title', 'Title', 'category_title_date'),
    OAIColumn('handle', 'Permanent Web Address', 'category_title_date'),
    OAICoreColumn('setName', 'Category', 'category_title_date'),
    OAIColumn('foi_topic', 'FOI Topic', 'category_title_date'),
    ]

manageables = ['foi_topics', 'author_email_addresses']

# categories is used a user searchable t be able to search for
# a category and find documents with a sub category too.
user_searchables = ['foi_topics', ]

fulltext_fields = ['title', 'description', 'plaintext']

item_fields = [] # no Items, so no need to define Item fields.

rss_fields = {
    'title': 'title',
    'creator': 'author_display_names',
    'date': 'availabledate',
    'subject': 'setName',
    'description': 'description',
    'uri': ['file_url', 'plaintext_url', 'pdf_url', 'handle'],
    }

# define the schema
dl_schema.setFields(fields)
dl_schema.setManageableFields(manageables)
dl_schema.setMultiSortables(multi_sortables)
dl_schema.setInitialSortOn('foitopic_title_availabledate')
dl_schema.setInitialSortOrder('ascending')
dl_schema.setResultColumns(result_columns)
dl_schema.setItemFields(item_fields)
dl_schema.setRSSFieldIds(rss_fields)
dl_schema.setFulltextFields(fulltext_fields)
dl_schema.setUserSearchables(user_searchables)
dl_schema.setDate('availabledate')
