import unittest

from datetime import datetime

# XXX should be a doctest, really
"""
We test (at least a bit) the following rule:

(i) If difference =>140 days then reminder alert is sent 14 days
before expiry date

(ii) If difference is >30 and <140 days then perform a calculation
based upon 10% (rounded up to next whole number), e.g.:

31 days - 40 days difference = 4 days notice
41 days - 50 days difference = 5 days notice
51 days - 60 days difference = 6 days notice
61 days - 70 days difference = 7 days notice
71 days - 80 days difference = 8 days notice

(iv) If difference >10 days and =<30 days then reminder alert
     is sent 3 days before expiry date
(v) If difference =<10 days then no alert is sent
"""   

from documentlibrary.core.alert import DocumentAlertDates

class Doc(object):
    def __init__(self, submissiondate, expirydate, availabledate=None):
        self.submissiondate = submissiondate
        self.expirydate = expirydate
        self.availabledate = availabledate
        
class AlertTestCase(unittest.TestCase):

    def test_bigger_140_alert(self):
        doc = Doc(datetime(2005, 1, 1), datetime(2005, 12, 15))
        self.assertEquals(
            datetime(2005, 12, 1),
            DocumentAlertDates(doc).getExpiryAlertDate())

    def test_bigger_140_alert_missing_submissiondate(self):
        doc = Doc(None, datetime(2005, 12, 15),
                  datetime(2005, 1, 1))
        self.assertEquals(
            datetime(2005, 12, 1),
            DocumentAlertDates(doc).getExpiryAlertDate())
        
    def test_smaller_30_alert(self):
        # > 10 <= 30
        doc = Doc(datetime(2005, 1, 1), datetime(2005, 1, 15))
        self.assertEquals(
            datetime(2005, 1, 12),
            DocumentAlertDates(doc).getExpiryAlertDate())
        # <= 10
        doc = Doc(datetime(2005, 1, 1), datetime(2005, 1, 5))
        self.assertEquals(
            None,
            DocumentAlertDates(doc).getExpiryAlertDate())

    def test_10_percent(self):
        doc = Doc(datetime(2005, 1, 1), datetime(2005, 2, 5))
        self.assertEquals(
            datetime(2005, 2, 1),
            DocumentAlertDates(doc).getExpiryAlertDate())
        doc = Doc(datetime(2005, 1, 1), datetime(2005, 2, 14))
        self.assertEquals(
            datetime(2005, 2, 9),
            DocumentAlertDates(doc).getExpiryAlertDate())

def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(AlertTestCase))
    return suite

if __name__ == '__main__':
    unittest.main()
