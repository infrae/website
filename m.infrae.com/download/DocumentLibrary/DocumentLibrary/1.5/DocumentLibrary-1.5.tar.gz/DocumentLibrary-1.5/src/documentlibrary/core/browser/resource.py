from hurry.resource import Library, ResourceInclusion
from hurry import yui

js = Library('js')

category_tree = ResourceInclusion(js, 'category_tree.js',
                                  depends=[yui.treeview, yui.event, yui.sam])

