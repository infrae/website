# the version number of the document library
_version = "1.5dev"

def getDocumentLibraryVersion():
    return _version
