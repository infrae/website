#! /usr/bin/env python2.3

# auto harvest
import urllib2
import base64
import optparse
from oaipmh.common import datestamp_to_datetime
from datetime import datetime
import fulltextretrieval

OAI_URL_METHOD = 'getRepositoryURI'
STORAGE_DIR_METHOD = 'getTTWFulltextDirectory'
FROM_DATETIME_METHOD = 'getTTWISODatestamp'
UPDATE_METHOD = 'manage_update'

def _callAuthenticated(url, username, passwd):
    request = urllib2.Request(url)
    info = '%s:%s' % (username, passwd)
    credentials = base64.encodestring(info).strip()
    request.add_header('Authorization', 'Basic ' + credentials)
    src = urllib2.urlopen(request)
    return src.read()
    
def _getServiceSettings(service_url, username, passwd):
    oai_url = _callAuthenticated(
        '%s/%s' % (service_url, OAI_URL_METHOD), username, passwd)
    storage_dir = _callAuthenticated(
        '%s/%s' % (service_url, STORAGE_DIR_METHOD), username, passwd)
    from_string  = _callAuthenticated(
        '%s/%s' % (service_url, FROM_DATETIME_METHOD), username, passwd)
    try:
        from_ = datestamp_to_datetime(from_string)
    except ValueError, e:
        from_ = None
    return oai_url, storage_dir, from_

def update(
        service_url, service_username, service_passwd, 
        repo_username, repo_passwd, redo=False):
    oai_url, storage_dir, from_ = _getServiceSettings(
        service_url, service_username, service_passwd)
    until = datetime.utcnow()
    fulltextretrieval.retrieval(
        oai_url, storage_dir, from_=from_, until=until, 
        username=repo_username, passwd=repo_passwd, redo=redo)
    _callAuthenticated(
        '%s/%s' % (service_url, UPDATE_METHOD), service_username, service_passwd)

if __name__ == '__main__':
    # command line UI
    version = '0.1'
    usage = (
        'usage: %prog [options] OAI_SERVICE_URL_1 '
        'OAI_SERVICE_URL_2...OAI_SERVICE_URL_n\n\n')
    parser = optparse.OptionParser(usage=usage, version=version)
    parser.add_option(
        '--service-username', dest='service_username', default=None, help=(
        'Username used for connecting to the OAI Services'))
    parser.add_option(
        '--service-passwd', dest='service_passwd', default=None, help=(
        'Password used for connecting to the OAI Services'))
    parser.add_option(
        '--repository-username', dest='repo_username', default=None, help=(
        'Username used for connecting to the OAI Repository'))
    parser.add_option(
        '--repository-passwd', dest='repo_passwd', default=None, help=(
        'Password used for connecting to the OAI Repository'))
    parser.add_option(
        '--redo', dest='redo', default=False, action='store_true', help=(
        'Retrieve fulltext even the corresponding file already exists.'))
        
    options, urls = parser.parse_args()
    for url in urls:
        update(
            url, options.service_username, options.service_passwd, 
            options.repo_username, options.repo_passwd, options.redo)
        