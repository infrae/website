import os, time, signal, subprocess, tempfile, shutil
import socket
import xmlrpclib
import md5
from zipfile import ZipFile
from StringIO import StringIO

OOOCONV_URL = 'http://localhost:11117'
TIMEOUT = 300

class ConversionError(Exception):
    pass

class TimeOutError(Exception):
    pass

def convertTo(data, filename, format, extension):
    orig_base, orig_ext = os.path.splitext(os.path.basename(filename))
    
    # special case handling for pdf to text
    if format == 'TXT' and orig_ext == '.pdf':
        output_filename = orig_base + extension
        return pdfToText(data, output_filename), output_filename
    
    server = xmlrpclib.Server(OOOCONV_URL)
    source_filename, target_filename = _computeFilenames(
        server, orig_base, orig_ext, extension)
    
    sourcefile = open(source_filename, 'w')
    sourcefile.write(data)
    sourcefile.close()
    
    try:
        jobid = server.addJob(
            dict(source=os.path.basename(source_filename),
                 dest=os.path.splitext(os.path.basename(target_filename))[0],
                 format=format))
        if not isinstance(jobid, int):
            raise ConversionError(jobid)
    except (socket.error, xmlrpclib.Fault), e:
        raise ConversionError(str(e))

    _waitUntilFinished(server, jobid)

    if not os.path.exists(target_filename):
        raise ConversionError("Expected target file in %r, but not there" %
                              target_filename)

    return open(target_filename).read(), orig_base + extension

def convertToPDF(data, filename):
    return convertTo(data, filename, 'PDF', '.pdf')
   
def convertToTxt(data, filename):
    data, filename = convertTo(data, filename, 'TXT', '.txt')
    # XXX if OpenOffice conversion services were ever to run on Windows,
    # this would screw up the line endings, but otherwise this is hopefully
    # reliable
    data = data.replace('\n', '\r\n')
    return data, filename

def pdfToText(data, filename):
    dirpath = tempfile.mkdtemp()
    try:
        f = open(os.path.join(dirpath, 'file.pdf'), 'wb')
        f.write(data)
        f.close()
        try:
            result = callWithTimeout(
                ['pdftotext', '-layout', '-nopgbrk', '-eol', 'unix',
                 '-enc', 'UTF-8', 'file.pdf', filename], cwd=dirpath)
        except TimeOutError:
            raise ConversionError("Conversion of PDF to text conversion hung.")
        if result != 0:
            raise ConversionError("Could not handle PDF to text conversion.")
        f = open(os.path.join(dirpath, filename), 'rb')
        result = f.read()
        f.close()
    finally:
        shutil.rmtree(dirpath)
    return result

def callWithTimeout(*args, **kw):
    timeout = kw.pop('timeout', TIMEOUT)
    granularity = kw.pop('granularity', 0.5)
    p = subprocess.Popen(*args, **kw) 
    count = 0
    status = None
    while count < timeout and status is None:
        time.sleep(granularity)
        count += granularity
        status = p.poll()

    if status is None:
        print "status is none:", status
        try:
            os.kill(p.pid, signal.SIGKILL)
            status = p.wait()
            raise TimeOutError
        except OSError:
            # process already ended by itself
            pass
    return p.returncode


def _computeFilenames(server, orig_base, orig_ext, extension):
    try:
        paths = server.getPaths()
    except (socket.error, xmlrpclib.Fault), e:
        raise ConversionError(str(e))
    
    source_dir = paths['source']
    target_dir = paths['dest']
    
    source_filename = os.path.join(
        source_dir,
        '%s-%s%s' % (orig_base,
                     md5.new(str(time.time())).hexdigest(),
                     orig_ext))
    
    target_filename = os.path.join(
        target_dir,
        os.path.splitext(os.path.basename(source_filename))[0] + extension)

    return source_filename, target_filename

def _waitUntilFinished(server, jobid):
    tries = 10
    while tries:
        tries -= 1
        completed = server.isJobCompleted(jobid)
        if completed == True:
            break
        elif completed == False:
            time.sleep(1)
        else:
            raise ConversionError(str(completed))
    
    if tries == 0:
        raise ConversionError("Job %r did not complete." % jobid)
