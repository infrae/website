from zope.app.pagetemplate import ViewPageTemplateFile
from zope.publisher.browser import BrowserPage

from documentlibrary.core.browser.feedback import IFeedback

from hurry import custom
from hurry.custom.interfaces import Error

class EmailTemplatesPage(BrowserPage):
    label = u'Email templates'
    
    template = ViewPageTemplateFile('templates/email_templates.pt')

    def __call__(self):
        return self.template()    

    def structure(self):
        result = custom.structure('email_templates')
        result = [entry for entry in result if 'directory' not in entry]
        return result

class EmailTemplatesEdit(BrowserPage):
    label = u'Edit email template'

    template = ViewPageTemplateFile('templates/email_templates_edit.pt')

    def __call__(self):
       content = self.request.get('content', None)
       if content is not None:
           template_id = self.request.get('template')
           try:
               custom.check('email_templates', template_id, content)
           except Error, e:
               IFeedback(self.request).addError(
                   "There is a problem with the template: %s" % unicode(e))
           collection = custom.collection('email_templates')
           collection.update(self.request.get('template'), content)
           IFeedback(self.request).addFeedback(
               "Template %s modified" % template_id)
       return self.template()

    def edit_content(self):
        template_id = self.request.get('template')
        result = custom.collection('email_templates').get_source(template_id)
        if result is None:
            result = custom.root_collection('email_templates').get_source(template_id)
        return result

    def useFeedback(self):
        return IFeedback(self.request).useFeedback()

    def useErrors(self):
        return IFeedback(self.request).useErrors()
