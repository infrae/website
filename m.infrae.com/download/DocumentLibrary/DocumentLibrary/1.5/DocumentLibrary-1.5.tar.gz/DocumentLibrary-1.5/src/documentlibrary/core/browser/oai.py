# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt

from oaipmh import server, metadata
from zope.traversing.browser.absoluteurl import absoluteURL

from documentlibrary.core import oai

class BaseOAIPMH:

    show_private = False
    
    def __init__(self, context, request):
        self.context = context
        self.request = request
        
    def _getRegistry(self):
        raise NotImplementedError

    def __call__(self):
        baseURL = absoluteURL(self, self.request)
        dloai = oai.DocumentLibraryOAI(
            self.context, baseURL, self.show_private)
        oaiserver = server.Server(
            dloai, metadata_registry=self._getRegistry(),
            resumption_batch_size=100)
        response = self.request.response
        response.setHeader('Content-type', 'application/xml')
        return oaiserver.handleRequest(self.request.form)

class PrivateOAIPMH(BaseOAIPMH):

    show_private = True
    
    def _getRegistry(self):
        metadata_registry = metadata.MetadataRegistry()
        metadata_registry.registerWriter('oai_dc', server.oai_dc_writer)
        metadata_registry.registerWriter('dl', oai.privateMetadataWriter)
        return metadata_registry
    
class PublicOAIPMH(BaseOAIPMH):
    
    def _getRegistry(self):
        metadata_registry = metadata.MetadataRegistry()
        metadata_registry.registerWriter('oai_dc', server.oai_dc_writer)
        metadata_registry.registerWriter('dl', oai.publicMetadataWriter)
        return metadata_registry
    
