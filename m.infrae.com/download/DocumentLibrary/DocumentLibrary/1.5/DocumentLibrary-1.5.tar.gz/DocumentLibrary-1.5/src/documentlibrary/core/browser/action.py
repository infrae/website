from zope.formlib.interfaces import IAction
from zope.formlib import namedtemplate, form
import zope.i18n
import zope.i18nmessageid
from zope.interface import implements

class ICssAction(IAction):
    """An action that has a CSS class.
    """

@namedtemplate.implementation(ICssAction)
def render_submit_button(self):
    if not self.available():
        return ''
    label = self.label
    if isinstance(label, zope.i18nmessageid.Message):
        label = zope.i18n.translate(self.label, context=self.form.request)
    result = ('<input type="submit" id="%s" name="%s" value="%s"'
              ' class="button' % (self.__name__, self.__name__, label))
    if self.cssClass:
        result += ' %s' % self.cssClass
    result += '" />'
    return result

class CssAction(form.Action):
    implements(ICssAction)
    
    def __init__(self, label, **options):
        self.cssClass = options.pop('cssClass', None)
        super(CssAction, self).__init__(label, **options)

class action(form.action): 
    def __call__(self, success):
        action = CssAction(self.label, success=success, **self.options)
        self.actions.append(action)
        return action
