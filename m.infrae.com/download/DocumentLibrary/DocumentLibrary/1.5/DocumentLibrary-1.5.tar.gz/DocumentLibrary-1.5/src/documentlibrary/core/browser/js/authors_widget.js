// Always something nice to find in Kupu...
function ContextFixer(func, context) {
    /* Make sure 'this' inside a method points to its class */
    this.func = func;
    this.context = context;
    this.args = arguments;
    var self = this;
      
    this.execute = function() {
        /* execute the method */
        var args = new Array();
        // the first arguments will be the extra ones of the class
        for (var i=0; i < self.args.length - 2; i++) {
            args.push(self.args[i + 2]);
        };
        // the last are the ones passed on to the execute method
        for (var i=0; i < arguments.length; i++) {
            args.push(arguments[i]);
        };
        return self.func.apply(self.context, args);
    };
};
      
function addEventHandler(element, event, method, context) {
    /* method to add an event handler for both IE and Mozilla */
    var wrappedmethod = new ContextFixer(method, context);
    var args = new Array(null, null);
    for (var i=4; i < arguments.length; i++) {
        args.push(arguments[i]);
    };
    wrappedmethod.args = args;
    try {
        if (element.addEventListener) {
            element.addEventListener(event, wrappedmethod.execute, false);
        } else if (element.attachEvent) {
            element.attachEvent("on" + event, wrappedmethod.execute);
        } else {
            throw _("Unsupported browser!");
        };
        return wrappedmethod.execute;
    } catch(e) {
        alert(_('exception ${message} while registering an event handler ' +
            'for element ${element}, event ${event}, method ${method}',
            {'message': e.message, 'element': element,
            'event': event,
                'method': method}));
    };
    return wrappedmethod.execute;
};
      
function removeEventHandler(element, event, method) {
    /* method to remove an event handler for both IE and Mozilla */
    if (window.removeEventListener) {
        element.removeEventListener(event, method, false);
    } else if (element.detachEvent) {
        element.detachEvent("on" + event, method);
    } else {
        throw _("Unsupported browser!");
    };
};
      
function repeatRowAndReplaceImage() {
    // get the row to repeat
    var button = this;
    var repeatrow = null;
    var currel = button;
    while (!repeatrow) {
        currel = currel.parentNode;
        if (!currel) {
            throw('No DIV found to repeat in repeatRowAndRemoveImage!');
        };
        if (currel.nodeName == 'DIV') {
            repeatrow = currel;
        };
    };
    // copy the node
    var clone = repeatrow.cloneNode(true);
    // place it before the current one
    repeatrow.parentNode.insertBefore(clone, repeatrow);
      
    // now change the last input from the clone, which should be 
    // the button with the + sign (note that this puts a dependency
    // on the structure of the div, not very nice)
    var inputs = clone.getElementsByTagName('IMG');
    var button = inputs[inputs.length - 1];
    button.setAttribute('src', '++resource++images/minussymbol.png');
    removeEventHandler(button, 'click', button.clickhandler);
    addEventHandler(button, 'click', removeRow, button);
      
    // fill the new fields with a default value
    var newvalues = ['', '', ''];
    var changeinputs = repeatrow.getElementsByTagName('INPUT');
    for (var i=0; i < 3; i++) {
        changeinputs[i].value = newvalues[i];
    };
};
      
function removeRow() {
    // find the div
    var button = this;
    var div = null;
    var currel = button;
    while (!div) {
        var currel = currel.parentNode;
        if (!currel) {
            throw('No DIV found as parent of the button in removeRow()!');
        };
        if (currel.nodeName == 'DIV') {
            div = currel;
        };
    };
    // remove it
    div.parentNode.removeChild(div);
};
      
function registerEvents() {
    var plusinput = document.getElementById('plussymbol');
    var inputs = document.getElementsByTagName('IMG');
    // register the event handler, store the return value on the element
    // so we can unregister the event handler later on
    plusinput.clickhandler = addEventHandler(plusinput, 'click',
                                    repeatRowAndReplaceImage, plusinput);
    for ( i = 0; i < inputs.length; i++) {
        var mi = inputs[i] ;
        // should use a dedicated attr here, since id must be unique
        if (mi.id ==  'minussymbol') {
            mi.clickhandler = addEventHandler(mi, 'click', removeRow, mi);
        };
    };
};
