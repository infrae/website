# Exception and error views
from zope.app.exception.browser import unauthorized
from zope.app.pagetemplate import ViewPageTemplateFile

from zope.publisher.browser import BrowserPage

class ExceptionPage(BrowserPage):
    
    label = u'System Error'
    template = ViewPageTemplateFile('templates/exception.pt')

    def __call__(self):
        return self.template()
    
class UnauthorizedPage(unauthorized.Unauthorized):

    label = u'Unauthorized'
    template = ViewPageTemplateFile('templates/unauthorized.pt')
    
class UserErrorPage(ExceptionPage):
    
    label = u'An error occured'
    template = ViewPageTemplateFile('templates/usererror.pt')
    
class NotFoundPage(ExceptionPage):
    
    label = u'Resource not found'
    template = ViewPageTemplateFile('templates/notfound.pt')
    
