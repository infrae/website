# Copyright (c) 2005 Infrae. All rights reserved.
# See also LICENSE.txt
# Zope 3
from zope.interface import implements
from zope.schema.vocabulary import SimpleTerm, SimpleVocabulary
#from zope.component import getUtility
from zope.app import zapi
from zope.app.intid.interfaces import IIntIds
from zope.app.container.contained import Contained
from zope.app.container.ordered import OrderedContainer
from zope.app.component.hooks import getSite
from persistent import Persistent

# documentlibrary
import interfaces

class FOITopicTree(OrderedContainer):
    
    implements(interfaces.IFOITopicTree)

class FOITopic(OrderedContainer):

    implements(interfaces.IFOITopicContained)
    
    def __init__(self, name):
        super(FOITopic, self).__init__()
        self.name = name

    def getPath(self):
        topic = self
        result = []
        while interfaces.IFOITopic.providedBy(topic):
            result.append(topic.name)
            topic = topic.__parent__
        result.reverse()
        return result

class FOITopicsUtility(Persistent, Contained):

    implements(interfaces.IHierarchicalTermsUtility)
    
    def getTop(self):
        return getSite()['foi_topics']

def vocabulary(context):
    util = zapi.getUtility(
        interfaces.IHierarchicalTermsUtility, name='foi_topics')
    terms = _getTerms(util.getTop(), [])
    return SimpleVocabulary(terms)
            
def _getTerms(context, terms, sequence=()):
    intid = zapi.getUtility(IIntIds, context=context)
    topics = [
        t for t in context.values() if interfaces.IFOITopic.providedBy(t)]
    for i in range(len(topics)):
        topic = topics[i]
        id = intid.getId(topic)
        term = SimpleTerm(id, str(id), topic.name)
        term.sequence = sequence + (i,) # XXX hack for widgets
        terms.append(term)
        # recursive for sub-items
        _getTerms(topic, terms, sequence + (i,))
    return terms
    
_topics = (
    (u'Governance', (
        (u'Legal Framework', ()),
        (u'Governance Structure', ()),
        (u'How the Institution is Organised', ()),
        (u'Information on the Institutional Context', ()),
        (u'Management Structure', ()))
    ),
    (u'Financial Resources', (
        (u'Finance', ()),
        (u'Resource Planning', ()))
    ),
    (u'Human Resources', (
        (u'Employment and employee relations', ()),
        (u'Equal opportunities', ()),
        (u'Human resources Strategy', ()),
        (u'Staff development', ()))
    ),
    (u'Physical Resources', (
        (u'Estates', ()),)
    ),
    (u'Student Adminstration and Support', (
        (u'Information on student admission, progression and completion', ()),
        (u'Student accommodation', ()),
        (u'Student admission and registration', ()),
        (u'Student discipline', ()),
        (u'Student learning support services', ()),
        (u'Student liaison', ()),
        (u'Student policies', ()),
        (u'Student welfare', ()),
        (u'Student associations and activities', ()))
    ),
    (u'Information Services', (
        (u'Availability and conditions of use of facilities', ()),
        (u'Mission statement and related documents', ()),
        (u'Policies with regard to data and information', ()),
        (u'Procurement policies', ()),
        (u'Scope of collections held', ()))
    ),
    (u'Teaching and Learning', (
        (u'Academic year dates', ()),
        (u'External review information', ()),
        (u'Honorary degrees', ()),
        ((u'Information on the institutions internal procedures'
        ' for assuring academic quality and standards'), ()),
        ((u'Qualitative data on the quality and standards of'
        ' learning and teaching'), ()),
        (u'Staffing structure of schools and departments', ()),
        (u'Student assessment strategy', ()),
        (u'Tuition fees', ()))
    ),
    (u'Research and Development', (
        (u'Commitees', ()),
        (u'Funding', ()),
        (u'Research Policies', ()))
    ),
    (u'External Relations', (
        (u'Alumni', ()),
        (u'Community liaison', ()),
        (u'Marketing and recruitment', ()),
        (u'Public relations', ()))
    ),
    )

def setupTopics(context):
    util = zapi.getUtility(
        interfaces.IHierarchicalTermsUtility, name='foi_topics', 
        context=context)
    tree = util.getTop()
    for title, subs in _topics:
        _addTerms(tree, title, subs)

def _addTerms(context, term, subterms):
    cat = FOITopic(term)
    id = term.lower().replace(' ', '_')
    context[id] = cat
    for title, subs in subterms:
        _addTerms(cat, title, subs)
