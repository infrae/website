##parameters=name, new_start
request = context.REQUEST
old_start = int(request.get(name + '_start', 0))

qs = request.QUERY_STRING

old_s = '%s_start=%s' % (name, old_start)
new_s = '%s_start=%s' % (name, new_start)

if old_s in qs:
    qs = qs.replace(old_s, new_s)
else:
    qs = qs + '&' + new_s

return request.URL + '?' + qs
