##parameters=sequence, name=None, start=0, size=20, batches=None
request = context.REQUEST
model = request.model

start = int(start)
size = int(size)

show_all = 'show_all'
if name:
    show_all = name + '_' + show_all

if size == 0:
    return sequence
if context.getAllowShowAll() and int(request.get(show_all, 0)):
    return sequence

from z3c.batching.batch import Batch
return Batch(sequence, start, size, batches)
