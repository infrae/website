# Copyright (c) 2002-2005 Infrae. All rights reserved.
# See also LICENSE.txt

from Products.FileSystemSite.DirectoryView import registerDirectory
from Products.Silva.ExtensionRegistry import extensionRegistry
from Products.SilvaMetadata.Compatibility import registerTypeForMetadata
from Products.OAICore.schemaRegistry import registerSchemaForDefaultReader

import documentlisting, documentsearch, cherrypicking, install

def initialize(context):
    
    extensionRegistry.register(
        'SilvaDocumentLibrary', 'Document Library Integration', context, [],
        install, depends_on='SilvaOAI')
    
    context.registerClass(
        documentlisting.DocumentListing,
        constructors = (documentlisting.manage_addQuerySourceForm,
                        documentlisting.manage_addDocumentListing),
        icon = "www/oaiquerysource.png"
        )

    context.registerClass(
        documentsearch.DocumentSearch,
        constructors = (documentsearch.manage_addQuerySourceForm,
                        documentsearch.manage_addDocumentSearch),
        icon = "www/oaiquerysource.png"
        )

    context.registerClass(
        cherrypicking.DocumentCherry,
        constructors = (cherrypicking.manage_addQuerySourceForm,
                        cherrypicking.manage_addDocumentCherryFromZMI),
        icon = "www/oaiquerysource.png"
        )
        
    registerDirectory('views', globals())
    registerTypeForMetadata(documentlisting.DocumentListing.meta_type)
    registerTypeForMetadata(documentsearch.DocumentSearch.meta_type)

    extensionRegistry.addAddable(documentlisting.DocumentListing.meta_type, 3)
    extensionRegistry.addAddable(documentsearch.DocumentSearch.meta_type, 3)
    
    from dl import dl_prefix, dl_schema
    registerSchemaForDefaultReader(dl_prefix, dl_schema)

from AccessControl import allow_module

allow_module('z3c.batching.batch')
from z3c.batching.batch import Batch
Batch.__allow_access_to_unprotected_subobjects__ = True
