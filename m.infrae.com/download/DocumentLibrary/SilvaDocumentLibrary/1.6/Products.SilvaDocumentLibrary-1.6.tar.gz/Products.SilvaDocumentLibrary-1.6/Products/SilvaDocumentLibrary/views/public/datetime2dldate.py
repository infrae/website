##parameters=dt
return dt.strftime('%d-%b-%Y')
