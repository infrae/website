##parameters=batches, currentBatchIdx, nb_left, nb_right
from z3c.batching.batch import first_neighbours_last
return first_neighbours_last(batches, currentBatchIdx, nb_left, nb_right)

