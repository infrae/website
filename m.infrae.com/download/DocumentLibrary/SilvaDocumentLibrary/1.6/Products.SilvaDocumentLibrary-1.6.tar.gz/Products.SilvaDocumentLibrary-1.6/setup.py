from setuptools import setup, find_packages
import os

setup(name='Products.SilvaDocumentLibrary',
      version='1.6',
      description="DocumentLibrary integration for Silva.",
      # Get more strings from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=[
              "Development Status :: 5 - Production/Stable",
              "Framework :: Zope2",
              "License :: OSI Approved :: BSD License",
              "Programming Language :: Python",
              "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='zope2 silva documentlibrary harvesting oai oaipmh',
      author='Infrae',
      author_email='info@infrae.com',
      url='http://infrae.com/products/oaipack',
      license='BSD',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'Products.SilvaOAI',
          'hurry.filesize',
          'z3c.batching',
         ],
      )
