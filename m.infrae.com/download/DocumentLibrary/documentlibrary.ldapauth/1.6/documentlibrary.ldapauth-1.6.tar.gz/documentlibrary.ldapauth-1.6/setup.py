from setuptools import setup, find_packages

setup(
    name='documentlibrary.ldapauth',
    version='1.6',
    author='Infrae',
    author_email='faassen@infrae.com',
    url='http://www.infrae.com/products/documentlibrary',
    description="""\
A ldap-based authentication and user management system for the DL.
""",   
    packages=find_packages('src'),
    package_dir = {'': 'src'},
    namespace_packages=['documentlibrary'],
    include_package_data = True,
    zip_safe=False,
    license='BSD',
    keywords='dms cms OAI-PMH xml archive',
    install_requires=[
      'setuptools',
      'DocumentLibrary',
      'ldapadapter',
      'ldappas',
      'gocept.cache',
      'hurry.query >= 0.9.1'],
)
