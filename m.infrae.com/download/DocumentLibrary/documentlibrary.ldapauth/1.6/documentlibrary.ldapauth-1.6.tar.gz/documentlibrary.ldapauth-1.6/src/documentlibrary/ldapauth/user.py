from zope.interface import implements, implementer
from zope import component
from zope.app.component.hooks import getSite
from zope import event

from ldap.filter import filter_format

from documentlibrary.core.user import UserFolderBase, UserInfoBase
from documentlibrary.core.user import GroupFolderBase, GroupInfoBase
from documentlibrary.core.interfaces import SUBMITTER, FirstLoginEvent
from documentlibrary.ldapauth import interfaces
from documentlibrary.ldapauth.utils import get_ldap_conn
from documentlibrary.ldapauth.interfaces import ILDAP

def authenticated_principal_created(e):
    users = getSite()['users']
    principal = e.principal
    id = principal.id[len('documentlibrary'):]
    userinfo = users.get(id)
    if userinfo is None:
        users[id] = userinfo = LDAPUserInfo(id)
        event.notify(FirstLoginEvent(userinfo))
    for group in userinfo.groups:
        principal.groups.append('documentlibrary' + group)

class LDAPUserFolder(UserFolderBase):
    implements(interfaces.ILDAPUserFolder)

class LDAPUserInfo(UserInfoBase):
    implements(interfaces.ILDAPUserInfo)

    def __init__(self, login):
        super(LDAPUserInfo, self).__init__(login, SUBMITTER, None)
        self.description = ''
        self.sync()

    def sync(self):
        conn = get_ldap_conn()
        config = component.getUtility(interfaces.ILDAP)
        filter = filter_format('(%s=%s)', (config.idAttribute, self.login,))
        res = conn.search(config.searchBase, config.searchScope, filter=filter)
        if len(res) == 0:
            return              # User has been deleted from LDAP
        assert len(res) == 1
        dn, entry = res[0]

        try:
            self.title = self._get_ldap_attribute(entry, config.titleAttribute)[0]
        except LookupError:
            self.title = self.login

        try:
            self.email = self._get_ldap_attribute(entry, config.emailAttribute)[0]
        except LookupError:
            self.email = ''

        groupsFilter = component.queryUtility(interfaces.IUserGroupsFilter)
        if groupsFilter is not None:
            if entry.has_key(config.groupsAttribute):
                self.groups = groupsFilter(entry[config.groupsAttribute])
            else:
                self.groups = []
        else:
            # XXX Now what?
            pass

    def _get_ldap_attribute(self, entry, name):
        try:
            return entry[name]
        except KeyError:
            raise LookupError(
                'LDAP attribute %r not found.  Available attributes: %s' %
                (name, sorted(entry.keys())))

class LDAPGroupFolder(GroupFolderBase):
    implements(interfaces.ILDAPGroupFolder)

    def sync(self):
        conn = get_ldap_conn()
        config = component.getUtility(interfaces.ILDAP)
        res = conn.search(config.groupsSearchBase, config.groupsSearchScope)

        # Delete groups no longer in LDAP and add new ones
        group_ids = set()
        for dn, group_info in res:
            if group_info.get('cn') is None:
                continue
            group_ids.add(group_info['cn'][0])

        for id in  set(self.keys()) - group_ids:
            del self[id]

        for id in group_ids - set(self.keys()):
            self[id] = LDAPGroupInfo(id, id)


class LDAPGroupInfo(GroupInfoBase):
    implements(interfaces.ILDAPGroupInfo)

    def _get_users(self):
        conn = get_ldap_conn()
        config = component.getUtility(interfaces.ILDAP)
        filter = filter_format('(%s=%s)',
                               (config.groupIdAttribute, self.login))
        res = conn.search(config.groupsSearchBase, config.groupsSearchScope,
                          filter=filter)

        assert len(res) == 1
        dn, entry = res[0]
        membersFilter = component.queryUtility(interfaces.IGroupMembersFilter)
        if membersFilter:
            if entry.has_key(config.membersAttribute):
                return membersFilter(entry[config.membersAttribute])
            else:
                return []
        else:
            # XXX Now what?
            pass
    
    users = property(_get_users)
