from StringIO import StringIO

from zope import component
from zope.app import zapi
from zope.formlib import form
from zope.interface import implements
from zope.publisher.browser import BrowserView
from zope.app.publisher.browser.menu import getMenu
from zope.app.component.hooks import getSite

from ldapadapter.interfaces import ILDAPAdapter
from ldappas.interfaces import ILDAPAuthentication

from documentlibrary.core.browser.configuration import ConfigureUtilityForm

from documentlibrary.core.browser.user import (
    UserListPage, UserEditFormBase, UserDisplayFormBase,
    GroupListPage, BrowseGroupListPage, BrowseGroupDisplayForm, GroupEditForm,
    GroupDisplayForm)
from documentlibrary.ldapauth import interfaces
from documentlibrary.ldapauth import install
from documentlibrary.ldapauth.interfaces import ILDAP
from documentlibrary.ldapauth.widget import UsersDisplayWidget


class LDAPSyncPage(BrowserView):

    def ldap_sync(self):
        site = getSite()
        site['groups'].sync()
        for uid, user in site['users'].items():
            user.sync()

    def __call__(self):
        self.ldap_sync()
        return "Sync done."


class ConfigureLDAPForm(ConfigureUtilityForm, LDAPSyncPage):

    form_fields = form.Fields(ILDAP)

    label = u'LDAP Configuration'

    def _getUtility(self):
        return component.getUtility(ILDAP)

    # XXX shouldn't have to copy this from form.PageEditForm,
    # actions don't seem to deal with subclassing properly yet
    @form.action('save changes')
    def handleEditAction(self, action, data):
        self.editAction(data)
        return self.redirect(zapi.absoluteURL(
            self.context, self.request) + '/@@ldap_configure')

    @form.action('update all existing user and group from LDAP')
    def resync(self, action, data):
        self.ldap_sync()
        self.addFeedback(u'Updated data from LDAP')

    
class InstallLDAP(BrowserView):
    def __call__(self):
        out = StringIO()
        print >> out, ("Install %s" %
                       install.addLDAPUtility())
        print >> out, ("Installed %r and %r" %
                       (install.addLDAPAdapter(), install.addLDAPAuth()))
        print >> out, ("Replaced user folder with %r" %
                       install.replaceUserFolder())
        print >> out, ("Replaced group folder with %r" %
                       install.replaceGroupFolder())
        return out.getvalue()

class UserListPage(UserListPage):

    def getMenu(self):
        return getMenu('ldap_user_menu', self.context, self.request)

    # XXX shouldn't have to copy this from user.ItemListPage,
    # actions don't seem to deal with subclassing properly yet
    @form.action('delete')
    def handleDelete(self, action, data):
        items = self._selectedItems()
        parent = self.__parent__
        names = []
        for item in items:
            names.append(item.__name__)
            del parent[item.__name__]
        if not items:
            self.addError('No items deleted as none selected')
        else:
            self.addFeedback('Items deleted: %s' % ', '.join(names))

    @form.action('update all users from LDAP')
    def resync(self, action, data):
        for uid, user in self.context.items():
            user.sync()
        self.addFeedback(u'Updated data from LDAP')


class UserEditForm(UserEditFormBase):

    form_fields = form.Fields(interfaces.ILDAPUserInfo).omit('__parent__')
    form_fields['login'].for_display = True
    form_fields['title'].for_display = True
    form_fields['email'].for_display = True
    form_fields['groups'].for_display = True

    # XXX shouldn't have to copy this from user.UserEditForm,
    # actions don't seem to deal with subclassing properly yet
    @form.action('save changes')
    def handleEditAction(self, action, data):
        self.editAction(data)
        return self.redirect(zapi.absoluteURL(
            self.context, self.request) + '/@@edit_user')
    
    @form.action('update from LDAP')
    def resync(self, action, data):
        self.context.sync()
        self.addFeedback(u'Updated user data from LDAP')

class UserDisplayForm(UserDisplayFormBase):

    form_fields = form.Fields(interfaces.ILDAPUserInfo).omit('__parent__')

    # XXX shouldn't have to copy this from user.UserDisplayForm,
    # actions don't seem to deal with subclassing properly yet
    @form.action('edit user information')
    def handleEdit(self, action, data):
        return self.redirect(zapi.absoluteURL(
            self.context, self.request) + '/@@edit_user')


class GroupListPage(GroupListPage):
    def getMenu(self):
        return getMenu('ldap_group_menu', self.context, self.request)

    @form.action('update all groups from LDAP')
    def resync(self, action, data):
        self.context.sync()
        self.addFeedback(u'Updated data from LDAP')


class BrowseGroupListPage(BrowseGroupListPage):
    pass

class BrowseGroupDisplayForm(BrowseGroupDisplayForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)
    form_fields = form_fields.omit('title')
    form_fields['users'].custom_widget = UsersDisplayWidget

class GroupEditForm(GroupEditForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)
    form_fields = form_fields.omit('title')
    form_fields['login'].for_display = True
    form_fields['users'].custom_widget = UsersDisplayWidget
    form_fields['users'].for_display = True

class GroupDisplayForm(GroupDisplayForm):
    form_fields = form.Fields(interfaces.ILDAPGroupInfo)    
    form_fields = form_fields.omit('title')
    form_fields['users'].custom_widget = UsersDisplayWidget    


