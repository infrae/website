import re

from zope import schema
from zope.interface import Interface
from zope.i18nmessageid import ZopeMessageFactory as _

from documentlibrary.core.interfaces import IUserFolder, IUserInfo
from documentlibrary.core.interfaces import IGroupFolder, IGroupInfo

class ILDAPUserFolder(IUserFolder):
    pass

class ILDAPUserInfo(IUserInfo):
    pass

class ILDAPGroupFolder(IGroupFolder):
    pass

class ILDAPGroupInfo(IGroupInfo):
    pass

class ILDAP(Interface):
    host = schema.TextLine(
        title=_("Host"),
        default=u'localhost',
        required=True,
        )
    port = schema.Int(
        title=_("Port"),
        default=389,
        required=True,
        )
    useSSL = schema.Bool(
        title=_("Use SSL"),
        default=False,
        )
    bindDN = schema.TextLine(
        title=_("Bind DN"),
        default=u'',
        required=False,
        )
    bindPassword = schema.Password(
        title=_("Bind password"),
        description=_(u"Password used to connect. The field is not filled with current value for security reason, you have to type it for each modification made."),
        default=u'',
        required=False,
        )

    searchBase = schema.TextLine(
        title=_("Search base"),
        description=_(u"The LDAP search base where principals are found."),
        default=u'dc=example,dc=org',
        required=True,
        )
    searchScope = schema.TextLine(
        title=_("Search scope"),
        description=_(u"The LDAP search scope used to find principals."),
        default=u'sub',
        required=True,
        )
    groupsSearchBase = schema.TextLine(
        title=_("Group search base"),
        description=_(u"The LDAP search base where groups are found."),
        required=False,
        )
    groupsSearchScope = schema.TextLine(
        title=_("Group search scope"),
        description=_(u"THe LDAP search scope used to find groups."),
        required=False,
        )
    loginAttribute = schema.TextLine(
        title=_("Login attribute"),
        description=_(u"The LDAP attribute used to find principals."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'uid',
        required=True,
        )
    idAttribute = schema.TextLine(
        title=_("Id attribute"),
        description=_(
            u"The LDAP attribute used to determine a principal's id."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'uid',
        required=True,
        )
    titleAttribute = schema.TextLine(
        title=_("Title attribute"),
        description=_(
            u"The LDAP attribute used to determine a principal's title."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'cn',
        required=True,
        )
    groupIdAttribute = schema.TextLine(
        title=_("Group Id attribute"),
        description=_(
        u"The LDAP attribute (on a group entry) used to determine the "
        "group's id."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'cn',
        required=False,
        )

    groupsAttribute = schema.TextLine(
        title=(u"Groups listing attribute"),
        description=(u"Groups listing attribute on the user"),
        required=True,
        )
    membersAttribute = schema.TextLine(
        title=(u"Members listing attribute"),
        description=(u"Members listing attribute on the group"),
        required=True,
        )
    emailAttribute = schema.TextLine(
        title=(u"E-Mail attribute"),
        description=_(
            u"The LDAP attribute used to determine a principal's e-mail."),
        constraint=re.compile("[a-zA-Z][-a-zA-Z0-9]*$").match,
        default=u'mail',
        required=True,
        )

class IUserGroupsFilter(Interface):
    def __call__(ldap_groups):
        """Given a list of groups retrieved from LDAP, this will
        return a list of actual groupnames.
        """

class IGroupMembersFilter(Interface):
    def __call__(ldap_users):
        """Given a list of users retrieved from LDAP, this will
        return a list of actual usernames.
        """
